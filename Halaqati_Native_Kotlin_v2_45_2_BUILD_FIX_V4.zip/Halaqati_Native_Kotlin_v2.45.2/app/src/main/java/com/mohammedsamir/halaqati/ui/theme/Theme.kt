package com.mohammedsamir.halaqati.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * Native translation of the v2.20 UI/UX Pro Max design layer.
 * Mobile-first, RTL, high contrast, 48dp touch targets and restrained elevation.
 */
object HalaqatiUiTokens {
    val TouchTarget = 48.dp
    val RadiusSmall = 12.dp
    val RadiusMedium = 16.dp
    val RadiusLarge = 22.dp
    val SpaceXs = 4.dp
    val SpaceSm = 8.dp
    val SpaceMd = 12.dp
    val SpaceLg = 16.dp
    val SpaceXl = 24.dp
}

private val HalaqatiLight = lightColorScheme(
    primary = Color(0xFF147A78),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFD2F0ED),
    onPrimaryContainer = Color(0xFF073F3D),
    secondary = Color(0xFF0B4F4B),
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFD8E8E5),
    onSecondaryContainer = Color(0xFF073A37),
    tertiary = Color(0xFFB9954A),
    onTertiary = Color(0xFF1B1B1B),
    tertiaryContainer = Color(0xFFF4E7C6),
    onTertiaryContainer = Color(0xFF493715),
    background = Color(0xFFF7F2E6),
    onBackground = Color(0xFF1B1B1B),
    surface = Color(0xFFFFFBF5),
    onSurface = Color(0xFF1B1B1B),
    surfaceVariant = Color(0xFFE7EFEC),
    onSurfaceVariant = Color(0xFF374744),
    outline = Color(0xFF657572),
    error = Color(0xFFB3261E),
)

private val HalaqatiDark = darkColorScheme(
    primary = Color(0xFF7ED6D1),
    onPrimary = Color(0xFF003735),
    primaryContainer = Color(0xFF0D5754),
    onPrimaryContainer = Color(0xFFB7F0EC),
    secondary = Color(0xFF8BCFC8),
    onSecondary = Color(0xFF053A37),
    secondaryContainer = Color(0xFF1E4744),
    onSecondaryContainer = Color(0xFFD8E8E5),
    tertiary = Color(0xFFD8BA73),
    onTertiary = Color(0xFF3D2F10),
    tertiaryContainer = Color(0xFF5A4720),
    onTertiaryContainer = Color(0xFFF4E7C6),
    background = Color(0xFF101715),
    onBackground = Color(0xFFE7ECE9),
    surface = Color(0xFF151E1B),
    onSurface = Color(0xFFE7ECE9),
    surfaceVariant = Color(0xFF25332F),
    onSurfaceVariant = Color(0xFFC7D2CE),
    outline = Color(0xFF8A9B96),
    error = Color(0xFFFFB4AB),
)

private val HalaqatiShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(HalaqatiUiTokens.RadiusSmall),
    medium = RoundedCornerShape(HalaqatiUiTokens.RadiusMedium),
    large = RoundedCornerShape(HalaqatiUiTokens.RadiusLarge),
    extraLarge = RoundedCornerShape(28.dp),
)

private val HalaqatiTypography = Typography(
    bodySmall = TextStyle(fontSize = 12.sp, lineHeight = 18.sp),
    bodyMedium = TextStyle(fontSize = 14.sp, lineHeight = 21.sp),
    bodyLarge = TextStyle(fontSize = 16.sp, lineHeight = 24.sp),
    labelSmall = TextStyle(fontSize = 12.sp, lineHeight = 16.sp, fontWeight = FontWeight.Medium),
    labelMedium = TextStyle(fontSize = 12.sp, lineHeight = 18.sp, fontWeight = FontWeight.SemiBold),
    labelLarge = TextStyle(fontSize = 14.sp, lineHeight = 20.sp, fontWeight = FontWeight.SemiBold),
    titleSmall = TextStyle(fontSize = 14.sp, lineHeight = 21.sp, fontWeight = FontWeight.SemiBold),
    titleMedium = TextStyle(fontSize = 16.sp, lineHeight = 24.sp, fontWeight = FontWeight.Bold),
    titleLarge = TextStyle(fontSize = 20.sp, lineHeight = 28.sp, fontWeight = FontWeight.Bold),
    headlineSmall = TextStyle(fontSize = 24.sp, lineHeight = 32.sp, fontWeight = FontWeight.Bold),
    headlineMedium = TextStyle(fontSize = 28.sp, lineHeight = 36.sp, fontWeight = FontWeight.Bold),
)

@Composable
fun HalaqatiTheme(content: @Composable () -> Unit) {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        MaterialTheme(
            colorScheme = if (isSystemInDarkTheme()) HalaqatiDark else HalaqatiLight,
            typography = HalaqatiTypography,
            shapes = HalaqatiShapes,
            content = content,
        )
    }
}
