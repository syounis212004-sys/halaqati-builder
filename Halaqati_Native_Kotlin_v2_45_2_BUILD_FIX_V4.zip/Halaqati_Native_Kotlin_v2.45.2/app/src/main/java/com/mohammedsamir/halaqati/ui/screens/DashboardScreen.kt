package com.mohammedsamir.halaqati.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.mohammedsamir.halaqati.data.AppGraph
import com.mohammedsamir.halaqati.model.Profile
import com.mohammedsamir.halaqati.model.SyncState
import com.mohammedsamir.halaqati.ui.components.EmptyState
import com.mohammedsamir.halaqati.ui.components.LoadingSkeleton
import com.mohammedsamir.halaqati.ui.components.MetricCard
import com.mohammedsamir.halaqati.ui.components.StateNotice
import com.mohammedsamir.halaqati.ui.theme.HalaqatiUiTokens
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.time.LocalDate

@Composable
fun DashboardScreen(
    p: Profile,
    sync: SyncState,
    navigate: (String) -> Unit,
    onSync: () -> Unit,
) {
    var stats by remember { mutableStateOf(listOf("0", "0", "0", sync.pending.toString())) }
    var focus by remember { mutableStateOf<List<Pair<String, String>>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(sync.lastSync, sync.online, sync.pending) {
        loading = true
        try {
            val result = withContext(Dispatchers.IO) {
                val repo = AppGraph.repo
                val sts = repo.students()
                val sessions = repo.sessions()
                val rec = repo.table(
                    "recitation_entries",
                    "select=student_id,pages_count,mistakes,prompts,safety_percentage,created_at&order=created_at.desc&limit=500",
                )
                val today = LocalDate.now().toString()
                val todaySessions = sessions.count { it.date == today }
                val pages = (0 until rec.length()).sumOf {
                    rec.optJSONObject(it)?.optDouble("pages_count", 0.0) ?: 0.0
                }
                val recentIds = mutableSetOf<String>()
                for (i in 0 until rec.length()) {
                    val row = rec.optJSONObject(i) ?: continue
                    if (row.optString("created_at").startsWith(today)) recentIds += row.optString("student_id")
                }
                val attention = sts
                    .filter { it.status == "active" && it.id !in recentIds }
                    .take(12)
                    .map { it.fullName to "لم يسمّع اليوم" }
                listOf(
                    sts.count { it.status == "active" }.toString(),
                    todaySessions.toString(),
                    "%.1f".format(pages),
                    sync.pending.toString(),
                ) to attention
            }
            stats = result.first
            focus = result.second
            error = null
        } catch (e: Exception) {
            error = e.message ?: "تعذر تحديث لوحة اليوم"
            stats = stats.toMutableList().also { it[3] = sync.pending.toString() }
        } finally {
            loading = false
        }
    }

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(HalaqatiUiTokens.SpaceLg),
        verticalArrangement = Arrangement.spacedBy(HalaqatiUiTokens.SpaceMd),
    ) {
        item {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("مرحبًا، ${p.fullName}", style = MaterialTheme.typography.headlineSmall)
                    Text(
                        "لوحة المتابعة اليومية",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                Surface(
                    color = if (sync.online) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.tertiaryContainer,
                    contentColor = if (sync.online) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onTertiaryContainer,
                    shape = MaterialTheme.shapes.extraLarge,
                ) {
                    Row(
                        Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                    ) {
                        Icon(
                            if (sync.online) Icons.Default.Sync else Icons.Default.CloudOff,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp),
                        )
                        Text(if (sync.online) "متصل" else "بدون اتصال", style = MaterialTheme.typography.labelLarge)
                    }
                }
            }
        }

        if (!sync.online) {
            item {
                StateNotice(
                    "أنت تعمل بدون اتصال. أي حضور أو تسميع جديد سيُحفظ محليًا ثم يُرفع تلقائيًا عند عودة الإنترنت.",
                    kind = "warning",
                )
            }
        } else if (sync.blocked > 0) {
            item { StateNotice("هناك ${sync.blocked} عمليات مزامنة تحتاج مراجعة من مركز المزامنة.", "error") }
        }

        item {
            Button(
                onClick = { navigate("sessions") },
                modifier = Modifier.fillMaxWidth().heightIn(min = 52.dp),
            ) {
                Icon(Icons.Default.PlayArrow, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("بدء / فتح جلسة اليوم")
            }
        }

        if (loading && stats.take(3).all { it == "0" }) {
            item { LoadingSkeleton(rows = 2) }
        } else {
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Box(Modifier.weight(1f)) { MetricCard("الطلاب", stats[0], onClick = { navigate("students") }) }
                    Box(Modifier.weight(1f)) { MetricCard("جلسات اليوم", stats[1], onClick = { navigate("sessions") }) }
                }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Box(Modifier.weight(1f)) { MetricCard("صفحات مسجلة", stats[2], onClick = { navigate("reports") }) }
                    Box(Modifier.weight(1f)) { MetricCard("معلّق للمزامنة", stats[3], onClick = onSync) }
                }
            }
        }

        error?.let { item { StateNotice(it, kind = "error") } }

        item { Text("يحتاج متابعة", style = MaterialTheme.typography.titleLarge) }
        if (!loading && focus.isEmpty()) item { EmptyState("لا توجد تنبيهات متابعة الآن") }
        items(focus) { (name, reason) ->
            ElevatedCard(onClick = { navigate("students") }, modifier = Modifier.fillMaxWidth()) {
                ListItem(
                    headlineContent = { Text(name, style = MaterialTheme.typography.titleMedium) },
                    supportingContent = { Text(reason, style = MaterialTheme.typography.bodyMedium) },
                    trailingContent = { Icon(Icons.Default.ChevronLeft, contentDescription = "فتح") },
                )
            }
        }
        item {
            OutlinedButton(
                onClick = { navigate("rankings") },
                modifier = Modifier.fillMaxWidth().heightIn(min = HalaqatiUiTokens.TouchTarget),
            ) { Text("عرض جميع مؤشرات الأداء والترتيب") }
        }
        item { Spacer(Modifier.height(8.dp)) }
    }
}
