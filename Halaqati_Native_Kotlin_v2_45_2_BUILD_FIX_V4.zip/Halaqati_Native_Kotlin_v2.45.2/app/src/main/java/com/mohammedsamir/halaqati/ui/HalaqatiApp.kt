@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.mohammedsamir.halaqati.ui

import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.mohammedsamir.halaqati.data.DeepLinkRules
import com.mohammedsamir.halaqati.model.Profile
import com.mohammedsamir.halaqati.model.SyncState
import com.mohammedsamir.halaqati.ui.components.SyncBanner
import com.mohammedsamir.halaqati.ui.components.EmptyState
import com.mohammedsamir.halaqati.ui.screens.*

@Composable
fun HalaqatiApp(
    initialDeepLink: String? = null,
    vm: AppViewModel = viewModel(),
) {
    val auth by vm.auth.collectAsState()
    val sync by vm.sync.collectAsState()

    LaunchedEffect(initialDeepLink) { vm.handleDeepLink(initialDeepLink) }

    when (val state = auth) {
        AuthState.Loading -> androidx.compose.foundation.layout.Box(
            Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center,
        ) { CircularProgressIndicator() }

        AuthState.SignedOut -> AuthScreen(
            onLogin = vm::login,
            onRegister = vm::register,
            googleOAuthUrl = vm::googleOAuthUrl,
            onResetPassword = vm::requestPasswordReset,
        )
        is AuthState.Error -> AuthScreen(
            error = state.message,
            onLogin = vm::login,
            onRegister = vm::register,
            googleOAuthUrl = vm::googleOAuthUrl,
            onResetPassword = vm::requestPasswordReset,
        )

        is AuthState.Pending -> PendingApprovalScreen(state.profile, vm::bootstrap, vm::logout)
        is AuthState.Recovery -> PasswordRecoveryScreen(
            email = state.email,
            onSubmit = vm::completePasswordRecovery,
            onCancel = vm::cancelPasswordRecovery,
        )
        is AuthState.Ready -> MainShell(state.profile, sync, vm::sync, vm::logout, initialDeepLink)
    }
}

@Composable
private fun MainShell(
    profile: Profile,
    sync: SyncState,
    onSync: () -> Unit,
    onLogout: () -> Unit,
    initialDeepLink: String?,
) {
    val nav = rememberNavController()
    val items = RoleNavigation.items(profile.role)
    var more by remember { mutableStateOf(false) }
    var deepLinkedStudentId by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(initialDeepLink, profile.role) {
        val destination = DeepLinkRules.navigation(initialDeepLink)
        deepLinkedStudentId = destination?.studentId
        val route = destination?.route.orEmpty()
        if (route.isNotBlank() && items.any { it.route == route }) {
            nav.navigate(route) { launchSingleTop = true }
        }
    }

    Scaffold(
        bottomBar = {
            NavigationBar {
                val current = nav.currentBackStackEntryAsState().value?.destination?.route ?: "home"
                RoleNavigation.bottom(profile.role).forEach { route ->
                    val target = route.takeUnless { it == "more" }
                    NavigationBarItem(
                        selected = if (target != null) current == target else more,
                        onClick = {
                            if (target == null) {
                                more = true
                            } else {
                                nav.navigate(target) {
                                    launchSingleTop = true
                                    restoreState = true
                                    popUpTo("home") { saveState = true }
                                }
                            }
                        },
                        icon = { Icon(iconFor(route), contentDescription = null, modifier = Modifier.size(24.dp)) },
                        label = { Text(labelFor(route), style = MaterialTheme.typography.labelMedium) },
                    )
                }
            }
        },
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize()) {
            SyncBanner(sync.online, sync.pending, sync.blocked, sync.error, onSync, onDetails = { nav.navigate("sync_center") { launchSingleTop = true } })
            NavHost(
                navController = nav,
                startDestination = "home",
                modifier = Modifier.weight(1f),
                enterTransition = { fadeIn() + slideInHorizontally { it / 10 } },
                exitTransition = { fadeOut() },
            ) {
                items.forEach { item ->
                    composable(item.route) {
                        FeatureRouter(
                            route = item.route,
                            profile = profile,
                            sync = sync,
                            onSync = onSync,
                            navigate = { nav.navigate(it) { launchSingleTop = true } },
                            onLogout = onLogout,
                            deepLinkedStudentId = deepLinkedStudentId,
                        )
                    }
                }
            }
        }

        if (more) {
            ModalBottomSheet(onDismissRequest = { more = false }) {
                items
                    .filter { it.route !in RoleNavigation.bottom(profile.role) }
                    .forEach { item ->
                        ListItem(
                            headlineContent = { Text(item.title) },
                            leadingContent = { Icon(iconFor(item.iconKey), contentDescription = null) },
                            trailingContent = { Icon(Icons.Default.ChevronLeft, contentDescription = null) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    more = false
                                    nav.navigate(item.route) { launchSingleTop = true }
                                },
                        )
                        HorizontalDivider()
                    }
                Spacer(Modifier.height(24.dp))
            }
        }
    }
}

@Composable
private fun FeatureRouter(
    route: String,
    profile: Profile,
    sync: SyncState,
    onSync: () -> Unit,
    navigate: (String) -> Unit,
    onLogout: () -> Unit,
    deepLinkedStudentId: String?,
) {
    when (route) {
        "home" -> DashboardScreen(profile, sync, navigate, onSync)
        "students" -> StudentsScreen(sync.pending, onSync)
        "sessions" -> SessionsScreen(sync.pending, onSync)
        "plans" -> PlansScreen(profile, sync.pending, onSync)
        "reports" -> ReportsScreen(profile, sync.pending, onSync)
        "certificates" -> CertificatesScreen(profile, sync.pending, onSync)
        "notifications" -> NotificationsNativeScreen(profile, sync.pending, onSync)
        "halaqas" -> HalaqasManagementScreen(profile, sync.pending, onSync)
        "community" -> CommunityNativeScreen(profile, sync.pending, onSync)
        "rankings" -> RankingsScreen(profile, sync.pending, onSync)
        "importexport" -> ImportExportScreen(profile, sync.pending, onSync)
        "sync_center" -> SyncCenterScreen(sync, onSync)
        "supervision" -> SupervisionNativeScreen(profile, sync.pending, onSync, navigate)
        "users" -> UsersScreen(sync.pending, onSync)
        "quran" -> QuranCalculatorScreen()
        "profile" -> GuardianProfileNativeScreen(profile, sync.online, sync.pending, onSync, initialStudentId = deepLinkedStudentId)
        "settings" -> SettingsScreen(profile, onLogout)
        else -> UnknownRouteScreen(route) { navigate("home") }
    }
}

@Composable
private fun UnknownRouteScreen(route: String, onHome: () -> Unit) {
    Column(Modifier.fillMaxSize()) {
        TopAppBar(title = { Text("صفحة غير متاحة") })
        EmptyState(
            text = "تعذر فتح المسار: $route",
            actionLabel = "العودة للرئيسية",
            onAction = onHome,
        )
    }
}


fun iconFor(key: String) = when (key) {
    "home" -> Icons.Default.Home
    "notifications" -> Icons.Default.Notifications
    "group" -> Icons.Default.Groups
    "forum" -> Icons.Default.Forum
    "event" -> Icons.Default.Event
    "person" -> Icons.Default.Person
    "timeline" -> Icons.Default.Timeline
    "award" -> Icons.Default.EmojiEvents
    "report" -> Icons.Default.Assessment
    "book" -> Icons.Default.MenuBook
    "leaderboard" -> Icons.Default.Leaderboard
    "sync" -> Icons.Default.Sync
    "supervisor" -> Icons.Default.SupervisorAccount
    "users" -> Icons.Default.ManageAccounts
    "profile" -> Icons.Default.AccountCircle
    "settings" -> Icons.Default.Settings
    "sessions" -> Icons.Default.Event
    "students" -> Icons.Default.Groups
    "plans" -> Icons.Default.Timeline
    "reports" -> Icons.Default.Assessment
    "more" -> Icons.Default.MoreHoriz
    else -> Icons.Default.Apps
}

fun labelFor(route: String) = when (route) {
    "home" -> "الرئيسية"
    "sessions" -> "الجلسات"
    "students" -> "الطلاب"
    "plans" -> "الخطط"
    "reports" -> "التقارير"
    "profile" -> "الملف"
    else -> "المزيد"
}
