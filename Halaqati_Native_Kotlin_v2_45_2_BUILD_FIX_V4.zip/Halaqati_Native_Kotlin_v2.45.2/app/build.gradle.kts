import java.util.Properties
import groovy.json.JsonOutput

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
    id("com.google.gms.google-services")
}

val props = Properties().apply {
    val f = rootProject.file("local.properties")
    if (f.exists()) f.inputStream().use { load(it) }
}
fun conf(name: String, fallback: String = ""): String = sequenceOf(
    providers.gradleProperty(name).orNull,
    System.getenv(name),
    props.getProperty(name)
).filterNotNull().firstOrNull { it.isNotBlank() } ?: fallback

android {
    namespace = "com.mohammedsamir.halaqati"
    compileSdk = 36
    defaultConfig {
        applicationId = "com.mohammedsamir.halaqati"
        minSdk = 23
        targetSdk = 36
        versionCode = 24502
        versionName = "2.45.2"
        vectorDrawables { useSupportLibrary = true }
        buildConfigField("String", "SUPABASE_URL", JsonOutput.toJson(conf("SUPABASE_URL", "https://xlxzwucqdtggkfwwqibk.supabase.co")))
        buildConfigField("String", "SUPABASE_PUBLISHABLE_KEY", JsonOutput.toJson(conf("SUPABASE_PUBLISHABLE_KEY", "sb_publishable_VZGYTedRpXfJdswijXoxig_F0Hva8ks")))
    }
    buildFeatures { compose = true; buildConfig = true }
    packaging { resources.excludes += setOf("META-INF/LICENSE*", "META-INF/NOTICE*") }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
        isCoreLibraryDesugaringEnabled = true
    }
    signingConfigs {
        create("release") {
            val storeFilePath = conf("HALAQATI_KEYSTORE_PATH")
            if (storeFilePath.isNotBlank()) storeFile = file(storeFilePath)
            storePassword = conf("HALAQATI_STORE_PASSWORD")
            keyAlias = conf("HALAQATI_KEY_ALIAS")
            keyPassword = conf("HALAQATI_KEY_PASSWORD")
        }
    }
    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            val ks = conf("HALAQATI_KEYSTORE_PATH")
            if (ks.isNotBlank()) signingConfig = signingConfigs.getByName("release")
        }
        debug {
            // Keep the production applicationId so the existing Firebase client in
            // google-services.json matches during CI unit-test resource processing.
            // versionNameSuffix is safe and does not change the Firebase package id.
            versionNameSuffix = "-debug"
        }
    }
}

kotlin {
    compilerOptions {
        jvmTarget.set(org.jetbrains.kotlin.gradle.dsl.JvmTarget.JVM_17)
    }
}

dependencies {
    val composeBom = platform("androidx.compose:compose-bom:2025.10.00")
    implementation(composeBom)
    androidTestImplementation(composeBom)
    coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.1.5")
    implementation("androidx.core:core-ktx:1.17.0")
    implementation("androidx.activity:activity-compose:1.11.0")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.9.4")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.9.4")
    implementation("androidx.navigation:navigation-compose:2.9.5")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.compose.animation:animation")
    implementation("androidx.work:work-runtime-ktx:2.11.2")
    implementation("androidx.security:security-crypto:1.1.0")
    implementation("com.google.firebase:firebase-messaging:25.1.1")
    debugImplementation("androidx.compose.ui:ui-tooling")
    debugImplementation("androidx.compose.ui:ui-test-manifest")
    testImplementation("junit:junit:4.13.2")
}
