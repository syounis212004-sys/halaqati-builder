#!/usr/bin/env python3
"""Guard the source patterns repaired after the FIR safe-call OOM (not a compiler test)."""
from pathlib import Path
import re
root=Path(__file__).resolve().parents[1]
s=(root/'app/src/main/java/com/mohammedsamir/halaqati/ui/screens/CoreScreens.kt').read_text()
editor=s.split('private fun SmartPlanEditorDialog(',1)[1].split('\n@Composable',1)[0]
assert 'remember(current?.id)' not in editor, 'Repeated nullable key/inline initializer graph returned'
assert len(re.findall(r'by remember\(planKey\) \{ initialPlan',editor)) == 30
assert len(re.findall(r'private fun initialPlan\w+\(',s)) == 30
assert 'initialPlanHalaqaId(current, halaqas, halaqaId)' not in s, 'Self-reference before initialization'
assert 'current?.settings?.' not in editor, 'Resolve settings before the large constructor'
app=(root/'app/build.gradle.kts').read_text()
assert app.count('JsonOutput.toJson(conf(')==2, 'BuildConfig must use escaped Java string literals'
assert 'kotlinOptions' not in app
properties=(root/'gradle.properties').read_text()
keys=[line.split('=',1)[0] for line in properties.splitlines() if '=' in line and not line.startswith('#')]
assert len(keys)==len(set(keys)), 'Duplicate Gradle properties'
print('Compiler regression source checks passed (not an APK compile)')
