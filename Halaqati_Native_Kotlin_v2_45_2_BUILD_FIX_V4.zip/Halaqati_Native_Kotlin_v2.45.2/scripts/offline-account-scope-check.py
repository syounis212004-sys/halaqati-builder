#!/usr/bin/env python3
from pathlib import Path
import re
import sqlite3

root = Path(__file__).resolve().parents[1]
queue = (root / 'app/src/main/java/com/mohammedsamir/halaqati/data/OfflineQueue.kt').read_text(encoding='utf-8')
repo = (root / 'app/src/main/java/com/mohammedsamir/halaqati/data/HalaqatiRepository.kt').read_text(encoding='utf-8')
app_vm = (root / 'app/src/main/java/com/mohammedsamir/halaqati/ui/AppViewModel.kt').read_text(encoding='utf-8')
all_kotlin = '\n'.join(p.read_text(encoding='utf-8') for p in (root / 'app/src/main/java').rglob('*.kt'))

required_queue = [
    'SQLiteOpenHelper(ctx, "halaqati-offline.db", null, 4)',
    'owner_user_id TEXT NOT NULL',
    'q_owner_dedupe ON q(owner_user_id,dedupe)',
    'WHERE owner_user_id=? AND blocked=0',
    'WHERE owner_user_id=? ORDER BY blocked DESC,id ASC',
    'Legacy offline item quarantined: missing account scope',
]
for token in required_queue:
    assert token in queue, f'missing offline account-scope contract: {token}'

required_repo = [
    'private fun queueOwnerId()',
    'queue.add(queueOwnerId(), method, path, obj?.toString(), dedupe)',
    'fun pendingQueueSize()',
    'fun blockedQueueSize()',
    'fun queueSnapshot(limit: Int = 200)',
    'val owner = currentUserId() ?: return',
    'queue.all(owner)',
    'queue.done(item.id, owner)',
    'queue.fail(item.id, owner)',
    'queue.markBlocked(item.id, owner,',
]
for token in required_repo:
    assert token in repo, f'missing repository account-scope contract: {token}'

assert 'pending = repo.pendingQueueSize()' in app_vm
assert 'blocked = repo.blockedQueueSize()' in app_vm

# UI is not allowed to bypass repository account scoping and read/mutate the raw queue directly.
for p in (root / 'app/src/main/java/com/mohammedsamir/halaqati/ui').rglob('*.kt'):
    text = p.read_text(encoding='utf-8')
    assert 'repo.queue.' not in text, f'raw queue access bypasses account scope in {p.relative_to(root)}'

# Guard against accidental reintroduction of the old unscoped OfflineQueue signatures/calls.
for bad in [
    'queue.add(method, path',
    'queue.all()',
    'queue.snapshot()',
    'queue.size()',
    'queue.blockedSize()',
]:
    assert bad not in all_kotlin, f'unscoped offline queue call returned: {bad}'


# Exercise the v3 -> v4 SQL shape with SQLite itself: legacy rows are quarantined and
# the same logical dedupe key may safely exist once per account.
db = sqlite3.connect(":memory:")
db.executescript("""
CREATE TABLE q(
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 method TEXT NOT NULL, path TEXT NOT NULL, body TEXT, headers TEXT, created INTEGER NOT NULL,
 attempts INTEGER NOT NULL DEFAULT 0, dedupe TEXT, blocked INTEGER NOT NULL DEFAULT 0, last_error TEXT
);
CREATE UNIQUE INDEX q_dedupe ON q(dedupe) WHERE dedupe IS NOT NULL;
INSERT INTO q(method,path,body,created,dedupe) VALUES('POST','/rest/v1/sessions','{}',1,'same-key');
ALTER TABLE q ADD COLUMN owner_user_id TEXT;
DROP INDEX IF EXISTS q_dedupe;
UPDATE q SET blocked=1,last_error=COALESCE(last_error,'Legacy offline item quarantined: missing account scope')
 WHERE owner_user_id IS NULL OR owner_user_id='';
CREATE UNIQUE INDEX q_owner_dedupe ON q(owner_user_id,dedupe) WHERE dedupe IS NOT NULL;
CREATE INDEX q_owner_state_id ON q(owner_user_id,blocked,id);
""")
legacy = db.execute("select blocked,last_error from q where id=1").fetchone()
assert legacy and legacy[0] == 1 and 'missing account scope' in legacy[1]
db.execute("insert into q(owner_user_id,method,path,body,created,dedupe) values(?,?,?,?,?,?)", ('user-a','POST','/x','{}',2,'same-key'))
db.execute("insert into q(owner_user_id,method,path,body,created,dedupe) values(?,?,?,?,?,?)", ('user-b','POST','/x','{}',3,'same-key'))
assert db.execute("select count(*) from q where owner_user_id='user-a' and blocked=0").fetchone()[0] == 1
assert db.execute("select count(*) from q where owner_user_id='user-b' and blocked=0").fetchone()[0] == 1

print('Offline account-scope check passed (queue v4, per-user replay isolation + migration simulation)')
