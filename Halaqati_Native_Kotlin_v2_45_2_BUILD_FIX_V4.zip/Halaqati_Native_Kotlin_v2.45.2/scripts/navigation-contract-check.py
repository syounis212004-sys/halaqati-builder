#!/usr/bin/env python3
from pathlib import Path
import re, sys
root=Path(__file__).resolve().parents[1]
nav=(root/'app/src/main/java/com/mohammedsamir/halaqati/ui/Navigation.kt').read_text(encoding='utf-8')
app=(root/'app/src/main/java/com/mohammedsamir/halaqati/ui/HalaqatiApp.kt').read_text(encoding='utf-8')
all_kt='\n'.join(p.read_text(encoding='utf-8', errors='ignore') for p in (root/'app/src/main/java').rglob('*.kt'))
expected=[
    'home','notifications','halaqas','community','sessions','students','plans','certificates','reports',
    'quran','rankings','importexport','sync_center','supervision','users','profile','settings',
]
errors=[]
nav_routes=re.findall(r'NavItem\("([^"]+)"', nav)
if nav_routes != expected:
    errors.append(f'Navigation routes changed: {nav_routes}')
for route in expected:
    if f'"{route}" ->' not in app:
        errors.append(f'FeatureRouter missing explicit route: {route}')
if 'GenericDataScreen' in all_kt:
    errors.append('GenericDataScreen remains in Native runtime source')
if 'else -> UnknownRouteScreen(route)' not in app:
    errors.append('Unknown route must fail closed to UnknownRouteScreen')
for token in ('HalaqasManagementScreen(', 'CommunityNativeScreen(', 'GuardianProfileNativeScreen('):
    if token not in app:
        errors.append(f'Dedicated route screen missing: {token}')
if errors:
    print('Navigation contract FAILED')
    for e in errors: print(' -',e)
    sys.exit(1)
print(f'Navigation contract passed ({len(expected)} explicit Native routes, no generic data fallback)')
