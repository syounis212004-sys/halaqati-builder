@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.mohammedsamir.halaqati.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.mohammedsamir.halaqati.data.AppGraph
import com.mohammedsamir.halaqati.model.Profile
import com.mohammedsamir.halaqati.model.Student
import com.mohammedsamir.halaqati.ui.components.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate
import java.time.YearMonth

@Composable
fun GuardianCompetitionNativeScreen(profile: Profile, pending: Int, onRefresh: () -> Unit) {
    val scope = rememberCoroutineScope()
    var students by remember { mutableStateOf<List<Student>>(emptyList()) }
    var selectedId by remember { mutableStateOf("") }
    var track by remember { mutableStateOf("hifz") }
    var boardScope by remember { mutableStateOf("halaqa") }
    var period by remember { mutableStateOf("month") }
    var board by remember { mutableStateOf(JSONArray()) }
    var loading by remember { mutableStateOf(true) }
    var message by remember { mutableStateOf<String?>(null) }

    fun range(): Pair<String,String> {
        val now = LocalDate.now()
        return when (period) {
            "week" -> now.minusDays(6).toString() to now.toString()
            "year" -> now.withDayOfYear(1).toString() to now.toString()
            else -> YearMonth.now().atDay(1).toString() to now.toString()
        }
    }

    suspend fun reload(force: Boolean = false) {
        loading = true
        try {
            val loadedStudents = withContext(Dispatchers.IO) { AppGraph.repo.students(forceRefresh = force).filter { it.status == "active" } }
            students = loadedStudents
            if (selectedId.isBlank() || loadedStudents.none { it.id == selectedId }) selectedId = loadedStudents.firstOrNull()?.id.orEmpty()
            val id = selectedId.ifBlank { loadedStudents.firstOrNull()?.id.orEmpty() }
            if (id.isNotBlank()) {
                val (start,end) = range()
                board = withContext(Dispatchers.IO) { AppGraph.repo.guardianCompetition(id, track, boardScope, start, end) }
            } else board = JSONArray()
            message = null
        } catch (e: Exception) { message = e.message ?: "تعذر تحميل المنافسة" }
        finally { loading = false }
    }

    LaunchedEffect(selectedId, track, boardScope, period) { reload() }

    Column(Modifier.fillMaxSize()) {
        AppTopBar("إحصائيات ومنافسة", onRefresh = { scope.launch { reload(true) }; onRefresh() }, pending = pending)
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(12.dp, 12.dp, 12.dp, 96.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item {
                GoldenFeatureHero(
                    title = "منافسة أبنائي",
                    subtitle = "ترتيب فعلي داخل الحلقة أو الفئة أو المركز، مع اختيار المسار والفترة كما في 2.44.",
                    icon = Icons.Default.EmojiEvents,
                )
            }
            item {
                ElevatedCard(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("الطالب", fontWeight = FontWeight.Bold)
                        SingleChoiceDropdown(
                            value = selectedId,
                            options = students.map { it.id to it.fullName },
                            onValueChange = { selectedId = it },
                            emptyLabel = "لا يوجد طالب مرتبط",
                        )
                        Text("المسار", fontWeight = FontWeight.Bold)
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf("hifz" to "الحفظ", "review" to "المراجعة", "sard" to "السرد").forEach { (v,l) ->
                                ProFilterChip(track == v, { track = v }, l, Modifier.weight(1f))
                            }
                        }
                        Text("نطاق المنافسة", fontWeight = FontWeight.Bold)
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf("halaqa" to "الحلقة", "category" to "الفئة", "center" to "المركز").forEach { (v,l) ->
                                ProFilterChip(boardScope == v, { boardScope = v }, l, Modifier.weight(1f))
                            }
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf("week" to "7 أيام", "month" to "الشهر", "year" to "السنة").forEach { (v,l) ->
                                ProFilterChip(period == v, { period = v }, l, Modifier.weight(1f))
                            }
                        }
                    }
                }
            }
            message?.let { item { StateNotice(it, "error") } }
            if (loading) item { LoadingSkeleton(rows = 4) }
            if (!loading && board.length() == 0) item { EmptyState("لا توجد نتائج منافسة لهذه الفترة") }
            itemsIndexed((0 until board.length()).mapNotNull { board.optJSONObject(it) }) { index,row ->
                val rank = row.optInt("rank", index + 1).takeIf { it > 0 } ?: index + 1
                val name = row.optString("student_name", row.optString("full_name", "طالب"))
                val pages = row.optDouble("pages", row.optDouble("total_pages", 0.0))
                val safety = row.optDouble("safety", row.optDouble("avg_safety", -1.0))
                val mine = row.optBoolean("is_current", false) || row.optString("student_id") == selectedId
                ElevatedCard(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.elevatedCardColors(containerColor = if (mine) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface),
                ) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Surface(shape = MaterialTheme.shapes.extraLarge, color = MaterialTheme.colorScheme.primary) {
                            Text(rank.toString(), Modifier.padding(horizontal = 13.dp, vertical = 9.dp), color = MaterialTheme.colorScheme.onPrimary, fontWeight = FontWeight.Bold)
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(name, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                            Text("${plainGuardianNumber(pages)} صفحة${if (safety >= 0) " · جودة ${plainGuardianNumber(safety)}%" else ""}", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        if (mine) StatusPill("ابني", "success")
                    }
                }
            }
        }
    }
}

@Composable
fun GuardianAchievementsNativeScreen(profile: Profile, pending: Int, onRefresh: () -> Unit) {
    val scope = rememberCoroutineScope()
    var students by remember { mutableStateOf<List<Student>>(emptyList()) }
    var selectedId by remember { mutableStateOf("") }
    var dashboard by remember { mutableStateOf(JSONObject()) }
    var loading by remember { mutableStateOf(true) }
    var message by remember { mutableStateOf<String?>(null) }

    suspend fun reload(force: Boolean = false) {
        loading = true
        try {
            val list = withContext(Dispatchers.IO) { AppGraph.repo.students(forceRefresh = force).filter { it.status == "active" } }
            students = list
            if (selectedId.isBlank() || list.none { it.id == selectedId }) selectedId = list.firstOrNull()?.id.orEmpty()
            val id = selectedId.ifBlank { list.firstOrNull()?.id.orEmpty() }
            if (id.isNotBlank()) dashboard = withContext(Dispatchers.IO) {
                AppGraph.repo.guardianDashboard(id, LocalDate.now().withDayOfYear(1).toString(), LocalDate.now().toString())
            }
            message = null
        } catch (e: Exception) { message = e.message ?: "تعذر تحميل الإنجازات" }
        finally { loading = false }
    }
    LaunchedEffect(selectedId) { reload() }

    Column(Modifier.fillMaxSize()) {
        AppTopBar("الإنجازات", onRefresh = { scope.launch { reload(true) }; onRefresh() }, pending = pending)
        LazyColumn(contentPadding = PaddingValues(12.dp, 12.dp, 12.dp, 96.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item { GoldenFeatureHero("إنجازات الطالب", "الحفظ والمراجعة والسرد والحضور والجودة في صفحة مستقلة كما في 2.44.", Icons.Default.WorkspacePremium) }
            item {
                SingleChoiceDropdown(selectedId, students.map { it.id to it.fullName }, { selectedId = it }, "لا يوجد طالب مرتبط")
            }
            message?.let { item { StateNotice(it, "error") } }
            if (loading) item { LoadingSkeleton(rows = 4) }
            if (!loading && selectedId.isNotBlank()) {
                val ranks = dashboard.optJSONObject("ranks") ?: JSONObject()
                val attendance = dashboard.optJSONObject("attendance") ?: JSONObject()
                val hifz = ranks.optJSONObject("hifz") ?: JSONObject()
                val review = ranks.optJSONObject("review") ?: JSONObject()
                val sard = ranks.optJSONObject("sard") ?: JSONObject()
                val present = attendance.optInt("present", 0)
                val absent = attendance.optInt("absent", 0)
                val excused = attendance.optInt("excused", 0)
                val late = attendance.optInt("late", 0)
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        GuardianAchievementMetric("الحفظ", "${plainGuardianNumber(hifz.optDouble("pages",0.0))} ص", Icons.Default.MenuBook, Modifier.weight(1f))
                        GuardianAchievementMetric("المراجعة", "${plainGuardianNumber(review.optDouble("pages",0.0))} ص", Icons.Default.Replay, Modifier.weight(1f))
                        GuardianAchievementMetric("السرد", "${plainGuardianNumber(sard.optDouble("pages",0.0))} ص", Icons.Default.AutoStories, Modifier.weight(1f))
                    }
                }
                item {
                    ElevatedCard(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Text("الحضور", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                GuardianSmallMetric("حاضر", present, Modifier.weight(1f))
                                GuardianSmallMetric("غياب", absent, Modifier.weight(1f))
                                GuardianSmallMetric("بعذر", excused, Modifier.weight(1f))
                                GuardianSmallMetric("تأخر", late, Modifier.weight(1f))
                            }
                        }
                    }
                }
                item {
                    ElevatedCard(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("شارات الإنجاز", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                            val total = hifz.optDouble("pages",0.0) + review.optDouble("pages",0.0) + sard.optDouble("pages",0.0)
                            if (total <= 0.0) Text("تظهر الشارات تلقائيًا مع تسجيل الإنجاز.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                            else {
                                if (hifz.optDouble("pages",0.0) >= 20) StatusPill("20+ صفحة حفظ", "success")
                                if (review.optDouble("pages",0.0) >= 40) StatusPill("40+ صفحة مراجعة", "success")
                                if (sard.optDouble("pages",0.0) >= 20) StatusPill("إنجاز سرد", "success")
                                if (present >= 20 && absent == 0) StatusPill("مواظبة متميزة", "success")
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun GuardianAchievementMetric(label: String, value: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier = Modifier) {
    ElevatedCard(modifier) {
        Column(Modifier.padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Icon(icon, null, tint = MaterialTheme.colorScheme.primary)
            Text(value, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Text(label, style = MaterialTheme.typography.labelMedium)
        }
    }
}

@Composable
private fun GuardianSmallMetric(label: String, value: Int, modifier: Modifier = Modifier) {
    Surface(modifier, shape = MaterialTheme.shapes.medium, color = MaterialTheme.colorScheme.surfaceVariant) {
        Column(Modifier.padding(8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(value.toString(), fontWeight = FontWeight.Bold)
            Text(label, style = MaterialTheme.typography.labelSmall)
        }
    }
}

@Composable
private fun SingleChoiceDropdown(value: String, options: List<Pair<String,String>>, onValueChange: (String)->Unit, emptyLabel: String) {
    var expanded by remember { mutableStateOf(false) }
    ExposedDropdownMenuBox(expanded, { expanded = !expanded }) {
        OutlinedTextField(
            value = options.firstOrNull { it.first == value }?.second ?: emptyLabel,
            onValueChange = {}, readOnly = true,
            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) },
            modifier = Modifier.menuAnchor().fillMaxWidth(),
        )
        ExposedDropdownMenu(expanded, { expanded = false }) {
            options.forEach { (id,label) -> DropdownMenuItem({ Text(label) }, onClick = { onValueChange(id); expanded = false }) }
        }
    }
}

private fun plainGuardianNumber(value: Double): String {
    val rounded = kotlin.math.round(value * 100.0) / 100.0
    return if (kotlin.math.abs(rounded - rounded.toInt()) < 0.000001) rounded.toInt().toString() else rounded.toString().trimEnd('0').trimEnd('.')
}
