package com.mohammedsamir.halaqati.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.mohammedsamir.halaqati.model.Profile
import com.mohammedsamir.halaqati.model.SyncState
import com.mohammedsamir.halaqati.ui.components.AppTopBar
import com.mohammedsamir.halaqati.ui.components.EmptyState
import com.mohammedsamir.halaqati.ui.components.LoadingSkeleton
import com.mohammedsamir.halaqati.ui.components.MetricCard
import com.mohammedsamir.halaqati.ui.components.StateNotice
import com.mohammedsamir.halaqati.ui.dashboard.DashboardRules
import com.mohammedsamir.halaqati.ui.dashboard.DashboardViewModel
import com.mohammedsamir.halaqati.ui.theme.HalaqatiUiTokens

@Composable
fun DashboardScreen(
    p: Profile,
    sync: SyncState,
    navigate: (String) -> Unit,
    onSync: () -> Unit,
    vm: DashboardViewModel = viewModel(),
) {
    val state by vm.state.collectAsState()
    LaunchedEffect(p.id, sync) { vm.bind(p, sync) }

    val previewLimit = 4
    val focus = state.notHeard.take(previewLimit)
    val hidden = DashboardRules.hiddenCount(state.notHeard.size, previewLimit)

    Column(Modifier.fillMaxSize()) {
        AppTopBar(
            title = "الرئيسية",
            onRefresh = { vm.refresh(force = true) },
            pending = sync.pending,
        )
        LazyColumn(
        Modifier.weight(1f).fillMaxWidth(),
        contentPadding = PaddingValues(HalaqatiUiTokens.SpaceLg),
        verticalArrangement = Arrangement.spacedBy(HalaqatiUiTokens.SpaceMd),
    ) {
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary,
                ),
            ) {
                Column(
                    Modifier.fillMaxWidth().padding(horizontal = 22.dp, vertical = 24.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    Text("لوحة اليوم", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
                    Text(
                        "مسار الحفظ العام · كل ما يحتاج تدخّل في شاشة واحدة.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onPrimary.copy(alpha = .82f),
                    )
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Button(
                            onClick = { navigate("session_today") },
                            modifier = Modifier.weight(1f).heightIn(min = 52.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MaterialTheme.colorScheme.secondary,
                                contentColor = MaterialTheme.colorScheme.onSecondary,
                            ),
                        ) {
                            Icon(Icons.Default.PlayArrow, contentDescription = null)
                            Spacer(Modifier.width(6.dp))
                            Text("ابدأ جلسة اليوم", fontWeight = FontWeight.Bold)
                        }
                        FilledTonalButton(
                            onClick = { navigate("students") },
                            modifier = Modifier.weight(1f).heightIn(min = 52.dp),
                            colors = ButtonDefaults.filledTonalButtonColors(
                                containerColor = MaterialTheme.colorScheme.surface,
                                contentColor = MaterialTheme.colorScheme.onSurface,
                            ),
                        ) { Text("التحفيظ السريع", fontWeight = FontWeight.Bold) }
                    }
                }
            }
        }

        if (!sync.online) {
            item {
                StateNotice(
                    "البيانات المحفوظة متاحة الآن. أي تسجيل جديد يُحفظ محليًا ويُزامن عند عودة الاتصال.",
                    kind = "warning",
                )
            }
        } else if (sync.blocked > 0) {
            item { StateNotice("هناك ${sync.blocked} عمليات مزامنة تحتاج مراجعة.", "error") }
        }

        state.errors.values.firstOrNull()?.let { message ->
            item { StateNotice("بقيت البيانات السابقة ظاهرة. $message", kind = "warning") }
        }

        if (!state.loaded) {
            item { LoadingSkeleton(rows = 2) }
        } else {
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Box(Modifier.weight(1f)) {
                        MetricCard(
                            "الطلاب النشطون",
                            state.progress.activeStudents.toString(),
                            onClick = { navigate("students") },
                        )
                    }
                    Box(Modifier.weight(1f)) {
                        MetricCard(
                            "جلسات اليوم",
                            state.todaySessions.toString(),
                            onClick = { navigate("sessions") },
                        )
                    }
                }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Box(Modifier.weight(1f)) {
                        MetricCard(
                            "صفحات اليوم",
                            "%.1f".format(state.progress.recordedPages),
                            onClick = { navigate("reports") },
                        )
                    }
                    Box(Modifier.weight(1f)) {
                        MetricCard(
                            "سمّع اليوم",
                            state.progress.heardStudents.toString(),
                            onClick = { navigate("reports") },
                        )
                    }
                }
            }
        }

        item {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("لم يسمّع اليوم", style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
                if (state.notHeard.isNotEmpty()) {
                    Text(
                        state.notHeard.size.toString(),
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.primary,
                    )
                }
            }
        }
        if (state.loaded && state.notHeard.isEmpty()) {
            item { EmptyState("لا توجد تنبيهات متابعة الآن") }
        }
        items(focus, key = { it.studentId }) { item ->
            ElevatedCard(onClick = { navigate("students") }, modifier = Modifier.fillMaxWidth()) {
                ListItem(
                    headlineContent = { Text(item.studentName, style = MaterialTheme.typography.titleMedium) },
                    supportingContent = { Text(item.reason, style = MaterialTheme.typography.bodyMedium) },
                    trailingContent = { Icon(Icons.Default.ChevronLeft, contentDescription = "فتح الطالب") },
                )
            }
        }
        if (hidden > 0) {
            item {
                OutlinedButton(
                    onClick = { navigate("students") },
                    modifier = Modifier.fillMaxWidth().heightIn(min = HalaqatiUiTokens.TouchTarget),
                ) {
                    Text("عرض $hidden طالبًا آخر")
                }
            }
        }

        item {
            OutlinedButton(
                onClick = { navigate("rankings") },
                modifier = Modifier.fillMaxWidth().heightIn(min = HalaqatiUiTokens.TouchTarget),
            ) { Text("الإحصائيات والترتيب") }
        }
        if (sync.pending > 0) {
            item {
                OutlinedButton(
                    onClick = onSync,
                    modifier = Modifier.fillMaxWidth().heightIn(min = HalaqatiUiTokens.TouchTarget),
                ) { Text("مزامنة ${sync.pending} عملية معلقة") }
            }
        }
        item { Spacer(Modifier.height(8.dp)) }
    }
    }
}
