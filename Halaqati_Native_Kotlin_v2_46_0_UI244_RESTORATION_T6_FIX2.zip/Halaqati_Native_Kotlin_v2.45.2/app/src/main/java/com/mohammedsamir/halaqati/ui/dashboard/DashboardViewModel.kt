package com.mohammedsamir.halaqati.ui.dashboard

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.mohammedsamir.halaqati.data.AppGraph
import com.mohammedsamir.halaqati.data.HalaqatiRepository
import com.mohammedsamir.halaqati.model.Profile
import com.mohammedsamir.halaqati.model.SessionRow
import com.mohammedsamir.halaqati.model.Student
import com.mohammedsamir.halaqati.model.SyncState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import java.time.LocalDate

class DashboardViewModel(
    private val repository: HalaqatiRepository = AppGraph.repo,
) : ViewModel() {
    private val _state = MutableStateFlow(DashboardUiState())
    val state: StateFlow<DashboardUiState> = _state.asStateFlow()

    private var boundOwner: String? = null

    fun bind(profile: Profile, sync: SyncState) {
        val ownerChanged = boundOwner != profile.id
        boundOwner = profile.id
        _state.value = _state.value.copy(profile = profile, sync = sync)
        if (ownerChanged) {
            viewModelScope.launch {
                loadCached(profile, sync)
                refresh(force = true)
            }
        } else if (_state.value.sync != sync) {
            _state.value = _state.value.copy(sync = sync)
        }
    }

    fun updateSync(sync: SyncState) {
        _state.value = _state.value.copy(sync = sync)
    }

    fun refresh(force: Boolean = true) {
        val profile = _state.value.profile ?: return
        val previous = _state.value
        _state.value = previous.copy(refreshing = true)
        viewModelScope.launch {
            val today = LocalDate.now().toString()
            val owner = profile.id
            val errors = linkedMapOf<String, String>()

            val studentsResult = runCatching {
                withContext(Dispatchers.IO) {
                    if (force) repository.refreshStudents()
                    else repository.cachedStudents(owner) ?: repository.refreshStudents()
                }
            }.onFailure { errors["students"] = it.message ?: "تعذر تحديث الطلاب" }

            val sessionsResult = runCatching {
                withContext(Dispatchers.IO) {
                    if (force) repository.refreshSessions()
                    else repository.cachedSessions(owner) ?: repository.refreshSessions()
                }
            }.onFailure { errors["sessions"] = it.message ?: "تعذر تحديث الجلسات" }

            val recitationsResult = runCatching {
                withContext(Dispatchers.IO) {
                    if (force) repository.refreshDashboardRecitations()
                    else repository.cachedDashboardRecitations(owner) ?: repository.refreshDashboardRecitations()
                }
            }.onFailure { errors["recitations"] = it.message ?: "تعذر تحديث التسميعات" }

            val recitations = recitationsResult.getOrNull()

            val merged = buildState(
                profile = profile,
                sync = _state.value.sync,
                today = today,
                students = studentsResult.getOrNull(),
                sessions = sessionsResult.getOrNull(),
                recitations = recitations,
                previous = previous,
                errors = errors,
            )
            _state.value = merged.copy(refreshing = false, loaded = true)
        }
    }

    private suspend fun loadCached(profile: Profile, sync: SyncState) {
        val cached = withContext(Dispatchers.IO) {
            Triple(
                repository.cachedStudents(profile.id),
                repository.cachedSessions(profile.id),
                repository.cachedDashboardRecitations(profile.id),
            )
        }
        if (cached.first == null && cached.second == null && cached.third == null) return
        _state.value = buildState(
            profile = profile,
            sync = sync,
            today = LocalDate.now().toString(),
            students = cached.first,
            sessions = cached.second,
            recitations = cached.third,
            previous = _state.value,
            errors = emptyMap(),
        ).copy(loaded = true)
    }

    private fun buildState(
        profile: Profile,
        sync: SyncState,
        today: String,
        students: List<Student>?,
        sessions: List<SessionRow>?,
        recitations: JSONArray?,
        previous: DashboardUiState,
        errors: Map<String, String>,
    ): DashboardUiState {
        val activeStudents = students?.filter { it.status == "active" }
        val heardToday = linkedSetOf<String>()
        var pages = if (recitations == null) previous.progress.recordedPages else 0.0
        if (recitations != null) {
            for (i in 0 until recitations.length()) {
                val row = recitations.optJSONObject(i) ?: continue
                val created = row.optString("created_at")
                if (created.startsWith(today)) {
                    row.optString("student_id").takeIf(String::isNotBlank)?.let(heardToday::add)
                    pages += row.optDouble("pages_count", 0.0)
                }
            }
        }
        val notHeard = activeStudents?.filter { it.id !in heardToday }?.map {
            DashboardAttentionItem(it.id, it.fullName, "لم يسمّع اليوم")
        } ?: previous.notHeard
        val progress = DashboardProgress(
            recordedPages = pages,
            heardStudents = if (recitations == null) previous.progress.heardStudents else heardToday.size,
            activeStudents = activeStudents?.size ?: previous.progress.activeStudents,
        )
        return previous.copy(
            profile = profile,
            today = today,
            notHeard = notHeard,
            attention = notHeard,
            progress = progress,
            todaySessions = sessions?.count { it.date == today } ?: previous.todaySessions,
            sync = sync,
            errors = errors,
        )
    }
}
