@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.mohammedsamir.halaqati.ui.screens

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.mohammedsamir.halaqati.model.Profile
import com.mohammedsamir.halaqati.model.UserRole
import com.mohammedsamir.halaqati.ui.components.ProFilterChip
import com.mohammedsamir.halaqati.ui.components.StateNotice
import com.mohammedsamir.halaqati.ui.theme.HalaqatiUiTokens
import com.mohammedsamir.halaqati.ui.auth.NativeGoogleSignIn
import kotlinx.coroutines.launch

@Composable
fun AuthScreen(
    error: String? = null,
    onLogin: (String, String) -> Unit,
    onRegister: (String, String, String, String, String) -> Unit,
    onGoogleIdToken: (String, String) -> Unit,
    onResetPassword: (String, (String) -> Unit) -> Unit,
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var register by remember { mutableStateOf(false) }
    var requestedRole by remember { mutableStateOf("guardian") }
    var resetDialog by remember { mutableStateOf(false) }
    var info by remember { mutableStateOf<String?>(null) }
    var googleBusy by remember { mutableStateOf(false) }

    Surface {
        Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
            Card(Modifier.widthIn(max = 520.dp)) {
                Column(
                    Modifier.padding(24.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    Text("حلقتي", style = MaterialTheme.typography.headlineLarge, color = MaterialTheme.colorScheme.primary)
                    Text("إدارة الحلقة — Native Android", style = MaterialTheme.typography.bodyMedium)
                    error?.let { StateNotice(it, kind = "error") }
                    info?.let { StateNotice(it, kind = "success") }

                    if (register) {
                        Text(
                            "إنشاء الحساب لا يمنح الصلاحية مباشرة؛ ينتظر اعتماد المسؤول.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        OutlinedTextField(
                            value = name,
                            onValueChange = { name = it },
                            label = { Text("الاسم الكامل") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                        )
                        OutlinedTextField(
                            value = phone,
                            onValueChange = { phone = it },
                            label = { Text("رقم الجوال") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                        )
                        Row(
                            Modifier.horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            listOf(
                                "guardian" to "ولي أمر",
                                "teacher" to "محفّظ الحلقة",
                                "supervisor" to "مشرف الحلقات",
                            ).forEach { (value, label) ->
                                ProFilterChip(
                                    selected = requestedRole == value,
                                    onClick = { requestedRole = value },
                                    label = label,
                                )
                            }
                        }
                    }

                    OutlinedTextField(
                        value = email,
                        onValueChange = { email = it },
                        label = { Text("البريد الإلكتروني") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                    )
                    OutlinedTextField(
                        value = password,
                        onValueChange = { password = it },
                        label = { Text("كلمة المرور") },
                        visualTransformation = PasswordVisualTransformation(),
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                    )

                    Button(
                        onClick = {
                            if (register) onRegister(email.trim(), password, name.trim(), phone.trim(), requestedRole)
                            else onLogin(email.trim(), password)
                        },
                        modifier = Modifier.fillMaxWidth().heightIn(min = HalaqatiUiTokens.TouchTarget),
                        enabled = email.isNotBlank() && password.length >= 6 && (!register || name.trim().length >= 3),
                    ) { Text(if (register) "إرسال طلب إنشاء الحساب" else "دخول") }

                    if (!register) {
                        OutlinedButton(
                            onClick = {
                                if (googleBusy) return@OutlinedButton
                                googleBusy = true
                                info = null
                                scope.launch {
                                    runCatching { NativeGoogleSignIn.launch(context) }
                                        .onSuccess { result -> onGoogleIdToken(result.idToken, result.rawNonce) }
                                        .onFailure { e ->
                                            googleBusy = false
                                            info = when {
                                                e.message?.contains("canceled", ignoreCase = true) == true -> "تم إلغاء اختيار حساب Google."
                                                else -> "تعذر تسجيل الدخول بحساب Google: ${e.message ?: "خطأ"}"
                                            }
                                        }
                                }
                            },
                            enabled = !googleBusy,
                            modifier = Modifier.fillMaxWidth().heightIn(min = HalaqatiUiTokens.TouchTarget),
                        ) {
                            if (googleBusy) {
                                CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                                Spacer(Modifier.width(8.dp))
                                Text("جارٍ فتح حسابات Google…")
                            } else {
                                Text("G", style = MaterialTheme.typography.titleMedium)
                                Spacer(Modifier.width(8.dp))
                                Text("الدخول باستخدام Google")
                            }
                        }
                        TextButton(onClick = { resetDialog = true }, modifier = Modifier.align(Alignment.CenterHorizontally)) {
                            Text("نسيت كلمة المرور؟")
                        }
                    }

                    TextButton(onClick = { register = !register }, modifier = Modifier.align(Alignment.CenterHorizontally)) {
                        Text(if (register) "لدي حساب بالفعل" else "إنشاء حساب جديد")
                    }
                }
            }
        }
    }

    if (resetDialog) {
        var resetEmail by remember(resetDialog) { mutableStateOf(email) }
        AlertDialog(
            onDismissRequest = { resetDialog = false },
            title = { Text("استرجاع كلمة المرور") },
            text = {
                OutlinedTextField(
                    value = resetEmail,
                    onValueChange = { resetEmail = it },
                    label = { Text("البريد الإلكتروني") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
            },
            confirmButton = {
                Button(
                    enabled = resetEmail.contains('@'),
                    onClick = {
                        onResetPassword(resetEmail) { result -> info = result }
                        resetDialog = false
                    },
                ) { Text("إرسال الرابط") }
            },
            dismissButton = { TextButton(onClick = { resetDialog = false }) { Text("إلغاء") } },
        )
    }
}

@Composable
fun PendingApprovalScreen(profile: Profile, onRefresh: () -> Unit, onLogout: () -> Unit) {
    val rejected = profile.approvalStatus == "rejected"
    val blocked = profile.approvalStatus == "approved" && !profile.active
    val roleLabel = when (profile.requestedRole.takeIf { it != UserRole.UNKNOWN } ?: profile.role) {
        UserRole.GUARDIAN -> "ولي أمر"
        UserRole.TEACHER -> "محفّظ الحلقة"
        UserRole.SUPERVISOR -> "مشرف الحلقات"
        UserRole.ADMIN -> "مدير"
        else -> "مستخدم"
    }

    Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
        Card {
            Column(
                Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Text(
                    when {
                        rejected -> "لم تتم الموافقة على الحساب"
                        blocked -> "الحساب موقوف"
                        else -> "الحساب قيد اعتماد المسؤول"
                    },
                    style = MaterialTheme.typography.headlineSmall,
                )
                Text(profile.fullName)
                Text("نوع الحساب المطلوب: $roleLabel")
                Text(
                    when {
                        rejected -> profile.rejectionReason.ifBlank { "راجع مسؤول النظام لمعرفة سبب رفض الطلب." }
                        blocked -> "تم إيقاف الحساب من إدارة النظام. تواصل مع مسؤول الحلقات."
                        else -> "تم التحقق من بيانات الدخول، لكن الوصول إلى بيانات الحلقة لن يفتح حتى يعتمد المسؤول الحساب."
                    },
                    style = MaterialTheme.typography.bodyMedium,
                )
                Button(onClick = onRefresh) { Text("تحديث حالة الاعتماد") }
                TextButton(onClick = onLogout) { Text("تسجيل الخروج") }
            }
        }
    }
}

@Composable
fun PasswordRecoveryScreen(
    email: String,
    onSubmit: (String, (String?) -> Unit) -> Unit,
    onCancel: () -> Unit,
) {
    var password by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    val valid = password.length >= 6 && password == confirm

    Surface {
        Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
            Card(Modifier.widthIn(max = 520.dp)) {
                Column(
                    Modifier.padding(24.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    Text("تعيين كلمة مرور جديدة", style = MaterialTheme.typography.headlineSmall)
                    if (email.isNotBlank()) {
                        Text(email, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Text(
                        "اكتب كلمة المرور الجديدة مرتين. بعد نجاح التغيير سيتم إنهاء جلسة الاسترجاع ويمكنك تسجيل الدخول بالكلمة الجديدة.",
                        style = MaterialTheme.typography.bodyMedium,
                    )
                    error?.let { StateNotice(it, kind = "error") }
                    OutlinedTextField(
                        value = password,
                        onValueChange = { password = it; error = null },
                        label = { Text("كلمة المرور الجديدة") },
                        visualTransformation = PasswordVisualTransformation(),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                    )
                    OutlinedTextField(
                        value = confirm,
                        onValueChange = { confirm = it; error = null },
                        label = { Text("تأكيد كلمة المرور") },
                        visualTransformation = PasswordVisualTransformation(),
                        singleLine = true,
                        isError = confirm.isNotBlank() && password != confirm,
                        modifier = Modifier.fillMaxWidth(),
                    )
                    if (confirm.isNotBlank() && password != confirm) {
                        Text(
                            "كلمتا المرور غير متطابقتين.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.error,
                        )
                    }
                    Button(
                        onClick = {
                            busy = true
                            error = null
                            onSubmit(password) { message ->
                                busy = false
                                error = message
                            }
                        },
                        enabled = valid && !busy,
                        modifier = Modifier.fillMaxWidth().heightIn(min = HalaqatiUiTokens.TouchTarget),
                    ) {
                        if (busy) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(20.dp),
                                strokeWidth = 2.dp,
                                color = MaterialTheme.colorScheme.onPrimary,
                            )
                            Spacer(Modifier.width(8.dp))
                        }
                        Text(if (busy) "جارٍ الحفظ…" else "حفظ كلمة المرور")
                    }
                    TextButton(
                        onClick = onCancel,
                        enabled = !busy,
                        modifier = Modifier.align(Alignment.CenterHorizontally),
                    ) { Text("إلغاء والعودة لتسجيل الدخول") }
                }
            }
        }
    }
}
