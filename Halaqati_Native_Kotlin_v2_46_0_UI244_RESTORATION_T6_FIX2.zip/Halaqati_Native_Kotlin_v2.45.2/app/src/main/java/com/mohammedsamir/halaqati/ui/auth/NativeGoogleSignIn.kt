package com.mohammedsamir.halaqati.ui.auth

import android.content.Context
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.android.libraries.identity.googleid.GoogleIdTokenParsingException
import com.mohammedsamir.halaqati.BuildConfig
import com.mohammedsamir.halaqati.data.GoogleAuthRules

object NativeGoogleSignIn {
    data class Result(val idToken: String, val rawNonce: String)

    suspend fun launch(context: Context): Result {
        val clientId = resolveWebClientId(context)
        require(clientId.isNotBlank()) {
            "معرّف Google Web Client غير موجود. تأكد من إعداد google-services.json وGoogle Auth."
        }
        val nonce = GoogleAuthRules.newNonce()
        val googleIdOption = GetGoogleIdOption.Builder()
            .setFilterByAuthorizedAccounts(false)
            .setServerClientId(clientId)
            .setNonce(nonce.hashed)
            .build()
        val request = GetCredentialRequest.Builder()
            .addCredentialOption(googleIdOption)
            .build()
        val result = CredentialManager.create(context).getCredential(
            request = request,
            context = context,
        )
        val credential = result.credential
        if (credential !is CustomCredential || credential.type != GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
            error("لم يُرجع Google بيانات اعتماد صالحة")
        }
        val googleCredential = try {
            GoogleIdTokenCredential.createFrom(credential.data)
        } catch (e: GoogleIdTokenParsingException) {
            error("تعذر قراءة حساب Google: ${e.message ?: "بيانات غير صالحة"}")
        }
        return Result(googleCredential.idToken, nonce.raw)
    }

    private fun resolveWebClientId(context: Context): String {
        val id = context.resources.getIdentifier("default_web_client_id", "string", context.packageName)
        val generated = if (id != 0) context.getString(id).trim() else ""
        return generated.ifBlank { BuildConfig.GOOGLE_WEB_CLIENT_ID.trim() }
    }
}
