#!/usr/bin/env python3
from pathlib import Path
import json,re,sys
root=Path(__file__).resolve().parents[1]
errors=[]

def read(rel):
    p=root/rel
    if not p.exists():
        errors.append(f'missing {rel}')
        return ''
    return p.read_text(encoding='utf-8',errors='ignore')

build=read('app/build.gradle.kts')
contract_text=read('migration/source-contract.json')
try: contract=json.loads(contract_text)
except Exception as e:
    contract={}; errors.append(f'invalid source-contract.json: {e}')

checks={
    'applicationId = "com.mohammedsamir.halaqati"':'applicationId',
    'namespace = "com.mohammedsamir.halaqati"':'namespace',
    'compileSdk = 36':'compileSdk',
    'minSdk = 23':'minSdk',
    'targetSdk = 36':'targetSdk',
    'versionCode = 24611':'versionCode',
    'versionName = "2.46.1-RC11"':'versionName',
}
for token,label in checks.items():
    if token not in build: errors.append(f'build contract missing {label}: {token}')
if contract.get('native_version')!='2.46.1-RC11': errors.append('source contract native_version mismatch')
if contract.get('application_id')!='com.mohammedsamir.halaqati': errors.append('source contract application_id mismatch')
required_tables={
    'profiles','halaqas','halaqa_teachers','halaqa_supervisors','student_categories','students','student_guardians',
    'sessions','attendance_records','recitation_entries','student_daily_notes','student_goals','monthly_comments',
    'announcements','forum_posts','forum_comments','student_points','app_settings','smart_plans','smart_plan_events','smart_plan_phases','smart_plan_phase_states','smart_plan_phase_templates',
    'user_devices','notification_preferences','notifications','supervisor_visits','data_import_jobs'
}
tables=set(contract.get('tables',[]))
missing=sorted(required_tables-tables)
if missing: errors.append(f'source contract missing tables: {missing}')
if len(tables)!=28: errors.append(f'expected 28 app tables, found {len(tables)}')
required_views={'leaderboard_daily','leaderboard_monthly','monthly_student_stats'}
views=set(contract.get('views',[]))
missing_views=sorted(required_views-views)
if missing_views: errors.append(f'source contract missing views: {missing_views}')
if len(views)!=3: errors.append(f'expected 3 compatibility views, found {len(views)}')
required_rpc={
    'admin_delete_account','delete_halaqa_cascade','guardian_competition_board_range','guardian_student_dashboard_range',
    'list_guardian_accounts','set_student_primary_guardian','student_rank_snapshot'
}
missing_rpc=sorted(required_rpc-set(contract.get('rpc',[])))
if missing_rpc: errors.append(f'source contract missing RPCs: {missing_rpc}')
if len(set(contract.get('rpc',[])))!=7: errors.append('expected exactly 7 required RPC functions')

# Every statically named table/RPC referenced by Native source must exist in the declared backend contract.
source_text='\n'.join(p.read_text(encoding='utf-8',errors='ignore') for p in (root/'app/src/main/java').rglob('*.kt'))
table_patterns=(
    r'api\.select\(\s*"([a-zA-Z0-9_]+)"',
    r'write\(\s*"([a-zA-Z0-9_]+)"',
    r'patch\(\s*"([a-zA-Z0-9_]+)"',
    r'api\.delete\(\s*"([a-zA-Z0-9_]+)"',
)
referenced_tables=set()
for pattern in table_patterns:
    referenced_tables.update(re.findall(pattern, source_text))
unknown_tables=sorted(referenced_tables - tables - views)
if unknown_tables: errors.append(f'Native source references undeclared backend tables/views: {unknown_tables}')
referenced_rpc=set(re.findall(r'api\.rpc\(\s*"([a-zA-Z0-9_]+)"', source_text))
unknown_rpc=sorted(referenced_rpc - set(contract.get('rpc',[])))
if unknown_rpc: errors.append(f'Native source references undeclared RPCs: {unknown_rpc}')

runtime='\n'.join(p.read_text(encoding='utf-8',errors='ignore') for p in (root/'app/src/main').rglob('*') if p.is_file())
for forbidden in ('android.webkit.WebView','Capacitor','BridgeActivity','cordova'):
    if forbidden.lower() in runtime.lower(): errors.append(f'forbidden runtime dependency/reference: {forbidden}')
tracks=read('app/src/main/java/com/mohammedsamir/halaqati/data/StudentTrackRules.kt')
if 'setOf(GENERAL_HIFZ, TATHBIT)' not in tracks: errors.append('student track contract is not exactly two tracks')
if '"sard"' not in tracks or 'GENERAL_HIFZ' not in tracks: errors.append('legacy sard track normalization missing')

if errors:
    print('Release contract FAILED')
    for e in errors: print(' -',e)
    sys.exit(1)
print('Release contract passed (2.46.1-RC11, 28 tables, 3 views, 7 RPCs, 2 student tracks, Native runtime only)')
