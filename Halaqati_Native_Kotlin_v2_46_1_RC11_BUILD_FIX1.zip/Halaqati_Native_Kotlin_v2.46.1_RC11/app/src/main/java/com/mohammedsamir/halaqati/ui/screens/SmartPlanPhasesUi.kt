@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.mohammedsamir.halaqati.ui.screens

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.mohammedsamir.halaqati.data.AppGraph
import com.mohammedsamir.halaqati.data.PlanSnapshot
import com.mohammedsamir.halaqati.model.PlanRow
import com.mohammedsamir.halaqati.model.SmartPlanPhaseDraft
import com.mohammedsamir.halaqati.model.SmartPlanPhaseRow
import com.mohammedsamir.halaqati.model.SmartPlanPhaseStateRow
import com.mohammedsamir.halaqati.model.SmartPlanPhaseTemplateRow
import com.mohammedsamir.halaqati.plans.SmartPlanPhaseEngine
import com.mohammedsamir.halaqati.ui.components.ProFilterChip
import com.mohammedsamir.halaqati.quran.QuranMetadata
import com.mohammedsamir.halaqati.quran.QuranTraversalDirection
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate
import java.time.YearMonth
import java.time.temporal.ChronoUnit
import kotlin.math.max

@Composable
fun PlanPhaseTimelineInline(snapshot: PlanSnapshot) {
    var phases by remember(snapshot.plan.id) { mutableStateOf<List<SmartPlanPhaseRow>>(emptyList()) }
    LaunchedEffect(snapshot.plan.id) {
        phases = withContext(Dispatchers.IO) { AppGraph.repo.planPhases(snapshot.plan.id) }
    }
    if (phases.isEmpty()) return

    val ordered = phases.filter { it.status != "archived" }.sortedBy { it.phaseOrder }
    ElevatedCard(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                Icon(Icons.Default.Timeline, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                Text("الخط الزمني للخطة", fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                snapshot.phase?.let {
                    Surface(
                        color = MaterialTheme.colorScheme.secondaryContainer,
                        contentColor = MaterialTheme.colorScheme.onSecondaryContainer,
                        shape = RoundedCornerShape(999.dp),
                    ) {
                        Row(Modifier.padding(horizontal = 9.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(if (it.phaseType == "sard") Icons.Default.RecordVoiceOver else Icons.Default.MenuBook, null, Modifier.size(17.dp))
                            Spacer(Modifier.width(5.dp))
                            Text(if (it.phaseType == "sard") "السرد نشط" else "الحفظ نشط", style = MaterialTheme.typography.labelMedium)
                        }
                    }
                }
            }
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ordered.forEachIndexed { index, phase ->
                    val active = snapshot.phase?.id == phase.id
                    Surface(
                        color = if (active) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,
                        contentColor = if (active) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurfaceVariant,
                        shape = RoundedCornerShape(14.dp),
                    ) {
                        Column(Modifier.padding(horizontal = 11.dp, vertical = 8.dp)) {
                            Text("${index + 1}. ${phaseTitle(phase)}", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelLarge)
                            Text("${phase.startDate} ← ${phase.endDate}", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                    if (index < ordered.lastIndex) Icon(Icons.Default.ArrowBack, contentDescription = null, modifier = Modifier.align(Alignment.CenterVertically))
                }
            }
            snapshot.phaseProgress?.let { progress ->
                val goal = progress.targetPages?.let { "${phaseNumber(progress.completedPages)} / ${phaseNumber(it)} ص" } ?: "سرد مفتوح · ${phaseNumber(progress.completedPages)} ص منجزة"
                Text(goal, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                progress.suggestedTodayPages?.takeIf { it > .001 }?.let {
                    Text("المقترح اليوم ${phaseNumber(it)} ص · توزيع ${if (snapshot.phase?.distributionMode == "equal") "متساوٍ" else "مرن"}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                if (snapshot.phase?.phaseType == "sard") {
                    val sardActivity = snapshot.activities.firstOrNull { it.key == "sard" }
                    sardActivity?.lastRecitation?.let { last ->
                        val anchor = if (last.endSurah != null && last.endAyah != null) "${QuranMetadata.surahName(last.endSurah)} ${last.endAyah}" else last.endPage?.let { "ص $it" } ?: "—"
                        Text("آخر سرد: $anchor · ${last.date}", style = MaterialTheme.typography.bodySmall)
                    }
                    sardActivity?.assignment?.let { assignment ->
                        val range = when {
                            assignment.startPage != null && assignment.endPage != null -> "ص ${assignment.startPage} → ${assignment.endPage}"
                            assignment.startPage != null -> "ص ${assignment.startPage}"
                            else -> "${phaseNumber(assignment.pages)} ص"
                        }
                        Text("المقرر التالي: $range · ${phaseNumber(assignment.pages)} ص", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold)
                    }
                    if (sardActivity?.needsStart == true) {
                        Text("يلزم تحديد نقطة بداية السرد لأن آخر Sard Anchor غير متاح.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
                    }
                }
            }
        }
    }
}

@Composable
fun SmartPlanPhasesManagerSheet(
    plan: PlanRow,
    snapshots: List<PlanSnapshot>,
    onDismiss: () -> Unit,
    onChanged: () -> Unit,
) {
    val scope = rememberCoroutineScope()
    var phases by remember(plan.id) { mutableStateOf<List<SmartPlanPhaseRow>>(emptyList()) }
    var states by remember(plan.id) { mutableStateOf<List<SmartPlanPhaseStateRow>>(emptyList()) }
    var templates by remember(plan.halaqaId) { mutableStateOf<List<SmartPlanPhaseTemplateRow>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var message by remember { mutableStateOf<String?>(null) }
    var editing by remember { mutableStateOf<SmartPlanPhaseRow?>(null) }
    var adding by remember { mutableStateOf(false) }
    var excluded by remember { mutableStateOf<Set<String>>(emptySet()) }
    var exceptionEndDate by remember { mutableStateOf("") }
    var showExceptions by remember { mutableStateOf(false) }
    var showStudentActions by remember { mutableStateOf(false) }
    var transitionOne by remember { mutableStateOf<PlanSnapshot?>(null) }
    var closePhaseOne by remember { mutableStateOf<PlanSnapshot?>(null) }
    var previousShortfalls by remember(plan.id) { mutableStateOf<Map<String, Double>>(emptyMap()) }
    var carryPreviousShortfallBulk by remember(plan.id) { mutableStateOf(false) }
    var carryPreviousShortfallOne by remember { mutableStateOf(false) }
    var showBulkConfirm by remember { mutableStateOf(false) }

    suspend fun reload(force: Boolean = false) {
        loading = true
        try {
            val loadedPhases = withContext(Dispatchers.IO) { AppGraph.repo.planPhases(plan.id, forceRefresh = force) }
            phases = loadedPhases
            states = withContext(Dispatchers.IO) { AppGraph.repo.planPhaseStates(forceRefresh = force) }
            templates = withContext(Dispatchers.IO) { AppGraph.repo.planPhaseTemplates(plan.halaqaId, forceRefresh = force) }
            val sardStart = loadedPhases.firstOrNull { it.phaseType == "sard" }
                ?.startDate?.let { runCatching { LocalDate.parse(it) }.getOrNull() }
            previousShortfalls = if (sardStart != null) withContext(Dispatchers.IO) {
                AppGraph.repo.previousSardShortfalls(snapshots.map { it.student.id }.toSet(), sardStart, forceRefresh = force)
            } else emptyMap()
            message = null
        } catch (e: Exception) {
            message = e.message ?: "تعذر تحميل مراحل الخطة"
        } finally { loading = false }
    }
    LaunchedEffect(plan.id) { reload() }
    LaunchedEffect(transitionOne?.student?.id) { carryPreviousShortfallOne = false }

    val ordered = phases.filter { it.status != "archived" }.sortedBy { it.phaseOrder }
    val hifz = ordered.firstOrNull { it.phaseType == "hifz" }
    val sard = ordered.firstOrNull { it.phaseType == "sard" }
    val planStudents = snapshots.distinctBy { it.student.id }
    fun hifzStateFor(studentId: String): SmartPlanPhaseStateRow? = hifz?.let { hp -> states.firstOrNull { it.phaseId == hp.id && it.studentId == studentId } }
    fun hifzTargetFor(snap: PlanSnapshot): Double {
        val st = hifzStateFor(snap.student.id)
        return st?.frozenTargetPages ?: st?.targetPagesOverride ?: hifz?.targetPages ?: plan.target
    }
    fun hifzCompletedFor(snap: PlanSnapshot): Double {
        val st = hifzStateFor(snap.student.id)
        st?.frozenCompletedPages?.let { return it }
        if (snap.phase?.id == hifz?.id) return snap.phaseProgress?.completedPages ?: snap.progress.completed
        return snap.progress.completed
    }
    val transitionCandidates = if (hifz == null) emptyList() else planStudents.filter { snap ->
        hifzStateFor(snap.student.id)?.status != "completed"
    }
    val completedCount = transitionCandidates.count { snap ->
        hifzCompletedFor(snap) + .001 >= hifzTargetFor(snap)
    }
    val avgPercent = if (transitionCandidates.isEmpty()) 0.0 else transitionCandidates.map { snap ->
        val target = hifzTargetFor(snap)
        if (target <= .001) 0.0 else (hifzCompletedFor(snap) / target * 100.0).coerceAtMost(200.0)
    }.average()
    val totalPreviousShortfall = transitionCandidates.sumOf { previousShortfalls[it.student.id] ?: 0.0 }

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("RC11 · مراحل الخطة", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold)
                    Text("الحفظ والسرد مرحلتان داخل نفس الخطة، مع حالة مستقلة لكل طالب.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                FilledTonalIconButton(onClick = { scope.launch { reload(true) } }) { Icon(Icons.Default.Refresh, "تحديث") }
            }

            message?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
            if (loading && phases.isEmpty()) LinearProgressIndicator(Modifier.fillMaxWidth())

            if (!loading && ordered.isEmpty()) {
                ElevatedCard(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("تهيئة الخطة كمراحل", fontWeight = FontWeight.Bold)
                        Text("سأقسم الفترة تلقائيًا إلى حفظ ثم أسبوع سرد أخير. تستطيع تعديل التواريخ والهدف بعد الإنشاء.", style = MaterialTheme.typography.bodySmall)
                        Button(
                            onClick = {
                                scope.launch {
                                    try {
                                        val start = LocalDate.parse(plan.startDate)
                                        val end = LocalDate.parse(plan.endDate)
                                        val sardStart = maxOf(start.plusDays(1), end.minusDays(6))
                                        val hifzEnd = sardStart.minusDays(1).coerceAtLeast(start)
                                        withContext(Dispatchers.IO) {
                                            AppGraph.repo.savePlanPhase(
                                                SmartPlanPhaseDraft(
                                                    planId = plan.id, phaseOrder = 1, phaseType = "hifz", title = "مرحلة الحفظ",
                                                    startDate = start.toString(), endDate = hifzEnd.toString(),
                                                    scheduleWeekdays = plan.scheduleWeekdays.ifEmpty { listOf(0,1,2,3,4) },
                                                    goalMode = "pages", goalUnit = "pages", targetPages = plan.target,
                                                    distributionMode = "flexible", startMode = "plan_start",
                                                    rangeStartPage = plan.rangeStartPage, rangeEndPage = plan.rangeEndPage,
                                                    rangeStartSurah = plan.rangeStartSurah, rangeStartAyah = plan.rangeStartAyah,
                                                    rangeEndSurah = plan.rangeEndSurah, rangeEndAyah = plan.rangeEndAyah,
                                                )
                                            )
                                            AppGraph.repo.savePlanPhase(
                                                SmartPlanPhaseDraft(
                                                    planId = plan.id, phaseOrder = 2, phaseType = "sard", title = "مرحلة السرد",
                                                    startDate = sardStart.toString(), endDate = end.toString(),
                                                    scheduleWeekdays = listOf(0,1,2,3,4,5),
                                                    goalMode = "open", goalUnit = "open", targetPages = null,
                                                    distributionMode = "flexible", startMode = "last_sard",
                                                )
                                            )
                                        }
                                        reload(false); onChanged(); message = "تم إنشاء مرحلتي الحفظ والسرد"
                                    } catch (e: Exception) { message = e.message ?: "تعذر إنشاء المراحل" }
                                }
                            },
                            modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp),
                        ) { Icon(Icons.Default.AutoAwesome, null); Spacer(Modifier.width(6.dp)); Text("إنشاء حفظ + سرد") }
                    }
                }
                if (templates.isNotEmpty()) {
                    Text("أو طبّق قالب الحلقة", fontWeight = FontWeight.Bold)
                    templates.take(6).forEach { template ->
                        OutlinedButton(
                            onClick = {
                                scope.launch {
                                    try {
                                        withContext(Dispatchers.IO) { AppGraph.repo.applyPlanPhaseTemplate(plan, template) }
                                        reload(false); onChanged(); message = "تم تطبيق قالب ${template.name}"
                                    } catch (e: Exception) { message = e.message ?: "تعذر تطبيق القالب" }
                                }
                            },
                            modifier = Modifier.fillMaxWidth().heightIn(min = 46.dp),
                        ) {
                            Icon(Icons.Default.ContentPasteGo, null); Spacer(Modifier.width(6.dp))
                            Text("${template.name} · ${templateModeAr(template.templateMode)}")
                        }
                    }
                }
            } else if (ordered.isNotEmpty()) {
                Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ordered.forEach { phase ->
                        val activeCount = states.count { it.phaseId == phase.id && it.status == "active" }
                        ElevatedCard(modifier = Modifier.widthIn(min = 220.dp)) {
                            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(if (phase.phaseType == "sard") Icons.Default.RecordVoiceOver else Icons.Default.MenuBook, null, tint = MaterialTheme.colorScheme.primary)
                                    Spacer(Modifier.width(6.dp))
                                    Text(phaseTitle(phase), fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                                    Text("#${phase.phaseOrder}", style = MaterialTheme.typography.labelMedium)
                                }
                                Text("${phase.startDate} ← ${phase.endDate}", style = MaterialTheme.typography.bodySmall)
                                Text(phaseGoalText(phase), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                if (activeCount > 0) Text("$activeCount طالب بحالة نشطة", style = MaterialTheme.typography.labelSmall)
                                OutlinedButton(onClick = { editing = phase }, modifier = Modifier.fillMaxWidth().heightIn(min = 44.dp)) {
                                    Icon(Icons.Default.Edit, null); Spacer(Modifier.width(5.dp)); Text("تعديل المرحلة")
                                }
                            }
                        }
                    }
                }
                OutlinedButton(onClick = { adding = true }, modifier = Modifier.fillMaxWidth().heightIn(min = 46.dp)) {
                    Icon(Icons.Default.Add, null); Spacer(Modifier.width(5.dp)); Text("إضافة مرحلة")
                }

                if (hifz != null && sard != null && transitionCandidates.isNotEmpty()) {
                    ElevatedCard(Modifier.fillMaxWidth(), colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = .55f))) {
                        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("الانتقال الجماعي إلى السرد", fontWeight = FontWeight.ExtraBold)
                            Text("${transitionCandidates.size} طالب ما زالوا في الحفظ · $completedCount أكملوا الهدف · ${transitionCandidates.size - completedCount} لم يكملوا · متوسط ${phaseNumber(avgPercent)}%", style = MaterialTheme.typography.bodyMedium)
                            Text("الطلاب غير المستثنين ستُجمّد نتيجة حفظهم الحالية ثم تبدأ لهم مرحلة السرد. لا يُرحّل النقص تلقائيًا.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedButton(onClick = { showExceptions = !showExceptions }, modifier = Modifier.weight(1f)) {
                                    Icon(Icons.Default.PersonOff, null); Spacer(Modifier.width(5.dp)); Text("استثناءات (${excluded.size})")
                                }
                                Button(
                                    onClick = {
                                        val rawExceptionEnd = exceptionEndDate.takeIf { it.isNotBlank() }
                                        if (rawExceptionEnd != null && runCatching { LocalDate.parse(rawExceptionEnd) }.isFailure) {
                                            message = "تاريخ نهاية الاستثناء غير صالح"
                                        } else {
                                            showBulkConfirm = true
                                        }
                                    },
                                    modifier = Modifier.weight(1f),
                                ) { Icon(Icons.Default.SwapHoriz, null); Spacer(Modifier.width(5.dp)); Text("معاينة النقل") }
                            }
                            if (totalPreviousShortfall > .001) {
                                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                    Checkbox(checked = carryPreviousShortfallBulk, onCheckedChange = { carryPreviousShortfallBulk = it })
                                    Column(Modifier.weight(1f)) {
                                        Text("ترحيل نقص السرد السابق اختياريًا", style = MaterialTheme.typography.labelLarge)
                                        Text("إجمالي النقص السابق للطلاب: ${phaseNumber(totalPreviousShortfall)} ص. الافتراضي: تجاهل.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                }
                            }
                            if (showExceptions) {
                                OutlinedTextField(
                                    value = exceptionEndDate,
                                    onValueChange = { exceptionEndDate = it },
                                    label = { Text("يبقى المستثنون في الحفظ حتى") },
                                    placeholder = { Text(plan.endDate) },
                                    modifier = Modifier.fillMaxWidth(), singleLine = true,
                                )
                                LazyColumn(modifier = Modifier.fillMaxWidth().heightIn(max = 230.dp)) {
                                    items(transitionCandidates, key = { it.student.id }) { snap ->
                                        Row(Modifier.fillMaxWidth().heightIn(min = 46.dp), verticalAlignment = Alignment.CenterVertically) {
                                            Checkbox(checked = snap.student.id in excluded, onCheckedChange = { checked ->
                                                excluded = if (checked) excluded + snap.student.id else excluded - snap.student.id
                                            })
                                            Text(snap.student.fullName, modifier = Modifier.weight(1f))
                                            Text("${phaseNumber(hifzCompletedFor(snap))} ص", style = MaterialTheme.typography.labelMedium)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                ElevatedCard(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("حالة الطلاب داخل المراحل", fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                            TextButton(onClick = { showStudentActions = !showStudentActions }) { Text(if (showStudentActions) "إخفاء" else "عرض") }
                        }
                        if (showStudentActions) {
                            LazyColumn(modifier = Modifier.fillMaxWidth().heightIn(max = 300.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                                items(planStudents, key = { it.student.id }) { snap ->
                                    val current = snap.phase
                                    val pp = snap.phaseProgress
                                    Surface(shape = RoundedCornerShape(12.dp), color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = .55f)) {
                                        Row(Modifier.fillMaxWidth().padding(9.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                                            Column(Modifier.weight(1f)) {
                                                Text(snap.student.fullName, fontWeight = FontWeight.SemiBold)
                                                Text(
                                                    when {
                                                        current == null -> "لا توجد مرحلة نشطة"
                                                        current.phaseType == "hifz" -> "حفظ · ${phaseNumber(pp?.completedPages ?: snap.progress.completed)} / ${phaseNumber(pp?.targetPages ?: current.targetPages ?: plan.target)} ص"
                                                        pp?.targetPages == null -> "سرد مفتوح · ${phaseNumber(pp?.completedPages ?: snap.progress.completed)} ص"
                                                        else -> "سرد · ${phaseNumber(pp.completedPages)} / ${phaseNumber(pp.targetPages)} ص"
                                                    },
                                                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                )
                                            }
                                            when {
                                                current?.phaseType == "hifz" && sard != null -> FilledTonalButton(onClick = { transitionOne = snap }) { Text("إنهاء الحفظ") }
                                                current?.phaseType == "sard" && pp?.goalComplete == true -> {
                                                    if (current.allowSurplus && snap.phaseState?.settings?.optBoolean("continue_surplus", false) != true) {
                                                        TextButton(onClick = {
                                                            scope.launch {
                                                                try {
                                                                    withContext(Dispatchers.IO) {
                                                                        AppGraph.repo.upsertPlanPhaseState(
                                                                            phaseId = current.id, studentId = snap.student.id, status = "active",
                                                                            targetPagesOverride = snap.phaseState?.targetPagesOverride,
                                                                            startDateOverride = snap.phaseState?.startDateOverride, endDateOverride = snap.phaseState?.endDateOverride,
                                                                            carryShortfallPages = snap.phaseState?.carryShortfallPages ?: 0.0,
                                                                            settings = JSONObject(snap.phaseState?.settings?.toString() ?: "{}").put("continue_surplus", true),
                                                                        )
                                                                    }
                                                                    reload(false); onChanged(); message = "سيستمر ${snap.student.fullName} بسرد إضافي"
                                                                } catch (e: Exception) { message = e.message ?: "تعذر تفعيل الاستمرار الإضافي" }
                                                            }
                                                        }) { Text("استمرار إضافي") }
                                                    }
                                                    Button(onClick = { closePhaseOne = snap }) { Text("إنهاء السرد") }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                ElevatedCard(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                        Text("قالب الحلقة", fontWeight = FontWeight.Bold)
                        Text("احفظ نفس دورة الحفظ ← السرد بأحد الأنماط الثلاثة: بالتاريخ، بالأسابيع، أو يدويًا.", style = MaterialTheme.typography.bodySmall)
                        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                            listOf("dates" to "بالتاريخ", "weeks" to "بالأسابيع", "manual" to "يدوي").forEach { (mode, label) ->
                                OutlinedButton(
                                    onClick = {
                                        scope.launch {
                                            try {
                                                val start = LocalDate.parse(plan.startDate)
                                                val h = hifz
                                                val sd = sard
                                                val definition = when (mode) {
                                                    "dates" -> JSONObject()
                                                        .put("hifz_start_day", h?.startDate?.let { LocalDate.parse(it) }?.dayOfMonth ?: 1)
                                                        .put("hifz_end_day", h?.endDate?.let { LocalDate.parse(it) }?.dayOfMonth ?: 24)
                                                        .put("sard_start_day", sd?.startDate?.let { LocalDate.parse(it) }?.dayOfMonth ?: 25)
                                                        .put("sard_end_day", if (sd?.endDate?.let { LocalDate.parse(it) } == YearMonth.from(start).atEndOfMonth()) 0 else sd?.endDate?.let { LocalDate.parse(it) }?.dayOfMonth ?: 0)
                                                        .put("sard_goal_mode", sd?.goalMode ?: "juz")
                                                        .put("sard_target_units", sd?.targetUnits ?: JSONObject.NULL)
                                                        .put("sard_target_pages", sd?.targetPages ?: JSONObject.NULL)
                                                        .put("sard_distribution", sd?.distributionMode ?: "flexible")
                                                        .put("sard_start_mode", sd?.startMode ?: "last_sard")
                                                    "weeks" -> JSONObject()
                                                        .put("hifz_weeks", 3)
                                                        .put("sard_weeks", maxOf(1, kotlin.math.ceil(((sd?.let { ChronoUnit.DAYS.between(LocalDate.parse(it.startDate), LocalDate.parse(it.endDate)) + 1 } ?: 7L).toDouble()) / 7.0).toInt()))
                                                        .put("sard_goal_mode", sd?.goalMode ?: "juz")
                                                        .put("sard_target_units", sd?.targetUnits ?: JSONObject.NULL)
                                                        .put("sard_target_pages", sd?.targetPages ?: JSONObject.NULL)
                                                        .put("sard_distribution", sd?.distributionMode ?: "flexible")
                                                        .put("sard_start_mode", sd?.startMode ?: "last_sard")
                                                    else -> JSONObject().put("phases", JSONArray().also { array ->
                                                        ordered.forEach { p ->
                                                            val ps = LocalDate.parse(p.startDate); val pe = LocalDate.parse(p.endDate)
                                                            array.put(JSONObject()
                                                                .put("phase_order", p.phaseOrder).put("phase_type", p.phaseType).put("title", p.title)
                                                                .put("start_offset_days", ChronoUnit.DAYS.between(start, ps))
                                                                .put("end_offset_days", ChronoUnit.DAYS.between(start, pe))
                                                                .put("schedule_weekdays", JSONArray(p.scheduleWeekdays))
                                                                .put("goal_mode", p.goalMode).put("goal_unit", p.goalUnit)
                                                                .put("target_units", p.targetUnits ?: JSONObject.NULL).put("target_pages", p.targetPages ?: JSONObject.NULL)
                                                                .put("distribution_mode", p.distributionMode).put("start_mode", p.startMode).put("allow_surplus", p.allowSurplus)
                                                                .put("range_start_page", p.rangeStartPage ?: JSONObject.NULL).put("range_end_page", p.rangeEndPage ?: JSONObject.NULL)
                                                                .put("range_start_surah", p.rangeStartSurah ?: JSONObject.NULL).put("range_start_ayah", p.rangeStartAyah ?: JSONObject.NULL)
                                                                .put("range_end_surah", p.rangeEndSurah ?: JSONObject.NULL).put("range_end_ayah", p.rangeEndAyah ?: JSONObject.NULL))
                                                        }
                                                    })
                                                }
                                                withContext(Dispatchers.IO) { AppGraph.repo.savePlanPhaseTemplate(plan.halaqaId, "${plan.title} · $label", mode, definition) }
                                                reload(false); message = "تم حفظ القالب $label"
                                            } catch (e: Exception) { message = e.message ?: "تعذر حفظ القالب" }
                                        }
                                    },
                                    modifier = Modifier.heightIn(min = 44.dp),
                                ) { Icon(Icons.Default.BookmarkAdd, null); Spacer(Modifier.width(5.dp)); Text(label) }
                            }
                        }
                    }
                }
            }
            Spacer(Modifier.height(28.dp))
        }
    }

    if (showBulkConfirm && hifz != null && sard != null) {
        val included = transitionCandidates.filterNot { it.student.id in excluded }
        val excludedCount = transitionCandidates.size - included.size
        val carryTotal = if (carryPreviousShortfallBulk) included.sumOf { previousShortfalls[it.student.id] ?: 0.0 } else 0.0
        AlertDialog(
            onDismissRequest = { showBulkConfirm = false },
            title = { Text("معاينة نقل الحلقة إلى السرد") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("سيتم نقل ${included.size} طالب إلى مرحلة السرد.", fontWeight = FontWeight.Bold)
                    Text("${included.count { hifzCompletedFor(it) + .001 >= hifzTargetFor(it) }} أكملوا هدف الحفظ، و${included.count { hifzCompletedFor(it) + .001 < hifzTargetFor(it) }} سيُغلق حفظهم عند النسبة الحالية.")
                    if (excludedCount > 0) Text("سيبقى $excludedCount طالب في الحفظ حتى التاريخ الاستثنائي المحدد.")
                    Text("متوسط إنجاز الحفظ للمنقولين: ${phaseNumber(if (included.isEmpty()) 0.0 else included.map { (hifzCompletedFor(it) / hifzTargetFor(it).coerceAtLeast(.001) * 100.0).coerceAtMost(200.0) }.average())}%")
                    if (carryPreviousShortfallBulk && carryTotal > .001) {
                        Text("سيُضاف نقص سرد سابق بإجمالي ${phaseNumber(carryTotal)} ص إلى أهداف الطلاب المعنيين. هذا اختيار يدوي وليس ترحيلًا تلقائيًا.")
                    } else {
                        Text("لن يُرحّل أي نقص سابق تلقائيًا.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            },
            confirmButton = {
                Button(onClick = {
                    showBulkConfirm = false
                    scope.launch {
                        try {
                            val exceptionEnd = exceptionEndDate.takeIf { it.isNotBlank() } ?: hifz.endDate
                            withContext(Dispatchers.IO) {
                                transitionCandidates.forEach { snap ->
                                    if (snap.student.id in excluded) {
                                        AppGraph.repo.upsertPlanPhaseState(
                                            phaseId = hifz.id,
                                            studentId = snap.student.id,
                                            status = "active",
                                            endDateOverride = exceptionEnd,
                                        )
                                        AppGraph.repo.upsertPlanPhaseState(
                                            phaseId = sard.id,
                                            studentId = snap.student.id,
                                            status = "skipped",
                                        )
                                    } else {
                                        AppGraph.repo.transitionPlanStudentPhase(
                                            planId = plan.id,
                                            studentId = snap.student.id,
                                            fromPhaseId = hifz.id,
                                            toPhaseId = sard.id,
                                            completedPages = hifzCompletedFor(snap),
                                            targetPages = hifzTargetFor(snap),
                                            carryShortfallPages = if (carryPreviousShortfallBulk) previousShortfalls[snap.student.id] ?: 0.0 else 0.0,
                                        )
                                    }
                                }
                            }
                            excluded = emptySet()
                            reload(false)
                            onChanged()
                            message = "تم نقل ${included.size} طالب إلى السرد مع تجميد نتائج الحفظ"
                        } catch (e: Exception) {
                            message = e.message ?: "تعذر تنفيذ الانتقال الجماعي"
                        }
                    }
                }) { Text("اعتماد ونقل الجميع") }
            },
            dismissButton = { TextButton(onClick = { showBulkConfirm = false }) { Text("إلغاء") } },
        )
    }

    transitionOne?.let { snap ->
        val target = hifzTargetFor(snap)
        val completed = hifzCompletedFor(snap)
        val percent = if (target > .001) completed / target * 100.0 else 0.0
        val priorShortfall = previousShortfalls[snap.student.id] ?: 0.0
        val lastHifz = snap.activities.firstOrNull { it.key == "hifz" }?.lastRecitation
        AlertDialog(
            onDismissRequest = { transitionOne = null },
            title = { Text("إنهاء مرحلة الحفظ") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(snap.student.fullName, fontWeight = FontWeight.Bold)
                    Text("الهدف: ${phaseNumber(target)} صفحة")
                    Text("المنجز: ${phaseNumber(completed)} صفحة")
                    Text("نسبة الإنجاز: ${phaseNumber(percent)}%")
                    lastHifz?.let { last ->
                        val label = if (last.endSurah != null && last.endAyah != null) "${QuranMetadata.surahName(last.endSurah)} ${last.endAyah}" else last.endPage?.let { "ص $it" } ?: "—"
                        Text("آخر حفظ: $label")
                    }
                    Text("تاريخ الإنهاء: ${LocalDate.now()}")
                    if (priorShortfall > .001) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(checked = carryPreviousShortfallOne, onCheckedChange = { carryPreviousShortfallOne = it })
                            Column(Modifier.weight(1f)) {
                                Text("ترحيل نقص السرد السابق: ${phaseNumber(priorShortfall)} ص", style = MaterialTheme.typography.labelLarge)
                                Text("اختياري؛ الافتراضي تجاهل النقص السابق.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                    Text("بعد الاعتماد سيتجمّد إنجاز الحفظ ويبدأ Sard Anchor المستقل في مرحلة السرد.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            },
            confirmButton = {
                Button(onClick = {
                    val targetSnap = transitionOne ?: return@Button
                    val from = hifz ?: return@Button
                    val to = sard ?: return@Button
                    transitionOne = null
                    scope.launch {
                        try {
                            withContext(Dispatchers.IO) {
                                AppGraph.repo.transitionPlanStudentPhase(plan.id, targetSnap.student.id, from.id, to.id, completed, target, if (carryPreviousShortfallOne) priorShortfall else 0.0)
                            }
                            reload(false); onChanged(); message = "تم إنهاء حفظ ${targetSnap.student.fullName} وبدء السرد"
                        } catch (e: Exception) { message = e.message ?: "تعذر إنهاء مرحلة الحفظ" }
                    }
                }) { Text("اعتماد وإنهاء الحفظ") }
            },
            dismissButton = { TextButton(onClick = { transitionOne = null }) { Text("إلغاء") } },
        )
    }

    closePhaseOne?.let { snap ->
        val phase = snap.phase
        val pp = snap.phaseProgress
        if (phase != null && pp != null) {
            AlertDialog(
                onDismissRequest = { closePhaseOne = null },
                title = { Text("إنهاء مرحلة السرد") },
                text = { Text("${snap.student.fullName}: ${phaseNumber(pp.completedPages)}${pp.targetPages?.let { " / ${phaseNumber(it)} صفحة · ${phaseNumber(pp.percentage ?: 0.0)}%" } ?: " صفحة"}. سيتم تجميد النتيجة ولن يُولد مقرر جديد لهذه المرحلة.") },
                confirmButton = {
                    Button(onClick = {
                        closePhaseOne = null
                        scope.launch {
                            try {
                                withContext(Dispatchers.IO) { AppGraph.repo.completePlanPhaseForStudent(plan.id, phase.id, snap.student.id, pp.completedPages, pp.targetPages) }
                                reload(false); onChanged(); message = "تم إنهاء مرحلة السرد لـ${snap.student.fullName}"
                            } catch (e: Exception) { message = e.message ?: "تعذر إنهاء مرحلة السرد" }
                        }
                    }) { Text("إنهاء المرحلة") }
                },
                dismissButton = { TextButton(onClick = { closePhaseOne = null }) { Text("إلغاء") } },
            )
        }
    }

    val currentEdit = editing
    if (adding || currentEdit != null) {
        PhaseEditorDialog(
            plan = plan,
            current = currentEdit,
            nextOrder = (ordered.maxOfOrNull { it.phaseOrder } ?: 0) + 1,
            states = states,
            snapshots = snapshots,
            onDismiss = { adding = false; editing = null },
            onSave = { draft ->
                scope.launch {
                    try {
                        withContext(Dispatchers.IO) { AppGraph.repo.savePlanPhase(draft) }
                        adding = false; editing = null; reload(false); onChanged(); message = "تم حفظ المرحلة"
                    } catch (e: Exception) { message = e.message ?: "تعذر حفظ المرحلة" }
                }
            },
        )
    }
}

@Composable
private fun PhaseEditorDialog(
    plan: PlanRow,
    current: SmartPlanPhaseRow?,
    nextOrder: Int,
    states: List<SmartPlanPhaseStateRow>,
    snapshots: List<PlanSnapshot>,
    onDismiss: () -> Unit,
    onSave: (SmartPlanPhaseDraft) -> Unit,
) {
    val source = current
    var type by remember(source?.id) { mutableStateOf(source?.phaseType ?: if (nextOrder == 1) "hifz" else "sard") }
    var title by remember(source?.id) { mutableStateOf(source?.title ?: if (type == "sard") "مرحلة السرد" else "مرحلة الحفظ") }
    var startDate by remember(source?.id) { mutableStateOf(source?.startDate ?: plan.startDate) }
    var endDate by remember(source?.id) { mutableStateOf(source?.endDate ?: plan.endDate) }
    var goalMode by remember(source?.id) { mutableStateOf(source?.goalMode ?: if (type == "sard") "juz" else "pages") }
    var target by remember(source?.id) { mutableStateOf((source?.targetUnits ?: source?.targetPages ?: if (type == "sard") 3.0 else plan.target).let(::phaseNumber)) }
    var distribution by remember(source?.id) { mutableStateOf(source?.distributionMode ?: "flexible") }
    var startMode by remember(source?.id) { mutableStateOf(source?.startMode ?: if (type == "sard") "last_sard" else "plan_start") }
    var weekdays by remember(source?.id) { mutableStateOf((source?.scheduleWeekdays ?: if (type == "sard") listOf(0,1,2,3,4,5) else plan.scheduleWeekdays.ifEmpty { listOf(0,1,2,3,4) }).toSet()) }
    var allowSurplus by remember(source?.id) { mutableStateOf(source?.allowSurplus ?: true) }
    var rangeStartPage by remember(source?.id) { mutableStateOf(source?.rangeStartPage) }
    var rangeEndPage by remember(source?.id) { mutableStateOf(source?.rangeEndPage) }
    var rangeStartSurah by remember(source?.id) { mutableStateOf(source?.rangeStartSurah) }
    var rangeStartAyah by remember(source?.id) { mutableStateOf(source?.rangeStartAyah) }
    var rangeEndSurah by remember(source?.id) { mutableStateOf(source?.rangeEndSurah) }
    var rangeEndAyah by remember(source?.id) { mutableStateOf(source?.rangeEndAyah) }
    var showRange by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var pendingDraft by remember(source?.id) { mutableStateOf<SmartPlanPhaseDraft?>(null) }
    val weekdaysAr = listOf("أح", "اث", "ثل", "أر", "خم", "جم", "سب")

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (source == null) "إضافة مرحلة" else "تعديل المرحلة") },
        text = {
            LazyColumn(modifier = Modifier.fillMaxWidth().heightIn(max = 610.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                item {
                    Text("نوع المرحلة", style = MaterialTheme.typography.labelLarge)
                    Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                        ProFilterChip(type == "hifz", { type="hifz"; if (source==null) { title="مرحلة الحفظ"; goalMode="pages"; startMode="plan_start" } }, "حفظ")
                        ProFilterChip(type == "sard", { type="sard"; if (source==null) { title="مرحلة السرد"; goalMode="juz"; startMode="last_sard" } }, "سرد")
                    }
                }
                item { OutlinedTextField(title, { title=it }, label={Text("اسم المرحلة")}, modifier=Modifier.fillMaxWidth(), singleLine=true) }
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(startDate,{startDate=it},label={Text("البداية")},modifier=Modifier.weight(1f),singleLine=true)
                        OutlinedTextField(endDate,{endDate=it},label={Text("النهاية")},modifier=Modifier.weight(1f),singleLine=true)
                    }
                }
                item {
                    Text("أيام المرحلة", style = MaterialTheme.typography.labelLarge)
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                        weekdaysAr.forEachIndexed { i,label -> ProFilterChip(i in weekdays, { weekdays=if(i in weekdays) weekdays-i else weekdays+i }, label) }
                    }
                }
                item {
                    Text("نوع الهدف", style = MaterialTheme.typography.labelLarge)
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("pages" to "صفحات", "juz" to "أجزاء", "quran_range" to "نطاق قرآني", "open" to "مفتوح").forEach { (k,l) ->
                            ProFilterChip(goalMode == k, { goalMode = k }, l)
                        }
                    }
                }
                if (goalMode != "open") item {
                    OutlinedTextField(target,{target=it.filter { ch -> ch.isDigit() || ch=='.' }},label={Text(if(goalMode=="juz") "عدد الأجزاء" else "الهدف بالصفحات")},modifier=Modifier.fillMaxWidth(),singleLine=true)
                }
                if (goalMode == "quran_range" || startMode == "manual" || startMode == "range_start") item {
                    OutlinedButton(onClick={showRange=true}, modifier=Modifier.fillMaxWidth()) {
                        Icon(Icons.Default.AutoStories,null); Spacer(Modifier.width(5.dp)); Text(if(rangeStartSurah!=null) "تعديل النطاق القرآني" else "اختيار النطاق القرآني")
                    }
                }
                if (type == "sard") item {
                    Text("ابدأ من", style = MaterialTheme.typography.labelLarge)
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("last_sard" to "آخر سرد", "manual" to "يدوي", "range_start" to "بداية النطاق").forEach { (k,l) -> ProFilterChip(startMode == k, { startMode = k }, l) }
                    }
                }
                item {
                    Text("التوزيع", style = MaterialTheme.typography.labelLarge)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        ProFilterChip(distribution == "equal", { distribution = "equal" }, "متساوٍ")
                        ProFilterChip(distribution == "flexible", { distribution = "flexible" }, "مرن")
                    }
                }
                item {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("استمرار إضافي بعد إكمال الهدف", modifier=Modifier.weight(1f))
                        Switch(checked=allowSurplus,onCheckedChange={allowSurplus=it})
                    }
                }
                error?.let { item { Text(it,color=MaterialTheme.colorScheme.error) } }
            }
        },
        confirmButton = {
            Button(onClick={
                try {
                    val s=LocalDate.parse(startDate); val e=LocalDate.parse(endDate); require(e>=s){"الفترة غير صالحة"}; require(weekdays.isNotEmpty()){"اختر أيام المرحلة"}
                    val numeric=target.toDoubleOrNull()
                    if(goalMode!="open") require(numeric!=null && numeric>0){"حدد الهدف"}
                    val pages=when(goalMode){"juz"->numeric?.times(20.0); "open"->null; else->numeric}
                    val units=when(goalMode){"juz"->numeric; "open"->null; else->numeric}
                    val draft = SmartPlanPhaseDraft(
                        id=source?.id, planId=plan.id, phaseOrder=source?.phaseOrder ?: nextOrder, phaseType=type, title=title,
                        startDate=startDate,endDate=endDate,scheduleWeekdays=weekdays.sorted(),goalMode=goalMode,
                        goalUnit=when(goalMode){"juz"->"juz";"quran_range"->"range";"open"->"open";else->"pages"},
                        targetUnits=units,targetPages=pages,distributionMode=distribution,startMode=startMode,
                        rangeStartPage=rangeStartPage,rangeEndPage=rangeEndPage,rangeStartSurah=rangeStartSurah,rangeStartAyah=rangeStartAyah,
                        rangeEndSurah=rangeEndSurah,rangeEndAyah=rangeEndAyah,allowSurplus=allowSurplus,status=source?.status ?: "active",
                    )
                    if (source == null) onSave(draft) else pendingDraft = draft
                } catch(e:Exception){error=e.message ?: "تحقق من البيانات"}
            }){Text(if (source == null) "اعتماد" else "معاينة التعديل")}
        },
        dismissButton = { TextButton(onClick=onDismiss){Text("إلغاء")} },
    )

    pendingDraft?.let { draft ->
        val stateCount = source?.let { src -> states.count { it.phaseId == src.id && it.status in setOf("active", "completed") } } ?: 0
        val sample = source?.let { src -> snapshots.firstOrNull { it.phase?.id == src.id } }
        val sampleCompleted = sample?.phaseProgress?.completedPages
        val newTarget = draft.targetPages ?: draft.targetUnits?.takeIf { draft.goalMode == "juz" }?.times(20.0)
        val previewStart = runCatching { LocalDate.parse(draft.startDate) }.getOrNull()
        val previewEnd = runCatching { LocalDate.parse(draft.endDate) }.getOrNull()
        val today = LocalDate.now()
        val remainingDays = if (previewStart != null && previewEnd != null) {
            val first = maxOf(today, previewStart)
            if (first > previewEnd) 0 else generateSequence(first) { it.plusDays(1) }
                .takeWhile { it <= previewEnd }
                .count { (it.dayOfWeek.value % 7) in draft.scheduleWeekdays }
        } else 0
        val sampleRemaining = if (sampleCompleted != null && newTarget != null) max(0.0, newTarget - sampleCompleted) else null
        AlertDialog(
            onDismissRequest = { pendingDraft = null },
            title = { Text("معاينة تأثير التعديل") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("الفترة الجديدة: ${draft.startDate} ← ${draft.endDate}")
                    Text("الهدف الجديد: ${newTarget?.let { "${phaseNumber(it)} ص" } ?: "مفتوح"}")
                    Text("هناك $stateCount طالب لديهم حالة منفذة/نشطة في هذه المرحلة.")
                    if (sampleCompleted != null) Text("مثال من التنفيذ الحالي: ${sample?.student?.fullName ?: "طالب"} أنجز ${phaseNumber(sampleCompleted)} ص.")
                    if (sampleRemaining != null) {
                        Text("المتبقي لهذا المثال: ${phaseNumber(sampleRemaining)} ص · الأيام المجدولة المتبقية: $remainingDays")
                        if (remainingDays > 0) Text("المقترح بعد التعديل ≈ ${phaseNumber(sampleRemaining / remainingDays)} ص/يوم، ثم يُعاد توزيعه حسب إنجاز الطالب.")
                    }
                    Text("التسميعات المنفذة لا تُحذف. سيُعاد حساب المقرر القادم فقط بعد اعتماد التعديل.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            },
            confirmButton = {
                Button(onClick = { pendingDraft = null; onSave(draft) }) { Text("اعتماد التعديل") }
            },
            dismissButton = { TextButton(onClick = { pendingDraft = null }) { Text("رجوع للتعديل") } },
        )
    }

    if (showRange) {
        QuranRangePickerDialog(
            initialStartPage = rangeStartPage,
            initialEndPage = rangeEndPage,
            initialStartSurah = rangeStartSurah,
            initialStartAyah = rangeStartAyah,
            initialEndSurah = rangeEndSurah,
            initialEndAyah = rangeEndAyah,
            track = if (type == "hifz") "general_hifz" else "tathbit",
            activityType = if (type == "sard") "sard" else "new_hifz",
            direction = QuranTraversalDirection.AUTO_BY_ACTIVITY,
            onDismiss = { showRange = false },
            onConfirm = { selected ->
                rangeStartPage=selected.startPage; rangeEndPage=selected.endPage
                rangeStartSurah=selected.start?.surah; rangeStartAyah=selected.start?.ayah
                rangeEndSurah=selected.end?.surah; rangeEndAyah=selected.end?.ayah
                if (goalMode == "quran_range") target = phaseNumber(selected.exactPages)
                showRange=false
            },
        )
    }
}


private fun templateModeAr(mode: String): String = when (mode) {
    "dates" -> "بالتاريخ"
    "weeks" -> "بالأسابيع"
    else -> "يدوي"
}

private fun phaseTitle(phase: SmartPlanPhaseRow): String = phase.title.ifBlank { if (phase.phaseType == "sard") "مرحلة السرد" else "مرحلة الحفظ" }

private fun phaseGoalText(phase: SmartPlanPhaseRow): String = when (phase.goalMode) {
    "open" -> "الهدف: سرد مفتوح"
    "juz" -> "الهدف: ${phaseNumber(phase.targetUnits ?: ((phase.targetPages ?: 0.0) / 20.0))} جزء"
    "quran_range" -> "الهدف: نطاق قرآني · ${phase.targetPages?.let { "${phaseNumber(it)} ص" } ?: "حسب النطاق"}"
    else -> "الهدف: ${phaseNumber(phase.targetPages ?: 0.0)} صفحة"
}

private fun phaseNumber(value: Double): String {
    val rounded = kotlin.math.round(value * 10.0) / 10.0
    return if (kotlin.math.abs(rounded - rounded.toInt()) < .0001) rounded.toInt().toString() else rounded.toString()
}

private fun LocalDate.coerceAtLeast(other: LocalDate): LocalDate = if (this < other) other else this
