package com.mohammedsamir.halaqati.documents

import android.graphics.Color
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView

/**
 * Visible RC13 preview. It renders the exact HTML/CSS later printed by [VectorDocumentRenderer].
 * Network is blocked; all assets are local/data URLs.
 */
@Composable
fun HtmlDocumentPreview(
    html: String,
    modifier: Modifier = Modifier,
    zoom: Float = 1f,
) {
    AndroidView(
        modifier = modifier,
        factory = { context ->
            WebView(context).apply {
                setBackgroundColor(Color.TRANSPARENT)
                settings.javaScriptEnabled = true
                settings.domStorageEnabled = false
                settings.allowContentAccess = false
                settings.allowFileAccess = true
                settings.blockNetworkLoads = true
                settings.cacheMode = WebSettings.LOAD_NO_CACHE
                settings.loadWithOverviewMode = true
                settings.useWideViewPort = true
                settings.builtInZoomControls = false
                settings.displayZoomControls = false
                settings.defaultTextEncodingName = "UTF-8"
                settings.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
                webViewClient = WebViewClient()
            }
        },
        update = { view ->
            val signature = "${html.hashCode()}:${zoom.coerceIn(.7f, 1.2f)}"
            if (view.tag != signature) {
                view.tag = signature
                view.loadDataWithBaseURL(
                    "file:///android_asset/documents/",
                    html,
                    "text/html",
                    "UTF-8",
                    null,
                )
                val scale = (zoom.coerceIn(.7f, 1.2f) * 100f).toInt()
                view.setInitialScale(scale)
            }
        },
    )
}
