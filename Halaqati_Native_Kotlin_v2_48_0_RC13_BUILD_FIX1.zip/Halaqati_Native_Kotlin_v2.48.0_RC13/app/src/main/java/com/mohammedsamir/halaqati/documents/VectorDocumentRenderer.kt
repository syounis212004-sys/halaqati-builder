package com.mohammedsamir.halaqati.documents

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.print.HalaqatiWebViewPdfWriter
import android.print.PrintAttributes
import android.print.PrintDocumentAdapter
import android.print.PrintDocumentInfo
import android.print.PageRange
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import java.io.File
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

enum class DocumentOrientation { LANDSCAPE, PORTRAIT }

data class VectorPdfResult(
    val pageCount: Int,
    val bytes: Long,
    val engine: String = "chromium-webview-vector",
)

/**
 * RC13 one-source document renderer.
 *
 * Both certificate and report PDFs are produced by Chromium/WebView from the same HTML/CSS
 * used by the visible preview. No Android Canvas/PdfDocument raster document path is used.
 */
object VectorDocumentRenderer {
    private const val READY_TIMEOUT_MS = 20_000L
    private const val WRITE_TIMEOUT_MS = 90_000L

    suspend fun saveHtmlPdf(
        context: Context,
        uri: Uri,
        html: String,
        documentName: String,
        orientation: DocumentOrientation,
    ): VectorPdfResult {
        require(html.isNotBlank()) { "محتوى المستند فارغ" }
        val descriptor = withContext(Dispatchers.IO) {
            context.contentResolver.openFileDescriptor(uri, "w") ?: error("تعذر فتح ملف PDF للحفظ")
        }
        return saveHtmlPdf(context, descriptor, html, documentName, orientation)
    }

    suspend fun saveHtmlPdfToFile(
        context: Context,
        file: File,
        html: String,
        documentName: String,
        orientation: DocumentOrientation,
    ): VectorPdfResult {
        require(html.isNotBlank()) { "محتوى المستند فارغ" }
        withContext(Dispatchers.IO) {
            file.parentFile?.mkdirs()
            if (file.exists()) file.delete()
        }
        val descriptor = withContext(Dispatchers.IO) {
            ParcelFileDescriptor.open(
                file,
                ParcelFileDescriptor.MODE_CREATE or ParcelFileDescriptor.MODE_TRUNCATE or ParcelFileDescriptor.MODE_READ_WRITE,
            )
        }
        val result = saveHtmlPdf(context, descriptor, html, documentName, orientation)
        return result.copy(bytes = withContext(Dispatchers.IO) { file.length() })
    }

    private suspend fun saveHtmlPdf(
        context: Context,
        descriptor: ParcelFileDescriptor,
        html: String,
        documentName: String,
        orientation: DocumentOrientation,
    ): VectorPdfResult {
        val activity = context.findActivity() ?: error("يلزم فتح المستند من واجهة التطبيق")
        return try {
            withTimeout(WRITE_TIMEOUT_MS) {
                withContext(Dispatchers.Main.immediate) {
                    val webView = createPdfWebView(activity)
                    try {
                        loadAndAwaitReady(webView, html)
                        val adapter = webView.createPrintDocumentAdapter(documentName)
                        writeAdapter(adapter, descriptor, orientation)
                    } finally {
                        runCatching { webView.stopLoading() }
                        runCatching { webView.loadUrl("about:blank") }
                        runCatching { webView.removeAllViews() }
                        runCatching { webView.destroy() }
                    }
                }
            }
        } catch (t: Throwable) {
            runCatching { descriptor.close() }
            throw t
        }
    }

    private fun createPdfWebView(activity: Activity): WebView = WebView(activity).apply {
        setBackgroundColor(android.graphics.Color.WHITE)
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = false
        settings.allowContentAccess = false
        settings.allowFileAccess = true
        settings.blockNetworkLoads = true
        settings.cacheMode = WebSettings.LOAD_NO_CACHE
        settings.loadWithOverviewMode = false
        settings.useWideViewPort = true
        settings.defaultTextEncodingName = "UTF-8"
        settings.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
    }

    private suspend fun loadAndAwaitReady(webView: WebView, html: String) {
        suspendCancellableCoroutine<Unit> { cont ->
            val terminal = AtomicBoolean(false)
            webView.webViewClient = object : WebViewClient() {
                override fun onPageFinished(view: WebView, url: String?) {
                    if (terminal.get()) return
                    view.post {
                        if (terminal.compareAndSet(false, true) && cont.isActive) cont.resume(Unit)
                    }
                }
            }
            cont.invokeOnCancellation {
                terminal.set(true)
                runCatching { webView.stopLoading() }
            }
            webView.loadDataWithBaseURL(
                "file:///android_asset/documents/",
                html,
                "text/html",
                "UTF-8",
                null,
            )
        }
        withTimeout(READY_TIMEOUT_MS) {
            while (true) {
                when (evaluateReady(webView)) {
                    1 -> break
                    -1 -> error("فشل فحص تخطيط المستند: يوجد تداخل أو محتوى خارج حدود A4")
                    else -> delay(80)
                }
            }
        }
    }

    /** 1=ready, 0=waiting, -1=layout rejected by the document preflight. */
    private suspend fun evaluateReady(webView: WebView): Int = suspendCancellableCoroutine { cont ->
        val js = """
            (function(){
              try {
                var fonts = (!document.fonts || document.fonts.status === 'loaded');
                var images = Array.prototype.every.call(document.images || [], function(i){return i.complete;});
                var app = (window.__HALAQATI_READY__ === true || window.__HALAQATI_READY__ === 'READY');
                if (!(document.readyState === 'complete' && fonts && images && app)) return 'WAIT';
                if (window.__HALAQATI_LAYOUT_OK__ === false || document.documentElement.dataset.layoutOk === '0') return 'LAYOUT_ERROR';
                return 'READY';
              } catch(e) { return 'WAIT'; }
            })();
        """.trimIndent()
        webView.evaluateJavascript(js) { raw ->
            if (cont.isActive) {
                when (raw?.replace("\"", "")) {
                    "READY" -> cont.resume(1)
                    "LAYOUT_ERROR" -> cont.resume(-1)
                    else -> cont.resume(0)
                }
            }
        }
    }

    private suspend fun writeAdapter(
        adapter: PrintDocumentAdapter,
        descriptor: ParcelFileDescriptor,
        orientation: DocumentOrientation,
    ): VectorPdfResult = suspendCancellableCoroutine { cont ->
        val media = when (orientation) {
            DocumentOrientation.PORTRAIT -> PrintAttributes.MediaSize.ISO_A4.asPortrait()
            DocumentOrientation.LANDSCAPE -> PrintAttributes.MediaSize.ISO_A4.asLandscape()
        }
        val attrs = PrintAttributes.Builder()
            .setMediaSize(media)
            .setResolution(PrintAttributes.Resolution("halaqati-vector", "Halaqati Vector", 600, 600))
            .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
            .setColorMode(PrintAttributes.COLOR_MODE_COLOR)
            .build()
        val done = AtomicBoolean(false)
        cont.invokeOnCancellation {
            if (done.compareAndSet(false, true)) {
                runCatching { descriptor.close() }
                runCatching { adapter.onFinish() }
            }
        }
        HalaqatiWebViewPdfWriter.write(adapter, attrs, descriptor, object : HalaqatiWebViewPdfWriter.Callback {
            override fun onSuccess(info: PrintDocumentInfo?, pages: Array<PageRange>?) {
                if (!done.compareAndSet(false, true) || !cont.isActive) return
                val pageCount = info?.pageCount ?: -1
                cont.resume(VectorPdfResult(pageCount = pageCount, bytes = -1L))
            }

            override fun onFailure(message: String?) {
                if (!done.compareAndSet(false, true) || !cont.isActive) return
                cont.resumeWithException(IllegalStateException(message ?: "تعذر إنشاء PDF المتجهي"))
            }

            override fun onCancelled() {
                if (!done.compareAndSet(false, true) || !cont.isActive) return
                cont.resumeWithException(IllegalStateException("تم إلغاء إنشاء PDF"))
            }
        })
    }
}

private tailrec fun Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
}
