package com.mohammedsamir.halaqati.documents

import android.graphics.Color
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView

private data class PreviewRenderState(
    val htmlHash: Int,
    val zoom: Float,
)

/**
 * Visible RC13 preview. It renders the exact HTML/CSS later printed by [VectorDocumentRenderer].
 *
 * The document itself keeps its fixed A4 layout width (1122px landscape / 792px portrait).
 * WebView's overview mode performs the fit-to-width. The optional zoom is then applied relative
 * to that fitted scale. This avoids the old bug where setInitialScale(94/100) forced a literal
 * 94%-100% page scale on a phone viewport, cropping the page and making the layout look broken.
 */
@Composable
fun HtmlDocumentPreview(
    html: String,
    modifier: Modifier = Modifier,
    zoom: Float = 1f,
) {
    val safeZoom = zoom.coerceIn(.7f, 1.2f)
    AndroidView(
        modifier = modifier,
        factory = { context ->
            WebView(context).apply {
                setBackgroundColor(Color.TRANSPARENT)
                settings.javaScriptEnabled = true
                settings.domStorageEnabled = false
                settings.allowContentAccess = false
                settings.allowFileAccess = true
                settings.blockNetworkLoads = true
                settings.cacheMode = WebSettings.LOAD_NO_CACHE
                settings.loadWithOverviewMode = true
                settings.useWideViewPort = true
                settings.setSupportZoom(true)
                settings.builtInZoomControls = false
                settings.displayZoomControls = false
                settings.defaultTextEncodingName = "UTF-8"
                settings.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
                setInitialScale(0) // 0 = let WebView compute fit-to-width from the wide viewport.
                webViewClient = object : WebViewClient() {
                    override fun onPageFinished(view: WebView, url: String?) {
                        val state = view.tag as? PreviewRenderState ?: return
                        view.post {
                            // Overview mode establishes the A4 fit first. Zoom is relative to it.
                            if (kotlin.math.abs(state.zoom - 1f) > .001f) {
                                runCatching { view.zoomBy(state.zoom) }
                            }
                            view.scrollTo(0, 0)
                        }
                    }
                }
            }
        },
        update = { view ->
            val previous = view.tag as? PreviewRenderState
            val next = PreviewRenderState(html.hashCode(), safeZoom)
            if (previous?.htmlHash != next.htmlHash) {
                view.tag = next
                view.setInitialScale(0)
                view.loadDataWithBaseURL(
                    "file:///android_asset/documents/",
                    html,
                    "text/html",
                    "UTF-8",
                    null,
                )
            } else if (previous != null && kotlin.math.abs(previous.zoom - next.zoom) > .001f) {
                view.tag = next
                val ratio = (next.zoom / previous.zoom).coerceIn(.5f, 2f)
                runCatching { view.zoomBy(ratio) }
            } else if (previous == null) {
                view.tag = next
            }
        },
    )
}
