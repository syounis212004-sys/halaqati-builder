package com.mohammedsamir.halaqati.ui.guardian

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.mohammedsamir.halaqati.ui.components.AppTopBar
import com.mohammedsamir.halaqati.ui.components.EmptyState
import com.mohammedsamir.halaqati.ui.components.LoadingSkeleton
import com.mohammedsamir.halaqati.ui.components.StateNotice
import com.mohammedsamir.halaqati.ui.components.ProFilterChip
import com.mohammedsamir.halaqati.ui.theme.HalaqatiUiTokens
import java.util.Locale

/**
 * RC17 guardian home. Child-first, read-only, no teacher/session actions anywhere.
 * Order: child switcher → today → month plan → compact metrics → last recitations → shortcuts.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GuardianHomeScreen(
    navigate: (String) -> Unit,
    vm: GuardianHomeViewModel = viewModel(),
) {
    val state by vm.state.collectAsStateWithLifecycle()
    LaunchedEffect(Unit) { vm.start() }
    val overview = state.overview

    Column(Modifier.fillMaxSize()) {
        AppTopBar(title = "اطمئن على رحلته", kicker = "ولي الأمر · متابعة الأبناء")
        PullToRefreshBox(
            isRefreshing = state.refreshing && overview != null,
            onRefresh = { vm.refresh() },
            modifier = Modifier.weight(1f).fillMaxWidth(),
        ) {
            LazyColumn(
                Modifier.fillMaxSize(),
                contentPadding = PaddingValues(start = HalaqatiUiTokens.ScreenHorizontal, end = HalaqatiUiTokens.ScreenHorizontal, top = 4.dp, bottom = 24.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                if (state.children.size > 1) {
                    item(key = "switcher", contentType = "switcher") {
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(state.children, key = { it.id }) { child ->
                                ProFilterChip(
                                    selected = child.id == state.selectedId,
                                    onClick = { vm.select(child.id) },
                                    label = child.name.substringBefore(' '),
                                )
                            }
                        }
                    }
                }
                if (state.stale && overview != null) {
                    item(key = "stale", contentType = "notice") {
                        StateNotice("تعرض آخر بيانات محفوظة${overview.updatedAt?.let { " · " + shortTime(it) } ?: ""}", kind = "warning")
                    }
                }
                state.message?.let { msg -> item(key = "msg", contentType = "notice") { StateNotice(msg, kind = "error") } }
                when {
                    overview == null && (state.loadingFirst || state.refreshing) ->
                        item(key = "loading", contentType = "loading") { LoadingSkeleton(rows = 3) }
                    overview == null && state.children.isEmpty() && !state.loadingFirst ->
                        item(key = "empty", contentType = "empty") { EmptyState("لا توجد ملفات طلاب مرتبطة بهذا الحساب") }
                    overview != null -> {
                        item(key = "today", contentType = "today") { TodayCard(overview) }
                        if (overview.planTitle != null) item(key = "plan", contentType = "plan") { PlanCard(overview) }
                        item(key = "metrics", contentType = "metrics") { MetricsStrip(overview) }
                        if (overview.latest.isNotEmpty()) {
                            item(key = "latest-title", contentType = "title") {
                                Text("آخر التسميعات", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            }
                            items(overview.latest, contentType = { "recitation" }) { line ->
                                RecitationRow(line)
                            }
                        }
                        item(key = "shortcuts", contentType = "shortcuts") {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedButton(onClick = { navigate("guardian_profile") }, modifier = Modifier.weight(1f).heightIn(min = 48.dp)) { Text("ملف الابن") }
                                OutlinedButton(onClick = { navigate("guardian_achievements") }, modifier = Modifier.weight(1f).heightIn(min = 48.dp)) { Text("الإنجاز") }
                                OutlinedButton(onClick = { navigate("guardian_competition") }, modifier = Modifier.weight(1f).heightIn(min = 48.dp)) { Text("المنافسة") }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun TodayCard(o: GuardianOverview) {
    val attendance = when (o.todayAttendance) {
        "present" -> "حضر اليوم"
        "late" -> "حضر اليوم (متأخر)"
        "absent" -> "غائب اليوم"
        "excused" -> "غائب بعذر اليوم"
        null -> "لم يُسجَّل الحضور بعد"
        else -> "الحضور: ${o.todayAttendance}"
    }
    Card(
        Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(HalaqatiUiTokens.RadiusHero),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.primary,
            contentColor = MaterialTheme.colorScheme.onPrimary,
        ),
    ) {
        Column(Modifier.padding(horizontal = 22.dp, vertical = 20.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Text(
                listOf(o.trackLabel, o.subtitle).filter { it.isNotBlank() }.joinToString(" · "),
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onPrimary.copy(alpha = .76f),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Text(o.childName, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Text(
                if (o.todayRecited) "$attendance وأتمّ ${if (o.tathbit) "التثبيت" else "التسميع"}" else attendance,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold,
            )
            if (o.todayRecited) {
                o.todayRange?.let { Text(it, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onPrimary.copy(alpha = .86f)) }
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.onPrimary.copy(alpha = .10f),
                ) {
                    Text(
                        "${if (o.tathbit) "تثبيت" else "تسميع"} اليوم: ${num(o.todayPages)} صفحة",
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp),
                        style = MaterialTheme.typography.labelMedium,
                    )
                }
            } else {
                Text(
                    if (o.tathbit) "لم يُسجَّل تثبيت اليوم بعد" else "لم يُسجَّل تسميع اليوم بعد",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onPrimary.copy(alpha = .76f),
                )
            }
        }
    }
}

@Composable
private fun PlanCard(o: GuardianOverview) {
    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(HalaqatiUiTokens.RadiusCard), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(o.planTitle.orEmpty(), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                Text("${num(o.planPercent)}٪", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.primary)
            }
            LinearProgressIndicator(progress = { (o.planPercent / 100.0).toFloat() }, modifier = Modifier.fillMaxWidth().height(7.dp), trackColor = MaterialTheme.colorScheme.outlineVariant)
            Text("${num(o.planDone)} / ${num(o.planTarget)} صفحة · المتبقي ${num(o.planRemaining)}", style = MaterialTheme.typography.bodyMedium)
        }
    }
}

@Composable
private fun MetricsStrip(o: GuardianOverview) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Metric(o.monthMainLabel, "${num(o.monthMain)} ص", Modifier.weight(1f))
        Metric("الحضور", "${o.monthPresent}/${o.monthSessions}", Modifier.weight(1f))
        Metric("الجودة", o.quality?.let { "${num(it)}٪" } ?: "—", Modifier.weight(1f))
    }
}

@Composable
private fun Metric(label: String, value: String, modifier: Modifier) {
    Surface(modifier, shape = RoundedCornerShape(HalaqatiUiTokens.RadiusMetric), color = MaterialTheme.colorScheme.surface) {
        Column(Modifier.padding(vertical = 14.dp, horizontal = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(value, fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.titleMedium, maxLines = 1)
            Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
        }
    }
}

@Composable
private fun RecitationRow(line: GuardianRecitationLine) {
    Surface(Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp), color = MaterialTheme.colorScheme.surface, tonalElevation = 0.dp) {
        Column(Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Row {
                Text("${line.activityLabel} · ${line.date}", fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f), maxLines = 1)
                Text("${num(line.pages)} ص${line.quality?.let { " · ${num(it)}٪" } ?: ""}", style = MaterialTheme.typography.labelMedium)
            }
            Text(line.range, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

private fun num(v: Double): String {
    val r = kotlin.math.round(v * 100) / 100
    return if (kotlin.math.abs(r - r.toLong()) < 1e-6) r.toLong().toString() else String.format(Locale.US, "%.2f", r).trimEnd('0').trimEnd('.')
}

private fun shortTime(iso: String): String = runCatching {
    java.time.OffsetDateTime.parse(iso).atZoneSameInstant(java.time.ZoneId.systemDefault())
        .format(java.time.format.DateTimeFormatter.ofPattern("d/M HH:mm", Locale.US))
}.getOrDefault("")
