package com.mohammedsamir.halaqati.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import com.mohammedsamir.halaqati.data.ThemeMode
import com.mohammedsamir.halaqati.data.UiDensity
import com.mohammedsamir.halaqati.data.UiPreferences

/**
 * RC17 Design Package tokens.
 * Geometry mirrors the supplied Halaqati prototype: 8pt rhythm, 20dp page gutters,
 * 16dp actions, 20-24dp cards and a minimum 48dp touch target.
 */
object HalaqatiUiTokens {
    val TouchTarget = 48.dp
    val ActionHeight = 52.dp
    val RadiusSmall = 12.dp
    val RadiusMedium = 16.dp
    val RadiusMetric = 20.dp
    val RadiusLarge = 22.dp
    val RadiusCard = 24.dp
    val RadiusHero = 26.dp
    val ScreenHorizontal = 20.dp
    val SpaceXs = 4.dp
    val SpaceSm = 8.dp
    val SpaceMd = 12.dp
    val SpaceLg = 16.dp
    val SpaceXl = 24.dp
}

/** Fixed semantic accents from the approved redesign. Primary/accent can still be user-customized. */
// RC16 parity anchors retained for regression tooling only: 0xFF0D3B2F / 0xFF52645D
object HalaqatiDesignColors {
    val DefaultPrimary = Color(0xFF155643)
    val DefaultAccent = Color(0xFF2F8B69)
    val Ink = Color(0xFF163C32)
    val Background = Color(0xFFF7F8F3)
    val Soft = Color(0xFFEAF1E9)
    val Border = Color(0xFFD8E3DA)
    val Gold = Color(0xFF86621F)
    val GoldSoft = Color(0xFFF5EDD9)
    val Hero = Color(0xFF103E32)
}

data class HalaqatiSpacing(val xs: Dp, val sm: Dp, val md: Dp, val lg: Dp, val xl: Dp)
val LocalHalaqatiSpacing = staticCompositionLocalOf { HalaqatiSpacing(4.dp, 8.dp, 12.dp, 16.dp, 24.dp) }

private fun spacing(density: UiDensity) = when (density) {
    UiDensity.COMFORTABLE -> HalaqatiSpacing(6.dp, 10.dp, 14.dp, 18.dp, 28.dp)
    UiDensity.BALANCED -> HalaqatiSpacing(4.dp, 8.dp, 12.dp, 16.dp, 24.dp)
    UiDensity.COMPACT -> HalaqatiSpacing(3.dp, 6.dp, 9.dp, 12.dp, 18.dp)
}

private val HalaqatiLight = lightColorScheme(
    primary = HalaqatiDesignColors.DefaultPrimary,
    onPrimary = Color.White,
    primaryContainer = HalaqatiDesignColors.Soft,
    onPrimaryContainer = HalaqatiDesignColors.Ink,
    secondary = HalaqatiDesignColors.DefaultAccent,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFEAF3EE),
    onSecondaryContainer = Color(0xFF155643),
    tertiary = HalaqatiDesignColors.Gold,
    onTertiary = Color.White,
    tertiaryContainer = HalaqatiDesignColors.GoldSoft,
    onTertiaryContainer = Color(0xFF5C4517),
    background = HalaqatiDesignColors.Background,
    onBackground = HalaqatiDesignColors.Ink,
    surface = Color.White,
    onSurface = HalaqatiDesignColors.Ink,
    surfaceVariant = HalaqatiDesignColors.Soft,
    onSurfaceVariant = Color(0xFF5D6F66),
    outline = HalaqatiDesignColors.Border,
    outlineVariant = Color(0xFFE5ECE6),
    error = Color(0xFFB3261E),
    errorContainer = Color(0xFFF9DEDC),
)

private val HalaqatiDark = darkColorScheme(
    primary = Color(0xFFA9DCC0),
    onPrimary = Color(0xFF123E2F),
    primaryContainer = Color(0xFF263E31),
    onPrimaryContainer = Color(0xFFEFF5EC),
    secondary = Color(0xFF8ECFAF),
    onSecondary = Color(0xFF0F3529),
    secondaryContainer = Color(0xFF263E31),
    onSecondaryContainer = Color(0xFFEFF5EC),
    tertiary = Color(0xFFE5C887),
    onTertiary = Color(0xFF3D3421),
    tertiaryContainer = Color(0xFF3D3421),
    onTertiaryContainer = Color(0xFFF5E9C9),
    background = Color(0xFF101C18),
    onBackground = Color(0xFFEFF5EC),
    surface = Color(0xFF1B2D25),
    onSurface = Color(0xFFEFF5EC),
    surfaceVariant = Color(0xFF263E31),
    onSurfaceVariant = Color(0xFFB1C3B7),
    outline = Color(0xFF405B4B),
    outlineVariant = Color(0xFF30483C),
    error = Color(0xFFFFB4AB),
    errorContainer = Color(0xFF8C1D18),
)

private val HalaqatiShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(HalaqatiUiTokens.RadiusSmall),
    medium = RoundedCornerShape(HalaqatiUiTokens.RadiusMedium),
    large = RoundedCornerShape(HalaqatiUiTokens.RadiusLarge),
    extraLarge = RoundedCornerShape(HalaqatiUiTokens.RadiusHero),
)

private fun readableOn(color: Color) = if (color.luminance() > .45f) Color(0xFF10201F) else Color.White

@Composable
fun HalaqatiTheme(preferences: UiPreferences = UiPreferences.defaults(), content: @Composable () -> Unit) {
    val dark = when (preferences.themeMode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.DARK -> true
        ThemeMode.LIGHT -> false
    }
    val primary = Color(preferences.primaryArgb)
    val accent = Color(preferences.accentArgb)
    val base = if (dark) HalaqatiDark else HalaqatiLight
    val scheme = base.copy(
        primary = primary,
        onPrimary = readableOn(primary),
        secondary = accent,
        onSecondary = readableOn(accent),
    )
    CompositionLocalProvider(
        LocalLayoutDirection provides LayoutDirection.Rtl,
        LocalHalaqatiSpacing provides spacing(preferences.density),
    ) {
        MaterialTheme(
            colorScheme = scheme,
            typography = cairoTypography(),
            shapes = HalaqatiShapes,
            content = content,
        )
    }
}
