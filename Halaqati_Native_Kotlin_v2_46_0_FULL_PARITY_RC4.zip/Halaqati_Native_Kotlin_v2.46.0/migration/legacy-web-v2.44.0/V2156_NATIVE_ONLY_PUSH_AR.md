# v2.15.6 Native-only Push
تم حذف Capacitor PushNotifications من مسار التشغيل بالكامل. الإذن والتسجيل والاستقبال وعرض إشعار النظام أصبح Native عبر FirebaseMessagingService والجسر المحلي.
