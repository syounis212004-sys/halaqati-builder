package com.mohammedsamir.halaqati.deeplink;

import com.getcapacitor.Plugin;
import com.getcapacitor.annotation.CapacitorPlugin;

@CapacitorPlugin(name = "HalaqatiDeepLink")
public class HalaqatiDeepLinkPlugin extends Plugin {
}
