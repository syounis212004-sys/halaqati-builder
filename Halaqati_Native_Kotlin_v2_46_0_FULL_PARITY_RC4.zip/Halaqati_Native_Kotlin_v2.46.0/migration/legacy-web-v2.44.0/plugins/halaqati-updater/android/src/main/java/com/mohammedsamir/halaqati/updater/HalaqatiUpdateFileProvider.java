package com.mohammedsamir.halaqati.updater;

import androidx.core.content.FileProvider;

public class HalaqatiUpdateFileProvider extends FileProvider {
}
