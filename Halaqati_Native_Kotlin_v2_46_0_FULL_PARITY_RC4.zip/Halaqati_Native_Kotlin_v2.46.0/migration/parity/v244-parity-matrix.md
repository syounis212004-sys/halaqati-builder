# Halaqati 2.44 → Native parity matrix

Total features: **48** — **IMPROVED 2**, **MATCHED 1**, **MISSING 11**, **PARTIAL 34**

| ID | Roles | Native | Status |
|---|---|---|---|
| `shell.bottom.admin_supervisor_teacher` | ADMIN, SUPERVISOR, TEACHER | `app_shell` | **PARTIAL** |
| `shell.bottom.guardian` | GUARDIAN | `app_shell_guardian` | **PARTIAL** |
| `shell.more.menu` | ADMIN, SUPERVISOR, TEACHER, GUARDIAN | `more` | **PARTIAL** |
| `home.dashboard` | ADMIN, SUPERVISOR, TEACHER, GUARDIAN | `home` | **PARTIAL** |
| `home.daily_supervisor_board` | ADMIN, SUPERVISOR, TEACHER | `home` | **PARTIAL** |
| `notifications.center` | ADMIN, SUPERVISOR, TEACHER, GUARDIAN | `notifications` | **PARTIAL** |
| `notifications.push_preferences` | ADMIN, SUPERVISOR, TEACHER, GUARDIAN | `settings_notifications` | **MISSING** |
| `community.announcements` | ADMIN, SUPERVISOR, TEACHER, GUARDIAN | `community` | **PARTIAL** |
| `community.forum_comments` | ADMIN, SUPERVISOR, TEACHER, GUARDIAN | `community` | **PARTIAL** |
| `halaqas.manage` | ADMIN, SUPERVISOR, TEACHER | `halaqas` | **PARTIAL** |
| `categories.manage` | ADMIN, SUPERVISOR, TEACHER | `halaqas` | **PARTIAL** |
| `sessions.list` | ADMIN, SUPERVISOR, TEACHER | `sessions` | **PARTIAL** |
| `sessions.start_today` | ADMIN, SUPERVISOR, TEACHER | `session_live` | **PARTIAL** |
| `sessions.attendance` | ADMIN, SUPERVISOR, TEACHER | `sessions` | **PARTIAL** |
| `sessions.recitation` | ADMIN, SUPERVISOR, TEACHER | `sessions` | **PARTIAL** |
| `sessions.tathbit_activity` | ADMIN, SUPERVISOR, TEACHER | `sessions` | **PARTIAL** |
| `sessions.sard_activity` | ADMIN, SUPERVISOR, TEACHER | `sessions` | **PARTIAL** |
| `sessions.daily_notes` | ADMIN, SUPERVISOR, TEACHER | `sessions` | **PARTIAL** |
| `students.list` | ADMIN, SUPERVISOR, TEACHER | `students` | **PARTIAL** |
| `students.detail` | ADMIN, SUPERVISOR, TEACHER | `student_detail` | **MISSING** |
| `students.edit` | ADMIN, SUPERVISOR, TEACHER | `student_edit` | **MISSING** |
| `students.archive_restore` | ADMIN, SUPERVISOR, TEACHER | `students` | **MISSING** |
| `plans.list` | ADMIN, SUPERVISOR, TEACHER, GUARDIAN | `plans` | **PARTIAL** |
| `plans.smart_hifz` | ADMIN, SUPERVISOR, TEACHER | `plans` | **PARTIAL** |
| `plans.smart_tathbit` | ADMIN, SUPERVISOR, TEACHER | `plans` | **PARTIAL** |
| `plans.student_override` | ADMIN, SUPERVISOR, TEACHER | `plans` | **MISSING** |
| `plans.guardian_view` | GUARDIAN | `plans` | **PARTIAL** |
| `reports.list` | ADMIN, SUPERVISOR, TEACHER, GUARDIAN | `reports` | **PARTIAL** |
| `reports.studio` | ADMIN, SUPERVISOR, TEACHER | `report_studio` | **MISSING** |
| `reports.guardian` | GUARDIAN | `reports` | **PARTIAL** |
| `certificates.editor` | ADMIN, SUPERVISOR, TEACHER | `certificates` | **PARTIAL** |
| `quran.calculator_picker` | ADMIN, SUPERVISOR, TEACHER, GUARDIAN | `quran` | **PARTIAL** |
| `ranking.staff` | ADMIN, SUPERVISOR, TEACHER | `rankings` | **PARTIAL** |
| `guardian.competition` | GUARDIAN | `guardian_competition` | **MISSING** |
| `guardian.achievements` | GUARDIAN | `guardian_achievements` | **MISSING** |
| `guardian.profile` | GUARDIAN | `guardian_profile` | **PARTIAL** |
| `supervision.teacher_tracking` | ADMIN, SUPERVISOR | `supervision` | **PARTIAL** |
| `users.permissions` | ADMIN | `users` | **PARTIAL** |
| `data.import` | ADMIN, SUPERVISOR | `importexport` | **PARTIAL** |
| `data.export_backup` | ADMIN, SUPERVISOR, TEACHER | `importexport` | **PARTIAL** |
| `sync.center` | ADMIN, SUPERVISOR, TEACHER, GUARDIAN | `sync_center` | **IMPROVED** |
| `settings.theme` | ADMIN, SUPERVISOR, TEACHER, GUARDIAN | `settings` | **PARTIAL** |
| `settings.cairo_font` | ADMIN, SUPERVISOR, TEACHER, GUARDIAN | `settings` | **PARTIAL** |
| `settings.password` | ADMIN, SUPERVISOR, TEACHER, GUARDIAN | `settings` | **MISSING** |
| `settings.account_name` | ADMIN, SUPERVISOR, TEACHER, GUARDIAN | `settings` | **MISSING** |
| `settings.update` | ADMIN, SUPERVISOR, TEACHER, GUARDIAN | `settings` | **MISSING** |
| `auth.login_approval_recovery` | ADMIN, SUPERVISOR, TEACHER, GUARDIAN | `auth` | **MATCHED** |
| `offline.account_scoped_queue` | ADMIN, SUPERVISOR, TEACHER, GUARDIAN | `sync_center` | **IMPROVED** |
