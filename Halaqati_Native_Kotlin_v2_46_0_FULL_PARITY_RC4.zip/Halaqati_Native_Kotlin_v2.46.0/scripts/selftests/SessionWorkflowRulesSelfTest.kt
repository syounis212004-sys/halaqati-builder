import com.mohammedsamir.halaqati.ui.sessions.SessionWorkflowRules
fun main(){
    check(SessionWorkflowRules.sessionTypeForAssignment("sard")=="sard")
    check(SessionWorkflowRules.sessionTypeForAssignment("tathbit")=="review")
    check(SessionWorkflowRules.sessionTypeForAssignment("review")=="review")
    check(SessionWorkflowRules.sessionTypeForAssignment("test")=="test")
    check(SessionWorkflowRules.sessionTypeForAssignment("hifz")=="tasmee")
    check(SessionWorkflowRules.manualSessionTypes==listOf("tasmee","sard","review","test","tajweed","lesson","other"))
    println("SessionWorkflowRules self-tests passed")
}
