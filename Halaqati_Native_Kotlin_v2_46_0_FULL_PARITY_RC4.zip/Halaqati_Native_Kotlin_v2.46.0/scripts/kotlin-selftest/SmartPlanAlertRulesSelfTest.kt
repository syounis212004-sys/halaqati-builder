import com.mohammedsamir.halaqati.data.SmartPlanAlertRules

fun main() {
    check(!SmartPlanAlertRules.shouldSendDelay(2, 3))
    check(SmartPlanAlertRules.shouldSendDelay(3, 3))
    check(!SmartPlanAlertRules.shouldSendHomePrep(16, true, 10))
    check(SmartPlanAlertRules.shouldSendHomePrep(17, true, 10))
    check(SmartPlanAlertRules.preferredPlanType("sard") == "hifz")
    check(SmartPlanAlertRules.preferredPlanType("tathbit") == "tathbit")
    check(SmartPlanAlertRules.assignmentLabel("hifz", 20, 22) == "حفظ ص 20–22")
    println("SmartPlanAlertRules self-test passed")
}
