#!/usr/bin/env python3
"""Fetch the official Cairo variable font at build time and verify the pinned Git blob.
The source archive deliberately does not redistribute a raw font file; CI embeds the verified font into the APK before Gradle runs.
"""
from pathlib import Path
import hashlib, urllib.request

URL = 'https://raw.githubusercontent.com/google/fonts/main/ofl/cairo/Cairo%5Bslnt%2Cwght%5D.ttf'
EXPECTED_GIT_BLOB_SHA1 = '25641b1c828857698457bcd9f5a102616b4e8033'
ROOT = Path(__file__).resolve().parents[1]
DEST = ROOT / 'app/src/main/res/font/cairo.ttf'

def blob_sha1(data: bytes) -> str:
    return hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()

def main() -> None:
    DEST.parent.mkdir(parents=True, exist_ok=True)
    if DEST.exists():
        data = DEST.read_bytes()
        if blob_sha1(data) == EXPECTED_GIT_BLOB_SHA1:
            print('Cairo font already present and verified.')
            return
    with urllib.request.urlopen(URL, timeout=60) as response:
        data = response.read()
    actual = blob_sha1(data)
    if actual != EXPECTED_GIT_BLOB_SHA1:
        raise SystemExit(f'Cairo Git blob SHA-1 mismatch: {actual}')
    tmp = DEST.with_suffix('.tmp')
    tmp.write_bytes(data)
    tmp.replace(DEST)
    print(f'Embedded verified Cairo font ({len(data)} bytes).')

if __name__ == '__main__':
    main()
