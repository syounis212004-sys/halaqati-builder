package com.mohammedsamir.halaqati

import android.app.Application
import com.mohammedsamir.halaqati.data.AppGraph
import com.mohammedsamir.halaqati.push.NotificationHelper

class HalaqatiApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        AppGraph.init(this)
        NotificationHelper.ensureChannel(this)
    }
}
