package com.mohammedsamir.halaqati.ui.theme

import androidx.compose.material3.Typography
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import com.mohammedsamir.halaqati.R

/** Cairo is the single application typeface. The variable font is embedded by CI before Android resource processing. */
val CairoFamily = FontFamily(
    Font(R.font.cairo, FontWeight.Normal),
    Font(R.font.cairo, FontWeight.Medium),
    Font(R.font.cairo, FontWeight.SemiBold),
    Font(R.font.cairo, FontWeight.Bold),
)

fun cairoTypography() = Typography(
    displayLarge = TextStyle(fontFamily = CairoFamily, fontWeight = FontWeight.Bold, fontSize = 48.sp, lineHeight = 60.sp),
    displayMedium = TextStyle(fontFamily = CairoFamily, fontWeight = FontWeight.Bold, fontSize = 40.sp, lineHeight = 52.sp),
    displaySmall = TextStyle(fontFamily = CairoFamily, fontWeight = FontWeight.Bold, fontSize = 34.sp, lineHeight = 44.sp),
    headlineLarge = TextStyle(fontFamily = CairoFamily, fontWeight = FontWeight.Bold, fontSize = 30.sp, lineHeight = 40.sp),
    headlineMedium = TextStyle(fontFamily = CairoFamily, fontWeight = FontWeight.Bold, fontSize = 28.sp, lineHeight = 36.sp),
    headlineSmall = TextStyle(fontFamily = CairoFamily, fontWeight = FontWeight.Bold, fontSize = 24.sp, lineHeight = 32.sp),
    titleLarge = TextStyle(fontFamily = CairoFamily, fontWeight = FontWeight.Bold, fontSize = 20.sp, lineHeight = 30.sp),
    titleMedium = TextStyle(fontFamily = CairoFamily, fontWeight = FontWeight.Bold, fontSize = 16.sp, lineHeight = 26.sp),
    titleSmall = TextStyle(fontFamily = CairoFamily, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, lineHeight = 23.sp),
    bodyLarge = TextStyle(fontFamily = CairoFamily, fontWeight = FontWeight.Normal, fontSize = 16.sp, lineHeight = 26.sp),
    bodyMedium = TextStyle(fontFamily = CairoFamily, fontWeight = FontWeight.Normal, fontSize = 14.sp, lineHeight = 23.sp),
    bodySmall = TextStyle(fontFamily = CairoFamily, fontWeight = FontWeight.Normal, fontSize = 12.sp, lineHeight = 20.sp),
    labelLarge = TextStyle(fontFamily = CairoFamily, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, lineHeight = 22.sp),
    labelMedium = TextStyle(fontFamily = CairoFamily, fontWeight = FontWeight.SemiBold, fontSize = 12.sp, lineHeight = 20.sp),
    labelSmall = TextStyle(fontFamily = CairoFamily, fontWeight = FontWeight.Medium, fontSize = 12.sp, lineHeight = 18.sp),
)
