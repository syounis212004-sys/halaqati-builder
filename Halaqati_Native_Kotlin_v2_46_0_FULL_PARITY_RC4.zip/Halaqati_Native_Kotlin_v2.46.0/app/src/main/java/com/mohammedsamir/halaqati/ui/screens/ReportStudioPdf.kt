package com.mohammedsamir.halaqati.ui.screens

import android.content.Context
import android.graphics.*
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.text.Layout
import android.text.StaticLayout
import android.text.TextDirectionHeuristics
import android.text.TextPaint
import androidx.core.content.res.ResourcesCompat
import com.mohammedsamir.halaqati.R
import org.json.JSONObject

internal object ReportStudioPdf {
    private data class ColumnDef(val key: String, val label: String, val weight: Float, val value: (JSONObject, Int)->String)

    fun exportSummary(context: Context, uri: Uri, rows: List<JSONObject>, style: NativeReportStyle, from: String, to: String, track: String) {
        val defs = listOf(
            ColumnDef("rank","#",.45f,{ _,i -> (i+1).toString() }),
            ColumnDef("student","الطالب",2.5f,{ r,_ -> r.optString("student_name","طالب") }),
            ColumnDef("category","الفئة",1.25f,{ r,_ -> r.optString("category_name").ifBlank { "—" } }),
            ColumnDef("hifz","الحفظ",.9f,{ r,_ -> reportNumber(r.optDouble("hifz_pages",0.0)) }),
            ColumnDef("tathbit","التثبيت",.9f,{ r,_ -> reportNumber(r.optDouble("tathbit_pages",0.0)) }),
            ColumnDef("review","المراجعة",1.0f,{ r,_ -> reportNumber(r.optDouble("review_pages",0.0)) }),
            ColumnDef("sard","السرد",.85f,{ r,_ -> reportNumber(r.optDouble("sard_pages",0.0)) }),
            ColumnDef("attendance","الحضور",.9f,{ r,_ -> (r.optInt("present",0)+r.optInt("late",0)).toString() }),
            ColumnDef("absence","الغياب",.85f,{ r,_ -> r.optInt("absent",0).toString() }),
            ColumnDef("points","النقاط",.95f,{ r,_ -> reportNumber(r.optDouble("points",0.0)) }),
        ).filter { it.key in style.visibleColumns }
        export(context, uri, rows, style, from, to, track, defs)
    }

    fun exportDetails(context: Context, uri: Uri, rows: List<JSONObject>, style: NativeReportStyle, from: String, to: String, track: String) {
        val defs = listOf(
            ColumnDef("rank","#",.45f,{ _,i -> (i+1).toString() }),
            ColumnDef("student","الطالب",2.4f,{ r,_ -> r.optJSONObject("students")?.optString("full_name") ?: "طالب" }),
            ColumnDef("date","التاريخ",1.15f,{ r,_ -> r.optJSONObject("sessions")?.optString("session_date").orEmpty() }),
            ColumnDef("activity","النوع",1.25f,{ r,_ -> activityStudioAr(r.optString("activity_type")) }),
            ColumnDef("pages","الصفحات",.9f,{ r,_ -> reportNumber(r.optDouble("pages_count",0.0)) }),
            ColumnDef("evaluation","التقييم",1.15f,{ r,_ -> evaluationStudioAr(r.optString("evaluation")) }),
            ColumnDef("safety","الأمان",.9f,{ r,_ -> "${r.optDouble("safety_percentage",0.0).toInt()}%" }),
        ).filter { it.key in style.visibleColumns }
        export(context, uri, rows, style, from, to, track, defs)
    }

    private fun export(context: Context, uri: Uri, rows: List<JSONObject>, style: NativeReportStyle, from: String, to: String, track: String, columns: List<ColumnDef>) {
        require(rows.isNotEmpty()) { "لا توجد بيانات لطباعة التقرير" }
        require(columns.isNotEmpty()) { "اختر عمودًا واحدًا على الأقل" }
        val pageWidth = if (style.orientation == ReportOrientation.LANDSCAPE) 842 else 595
        val pageHeight = if (style.orientation == ReportOrientation.LANDSCAPE) 595 else 842
        val margin = 28f
        val rowHeight = 29f * style.fontScale.coerceIn(.75f,1.55f)
        val tableTop = 132f
        val rowsPerPage = ((pageHeight - tableTop - 38f) / rowHeight).toInt().coerceAtLeast(1)
        val totalPages = (rows.size + rowsPerPage - 1) / rowsPerPage
        val pdf = PdfDocument()
        val baseTypeface = when (style.fontFamily) {
            "Cairo" -> ResourcesCompat.getFont(context, R.font.cairo) ?: Typeface.DEFAULT
            "Serif" -> Typeface.SERIF
            else -> Typeface.create(style.fontFamily, Typeface.NORMAL)
        }
        val normal = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = style.textColor.toInt(); textSize = 10.4f * style.fontScale; typeface = baseTypeface }
        val bold = TextPaint(normal).apply { typeface = Typeface.create(baseTypeface, Typeface.BOLD); textSize = 10.8f * style.fontScale }
        val titlePaint = TextPaint(bold).apply { color = style.primaryColor.toInt(); textSize = 20f * style.fontScale }
        val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(205,215,210); strokeWidth = .8f }
        val headerFill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = blendToWhite(style.primaryColor.toInt(), .88f) }
        val altFill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(249,250,249) }
        val usable = pageWidth - margin * 2
        val weightSum = columns.sumOf { it.weight.toDouble() }.toFloat()
        val widths = columns.map { usable * it.weight / weightSum }

        fun rtl(canvas: Canvas, text: String, x: Float, y: Float, width: Float, paint: TextPaint, center: Boolean = false) {
            if (text.isBlank()) return
            val layout = StaticLayout.Builder.obtain(text,0,text.length,paint,width.toInt().coerceAtLeast(2))
                .setAlignment(if (center) Layout.Alignment.ALIGN_CENTER else Layout.Alignment.ALIGN_OPPOSITE)
                .setTextDirection(TextDirectionHeuristics.RTL).setIncludePad(false).setMaxLines(1).build()
            canvas.save(); canvas.translate(x,y); layout.draw(canvas); canvas.restore()
        }

        fun logos(canvas: Canvas) {
            if (style.logoMode == "none") return
            runCatching {
                if (style.logoMode in setOf("both","center")) {
                    val bmp = BitmapFactory.decodeResource(context.resources,R.drawable.center_logo)
                    canvas.drawBitmap(bmp,null,RectF(margin,18f,margin+54f,72f),null)
                }
                if (style.logoMode in setOf("both","halaqa")) {
                    val bmp = BitmapFactory.decodeResource(context.resources,R.drawable.halaqa_logo)
                    canvas.drawBitmap(bmp,null,RectF(pageWidth-margin-54f,18f,pageWidth-margin,72f),null)
                }
            }
        }

        rows.chunked(rowsPerPage).forEachIndexed { pageIndex,chunk ->
            val page = pdf.startPage(PdfDocument.PageInfo.Builder(pageWidth,pageHeight,pageIndex+1).create())
            val canvas = page.canvas; canvas.drawColor(Color.WHITE); logos(canvas)
            rtl(canvas, style.title.ifBlank { "تقرير حلقتي" }, 100f, 25f, pageWidth-200f, titlePaint, true)
            val trackLabel = when(track){ "general_hifz"->"مسار الحفظ العام"; "tathbit"->"مسار التثبيت"; else->"جميع المسارات" }
            rtl(canvas,"$trackLabel · الفترة: $from إلى $to",80f,59f,pageWidth-160f,normal,true)
            rtl(canvas,"عدد السجلات: ${rows.size}",80f,82f,pageWidth-160f,bold,true)
            canvas.drawLine(margin,112f,pageWidth-margin,112f,linePaint)
            canvas.drawRect(margin,tableTop,pageWidth-margin,tableTop+rowHeight,headerFill)
            var x = pageWidth-margin
            columns.forEachIndexed { i,c ->
                val w=widths[i]; x-=w; rtl(canvas,c.label,x+2f,tableTop+7f,w-4f,bold,true); canvas.drawLine(x,tableTop,x,tableTop+rowHeight,linePaint)
            }
            canvas.drawLine(pageWidth-margin,tableTop,pageWidth-margin,tableTop+rowHeight,linePaint)
            canvas.drawLine(margin,tableTop,pageWidth-margin,tableTop,linePaint)
            var y=tableTop+rowHeight
            chunk.forEachIndexed { local,row ->
                val global=pageIndex*rowsPerPage+local
                if(global%2==1) canvas.drawRect(margin,y,pageWidth-margin,y+rowHeight,altFill)
                x=pageWidth-margin
                columns.forEachIndexed { i,c ->
                    val w=widths[i]; x-=w; rtl(canvas,c.value(row,global),x+2f,y+7f,w-4f,normal, c.key !in setOf("student","category","activity")); canvas.drawLine(x,y,x,y+rowHeight,linePaint)
                }
                canvas.drawLine(pageWidth-margin,y,pageWidth-margin,y+rowHeight,linePaint)
                canvas.drawLine(margin,y+rowHeight,pageWidth-margin,y+rowHeight,linePaint)
                y+=rowHeight
            }
            rtl(canvas,"صفحة ${pageIndex+1} من $totalPages",pageWidth/2f-80f,pageHeight-25f,160f,normal,true)
            rtl(canvas,style.footer,margin,pageHeight-25f,pageWidth-2*margin,normal)
            pdf.finishPage(page)
        }
        context.contentResolver.openOutputStream(uri)?.use { pdf.writeTo(it) } ?: error("تعذر فتح ملف الحفظ")
        pdf.close()
    }

    private fun blendToWhite(color: Int, whiteRatio: Float): Int {
        val r=(Color.red(color)*(1-whiteRatio)+255*whiteRatio).toInt(); val g=(Color.green(color)*(1-whiteRatio)+255*whiteRatio).toInt(); val b=(Color.blue(color)*(1-whiteRatio)+255*whiteRatio).toInt()
        return Color.rgb(r,g,b)
    }
    private fun reportNumber(v: Double): String = if(v%1.0==0.0) v.toInt().toString() else "%.2f".format(v).trimEnd('0').trimEnd('.')
    private fun activityStudioAr(v:String)=mapOf("new_hifz" to "حفظ","review_near" to "مراجعة قريبة","review_far" to "مراجعة بعيدة","sard" to "سرد","tilawah" to "تلاوة","test" to "اختبار")[v]?:v
    private fun evaluationStudioAr(v:String)=mapOf("excellent" to "ممتاز","very_good" to "جيد جدًا","good" to "جيد","repeat" to "إعادة","not_rated" to "غير مقيم")[v]?:v
}
