package com.mohammedsamir.halaqati.ui.screens

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.mohammedsamir.halaqati.ui.components.ProFilterChip

internal enum class ReportOrientation { LANDSCAPE, PORTRAIT }

internal data class NativeReportStyle(
    val title: String = "تقرير حلقتي",
    val footer: String = "مركز إبراهيم خليل الرحمن · حلقة معاوية بن أبي سفيان",
    val orientation: ReportOrientation = ReportOrientation.LANDSCAPE,
    val fontFamily: String = "Cairo",
    val fontScale: Float = 1f,
    val primaryColor: Long = 0xFF0D3B2F,
    val textColor: Long = 0xFF1C302A,
    val logoMode: String = "both",
    val visibleColumns: Set<String> = setOf("rank", "student", "category", "hifz", "tathbit", "review", "sard", "attendance", "absence", "points"),
)

@Composable
internal fun ReportStudioControls(style: NativeReportStyle, detailsMode: Boolean, onChange: (NativeReportStyle)->Unit) {
    ElevatedCard(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(Icons.Default.Tune, null, tint = MaterialTheme.colorScheme.primary)
                Text("تخصيص استوديو التقارير", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            }
            OutlinedTextField(style.title, { onChange(style.copy(title = it)) }, label = { Text("عنوان التقرير") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            OutlinedTextField(style.footer, { onChange(style.copy(footer = it)) }, label = { Text("تذييل التقرير") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            Text("اتجاه A4", style = MaterialTheme.typography.labelLarge)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ProFilterChip(style.orientation == ReportOrientation.LANDSCAPE, { onChange(style.copy(orientation = ReportOrientation.LANDSCAPE)) }, "أفقي A4", Modifier.weight(1f))
                ProFilterChip(style.orientation == ReportOrientation.PORTRAIT, { onChange(style.copy(orientation = ReportOrientation.PORTRAIT)) }, "رأسي A4", Modifier.weight(1f))
            }
            Text("الخط", style = MaterialTheme.typography.labelLarge)
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("Cairo", "Tahoma", "Arial", "Serif").forEach { f -> ProFilterChip(style.fontFamily == f, { onChange(style.copy(fontFamily = f)) }, f) }
            }
            Text("حجم الخط ${(style.fontScale * 100).toInt()}%", style = MaterialTheme.typography.labelLarge)
            Slider(style.fontScale, { onChange(style.copy(fontScale = it)) }, valueRange = .75f..1.55f)
            Text("الهوية اللونية", style = MaterialTheme.typography.labelLarge)
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf(
                    Triple(0xFF0D3B2F,0xFF1C302A,"الأخضر"),
                    Triple(0xFF12345B,0xFF1D2C40,"الأزرق"),
                    Triple(0xFF5A3825,0xFF35251D,"البني"),
                    Triple(0xFF342B5F,0xFF29233E,"البنفسجي"),
                ).forEach { (p,t,label) -> ProFilterChip(style.primaryColor == p, { onChange(style.copy(primaryColor = p, textColor = t)) }, label) }
            }
            Text("الشعارات", style = MaterialTheme.typography.labelLarge)
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("both" to "الشعاران", "center" to "المركز", "halaqa" to "الحلقة", "none" to "بدون").forEach { (v,l) -> ProFilterChip(style.logoMode == v, { onChange(style.copy(logoMode = v)) }, l) }
            }
            Text("الأعمدة الظاهرة", style = MaterialTheme.typography.labelLarge)
            val columns = if (detailsMode) listOf(
                "rank" to "#", "student" to "الطالب", "date" to "التاريخ", "activity" to "النوع", "pages" to "الصفحات", "evaluation" to "التقييم", "safety" to "الأمان"
            ) else listOf(
                "rank" to "#", "student" to "الطالب", "category" to "الفئة", "hifz" to "الحفظ", "tathbit" to "التثبيت", "review" to "المراجعة", "sard" to "السرد", "attendance" to "الحضور", "absence" to "الغياب", "points" to "النقاط"
            )
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                columns.forEach { (key,label) ->
                    ProFilterChip(style.visibleColumns.contains(key), {
                        val next = if (style.visibleColumns.contains(key)) style.visibleColumns - key else style.visibleColumns + key
                        onChange(style.copy(visibleColumns = next))
                    }, label)
                }
            }
        }
    }
}
