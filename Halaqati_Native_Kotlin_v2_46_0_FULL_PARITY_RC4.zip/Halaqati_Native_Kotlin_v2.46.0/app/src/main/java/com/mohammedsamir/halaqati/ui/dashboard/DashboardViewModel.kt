package com.mohammedsamir.halaqati.ui.dashboard

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.mohammedsamir.halaqati.data.AppGraph
import com.mohammedsamir.halaqati.data.HalaqatiRepository
import com.mohammedsamir.halaqati.model.Profile
import com.mohammedsamir.halaqati.model.SessionRow
import com.mohammedsamir.halaqati.model.Student
import com.mohammedsamir.halaqati.model.SyncState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import java.time.LocalDate

class DashboardViewModel(
    private val repository: HalaqatiRepository = AppGraph.repo,
) : ViewModel() {
    private val _state = MutableStateFlow(DashboardUiState())
    val state: StateFlow<DashboardUiState> = _state.asStateFlow()

    private var boundOwner: String? = null

    fun bind(profile: Profile, sync: SyncState) {
        val ownerChanged = boundOwner != profile.id
        boundOwner = profile.id
        _state.value = _state.value.copy(profile = profile, sync = sync)
        if (ownerChanged) {
            viewModelScope.launch {
                loadCached(profile, sync)
                refresh(force = true)
            }
        } else if (_state.value.sync != sync) {
            _state.value = _state.value.copy(sync = sync)
        }
    }

    fun updateSync(sync: SyncState) {
        _state.value = _state.value.copy(sync = sync)
    }

    fun refresh(force: Boolean = true) {
        val profile = _state.value.profile ?: return
        val previous = _state.value
        _state.value = previous.copy(refreshing = true)
        viewModelScope.launch {
            val today = LocalDate.now().toString()
            val owner = profile.id
            val errors = linkedMapOf<String, String>()

            val studentsResult = runCatching {
                withContext(Dispatchers.IO) {
                    if (force) repository.refreshStudents()
                    else repository.cachedStudents(owner) ?: repository.refreshStudents()
                }
            }.onFailure { errors["students"] = it.message ?: "تعذر تحديث الطلاب" }

            val sessionsResult = runCatching {
                withContext(Dispatchers.IO) {
                    if (force) repository.refreshSessions()
                    else repository.cachedSessions(owner) ?: repository.refreshSessions()
                }
            }.onFailure { errors["sessions"] = it.message ?: "تعذر تحديث الجلسات" }

            val recitationsResult = runCatching {
                withContext(Dispatchers.IO) {
                    if (force) repository.refreshDashboardRecitations()
                    else repository.cachedDashboardRecitations(owner) ?: repository.refreshDashboardRecitations()
                }
            }.onFailure { errors["recitations"] = it.message ?: "تعذر تحديث التسميعات" }

            val recitations = recitationsResult.getOrNull()
            val students = studentsResult.getOrNull()
            val sessions = sessionsResult.getOrNull()

            var merged = buildState(
                profile = profile,
                sync = _state.value.sync,
                today = today,
                students = students,
                sessions = sessions,
                recitations = recitations,
                previous = previous,
                errors = errors,
            )

            // Golden-master daily supervisor board: absence/late, plan delay,
            // review need, and students who exceeded their target. These are
            // fetched outside Compose so opening the dashboard never blocks UI.
            val attendanceSignals = runCatching {
                withContext(Dispatchers.IO) {
                    val byId = students.orEmpty().associateBy { it.id }
                    sessions.orEmpty().filter { it.date == today }.flatMap { session ->
                        repository.attendanceForSession(session.id).values.mapNotNull { row ->
                            val student = byId[row.studentId] ?: return@mapNotNull null
                            when {
                                row.status in setOf("absent", "excused") -> DashboardAttentionItem(student.id, student.fullName, "غائب اليوم")
                                row.arrivalMinutesLate > 0 -> DashboardAttentionItem(student.id, student.fullName, "متأخر ${row.arrivalMinutesLate} دقيقة")
                                else -> null
                            }
                        }
                    }.distinctBy { it.studentId }
                }
            }.onFailure { errors["attendance"] = it.message ?: "تعذر تحديث الحضور" }
                .getOrElse { previous.absentLate }

            val planSignals = runCatching {
                withContext(Dispatchers.IO) { repository.planSnapshots(LocalDate.now(), forceRefresh = force) }
            }.onFailure { errors["plans"] = it.message ?: "تعذر تحديث الخطط" }
                .getOrNull()

            val behind = planSignals?.filter { it.progress.behindBy > 0.01 }?.map {
                DashboardAttentionItem(it.student.id, it.student.fullName, "متأخر عن الخطة · ${"%.1f".format(it.progress.behindBy)} ص")
            }?.distinctBy { it.studentId } ?: previous.attention
            val exceeded = planSignals?.filter { it.progress.aheadBy > 0.01 }?.map {
                DashboardAttentionItem(it.student.id, it.student.fullName, "تجاوز هدفه · +${"%.1f".format(it.progress.aheadBy)} ص")
            }?.distinctBy { it.studentId } ?: previous.overTarget

            val byStudent = students.orEmpty().associateBy { it.id }
            val latestSafety = linkedMapOf<String, Double>()
            if (recitations != null) for (i in 0 until recitations.length()) {
                val row = recitations.optJSONObject(i) ?: continue
                val sid = row.optString("student_id")
                if (sid.isNotBlank() && sid !in latestSafety) latestSafety[sid] = row.optDouble("safety_percentage", 100.0)
            }
            val review = if (recitations == null) previous.attendance else latestSafety.entries
                .filter { it.value < 78.0 }
                .mapNotNull { (sid, safety) -> byStudent[sid]?.let { DashboardAttentionItem(sid, it.fullName, "يحتاج مراجعة · ${"%.0f".format(safety)}%") } }

            merged = merged.copy(
                absentLate = attendanceSignals,
                attention = behind,
                attendance = review,
                overTarget = exceeded,
                smartPlanAlerts = planSignals.orEmpty().filter { it.progress.consecutiveMissed > 0 }.map {
                    "${it.student.fullName}: ${it.progress.healthLabel}"
                },
                errors = errors,
            )
            _state.value = merged.copy(refreshing = false, loaded = true)
        }
    }

    private suspend fun loadCached(profile: Profile, sync: SyncState) {
        val cached = withContext(Dispatchers.IO) {
            Triple(
                repository.cachedStudents(profile.id),
                repository.cachedSessions(profile.id),
                repository.cachedDashboardRecitations(profile.id),
            )
        }
        if (cached.first == null && cached.second == null && cached.third == null) return
        _state.value = buildState(
            profile = profile,
            sync = sync,
            today = LocalDate.now().toString(),
            students = cached.first,
            sessions = cached.second,
            recitations = cached.third,
            previous = _state.value,
            errors = emptyMap(),
        ).copy(loaded = true)
    }

    private fun buildState(
        profile: Profile,
        sync: SyncState,
        today: String,
        students: List<Student>?,
        sessions: List<SessionRow>?,
        recitations: JSONArray?,
        previous: DashboardUiState,
        errors: Map<String, String>,
    ): DashboardUiState {
        val activeStudents = students?.filter { it.status == "active" }
        val heardToday = linkedSetOf<String>()
        var pages = if (recitations == null) previous.progress.recordedPages else 0.0
        if (recitations != null) {
            for (i in 0 until recitations.length()) {
                val row = recitations.optJSONObject(i) ?: continue
                val created = row.optString("created_at")
                if (created.startsWith(today)) {
                    row.optString("student_id").takeIf(String::isNotBlank)?.let(heardToday::add)
                    pages += row.optDouble("pages_count", 0.0)
                }
            }
        }
        val notHeard = activeStudents?.filter { it.id !in heardToday }?.map {
            DashboardAttentionItem(it.id, it.fullName, "لم يسمّع اليوم")
        } ?: previous.notHeard
        val progress = DashboardProgress(
            recordedPages = pages,
            heardStudents = if (recitations == null) previous.progress.heardStudents else heardToday.size,
            activeStudents = activeStudents?.size ?: previous.progress.activeStudents,
        )
        return previous.copy(
            profile = profile,
            today = today,
            notHeard = notHeard,
            attention = notHeard,
            progress = progress,
            todaySessions = sessions?.count { it.date == today } ?: previous.todaySessions,
            sync = sync,
            errors = errors,
        )
    }
}
