package com.mohammedsamir.halaqati.data

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

/**
 * Durable queue for offline writes.
 *
 * Queue rows are scoped to the authenticated Supabase user that created them. This is a
 * release-critical invariant: a write created by account A must never be replayed with account
 * B's bearer token after a logout/login on the same phone.
 */
class OfflineQueue(ctx: Context) : SQLiteOpenHelper(ctx, "halaqati-offline.db", null, 4) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            """
            CREATE TABLE q(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                owner_user_id TEXT NOT NULL,
                method TEXT NOT NULL,
                path TEXT NOT NULL,
                body TEXT,
                headers TEXT,
                created INTEGER NOT NULL,
                attempts INTEGER NOT NULL DEFAULT 0,
                dedupe TEXT,
                blocked INTEGER NOT NULL DEFAULT 0,
                last_error TEXT
            )
            """.trimIndent(),
        )
        createIndexes(db)
    }

    override fun onUpgrade(db: SQLiteDatabase, old: Int, new: Int) {
        if (old < 2) {
            db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS q_dedupe ON q(dedupe) WHERE dedupe IS NOT NULL")
        }
        if (old < 3) {
            db.execSQL("ALTER TABLE q ADD COLUMN blocked INTEGER NOT NULL DEFAULT 0")
            db.execSQL("ALTER TABLE q ADD COLUMN last_error TEXT")
        }
        if (old < 4) {
            // v1-v3 had no account scope. Replaying those rows after an account switch could
            // write one user's offline data with another user's token, so legacy rows are
            // quarantined instead of guessed or replayed.
            db.execSQL("ALTER TABLE q ADD COLUMN owner_user_id TEXT")
            db.execSQL("DROP INDEX IF EXISTS q_dedupe")
            db.execSQL(
                "UPDATE q SET blocked=1, last_error=COALESCE(last_error, 'Legacy offline item quarantined: missing account scope') WHERE owner_user_id IS NULL OR owner_user_id=''",
            )
            createIndexes(db)
        }
    }

    private fun createIndexes(db: SQLiteDatabase) {
        db.execSQL(
            "CREATE UNIQUE INDEX IF NOT EXISTS q_owner_dedupe ON q(owner_user_id,dedupe) WHERE dedupe IS NOT NULL",
        )
        db.execSQL(
            "CREATE INDEX IF NOT EXISTS q_owner_state_id ON q(owner_user_id,blocked,id)",
        )
    }

    fun add(
        ownerUserId: String,
        method: String,
        path: String,
        body: String?,
        dedupe: String? = null,
    ) {
        require(ownerUserId.isNotBlank()) { "Offline queue requires an authenticated account" }
        writableDatabase.beginTransaction()
        try {
            if (dedupe != null) {
                writableDatabase.delete(
                    "q",
                    "owner_user_id=? AND dedupe=?",
                    arrayOf(ownerUserId, dedupe),
                )
            }
            val values = ContentValues().apply {
                put("owner_user_id", ownerUserId)
                put("method", method)
                put("path", path)
                put("body", body)
                put("created", System.currentTimeMillis())
                put("dedupe", dedupe)
                put("blocked", 0)
            }
            writableDatabase.insertOrThrow("q", null, values)
            writableDatabase.setTransactionSuccessful()
        } finally {
            writableDatabase.endTransaction()
        }
    }

    fun size(ownerUserId: String): Int = count(ownerUserId, blocked = false)

    fun blockedSize(ownerUserId: String): Int = count(ownerUserId, blocked = true)

    private fun count(ownerUserId: String, blocked: Boolean): Int {
        if (ownerUserId.isBlank()) return 0
        return readableDatabase.rawQuery(
            "SELECT COUNT(*) FROM q WHERE owner_user_id=? AND blocked=?",
            arrayOf(ownerUserId, if (blocked) "1" else "0"),
        ).use {
            it.moveToFirst()
            it.getInt(0)
        }
    }

    data class Item(
        val id: Long,
        val method: String,
        val path: String,
        val body: String?,
        val attempts: Int,
    )

    data class SnapshotItem(
        val id: Long,
        val method: String,
        val path: String,
        val attempts: Int,
        val blocked: Boolean,
        val lastError: String?,
        val created: Long,
        val dedupe: String?,
        val body: String?,
    )

    fun all(ownerUserId: String, limit: Int = 100): List<Item> {
        if (ownerUserId.isBlank()) return emptyList()
        return buildList {
            readableDatabase.rawQuery(
                "SELECT id,method,path,body,attempts FROM q WHERE owner_user_id=? AND blocked=0 ORDER BY id LIMIT ?",
                arrayOf(ownerUserId, limit.toString()),
            ).use { cursor ->
                while (cursor.moveToNext()) {
                    add(
                        Item(
                            id = cursor.getLong(0),
                            method = cursor.getString(1),
                            path = cursor.getString(2),
                            body = if (cursor.isNull(3)) null else cursor.getString(3),
                            attempts = cursor.getInt(4),
                        ),
                    )
                }
            }
        }
    }

    fun snapshot(ownerUserId: String, limit: Int = 200): List<SnapshotItem> {
        if (ownerUserId.isBlank()) return emptyList()
        return buildList {
            readableDatabase.rawQuery(
                "SELECT id,method,path,attempts,blocked,last_error,created,dedupe,body FROM q WHERE owner_user_id=? ORDER BY blocked DESC,id ASC LIMIT ?",
                arrayOf(ownerUserId, limit.toString()),
            ).use { cursor ->
                while (cursor.moveToNext()) {
                    add(
                        SnapshotItem(
                            id = cursor.getLong(0),
                            method = cursor.getString(1),
                            path = cursor.getString(2),
                            attempts = cursor.getInt(3),
                            blocked = cursor.getInt(4) == 1,
                            lastError = if (cursor.isNull(5)) null else cursor.getString(5),
                            created = cursor.getLong(6),
                            dedupe = if (cursor.isNull(7)) null else cursor.getString(7),
                            body = if (cursor.isNull(8)) null else cursor.getString(8),
                        ),
                    )
                }
            }
        }
    }

    fun retryBlocked(id: Long, ownerUserId: String) {
        if (ownerUserId.isBlank()) return
        val values = ContentValues().apply {
            put("blocked", 0)
            putNull("last_error")
        }
        writableDatabase.update(
            "q",
            values,
            "id=? AND owner_user_id=?",
            arrayOf(id.toString(), ownerUserId),
        )
    }

    fun discard(id: Long, ownerUserId: String) {
        if (ownerUserId.isBlank()) return
        writableDatabase.delete(
            "q",
            "id=? AND owner_user_id=?",
            arrayOf(id.toString(), ownerUserId),
        )
    }

    fun done(id: Long, ownerUserId: String) {
        discard(id, ownerUserId)
    }

    fun fail(id: Long, ownerUserId: String) {
        if (ownerUserId.isBlank()) return
        writableDatabase.execSQL(
            "UPDATE q SET attempts=attempts+1 WHERE id=? AND owner_user_id=?",
            arrayOf(id, ownerUserId),
        )
    }

    fun markBlocked(id: Long, ownerUserId: String, error: String) {
        if (ownerUserId.isBlank()) return
        val values = ContentValues().apply {
            put("blocked", 1)
            put("last_error", error.take(1000))
        }
        writableDatabase.update(
            "q",
            values,
            "id=? AND owner_user_id=?",
            arrayOf(id.toString(), ownerUserId),
        )
    }

    fun clearBlocked(ownerUserId: String) {
        if (ownerUserId.isBlank()) return
        writableDatabase.delete(
            "q",
            "owner_user_id=? AND blocked=1",
            arrayOf(ownerUserId),
        )
    }
}
