package com.mohammedsamir.halaqati.quran

/**
 * Offline Hafs/Madinah Mushaf metadata used by the native Android runtime.
 * Surah names/counts are preserved from Halaqati v2.44.0.
 * Page/Juz/Rub boundaries match quran-center/quran-meta Hafs lists
 * (Madinah mushaf, 604 pages). Arrays include leading/trailing sentinels.
 */
data class QuranLocation(val surah: Int, val ayah: Int) {
    val label: String get() = "${QuranMetadata.surahName(surah)} $ayah"
}

data class QuranRange(
    val start: QuranLocation,
    val end: QuranLocation,
    val startPage: Int,
    val endPage: Int,
) {
    val pageCount: Int get() = kotlin.math.abs(endPage - startPage) + 1
    val normalizedStartPage: Int get() = minOf(startPage, endPage)
    val normalizedEndPage: Int get() = maxOf(startPage, endPage)
}

object QuranMetadata {
    const val SURAH_COUNT = 114
    const val AYAH_COUNT = 6236
    const val PAGE_COUNT = 604
    const val JUZ_COUNT = 30
    const val RUB_COUNT = 240

    val surahNames: List<String> = listOf(
        "الفاتحة", "البقرة", "آل عمران", "النساء", "المائدة", "الأنعام",
        "الأعراف", "الأنفال", "التوبة", "يونس", "هود", "يوسف",
        "الرعد", "إبراهيم", "الحجر", "النحل", "الإسراء", "الكهف",
        "مريم", "طه", "الأنبياء", "الحج", "المؤمنون", "النور",
        "الفرقان", "الشعراء", "النمل", "القصص", "العنكبوت", "الروم",
        "لقمان", "السجدة", "الأحزاب", "سبأ", "فاطر", "يس",
        "الصافات", "ص", "الزمر", "غافر", "فصلت", "الشورى",
        "الزخرف", "الدخان", "الجاثية", "الأحقاف", "محمد", "الفتح",
        "الحجرات", "ق", "الذاريات", "الطور", "النجم", "القمر",
        "الرحمن", "الواقعة", "الحديد", "المجادلة", "الحشر", "الممتحنة",
        "الصف", "الجمعة", "المنافقون", "التغابن", "الطلاق", "التحريم",
        "الملك", "القلم", "الحاقة", "المعارج", "نوح", "الجن",
        "المزمل", "المدثر", "القيامة", "الإنسان", "المرسلات", "النبأ",
        "النازعات", "عبس", "التكوير", "الانفطار", "المطففين", "الانشقاق",
        "البروج", "الطارق", "الأعلى", "الغاشية", "الفجر", "البلد",
        "الشمس", "الليل", "الضحى", "الشرح", "التين", "العلق",
        "القدر", "البينة", "الزلزلة", "العاديات", "القارعة", "التكاثر",
        "العصر", "الهمزة", "الفيل", "قريش", "الماعون", "الكوثر",
        "الكافرون", "النصر", "المسد", "الإخلاص", "الفلق", "الناس",
    )

    val ayahCounts: IntArray = intArrayOf(
        7, 286, 200, 176, 120, 165, 206, 75, 129, 109, 123, 111, 43, 52, 99, 128, 111, 110,
        98, 135, 112, 78, 118, 64, 77, 227, 93, 88, 69, 60, 34, 30, 73, 54, 45, 83,
        182, 88, 75, 85, 54, 53, 89, 59, 37, 35, 38, 29, 18, 45, 60, 49, 62, 55,
        78, 96, 29, 22, 24, 13, 14, 11, 11, 18, 12, 12, 30, 52, 52, 44, 28, 28,
        20, 56, 40, 31, 50, 40, 46, 42, 29, 19, 36, 25, 22, 17, 19, 26, 30, 20,
        15, 21, 11, 8, 8, 19, 5, 8, 8, 11, 11, 8, 3, 9, 5, 4, 7, 3,
        6, 3, 5, 4, 5, 6,
    )

    /** Index 1..604 = first global ayah on the page; 605 is the end sentinel. */
    val pageStarts: IntArray = intArrayOf(
        0, 1, 8, 13, 24, 32, 37, 45, 56, 65, 69, 77, 84, 91, 96, 101, 109, 113,
        120, 127, 134, 142, 149, 153, 161, 171, 177, 184, 189, 194, 198, 204, 210, 218, 223, 227,
        232, 238, 241, 245, 253, 256, 260, 264, 267, 272, 277, 282, 289, 290, 294, 303, 309, 316,
        323, 331, 339, 346, 355, 364, 371, 377, 385, 394, 402, 409, 415, 426, 434, 442, 447, 451,
        459, 467, 474, 480, 488, 494, 500, 505, 508, 513, 517, 520, 527, 531, 538, 545, 553, 559,
        568, 573, 580, 585, 588, 595, 599, 607, 615, 621, 628, 634, 641, 648, 656, 664, 669, 672,
        675, 679, 683, 687, 693, 701, 706, 711, 715, 720, 727, 734, 740, 746, 752, 759, 765, 773,
        778, 783, 790, 798, 808, 817, 825, 834, 842, 849, 858, 863, 871, 880, 884, 891, 900, 908,
        914, 921, 927, 932, 936, 941, 947, 955, 966, 977, 985, 992, 998, 1006, 1012, 1022, 1028, 1036,
        1042, 1050, 1059, 1075, 1085, 1092, 1098, 1104, 1110, 1114, 1118, 1125, 1133, 1142, 1150, 1161, 1169, 1177,
        1186, 1194, 1201, 1206, 1213, 1222, 1230, 1236, 1242, 1249, 1256, 1262, 1267, 1272, 1276, 1283, 1290, 1297,
        1304, 1308, 1315, 1322, 1329, 1335, 1342, 1347, 1353, 1358, 1365, 1371, 1379, 1385, 1390, 1398, 1407, 1418,
        1426, 1435, 1443, 1453, 1462, 1471, 1479, 1486, 1493, 1502, 1511, 1519, 1527, 1536, 1545, 1555, 1562, 1571,
        1582, 1591, 1601, 1611, 1619, 1627, 1634, 1640, 1649, 1660, 1666, 1675, 1683, 1692, 1700, 1708, 1713, 1721,
        1726, 1736, 1742, 1750, 1756, 1761, 1769, 1775, 1784, 1793, 1803, 1818, 1834, 1854, 1873, 1893, 1908, 1916,
        1928, 1936, 1944, 1956, 1966, 1974, 1981, 1989, 1995, 2004, 2012, 2020, 2030, 2037, 2047, 2057, 2068, 2079,
        2088, 2096, 2105, 2116, 2126, 2134, 2145, 2156, 2161, 2168, 2175, 2186, 2194, 2202, 2215, 2224, 2238, 2251,
        2262, 2276, 2289, 2302, 2315, 2327, 2346, 2361, 2386, 2400, 2413, 2425, 2436, 2447, 2462, 2474, 2484, 2494,
        2508, 2519, 2528, 2541, 2556, 2565, 2574, 2585, 2596, 2601, 2611, 2619, 2626, 2634, 2642, 2651, 2660, 2668,
        2674, 2691, 2701, 2716, 2733, 2748, 2763, 2778, 2792, 2802, 2812, 2819, 2823, 2828, 2835, 2845, 2850, 2853,
        2858, 2867, 2876, 2888, 2899, 2911, 2923, 2933, 2952, 2972, 2993, 3016, 3044, 3069, 3092, 3116, 3139, 3160,
        3173, 3182, 3195, 3204, 3215, 3223, 3236, 3248, 3258, 3266, 3274, 3281, 3288, 3296, 3303, 3312, 3323, 3330,
        3337, 3347, 3355, 3364, 3371, 3379, 3386, 3393, 3404, 3415, 3425, 3434, 3442, 3451, 3460, 3470, 3481, 3489,
        3498, 3504, 3515, 3524, 3534, 3540, 3549, 3556, 3564, 3569, 3577, 3584, 3588, 3596, 3607, 3614, 3621, 3629,
        3638, 3646, 3655, 3664, 3672, 3679, 3691, 3699, 3705, 3718, 3733, 3746, 3760, 3776, 3789, 3813, 3840, 3865,
        3891, 3915, 3942, 3971, 3987, 3997, 4013, 4032, 4054, 4064, 4069, 4080, 4090, 4099, 4106, 4115, 4126, 4133,
        4141, 4150, 4159, 4167, 4174, 4183, 4192, 4200, 4211, 4219, 4230, 4239, 4248, 4257, 4265, 4273, 4283, 4288,
        4295, 4304, 4317, 4324, 4336, 4348, 4359, 4373, 4386, 4399, 4415, 4433, 4454, 4474, 4487, 4496, 4506, 4516,
        4525, 4531, 4539, 4546, 4557, 4565, 4575, 4584, 4593, 4599, 4607, 4612, 4617, 4624, 4631, 4646, 4666, 4682,
        4706, 4727, 4750, 4767, 4785, 4811, 4829, 4853, 4874, 4896, 4918, 4942, 4969, 4996, 5030, 5056, 5079, 5087,
        5094, 5100, 5105, 5111, 5116, 5126, 5130, 5136, 5143, 5151, 5156, 5162, 5169, 5178, 5186, 5193, 5200, 5209,
        5218, 5223, 5230, 5237, 5242, 5254, 5268, 5287, 5314, 5332, 5358, 5386, 5415, 5430, 5448, 5461, 5476, 5495,
        5513, 5543, 5571, 5597, 5617, 5642, 5673, 5703, 5728, 5759, 5801, 5830, 5855, 5883, 5910, 5932, 5964, 5994,
        6017, 6044, 6073, 6099, 6126, 6138, 6156, 6177, 6194, 6208, 6222, 6237,
    )

    /** Index 1..30 = first global ayah of the juz; 31 is the end sentinel. */
    val juzStarts: IntArray = intArrayOf(
        0, 1, 149, 260, 386, 517, 641, 751, 900, 1042, 1201, 1328, 1479, 1649, 1803, 2030, 2215, 2484,
        2674, 2876, 3215, 3386, 3564, 3733, 4090, 4265, 4511, 4706, 5105, 5242, 5673, 6237,
    )

    /** Index 1..240 = first global ayah of the rub; 241 is the end sentinel. */
    val rubStarts: IntArray = intArrayOf(
        0, 1, 33, 51, 67, 82, 99, 113, 131, 149, 165, 184, 196, 210, 226, 240, 250, 260,
        270, 279, 290, 308, 326, 345, 368, 386, 406, 426, 446, 464, 479, 494, 505, 517, 529, 551,
        567, 581, 593, 607, 628, 641, 656, 670, 681, 696, 710, 720, 736, 751, 766, 778, 802, 825,
        848, 863, 884, 900, 916, 930, 940, 955, 985, 1001, 1019, 1042, 1071, 1096, 1110, 1125, 1143, 1161,
        1182, 1201, 1221, 1236, 1254, 1269, 1281, 1295, 1310, 1328, 1346, 1357, 1375, 1390, 1417, 1435, 1454, 1479,
        1497, 1514, 1534, 1557, 1581, 1603, 1626, 1649, 1673, 1697, 1712, 1726, 1742, 1760, 1778, 1803, 1852, 1902,
        1931, 1952, 1976, 1991, 2012, 2030, 2052, 2079, 2099, 2128, 2157, 2172, 2191, 2215, 2239, 2272, 2309, 2349,
        2403, 2431, 2459, 2484, 2512, 2534, 2566, 2596, 2614, 2633, 2655, 2674, 2709, 2748, 2792, 2812, 2826, 2844,
        2856, 2876, 2908, 2933, 2984, 3043, 3113, 3160, 3186, 3215, 3241, 3264, 3281, 3303, 3328, 3341, 3366, 3386,
        3410, 3440, 3463, 3491, 3514, 3534, 3551, 3564, 3584, 3593, 3616, 3630, 3652, 3675, 3701, 3733, 3765, 3810,
        3871, 3933, 3991, 4022, 4066, 4090, 4111, 4134, 4154, 4174, 4199, 4227, 4243, 4265, 4285, 4299, 4323, 4349,
        4382, 4431, 4485, 4511, 4531, 4555, 4578, 4601, 4613, 4626, 4657, 4706, 4759, 4810, 4855, 4902, 4980, 5054,
        5091, 5105, 5118, 5137, 5157, 5178, 5192, 5218, 5230, 5242, 5272, 5324, 5394, 5448, 5495, 5552, 5610, 5673,
        5759, 5830, 5885, 5949, 6024, 6091, 6155, 6237,
    )

    private val prefix: IntArray = IntArray(SURAH_COUNT + 1).also { out ->
        for (i in ayahCounts.indices) out[i + 1] = out[i] + ayahCounts[i]
    }

    init {
        require(surahNames.size == SURAH_COUNT)
        require(ayahCounts.size == SURAH_COUNT && ayahCounts.sum() == AYAH_COUNT)
        require(pageStarts.size == PAGE_COUNT + 2)
        require(juzStarts.size == JUZ_COUNT + 2)
        require(rubStarts.size == RUB_COUNT + 2)
        require(pageStarts[1] == 1 && pageStarts[PAGE_COUNT + 1] == AYAH_COUNT + 1)
        require(juzStarts[1] == 1 && juzStarts[JUZ_COUNT + 1] == AYAH_COUNT + 1)
        require(rubStarts[1] == 1 && rubStarts[RUB_COUNT + 1] == AYAH_COUNT + 1)
    }

    fun surahName(surah: Int): String = surahNames.getOrElse(surah - 1) { "سورة $surah" }
    fun maxAyah(surah: Int): Int = ayahCounts.getOrElse(surah - 1) { 1 }

    fun globalAyah(surah: Int, ayah: Int): Int {
        require(surah in 1..SURAH_COUNT) { "رقم السورة يجب أن يكون بين 1 و114" }
        require(ayah in 1..maxAyah(surah)) { "رقم الآية غير صالح لسورة ${surahName(surah)}" }
        return prefix[surah - 1] + ayah
    }

    fun location(globalAyah: Int): QuranLocation {
        val id = globalAyah.coerceIn(1, AYAH_COUNT)
        var lo = 0
        var hi = SURAH_COUNT - 1
        while (lo <= hi) {
            val mid = (lo + hi) ushr 1
            val start = prefix[mid] + 1
            val end = prefix[mid + 1]
            when {
                id < start -> hi = mid - 1
                id > end -> lo = mid + 1
                else -> return QuranLocation(mid + 1, id - prefix[mid])
            }
        }
        return QuranLocation(SURAH_COUNT, maxAyah(SURAH_COUNT))
    }

    fun pageFor(surah: Int, ayah: Int): Int = boundaryIndex(pageStarts, globalAyah(surah, ayah), PAGE_COUNT)
    fun juzFor(surah: Int, ayah: Int): Int = boundaryIndex(juzStarts, globalAyah(surah, ayah), JUZ_COUNT)
    fun rubFor(surah: Int, ayah: Int): Int = boundaryIndex(rubStarts, globalAyah(surah, ayah), RUB_COUNT)

    fun pageStart(page: Int): QuranLocation {
        require(page in 1..PAGE_COUNT)
        return location(pageStarts[page])
    }

    fun pageEnd(page: Int): QuranLocation {
        require(page in 1..PAGE_COUNT)
        return location(pageStarts[page + 1] - 1)
    }

    fun juzStart(juz: Int): QuranLocation {
        require(juz in 1..JUZ_COUNT)
        return location(juzStarts[juz])
    }

    fun juzEnd(juz: Int): QuranLocation {
        require(juz in 1..JUZ_COUNT)
        return location(juzStarts[juz + 1] - 1)
    }

    fun rubStart(rub: Int): QuranLocation {
        require(rub in 1..RUB_COUNT)
        return location(rubStarts[rub])
    }

    fun rubEnd(rub: Int): QuranLocation {
        require(rub in 1..RUB_COUNT)
        return location(rubStarts[rub + 1] - 1)
    }

    fun range(startSurah: Int, startAyah: Int, endSurah: Int, endAyah: Int): QuranRange {
        val a = QuranLocation(startSurah, startAyah)
        val b = QuranLocation(endSurah, endAyah)
        val ga = globalAyah(a.surah, a.ayah)
        val gb = globalAyah(b.surah, b.ayah)
        val start = if (ga <= gb) a else b
        val end = if (ga <= gb) b else a
        return QuranRange(start, end, pageFor(start.surah, start.ayah), pageFor(end.surah, end.ayah))
    }

    fun rangeForPages(pageA: Int, pageB: Int): QuranRange {
        require(pageA in 1..PAGE_COUNT && pageB in 1..PAGE_COUNT)
        val first = minOf(pageA, pageB)
        val last = maxOf(pageA, pageB)
        return QuranRange(pageStart(first), pageEnd(last), first, last)
    }

    fun rangeForJuz(juz: Int): QuranRange {
        val start = juzStart(juz)
        val end = juzEnd(juz)
        return QuranRange(start, end, pageFor(start.surah, start.ayah), pageFor(end.surah, end.ayah))
    }

    fun rangeForRub(rub: Int): QuranRange {
        val start = rubStart(rub)
        val end = rubEnd(rub)
        return QuranRange(start, end, pageFor(start.surah, start.ayah), pageFor(end.surah, end.ayah))
    }

    private fun boundaryIndex(boundaries: IntArray, id: Int, maxIndex: Int): Int {
        var lo = 1
        var hi = maxIndex
        var answer = 1
        while (lo <= hi) {
            val mid = (lo + hi) ushr 1
            if (boundaries[mid] <= id) {
                answer = mid
                lo = mid + 1
            } else hi = mid - 1
        }
        return answer
    }
}
