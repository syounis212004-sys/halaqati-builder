@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.mohammedsamir.halaqati.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.mohammedsamir.halaqati.data.AppGraph
import com.mohammedsamir.halaqati.data.OfflineQueue
import com.mohammedsamir.halaqati.model.SyncState
import com.mohammedsamir.halaqati.ui.components.AppTopBar
import com.mohammedsamir.halaqati.ui.components.EmptyState
import com.mohammedsamir.halaqati.ui.components.LoadingSkeleton
import com.mohammedsamir.halaqati.ui.components.StateNotice
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter

@Composable
fun SyncCenterScreen(sync: SyncState, onSync: () -> Unit) {
    val scope = rememberCoroutineScope()
    var rows by remember { mutableStateOf<List<OfflineQueue.SnapshotItem>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var message by remember { mutableStateOf<String?>(null) }

    suspend fun reload() {
        loading = true
        rows = try {
            withContext(Dispatchers.IO) { AppGraph.repo.queueSnapshot() }
        } catch (e: Exception) {
            message = e.message ?: "تعذر قراءة قائمة المزامنة"
            emptyList()
        }
        loading = false
    }

    LaunchedEffect(sync.pending, sync.blocked) { reload() }

    Column(Modifier.fillMaxSize()) {
        AppTopBar(
            title = "مركز المزامنة",
            onRefresh = { scope.launch { reload() } },
            pending = sync.pending,
        )
        if (loading && rows.isNotEmpty()) {
            StateNotice(
                "جارٍ تحديث حالة المزامنة…",
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
            )
        }
        message?.let {
            StateNotice(it, "error", Modifier.padding(horizontal = 12.dp, vertical = 8.dp))
        }

        Row(
            Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            SyncMetric("الاتصال", if (sync.online) "متصل" else "غير متصل", Modifier.weight(1f))
            SyncMetric("معلّق", sync.pending.toString(), Modifier.weight(1f))
            SyncMetric("يحتاج مراجعة", sync.blocked.toString(), Modifier.weight(1f))
        }

        ElevatedCard(Modifier.fillMaxWidth().padding(horizontal = 12.dp)) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        if (sync.online) Icons.Default.CloudDone else Icons.Default.CloudOff,
                        contentDescription = null,
                    )
                    Spacer(Modifier.width(8.dp))
                    Column(Modifier.weight(1f)) {
                        Text(
                            if (sync.online) "Supabase متاح" else "أنت تعمل دون اتصال",
                            fontWeight = FontWeight.SemiBold,
                        )
                        Text(
                            sync.lastSync?.let { "آخر مزامنة: ${prettyInstant(it)}" }
                                ?: "لم تُسجل مزامنة ناجحة في هذه الجلسة",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    Button(
                        onClick = onSync,
                        enabled = sync.online && sync.pending > 0 && !sync.syncing,
                        modifier = Modifier.heightIn(min = 48.dp),
                    ) {
                        if (sync.syncing) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(18.dp),
                                strokeWidth = 2.dp,
                            )
                        } else {
                            Icon(Icons.Default.Sync, contentDescription = null)
                        }
                        Spacer(Modifier.width(6.dp))
                        Text(if (sync.syncing) "جارٍ…" else "مزامنة")
                    }
                }
                if (!sync.online && sync.pending > 0) {
                    Surface(
                        color = MaterialTheme.colorScheme.tertiaryContainer,
                        shape = MaterialTheme.shapes.medium,
                    ) {
                        Text(
                            "تم حفظ ${sync.pending} تغييرات محليًا على هذا الجهاز. لن تضيع عند إغلاق الشاشة، وستُرفع تلقائيًا بعد عودة الاتصال.",
                            modifier = Modifier.fillMaxWidth().padding(10.dp),
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onTertiaryContainer,
                            fontWeight = FontWeight.SemiBold,
                        )
                    }
                }
                if (sync.blocked > 0) {
                    Text(
                        "العمليات المحجوبة لا تُحذف تلقائيًا لأنها قد تحتوي على خطأ صلاحيات RLS أو بيانات غير صالحة. راجع الخطأ ثم أعد المحاولة أو احذف العملية يدويًا.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.error,
                    )
                    OutlinedButton(
                        onClick = {
                            scope.launch {
                                withContext(Dispatchers.IO) {
                                    AppGraph.repo.retryAllBlockedQueueItems()
                                }
                                reload()
                            }
                        },
                        enabled = sync.online && !sync.syncing,
                        modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp),
                    ) {
                        Icon(Icons.Default.Replay, contentDescription = null)
                        Spacer(Modifier.width(6.dp))
                        Text("إعادة محاولة كل العمليات المحجوبة")
                    }
                }
            }
        }

        Spacer(Modifier.height(8.dp))
        if (loading && rows.isEmpty()) {
            LoadingSkeleton(rows = 3, modifier = Modifier.padding(horizontal = 12.dp))
        }
        if (!loading && rows.isEmpty()) {
            EmptyState("لا توجد عمليات معلقة — البيانات متزامنة")
        } else {
            LazyColumn(
                contentPadding = PaddingValues(12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                items(rows, key = { it.id }) { item ->
                    ElevatedCard(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    if (item.blocked) Icons.Default.ErrorOutline else Icons.Default.CloudUpload,
                                    contentDescription = null,
                                    tint = if (item.blocked) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary,
                                )
                                Spacer(Modifier.width(8.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(
                                        "${operationAr(item.method)} · ${resourceLabel(item.path)}",
                                        fontWeight = FontWeight.SemiBold,
                                    )
                                    Text(
                                        "المحاولات: ${item.attempts} · ${prettyMillis(item.created)}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    )
                                }
                                Surface(
                                    color = if (item.blocked) MaterialTheme.colorScheme.errorContainer else MaterialTheme.colorScheme.secondaryContainer,
                                    contentColor = if (item.blocked) MaterialTheme.colorScheme.onErrorContainer else MaterialTheme.colorScheme.onSecondaryContainer,
                                    shape = MaterialTheme.shapes.extraLarge,
                                ) {
                                    Row(
                                        Modifier.padding(horizontal = 10.dp, vertical = 7.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(5.dp),
                                    ) {
                                        Icon(
                                            if (item.blocked) Icons.Default.WarningAmber else Icons.Default.Schedule,
                                            contentDescription = null,
                                            modifier = Modifier.size(16.dp),
                                        )
                                        Text(if (item.blocked) "مراجعة" else "بانتظار الرفع", style = MaterialTheme.typography.labelMedium)
                                    }
                                }
                            }
                            if (item.blocked && !item.lastError.isNullOrBlank()) {
                                Surface(
                                    color = MaterialTheme.colorScheme.errorContainer,
                                    shape = MaterialTheme.shapes.medium,
                                ) {
                                    Text(
                                        simplifyError(item.lastError),
                                        modifier = Modifier.fillMaxWidth().padding(10.dp),
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onErrorContainer,
                                    )
                                }
                            }
                            if (item.blocked) {
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    OutlinedButton(onClick = {
                                        scope.launch {
                                            withContext(Dispatchers.IO) {
                                                AppGraph.repo.retryBlockedQueueItem(item.id)
                                                AppGraph.repo.scheduleSync()
                                            }
                                            reload()
                                        }
                                    }, modifier = Modifier.heightIn(min = 48.dp)) {
                                        Icon(Icons.Default.Refresh, contentDescription = null)
                                        Text(" إعادة المحاولة")
                                    }
                                    TextButton(onClick = {
                                        scope.launch {
                                            withContext(Dispatchers.IO) { AppGraph.repo.discardQueueItem(item.id) }
                                            reload()
                                        }
                                    }, modifier = Modifier.heightIn(min = 48.dp)) {
                                        Icon(Icons.Default.DeleteOutline, contentDescription = null)
                                        Text(" حذف العملية")
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SyncMetric(title: String, value: String, modifier: Modifier = Modifier) {
    ElevatedCard(modifier) {
        Column(Modifier.padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(title, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(value, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        }
    }
}

private fun operationAr(method: String) = when (method.uppercase()) {
    "POST" -> "إضافة"
    "PATCH" -> "تعديل"
    "DELETE" -> "حذف"
    else -> method.uppercase()
}

private fun resourceLabel(path: String): String {
    val table = path.substringAfter("/rest/v1/", "").substringBefore('?')
    return when (table) {
        "attendance_records" -> "الحضور"
        "recitation_entries" -> "التسميع"
        "student_daily_notes" -> "ملاحظات الطالب"
        "sessions" -> "الجلسات"
        "smart_plans" -> "الخطط الذكية"
        "smart_plan_events" -> "أحداث الخطة"
        "students" -> "الطلاب"
        "user_devices" -> "الإشعارات"
        else -> table.ifBlank { "بيانات" }
    }
}

private fun simplifyError(error: String): String {
    val clean = error.replace("\\n", " ").replace(Regex("\\s+"), " ").trim()
    return when {
        clean.contains("row-level security", ignoreCase = true) || clean.contains("RLS", ignoreCase = true) ->
            "رفضت صلاحيات قاعدة البيانات هذه العملية. أعد فتح الحساب أو تحقق من صلاحية الدور وربط الحلقة/الطالب ثم أعد المحاولة."
        clean.contains("violates check constraint", ignoreCase = true) ->
            "إحدى القيم لا تطابق قواعد البيانات المسموح بها. افتح السجل وصحح القيمة قبل إعادة المحاولة."
        clean.contains("duplicate", ignoreCase = true) ->
            "يوجد سجل مطابق بالفعل في الخادم. حدّث البيانات ثم أعد المحاولة إذا لزم."
        clean.length > 280 -> clean.take(280) + "…"
        else -> clean
    }
}

private fun prettyMillis(value: Long): String = runCatching {
    Instant.ofEpochMilli(value)
        .atZone(ZoneId.systemDefault())
        .format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm"))
}.getOrDefault("—")

private fun prettyInstant(value: String): String = runCatching {
    Instant.parse(value)
        .atZone(ZoneId.systemDefault())
        .format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm"))
}.getOrDefault(value)
