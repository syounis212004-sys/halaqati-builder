@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.mohammedsamir.halaqati.ui.screens

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.mohammedsamir.halaqati.quran.QuranMetadata
import com.mohammedsamir.halaqati.ui.components.ProFilterChip
import com.mohammedsamir.halaqati.quran.QuranRange

private data class PickerOption(val value: Int, val label: String)

@Composable
private fun NumberDropdown(
    label: String,
    selected: Int,
    options: List<PickerOption>,
    onSelected: (Int) -> Unit,
    modifier: Modifier = Modifier,
) {
    var expanded by remember { mutableStateOf(false) }
    Box(modifier) {
        OutlinedButton(
            onClick = { expanded = true },
            modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp),
        ) {
            Text("$label: ${options.firstOrNull { it.value == selected }?.label ?: selected}", modifier = Modifier.weight(1f))
            Icon(Icons.Default.KeyboardArrowDown, contentDescription = null)
        }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            options.forEach { option ->
                DropdownMenuItem(
                    text = { Text(option.label) },
                    onClick = {
                        onSelected(option.value)
                        expanded = false
                    },
                    modifier = Modifier.heightIn(min = 48.dp),
                )
            }
        }
    }
}

@Composable
fun QuranRangePickerDialog(
    initialStartPage: Int? = null,
    initialEndPage: Int? = null,
    onDismiss: () -> Unit,
    onConfirm: (QuranRange) -> Unit,
) {
    var mode by remember { mutableStateOf(if (initialStartPage != null || initialEndPage != null) "pages" else "ayahs") }
    var startPageText by remember { mutableStateOf((initialStartPage ?: 1).toString()) }
    var endPageText by remember { mutableStateOf((initialEndPage ?: initialStartPage ?: 1).toString()) }
    var startSurah by remember { mutableIntStateOf(1) }
    var startAyah by remember { mutableIntStateOf(1) }
    var endSurah by remember { mutableIntStateOf(1) }
    var endAyah by remember { mutableIntStateOf(7) }
    var startJuz by remember { mutableIntStateOf(1) }
    var endJuz by remember { mutableIntStateOf(1) }
    var startRub by remember { mutableIntStateOf(1) }
    var endRub by remember { mutableIntStateOf(1) }

    val surahOptions = remember {
        (1..QuranMetadata.SURAH_COUNT).map { PickerOption(it, "$it. ${QuranMetadata.surahName(it)}") }
    }
    val juzOptions = remember { (1..QuranMetadata.JUZ_COUNT).map { PickerOption(it, "الجزء $it") } }
    val rubOptions = remember { (1..QuranMetadata.RUB_COUNT).map { PickerOption(it, "ربع الحزب $it") } }

    fun buildRange(): QuranRange? = runCatching {
        when (mode) {
            "pages" -> {
                val a = startPageText.toInt()
                val b = endPageText.toInt()
                QuranMetadata.rangeForPages(a, b)
            }
            "juz" -> {
                val a = minOf(startJuz, endJuz)
                val b = maxOf(startJuz, endJuz)
                val start = QuranMetadata.juzStart(a)
                val end = QuranMetadata.juzEnd(b)
                QuranMetadata.range(start.surah, start.ayah, end.surah, end.ayah)
            }
            "rub" -> {
                val a = minOf(startRub, endRub)
                val b = maxOf(startRub, endRub)
                val start = QuranMetadata.rubStart(a)
                val end = QuranMetadata.rubEnd(b)
                QuranMetadata.range(start.surah, start.ayah, end.surah, end.ayah)
            }
            else -> QuranMetadata.range(startSurah, startAyah, endSurah, endAyah)
        }
    }.getOrNull()

    val range = buildRange()

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("اختيار المقرر من المصحف") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    listOf(
                        "ayahs" to "سورة وآية",
                        "pages" to "صفحات",
                        "juz" to "أجزاء",
                        "rub" to "أرباع الحزب",
                    ).forEach { (value, title) ->
                        ProFilterChip(
                            selected = mode == value,
                            onClick = { mode = value },
                            label = title,
                        )
                    }
                }

                when (mode) {
                    "pages" -> {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = startPageText,
                                onValueChange = { startPageText = it.filter(Char::isDigit).take(3) },
                                label = { Text("من صفحة") },
                                modifier = Modifier.weight(1f),
                                singleLine = true,
                            )
                            OutlinedTextField(
                                value = endPageText,
                                onValueChange = { endPageText = it.filter(Char::isDigit).take(3) },
                                label = { Text("إلى صفحة") },
                                modifier = Modifier.weight(1f),
                                singleLine = true,
                            )
                        }
                        Text("النطاق الصحيح: 1–604", style = MaterialTheme.typography.bodySmall)
                    }

                    "juz" -> {
                        NumberDropdown("من", startJuz, juzOptions, { startJuz = it }, Modifier.fillMaxWidth())
                        NumberDropdown("إلى", endJuz, juzOptions, { endJuz = it }, Modifier.fillMaxWidth())
                    }

                    "rub" -> {
                        NumberDropdown("من", startRub, rubOptions, { startRub = it }, Modifier.fillMaxWidth())
                        NumberDropdown("إلى", endRub, rubOptions, { endRub = it }, Modifier.fillMaxWidth())
                    }

                    else -> {
                        Text("البداية", style = MaterialTheme.typography.titleSmall)
                        NumberDropdown("السورة", startSurah, surahOptions, {
                            startSurah = it
                            startAyah = startAyah.coerceAtMost(QuranMetadata.maxAyah(it))
                        })
                        NumberDropdown(
                            "الآية",
                            startAyah,
                            (1..QuranMetadata.maxAyah(startSurah)).map { PickerOption(it, it.toString()) },
                            { startAyah = it },
                        )
                        HorizontalDivider()
                        Text("النهاية", style = MaterialTheme.typography.titleSmall)
                        NumberDropdown("السورة", endSurah, surahOptions, {
                            endSurah = it
                            endAyah = endAyah.coerceAtMost(QuranMetadata.maxAyah(it))
                        })
                        NumberDropdown(
                            "الآية",
                            endAyah,
                            (1..QuranMetadata.maxAyah(endSurah)).map { PickerOption(it, it.toString()) },
                            { endAyah = it },
                        )
                    }
                }

                range?.let { selected ->
                    ElevatedCard(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text("النطاق المختار", style = MaterialTheme.typography.labelLarge)
                            Text(
                                "من ${selected.start.label} إلى ${selected.end.label}",
                                style = MaterialTheme.typography.bodyLarge,
                            )
                            Text(
                                "الصفحات ${selected.normalizedStartPage}–${selected.normalizedEndPage} · ${selected.pageCount} صفحة",
                                style = MaterialTheme.typography.bodyMedium,
                            )
                            Text(
                                "الجزء ${QuranMetadata.juzFor(selected.start.surah, selected.start.ayah)} → " +
                                    "${QuranMetadata.juzFor(selected.end.surah, selected.end.ayah)} · " +
                                    "ربع الحزب ${QuranMetadata.rubFor(selected.start.surah, selected.start.ayah)} → " +
                                    "${QuranMetadata.rubFor(selected.end.surah, selected.end.ayah)}",
                                style = MaterialTheme.typography.bodySmall,
                            )
                        }
                    }
                } ?: Text(
                    "الاختيار غير صالح. تحقق من القيم.",
                    color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.bodyMedium,
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { range?.let(onConfirm) },
                enabled = range != null,
                modifier = Modifier.heightIn(min = 48.dp),
            ) { Text("اعتماد الاختيار") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss, modifier = Modifier.heightIn(min = 48.dp)) { Text("إلغاء") }
        },
    )
}
