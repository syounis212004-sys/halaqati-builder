package com.mohammedsamir.halaqati.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Badge
import androidx.compose.material.icons.filled.SystemUpdate
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.mohammedsamir.halaqati.BuildConfig
import com.mohammedsamir.halaqati.data.AppGraph
import com.mohammedsamir.halaqati.model.Profile
import com.mohammedsamir.halaqati.ui.components.StateNotice
import com.mohammedsamir.halaqati.ui.update.NativeAppUpdater
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
internal fun AccountNameSettingsCard(profile: Profile) {
    val scope = rememberCoroutineScope()
    var editing by remember { mutableStateOf(false) }
    var value by remember(profile.id) { mutableStateOf(profile.fullName) }
    var saving by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }
    Card(Modifier.fillMaxWidth(), border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline)) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Badge, null, tint = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text("اسم الحساب", fontWeight = FontWeight.Bold)
                    Text("الاسم الذي يظهر للمسؤولين وأولياء الأمور والمحفظين.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            if (editing) {
                OutlinedTextField(value, { value = it }, label = { Text("الاسم الكامل") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(enabled = !saving && value.trim().length >= 3, onClick = {
                        saving = true; message = null
                        scope.launch {
                            val r = withContext(Dispatchers.IO) { runCatching { AppGraph.repo.updateMyFullName(value) } }
                            saving = false
                            r.onSuccess { message = "تم تحديث اسم الحساب"; editing = false }
                                .onFailure { message = it.message ?: "تعذر تحديث الاسم" }
                        }
                    }) { Text(if (saving) "جارٍ الحفظ…" else "حفظ") }
                    OutlinedButton(onClick = { value = profile.fullName; editing = false }, enabled = !saving) { Text("إلغاء") }
                }
            } else {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) { Text(value.ifBlank { profile.fullName }, style = MaterialTheme.typography.titleMedium); Text(profile.email, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                    OutlinedButton(onClick = { editing = true }) { Text("تعديل الاسم الكامل") }
                }
            }
            message?.let { StateNotice(it, if (it.startsWith("تم")) "success" else "warning") }
        }
    }
}

@Composable
internal fun AppUpdateSettingsCard() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var checking by remember { mutableStateOf(false) }
    var info by remember { mutableStateOf<NativeAppUpdater.UpdateInfo?>(null) }
    var message by remember { mutableStateOf<String?>(null) }
    Card(Modifier.fillMaxWidth(), border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline)) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.SystemUpdate, null, tint = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text("تحديث التطبيق", fontWeight = FontWeight.Bold)
                    Text("الإصدار الحالي ${BuildConfig.VERSION_NAME}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                if (info?.available == false) Icon(Icons.Default.Verified, null, tint = MaterialTheme.colorScheme.primary)
            }
            info?.let { update ->
                StateNotice(if (update.available) "يتوفر تحديث ${update.versionName}" else "أنت على أحدث إصدار", if (update.available) "info" else "success")
                update.notes.take(4).forEach { Text("• $it", style = MaterialTheme.typography.bodySmall) }
                if (update.available) {
                    Button(onClick = {
                        val id = NativeAppUpdater.downloadAndInstall(context, update)
                        message = "بدأ تنزيل التحديث (رقم $id). بعد اكتماله افتح التنزيلات لإكمال التثبيت."
                    }, modifier = Modifier.fillMaxWidth()) { Text("تنزيل وتثبيت التحديث") }
                    OutlinedButton(onClick = { NativeAppUpdater.openDownloads(context) }, modifier = Modifier.fillMaxWidth()) { Text("فتح التنزيلات") }
                }
            }
            message?.let { StateNotice(it, if (it.startsWith("تعذر")) "warning" else "info") }
            OutlinedButton(enabled = !checking, onClick = {
                checking = true; message = null
                scope.launch {
                    val r = runCatching { NativeAppUpdater.check() }
                    checking = false
                    r.onSuccess { info = it }.onFailure { message = "تعذر فحص التحديثات: ${it.message ?: "خطأ"}" }
                }
            }, modifier = Modifier.fillMaxWidth()) { Text(if (checking) "جاري فحص التحديثات…" else "فحص الآن") }
        }
    }
}

@Composable
internal fun V6ScoringSettingsCard() {
    Card(Modifier.fillMaxWidth(), border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline)) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("معيار جودة التسميع V6", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Text("الخطأ = 1 · التلقين = 0.5 · تطبيع على 15 سطرًا حسب السطور المسمعة فعليًا.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                V6Band("ممتاز", "90–100%", Modifier.weight(1f))
                V6Band("جيد جدًا", "80–<90%", Modifier.weight(1f))
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                V6Band("جيد", "70–<80%", Modifier.weight(1f))
                V6Band("يحتاج إعادة", "<70%", Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun V6Band(label: String, range: String, modifier: Modifier = Modifier) {
    Surface(modifier, shape = MaterialTheme.shapes.medium, color = MaterialTheme.colorScheme.surfaceVariant) {
        Column(Modifier.padding(9.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(label, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelLarge)
            Text(range, style = MaterialTheme.typography.labelSmall)
        }
    }
}
