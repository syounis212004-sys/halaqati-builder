package com.mohammedsamir.halaqati.data

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.time.Duration
import java.time.Instant

/**
 * Account-scoped cache for read-only Supabase payloads.
 *
 * This database intentionally stores only response JSON and timestamps. Authentication tokens,
 * service credentials, and unscoped rows do not belong here. Every read/write predicate includes
 * owner_user_id so switching accounts on the same device cannot surface another account's cache.
 */
class LocalCache(context: Context) : SQLiteOpenHelper(
    context.applicationContext,
    DATABASE_NAME,
    null,
    DATABASE_VERSION,
) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            """
            CREATE TABLE cache_entries(
                owner_user_id TEXT NOT NULL,
                cache_key TEXT NOT NULL,
                json_value TEXT NOT NULL,
                saved_at INTEGER NOT NULL,
                PRIMARY KEY(owner_user_id, cache_key)
            )
            """.trimIndent(),
        )
        db.execSQL(
            "CREATE INDEX IF NOT EXISTS cache_owner_saved_at ON cache_entries(owner_user_id, saved_at)",
        )
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) = Unit

    fun put(
        ownerUserId: String,
        key: String,
        json: String,
        savedAt: Instant = Instant.now(),
    ) {
        requireScope(ownerUserId, key)
        require(json.isNotBlank()) { "cache json must not be blank" }
        val values = ContentValues().apply {
            put("owner_user_id", ownerUserId.trim())
            put("cache_key", key.trim())
            put("json_value", json)
            put("saved_at", savedAt.toEpochMilli())
        }
        writableDatabase.insertWithOnConflict(
            "cache_entries",
            null,
            values,
            SQLiteDatabase.CONFLICT_REPLACE,
        )
    }

    fun get(
        ownerUserId: String,
        key: String,
        maxAge: Duration? = null,
        now: Instant = Instant.now(),
    ): String? {
        if (!isValidScope(ownerUserId, key)) return null
        if (maxAge != null && maxAge.isNegative) return null
        return readableDatabase.query(
            "cache_entries",
            arrayOf("json_value", "saved_at"),
            "owner_user_id=? AND cache_key=?",
            arrayOf(ownerUserId.trim(), key.trim()),
            null,
            null,
            null,
            "1",
        ).use { cursor ->
            if (!cursor.moveToFirst()) return@use null
            val savedAt = Instant.ofEpochMilli(cursor.getLong(1))
            if (!isUsable(savedAt, maxAge, now)) return@use null
            cursor.getString(0)
        }
    }

    fun invalidate(ownerUserId: String, prefix: String) {
        if (!isValidScope(ownerUserId, prefix)) return
        val escaped = prefix.trim()
            .replace("\\", "\\\\")
            .replace("%", "\\%")
            .replace("_", "\\_")
        writableDatabase.delete(
            "cache_entries",
            "owner_user_id=? AND cache_key LIKE ? ESCAPE '\\'",
            arrayOf(ownerUserId.trim(), "$escaped%"),
        )
    }

    fun clearOwner(ownerUserId: String) {
        if (ownerUserId.isBlank()) return
        writableDatabase.delete(
            "cache_entries",
            "owner_user_id=?",
            arrayOf(ownerUserId.trim()),
        )
    }

    private fun requireScope(ownerUserId: String, key: String) {
        require(isValidScope(ownerUserId, key)) { "cache owner and key are required" }
    }

    companion object {
        private const val DATABASE_NAME = "halaqati-cache.db"
        private const val DATABASE_VERSION = 1

        fun isValidScope(ownerUserId: String, key: String): Boolean =
            ownerUserId.isNotBlank() && key.isNotBlank()

        fun isUsable(savedAt: Instant, maxAge: Duration?, now: Instant = Instant.now()): Boolean {
            if (maxAge == null) return true
            if (maxAge.isNegative) return false
            if (savedAt.isAfter(now)) return true
            return Duration.between(savedAt, now) <= maxAge
        }
    }
}
