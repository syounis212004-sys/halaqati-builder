package com.mohammedsamir.halaqati.ui.update

import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Environment
import com.mohammedsamir.halaqati.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object NativeAppUpdater {
    const val UPDATE_MANIFEST_URL = "https://syounis212004-sys.github.io/halaqati-web/version.json"

    data class UpdateInfo(val versionCode: Int, val versionName: String, val apkUrl: String, val notes: List<String>) {
        val available: Boolean get() = versionCode > BuildConfig.VERSION_CODE
    }

    suspend fun check(): UpdateInfo = withContext(Dispatchers.IO) {
        val conn = URL("$UPDATE_MANIFEST_URL?t=${System.currentTimeMillis()}").openConnection() as HttpURLConnection
        conn.connectTimeout = 12_000
        conn.readTimeout = 12_000
        conn.setRequestProperty("Cache-Control", "no-cache")
        try {
            if (conn.responseCode !in 200..299) error("تعذر الوصول إلى ملف التحديث (${conn.responseCode})")
            val json = JSONObject(conn.inputStream.bufferedReader().use { it.readText() })
            val code = json.optInt("versionCode", 0)
            val url = json.optString("apkUrl")
            require(code > 0 && url.startsWith("http")) { "ملف التحديث غير مكتمل" }
            val rawNotes = json.opt("notes")
            val notes = when (rawNotes) {
                is org.json.JSONArray -> (0 until rawNotes.length()).mapNotNull { rawNotes.optString(it).takeIf(String::isNotBlank) }
                is String -> rawNotes.lines().map(String::trim).filter(String::isNotBlank)
                else -> emptyList()
            }
            UpdateInfo(code, json.optString("versionName", code.toString()), url, notes)
        } finally { conn.disconnect() }
    }

    fun downloadAndInstall(context: Context, info: UpdateInfo): Long {
        val request = DownloadManager.Request(Uri.parse(info.apkUrl))
            .setTitle("تحديث حلقتي ${info.versionName}")
            .setDescription("تنزيل إصدار حلقتي الجديد")
            .setMimeType("application/vnd.android.package-archive")
            .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "Halaqati-${info.versionName}.apk")
        return context.getSystemService(DownloadManager::class.java).enqueue(request)
    }

    fun openDownloads(context: Context) {
        context.startActivity(Intent(DownloadManager.ACTION_VIEW_DOWNLOADS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
}
