package com.mohammedsamir.halaqati.data

/**
 * Canonical student-track contract for the Native app.
 * The product has exactly two student tracks:
 *  - general_hifz: مسار الحفظ العام
 *  - tathbit: مسار التثبيت
 *
 * Legacy production rows may still contain `sard`; that value is read as
 * general_hifz. Sard remains a recitation/activity type, never a third track.
 */
object StudentTrackRules {
    const val GENERAL_HIFZ = "general_hifz"
    const val TATHBIT = "tathbit"
    val allowed = setOf(GENERAL_HIFZ, TATHBIT)

    fun canonicalStored(value: String?): String = when (value?.trim()?.lowercase()) {
        TATHBIT -> TATHBIT
        GENERAL_HIFZ, "sard", "", null -> GENERAL_HIFZ
        else -> GENERAL_HIFZ
    }

    /** Strict parser for user/import input. Blank means the normal general track. */
    fun parseInput(value: String?): String? {
        val raw = value.orEmpty().trim()
        if (raw.isBlank()) return GENERAL_HIFZ
        val n = raw.lowercase()
            .replace('أ', 'ا').replace('إ', 'ا').replace('آ', 'ا')
            .replace(Regex("\\s+"), " ")
        return when {
            n == GENERAL_HIFZ || n == "hifz" || n == "general hifz" || n == "general-hifz" ||
                n.contains("الحفظ العام") || n == "حفظ" || n == "سرد" || n == "sard" -> GENERAL_HIFZ
            n == TATHBIT || n.contains("تثبيت") -> TATHBIT
            else -> null
        }
    }

    fun label(value: String?): String = when (canonicalStored(value)) {
        TATHBIT -> "مسار التثبيت"
        else -> "مسار الحفظ العام"
    }

    /** PostgREST filter that also includes legacy `sard` rows in general_hifz. */
    fun postgrestFilter(column: String, track: String): String = when (track) {
        GENERAL_HIFZ -> "$column=in.($GENERAL_HIFZ,sard)"
        TATHBIT -> "$column=eq.$TATHBIT"
        else -> error("المسار غير صالح")
    }
}
