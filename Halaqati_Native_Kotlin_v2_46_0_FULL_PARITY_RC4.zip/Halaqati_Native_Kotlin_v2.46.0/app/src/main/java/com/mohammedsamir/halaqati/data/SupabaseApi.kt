package com.mohammedsamir.halaqati.data

import com.mohammedsamir.halaqati.BuildConfig
import com.mohammedsamir.halaqati.model.UserSession
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URI
import java.net.URL
import java.net.URLEncoder
import java.nio.charset.StandardCharsets
import java.util.Base64

class SupabaseException(message: String, val status: Int = 0) : Exception(message)

class SupabaseApi(private val sessionStore: SecureSessionStore) {
    companion object {
        const val APP_DEEP_LINK = "com.mohammedsamir.halaqati://auth/callback"
    }

    private fun connection(
        url: String,
        method: String,
        auth: Boolean = true,
        prefer: String? = null,
        bearerOverride: String? = null,
    ): HttpURLConnection = (URL(url).openConnection() as HttpURLConnection).apply {
        requestMethod = method
        connectTimeout = 12_000
        readTimeout = 20_000
        setRequestProperty("apikey", BuildConfig.SUPABASE_PUBLISHABLE_KEY)
        setRequestProperty("Accept", "application/json")
        setRequestProperty("Content-Type", "application/json")
        val bearer = bearerOverride ?: if (auth) sessionStore.load()?.accessToken else null
        bearer?.takeIf { it.isNotBlank() }?.let { setRequestProperty("Authorization", "Bearer $it") }
        prefer?.let { setRequestProperty("Prefer", it) }
    }

    private fun call(
        url: String,
        method: String = "GET",
        body: String? = null,
        auth: Boolean = true,
        prefer: String? = null,
        bearerOverride: String? = null,
    ): String {
        val connection = connection(url, method, auth, prefer, bearerOverride)
        if (body != null) {
            connection.doOutput = true
            connection.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
        }
        val code = connection.responseCode
        val stream = if (code in 200..299) connection.inputStream else connection.errorStream
        val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
        if (code !in 200..299) {
            val detail = runCatching {
                val json = JSONObject(text)
                json.optString("message")
                    .ifBlank { json.optString("msg") }
                    .ifBlank { json.optString("error_description") }
                    .ifBlank { text }
            }.getOrDefault(text)
            throw SupabaseException(detail.ifBlank { "HTTP $code" }, code)
        }
        return text
    }

    fun signIn(email: String, password: String): UserSession {
        val json = JSONObject(
            call(
                "${BuildConfig.SUPABASE_URL}/auth/v1/token?grant_type=password",
                "POST",
                JSONObject().put("email", email).put("password", password).toString(),
                auth = false,
            ),
        )
        return sessionFromAuthJson(json, email).also(sessionStore::save)
    }

    fun signInWithGoogleIdToken(idToken: String, rawNonce: String): UserSession {
        require(idToken.isNotBlank()) { "Google ID token فارغ" }
        val request = JSONObject()
            .put("provider", "google")
            .put("id_token", idToken)
            .put("nonce", rawNonce)
        val json = JSONObject(
            call(
                "${BuildConfig.SUPABASE_URL}/auth/v1/token?grant_type=id_token",
                "POST",
                request.toString(),
                auth = false,
            ),
        )
        return sessionFromAuthJson(json, "").also(sessionStore::save)
    }

    fun signUp(
        email: String,
        password: String,
        fullName: String,
        phone: String,
        requestedRole: String,
    ): UserSession? {
        val request = JSONObject()
            .put("email", email)
            .put("password", password)
            .put(
                "data",
                JSONObject()
                    .put("full_name", fullName)
                    .put("phone", phone)
                    .put("requested_role", requestedRole),
            )
        val json = JSONObject(
            call(
                "${BuildConfig.SUPABASE_URL}/auth/v1/signup",
                "POST",
                request.toString(),
                auth = false,
            ),
        )
        val accessToken = json.optString("access_token")
        if (accessToken.isBlank()) return null
        return sessionFromAuthJson(json, email).also(sessionStore::save)
    }

    fun refresh(): UserSession? {
        val old = sessionStore.load() ?: return null
        if (old.refreshToken.isBlank()) return null
        val json = JSONObject(
            call(
                "${BuildConfig.SUPABASE_URL}/auth/v1/token?grant_type=refresh_token",
                "POST",
                JSONObject().put("refresh_token", old.refreshToken).toString(),
                auth = false,
            ),
        )
        return sessionFromAuthJson(json, old.email).also(sessionStore::save)
    }

    fun googleOAuthUrl(): String = buildString {
        append(BuildConfig.SUPABASE_URL)
        append("/auth/v1/authorize?provider=google&redirect_to=")
        append(URLEncoder.encode(APP_DEEP_LINK, StandardCharsets.UTF_8.name()))
        append("&prompt=select_account")
    }

    /** Accepts Supabase OAuth or recovery callbacks delivered through the app deep link. */
    fun acceptOAuthCallback(url: String): UserSession? {
        val callback = AuthCallbackRules.parse(url, APP_DEEP_LINK) ?: return null
        callback.error?.takeIf { it.isNotBlank() }?.let { throw SupabaseException(it) }
        val access = callback.accessToken
        val refresh = callback.refreshToken
        if (access.isBlank() || refresh.isBlank()) return null
        // Validate the access token with Supabase before persisting it.  The JWT
        // payload is only used as a fallback for older auth responses; RLS will
        // still validate the bearer token on every data request.
        val verifiedUser = userForToken(access)
        val payload = decodeJwtPayload(access)
        val userId = verifiedUser.optString("id").ifBlank { payload.optString("sub") }
        if (userId.isBlank()) throw SupabaseException("تعذر تحديد حساب Google من جلسة Supabase")
        val email = verifiedUser.optString("email").ifBlank { payload.optString("email") }
        return UserSession(access, refresh, userId, email).also(sessionStore::save)
    }

    fun callbackType(url: String): String = AuthCallbackRules.parse(url, APP_DEEP_LINK)?.type.orEmpty()

    fun requestPasswordReset(email: String) {
        val redirect = URLEncoder.encode(APP_DEEP_LINK, StandardCharsets.UTF_8.name())
        call(
            "${BuildConfig.SUPABASE_URL}/auth/v1/recover?redirect_to=$redirect",
            "POST",
            JSONObject().put("email", email).toString(),
            auth = false,
        )
    }

    fun updatePassword(newPassword: String) {
        require(newPassword.length >= 6) { "كلمة المرور يجب أن تكون 6 أحرف على الأقل" }
        call(
            "${BuildConfig.SUPABASE_URL}/auth/v1/user",
            "PUT",
            JSONObject().put("password", newPassword).toString(),
        )
    }

    fun userForToken(accessToken: String): JSONObject = JSONObject(
        call(
            "${BuildConfig.SUPABASE_URL}/auth/v1/user",
            auth = false,
            bearerOverride = accessToken,
        ),
    )

    private fun sessionFromAuthJson(json: JSONObject, fallbackEmail: String): UserSession {
        val user = json.optJSONObject("user") ?: JSONObject()
        return UserSession(
            accessToken = json.getString("access_token"),
            refreshToken = json.optString("refresh_token"),
            userId = user.optString("id").ifBlank { decodeJwtPayload(json.getString("access_token")).optString("sub") },
            email = user.optString("email").ifBlank { fallbackEmail },
        )
    }

    private fun decodeJwtPayload(jwt: String): JSONObject = runCatching {
        val segment = jwt.split('.').getOrNull(1) ?: return@runCatching JSONObject()
        val padded = segment + "=".repeat((4 - segment.length % 4) % 4)
        JSONObject(String(Base64.getUrlDecoder().decode(padded), Charsets.UTF_8))
    }.getOrElse { JSONObject() }

    fun select(table: String, query: String = "select=*&limit=500", auth: Boolean = true): JSONArray {
        val text = call("${BuildConfig.SUPABASE_URL}/rest/v1/$table?$query", auth = auth)
        return if (text.isBlank()) JSONArray() else JSONArray(text)
    }

    fun insert(table: String, obj: JSONObject): JSONArray = JSONArray(
        call(
            "${BuildConfig.SUPABASE_URL}/rest/v1/$table",
            "POST",
            obj.toString(),
            prefer = "return=representation",
        ),
    )

    fun upsert(table: String, obj: JSONObject, onConflict: String? = null): JSONArray {
        val query = onConflict?.let { "?on_conflict=$it" }.orEmpty()
        return JSONArray(
            call(
                "${BuildConfig.SUPABASE_URL}/rest/v1/$table$query",
                "POST",
                obj.toString(),
                prefer = "resolution=merge-duplicates,return=representation",
            ),
        )
    }

    fun patch(table: String, filter: String, obj: JSONObject): JSONArray = JSONArray(
        call(
            "${BuildConfig.SUPABASE_URL}/rest/v1/$table?$filter",
            "PATCH",
            obj.toString(),
            prefer = "return=representation",
        ),
    )

    fun delete(table: String, filter: String): JSONArray = JSONArray(
        call(
            "${BuildConfig.SUPABASE_URL}/rest/v1/$table?$filter",
            "DELETE",
            prefer = "return=representation",
        ),
    )

    fun rpc(name: String, args: JSONObject = JSONObject()): String = call(
        "${BuildConfig.SUPABASE_URL}/rest/v1/rpc/$name",
        "POST",
        args.toString(),
    )

    fun function(name: String, args: JSONObject = JSONObject(), auth: Boolean = true): String = call(
        "${BuildConfig.SUPABASE_URL}/functions/v1/$name",
        "POST",
        args.toString(),
        auth,
    )

    fun raw(method: String, path: String, body: String?): String = call(
        "${BuildConfig.SUPABASE_URL}$path",
        method,
        body,
    )
}
