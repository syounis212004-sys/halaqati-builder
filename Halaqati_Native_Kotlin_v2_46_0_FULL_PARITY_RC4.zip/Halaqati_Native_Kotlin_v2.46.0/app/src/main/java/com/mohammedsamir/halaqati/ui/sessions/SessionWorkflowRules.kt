package com.mohammedsamir.halaqati.ui.sessions

object SessionWorkflowRules {
    val manualSessionTypes = listOf("tasmee", "sard", "review", "test", "tajweed", "lesson", "other")

    fun sessionTypeForAssignment(assignmentKind: String): String = when (assignmentKind) {
        "sard" -> "sard"
        "review", "tathbit" -> "review"
        "test" -> "test"
        else -> "tasmee"
    }
}
