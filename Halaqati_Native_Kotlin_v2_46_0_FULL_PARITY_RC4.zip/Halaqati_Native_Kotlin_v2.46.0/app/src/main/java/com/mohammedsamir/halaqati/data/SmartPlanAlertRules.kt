package com.mohammedsamir.halaqati.data

/** Pure release-critical rules for smart-plan guardian alerts. */
object SmartPlanAlertRules {
    fun shouldSendDelay(consecutiveMissed: Int, delayAlertDays: Int): Boolean =
        delayAlertDays > 0 && consecutiveMissed >= delayAlertDays

    fun shouldSendHomePrep(localHour: Int, enabled: Boolean, startPage: Int?): Boolean =
        enabled && localHour >= 17 && startPage != null

    fun preferredPlanType(studentTrack: String): String =
        if (StudentTrackRules.canonicalStored(studentTrack) == StudentTrackRules.TATHBIT) "tathbit" else "hifz"

    fun assignmentLabel(kind: String, startPage: Int?, endPage: Int?): String {
        val range = when {
            startPage == null -> "المقرر المحدد في الخطة"
            endPage == null || endPage == startPage -> "ص $startPage"
            else -> "ص $startPage–$endPage"
        }
        return when (kind) {
            "hifz" -> "حفظ $range"
            "sard" -> "سرد $range"
            "test" -> "اختبار مرحلي $range"
            "tathbit" -> "تثبيت/إعادة $range"
            "review", "review_near" -> "مراجعة قريبة $range"
            "review_far" -> "مراجعة بعيدة $range"
            else -> range
        }
    }
}
