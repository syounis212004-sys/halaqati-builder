package com.mohammedsamir.halaqati.ui.components

import androidx.annotation.DrawableRes
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.mohammedsamir.halaqati.R
import com.mohammedsamir.halaqati.model.Profile
import com.mohammedsamir.halaqati.model.UserRole
import com.mohammedsamir.halaqati.ui.navigation.AppDestination
import com.mohammedsamir.halaqati.ui.navigation.RoleNavigationPolicy

private val GoldenGreen = Color(0xFF0D3B2F)
private val GoldenGreen2 = Color(0xFF16634F)
private val GoldenGreen3 = Color(0xFF2F8B69)
private val GoldenMint = Color(0xFFE9F3EE)
private val GoldenLine = Color(0xFFE4EBE7)
private val GoldenMuted = Color(0xFF78837E)


data class GoldenShellActions(
    val roleLabel: String,
    val online: Boolean,
    val pending: Int,
    val openDrawer: () -> Unit,
    val openNotifications: () -> Unit,
    val openSyncCenter: () -> Unit,
)

val LocalGoldenShellActions = staticCompositionLocalOf<GoldenShellActions?> { null }

@DrawableRes
private fun goldenIconRes(key: String): Int = when (key) {
    "home" -> R.drawable.ic_gm_home
    "notifications" -> R.drawable.ic_gm_notifications
    "group", "halaqas" -> R.drawable.ic_gm_halaqas
    "forum", "community" -> R.drawable.ic_gm_community
    "event", "sessions" -> R.drawable.ic_gm_sessions
    "person", "students" -> R.drawable.ic_gm_students
    "timeline", "plans" -> R.drawable.ic_gm_plans
    "award", "certificates" -> R.drawable.ic_gm_certificates
    "report", "reports" -> R.drawable.ic_gm_reports
    "book", "quran" -> R.drawable.ic_gm_quran
    "leaderboard", "ranking", "rankings" -> R.drawable.ic_gm_ranking
    "competition" -> R.drawable.ic_gm_competition
    "importexport", "data" -> R.drawable.ic_gm_data
    "supervisor", "supervision" -> R.drawable.ic_gm_supervision
    "users" -> R.drawable.ic_gm_users
    "profile" -> R.drawable.ic_gm_profile
    "settings" -> R.drawable.ic_gm_settings
    "more" -> R.drawable.ic_gm_more
    else -> R.drawable.ic_gm_more
}

@Composable
fun GoldenNavIcon(
    key: String,
    contentDescription: String?,
    modifier: Modifier = Modifier,
    tint: Color = LocalContentColor.current,
) {
    Icon(
        painter = painterResource(goldenIconRes(key)),
        contentDescription = contentDescription,
        modifier = modifier,
        tint = tint,
    )
}

@Composable
fun GoldenBottomBar(
    role: UserRole,
    currentRoute: String,
    drawerOpen: Boolean,
    onNavigate: (AppDestination) -> Unit,
    onMore: () -> Unit,
) {
    val items = RoleNavigationPolicy.bottom(role)
    val coreRoutes = items.filterNot { it == AppDestination.More }.map { it.route }.toSet()
    Surface(
        color = MaterialTheme.colorScheme.surface.copy(alpha = .98f),
        tonalElevation = 0.dp,
        shadowElevation = 8.dp,
        modifier = Modifier.fillMaxWidth(),
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .height(74.dp)
                .navigationBarsPadding(),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            items.forEach { destination ->
                val isMore = destination == AppDestination.More
                val selected = if (isMore) {
                    drawerOpen || currentRoute !in coreRoutes
                } else {
                    currentRoute == destination.route ||
                        (currentRoute == AppDestination.SessionToday.route && destination == AppDestination.Sessions)
                }
                val tint = if (selected) MaterialTheme.colorScheme.primary else GoldenMuted
                Box(
                    modifier = Modifier.weight(1f).fillMaxHeight().padding(horizontal = 4.dp, vertical = 6.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    Column(
                        modifier = Modifier
                            .clip(RoundedCornerShape(14.dp))
                            .background(if (selected) GoldenMint else Color.Transparent)
                            .clickable { if (isMore) onMore() else onNavigate(destination) }
                            .heightIn(min = 56.dp)
                            .padding(horizontal = 8.dp, vertical = 5.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center,
                    ) {
                        if (selected) {
                            Box(
                                Modifier
                                    .width(22.dp)
                                    .height(3.dp)
                                    .clip(RoundedCornerShape(2.dp))
                                    .background(GoldenGreen3),
                            )
                            Spacer(Modifier.height(3.dp))
                        }
                        GoldenNavIcon(
                            key = destination.iconKey,
                            contentDescription = destination.label,
                            tint = tint,
                            modifier = Modifier.size(22.dp),
                        )
                        Spacer(Modifier.height(3.dp))
                        Text(
                            destination.label,
                            style = MaterialTheme.typography.labelMedium,
                            color = tint,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun GoldenDrawerContent(
    profile: Profile,
    currentRoute: String,
    onNavigate: (AppDestination) -> Unit,
    onClose: () -> Unit,
    onLogout: () -> Unit,
) {
    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.surface),
    ) {
        Box(
            Modifier
                .fillMaxWidth()
                .height(188.dp)
                .background(Brush.linearGradient(listOf(GoldenGreen, GoldenGreen2, GoldenGreen3))),
        ) {
            IconButton(
                onClick = onClose,
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(18.dp)
                    .size(48.dp)
                    .background(Color.White.copy(alpha = .10f), RoundedCornerShape(14.dp)),
            ) {
                Icon(Icons.Default.Close, contentDescription = "إغلاق القائمة", tint = Color.White, modifier = Modifier.size(30.dp))
            }
            Column(
                Modifier.align(Alignment.CenterEnd).padding(horizontal = 22.dp, vertical = 18.dp),
                horizontalAlignment = Alignment.End,
            ) {
                Text("۞", color = Color.White.copy(alpha = .9f), style = MaterialTheme.typography.headlineLarge)
                Text("حلقتي", color = Color.White, style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
                Text(
                    "${profile.fullName} · ${roleTitle(profile.role)}",
                    color = Color.White.copy(alpha = .82f),
                    style = MaterialTheme.typography.bodyMedium,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                )
            }
        }

        // The body owns the scroll. The footer stays reachable at all times, fixing the
        // clipped/non-scrollable drawer regression in the first native migration.
        LazyColumn(
            modifier = Modifier.weight(1f).fillMaxWidth(),
            contentPadding = PaddingValues(horizontal = 11.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(3.dp),
        ) {
            items(RoleNavigationPolicy.drawerItems(profile.role), key = { it.destination.route }) { item ->
                val active = currentRoute == item.destination.route ||
                    (currentRoute == AppDestination.SessionToday.route && item.destination == AppDestination.Sessions)
                val color = if (active) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(13.dp))
                        .background(if (active) GoldenMint else Color.Transparent)
                        .clickable { onNavigate(item.destination) }
                        .heightIn(min = 52.dp)
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(14.dp),
                ) {
                    GoldenNavIcon(
                        item.destination.iconKey,
                        contentDescription = null,
                        tint = color,
                        modifier = Modifier.size(24.dp),
                    )
                    Text(
                        item.label,
                        color = color,
                        style = MaterialTheme.typography.bodyLarge,
                        fontWeight = if (active) FontWeight.Bold else FontWeight.Normal,
                        modifier = Modifier.weight(1f),
                    )
                }
            }
        }

        HorizontalDivider(color = GoldenLine)
        Column(Modifier.fillMaxWidth().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            OutlinedButton(
                onClick = onLogout,
                modifier = Modifier.fillMaxWidth().heightIn(min = 52.dp),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.onSurface),
            ) { Text("تسجيل الخروج", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold) }
            Spacer(Modifier.height(10.dp))
            Text("Designed by Dr. Mohammed Samir", color = GoldenMuted, style = MaterialTheme.typography.labelSmall)
        }
    }
}

fun roleTitle(role: UserRole): String = when (role) {
    UserRole.ADMIN -> "مسؤول النظام والحلقات"
    UserRole.SUPERVISOR -> "مشرف الحلقات"
    UserRole.TEACHER -> "محفّظ الحلقة"
    UserRole.GUARDIAN -> "ولي الأمر"
    else -> "المستخدم"
}
