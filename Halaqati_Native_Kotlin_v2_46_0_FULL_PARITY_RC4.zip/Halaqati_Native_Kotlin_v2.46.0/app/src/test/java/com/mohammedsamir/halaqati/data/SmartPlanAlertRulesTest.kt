package com.mohammedsamir.halaqati.data

import org.junit.Assert.*
import org.junit.Test

class SmartPlanAlertRulesTest {
    @Test fun delayThresholdIsInclusive() {
        assertFalse(SmartPlanAlertRules.shouldSendDelay(2, 3))
        assertTrue(SmartPlanAlertRules.shouldSendDelay(3, 3))
    }

    @Test fun homePrepNeedsEveningEnabledAndRange() {
        assertFalse(SmartPlanAlertRules.shouldSendHomePrep(16, true, 20))
        assertFalse(SmartPlanAlertRules.shouldSendHomePrep(18, false, 20))
        assertFalse(SmartPlanAlertRules.shouldSendHomePrep(18, true, null))
        assertTrue(SmartPlanAlertRules.shouldSendHomePrep(17, true, 20))
    }

    @Test fun studentTrackSelectsOnlyTwoPlanFamilies() {
        assertEquals("hifz", SmartPlanAlertRules.preferredPlanType("general_hifz"))
        assertEquals("hifz", SmartPlanAlertRules.preferredPlanType("sard"))
        assertEquals("tathbit", SmartPlanAlertRules.preferredPlanType("tathbit"))
    }

    @Test fun labelsAssignmentsInArabic() {
        assertEquals("حفظ ص 20–22", SmartPlanAlertRules.assignmentLabel("hifz", 20, 22))
        assertEquals("اختبار مرحلي ص 41", SmartPlanAlertRules.assignmentLabel("test", 41, 41))
    }
}
