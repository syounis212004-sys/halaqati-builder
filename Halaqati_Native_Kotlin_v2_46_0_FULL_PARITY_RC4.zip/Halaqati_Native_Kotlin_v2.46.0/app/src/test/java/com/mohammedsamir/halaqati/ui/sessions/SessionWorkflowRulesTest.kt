package com.mohammedsamir.halaqati.ui.sessions

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class SessionWorkflowRulesTest {
    @Test fun mapsAssignmentKindsToLegacySessionTypes() {
        assertEquals("sard", SessionWorkflowRules.sessionTypeForAssignment("sard"))
        assertEquals("review", SessionWorkflowRules.sessionTypeForAssignment("tathbit"))
        assertEquals("review", SessionWorkflowRules.sessionTypeForAssignment("review"))
        assertEquals("test", SessionWorkflowRules.sessionTypeForAssignment("test"))
        assertEquals("tasmee", SessionWorkflowRules.sessionTypeForAssignment("hifz"))
    }

    @Test fun supportedManualTypesMatchGoldenMaster() {
        assertTrue(SessionWorkflowRules.manualSessionTypes.containsAll(listOf("tasmee","sard","review","test","tajweed","lesson","other")))
    }
}
