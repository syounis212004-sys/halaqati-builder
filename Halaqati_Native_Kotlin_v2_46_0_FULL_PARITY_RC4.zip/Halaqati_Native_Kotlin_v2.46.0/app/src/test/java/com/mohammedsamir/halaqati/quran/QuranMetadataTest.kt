package com.mohammedsamir.halaqati.quran

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class QuranMetadataTest {
    @Test fun metadataShapeMatchesMadinahHafs() {
        assertEquals(114, QuranMetadata.surahNames.size)
        assertEquals(6236, QuranMetadata.ayahCounts.sum())
        assertEquals(606, QuranMetadata.pageStarts.size)
        assertEquals(32, QuranMetadata.juzStarts.size)
        assertEquals(242, QuranMetadata.rubStarts.size)
        assertEquals(1, QuranMetadata.pageStarts[1])
        assertEquals(6237, QuranMetadata.pageStarts[605])
    }

    @Test fun knownBoundariesResolveCorrectly() {
        assertEquals(1, QuranMetadata.pageFor(1, 1))
        assertEquals(2, QuranMetadata.pageFor(2, 1))
        assertEquals(22, QuranMetadata.pageFor(2, 142))
        assertEquals(30, QuranMetadata.juzFor(78, 1))
        assertEquals(112, QuranMetadata.pageStart(604).surah)
        assertEquals(114, QuranMetadata.pageEnd(604).surah)
    }

    @Test fun rangesAreVisuallyNormalized() {
        val range = QuranMetadata.range(114, 6, 113, 5)
        assertTrue(QuranMetadata.globalAyah(range.start.surah, range.start.ayah) < QuranMetadata.globalAyah(range.end.surah, range.end.ayah))
        assertTrue(range.normalizedStartPage <= range.normalizedEndPage)
    }
}
