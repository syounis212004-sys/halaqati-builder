package com.mohammedsamir.halaqati.navigation
import com.mohammedsamir.halaqati.model.UserRole
import com.mohammedsamir.halaqati.ui.navigation.RoleNavigationPolicy
import org.junit.Assert.*
import org.junit.Test
class RoleNavigationPolicyTest {
 @Test fun guardianBottomBarMatchesGoldenMaster(){ assertEquals(listOf("home","reports","plans","guardian_profile","more"),RoleNavigationPolicy.bottom(UserRole.GUARDIAN).map{it.route}) }
 @Test fun staffBottomBarMatchesGoldenMaster(){ assertEquals(listOf("home","sessions","students","plans","more"),RoleNavigationPolicy.bottom(UserRole.TEACHER).map{it.route}) }
 @Test fun guardianCompetitionAndAchievementsStayDistinct(){ val r=RoleNavigationPolicy.destinations(UserRole.GUARDIAN).map{it.route}; assertTrue("guardian_competition" in r); assertTrue("guardian_achievements" in r); assertFalse("users" in r) }
}
