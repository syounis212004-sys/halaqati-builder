@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.mohammedsamir.halaqati.ui.screens

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.mohammedsamir.halaqati.data.AppGraph
import com.mohammedsamir.halaqati.data.PlanSnapshot
import com.mohammedsamir.halaqati.model.*
import com.mohammedsamir.halaqati.quran.QuranMetadata
import com.mohammedsamir.halaqati.ui.components.*
import com.mohammedsamir.halaqati.ui.sessions.SessionWorkflowRules
import com.mohammedsamir.halaqati.ui.theme.HalaqatiUiTokens
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.time.LocalDate

@Composable
fun StudentsScreen(pending: Int, onRefresh: () -> Unit) {
    val scope = rememberCoroutineScope()
    var rows by remember { mutableStateOf<List<Student>>(emptyList()) }
    var halaqas by remember { mutableStateOf<List<JSONObject>>(emptyList()) }
    var categories by remember { mutableStateOf<List<JSONObject>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var query by remember { mutableStateOf("") }
    var trackFilter by remember { mutableStateOf("all") }
    var statusFilter by remember { mutableStateOf("active") }
    var halaqaFilter by remember { mutableStateOf("all") }
    var categoryFilter by remember { mutableStateOf("all") }
    var add by remember { mutableStateOf(false) }
    var selectedStudent by remember { mutableStateOf<Student?>(null) }
    var directRecitation by remember { mutableStateOf<Triple<Student, SessionRow, PlanSnapshot?>?>(null) }
    var message by remember { mutableStateOf<String?>(null) }

    suspend fun reload(force: Boolean = false) {
        loading = true
        try {
            val loaded = withContext(Dispatchers.IO) {
                val studentRows = AppGraph.repo.students(forceRefresh = force)
                val h = AppGraph.repo.table("halaqas", "select=id,name,active&order=name.asc&limit=200")
                val c = AppGraph.repo.table("student_categories", "select=id,halaqa_id,name,active&order=name.asc&limit=500")
                Triple(
                    studentRows,
                    (0 until h.length()).mapNotNull { h.optJSONObject(it) },
                    (0 until c.length()).mapNotNull { c.optJSONObject(it) },
                )
            }
            rows = loaded.first
            halaqas = loaded.second
            categories = loaded.third
            message = null
        } catch (e: Exception) {
            message = e.message ?: "تعذر تحميل الطلاب"
        } finally {
            loading = false
        }
    }

    Column {
        AppTopBar(
            title = "الطلاب",
            onRefresh = {
                scope.launch { reload(force = true) }
                onRefresh()
            },
            pending = pending,
        )

        Row(
            Modifier.padding(horizontal = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                label = { Text("بحث") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                modifier = Modifier.weight(1f),
                singleLine = true,
            )
            Spacer(Modifier.width(8.dp))
            FilledIconButton(
                onClick = { add = true },
                modifier = Modifier.size(HalaqatiUiTokens.TouchTarget),
            ) {
                Icon(Icons.Default.Add, contentDescription = "إضافة")
            }
        }

        Column(
            Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ProFilterChip(statusFilter == "active", { statusFilter = "active" }, "الطلاب الحاليون")
                ProFilterChip(statusFilter == "all", { statusFilter = "all" }, "كل الحالات")
                ProFilterChip(statusFilter == "inactive", { statusFilter = "inactive" }, "غير نشط")
                ProFilterChip(statusFilter == "suspended", { statusFilter = "suspended" }, "موقوف")
            }
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ProFilterChip(trackFilter == "all", { trackFilter = "all" }, "كل المسارات")
                ProFilterChip(trackFilter == "general_hifz", { trackFilter = "general_hifz" }, "الحفظ العام")
                ProFilterChip(trackFilter == "tathbit", { trackFilter = "tathbit" }, "التثبيت")
            }
            if (halaqas.size > 1) {
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ProFilterChip(halaqaFilter == "all", { halaqaFilter = "all"; categoryFilter = "all" }, "كل الحلقات")
                    halaqas.filter { it.optBoolean("active", true) }.forEach { h ->
                        val id = h.optString("id")
                        ProFilterChip(halaqaFilter == id, { halaqaFilter = id; categoryFilter = "all" }, h.optString("name", "حلقة"))
                    }
                }
            }
            val visibleCategories = categories.filter {
                it.optBoolean("active", true) && (halaqaFilter == "all" || it.optString("halaqa_id") == halaqaFilter)
            }
            if (visibleCategories.isNotEmpty()) {
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ProFilterChip(categoryFilter == "all", { categoryFilter = "all" }, "كل الفئات")
                    ProFilterChip(categoryFilter == "none", { categoryFilter = "none" }, "بدون فئة")
                    visibleCategories.forEach { c ->
                        val id = c.optString("id")
                        ProFilterChip(categoryFilter == id, { categoryFilter = id }, c.optString("name", "فئة"))
                    }
                }
            }
        }

        message?.let { StateNotice(it, kind = "error", modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)) }

        val filtered = rows.filter { student ->
            val searchOk = query.isBlank() || student.fullName.contains(query, ignoreCase = true)
            val statusOk = statusFilter == "all" || student.status == statusFilter
            val trackOk = trackFilter == "all" || student.track == trackFilter
            val halaqaOk = halaqaFilter == "all" || student.halaqaId == halaqaFilter
            val categoryOk = when (categoryFilter) {
                "all" -> true
                "none" -> student.categoryId.isNullOrBlank()
                else -> student.categoryId == categoryFilter
            }
            searchOk && statusOk && trackOk && halaqaOk && categoryOk
        }
        if (loading && rows.isEmpty()) {
            LoadingSkeleton(rows = 4, modifier = Modifier.padding(12.dp))
        }
        if (!loading && filtered.isEmpty()) {
            EmptyState(
                text = if (query.isBlank()) "لا يوجد طلاب حتى الآن" else "لا توجد نتائج مطابقة للبحث",
                actionLabel = "إعادة تعيين الفلاتر",
                onAction = {
                    query = ""
                    trackFilter = "all"
                    statusFilter = "active"
                    halaqaFilter = "all"
                    categoryFilter = "all"
                },
            )
        }

        LazyColumn(
            contentPadding = PaddingValues(start = 12.dp, end = 12.dp, top = 12.dp, bottom = 120.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            items(filtered, key = { it.id }) { student ->
                ElevatedCard(
                    onClick = { selectedStudent = student },
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    ListItem(
                        headlineContent = { Text(student.fullName) },
                        supportingContent = {
                            val halaqaName = halaqas.firstOrNull { it.optString("id") == student.halaqaId }?.optString("name")
                            val categoryName = categories.firstOrNull { it.optString("id") == student.categoryId }?.optString("name")
                            Text(
                                buildList {
                                    add(if (student.track == "tathbit") "مسار التثبيت" else "مسار الحفظ العام")
                                    add(studentStatusAr(student.status))
                                    if (!halaqaName.isNullOrBlank()) add(halaqaName)
                                    if (!categoryName.isNullOrBlank()) add(categoryName)
                                }.joinToString(" · "),
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        },
                        leadingContent = { Icon(Icons.Default.Person, contentDescription = null) },
                    )
                }
            }
        }
    }

    if (add) {
        StudentDialog(
            close = { add = false },
            save = { name, track ->
                scope.launch {
                    try {
                        withContext(Dispatchers.IO) {
                            val halaqaId = AppGraph.repo.firstHalaqaId()
                                ?: error("لا توجد حلقة مفعلة لإضافة الطالب إليها")
                            AppGraph.repo.write(
                                table = "students",
                                obj = JSONObject()
                                    .put("full_name", name)
                                    .put("halaqa_id", halaqaId)
                                    .put("track_code", track)
                                    .put("status", "active"),
                            )
                        }
                        add = false
                        reload()
                    } catch (e: Exception) {
                        message = e.message ?: "تعذر إضافة الطالب"
                    }
                }
            },
        )
    }


    selectedStudent?.let { student ->
        StudentDetailSheet(
            student = student,
            onDismiss = { selectedStudent = null },
            onChanged = {
                scope.launch { reload(force = true) }
                onRefresh()
            },
            onStartRecitation = { snapshot ->
                scope.launch {
                    try {
                        val halaqaId = student.halaqaId ?: snapshot?.plan?.halaqaId
                            ?: error("الطالب غير مرتبط بحلقة")
                        val assignment = snapshot?.progress?.assignment
                        val session = withContext(Dispatchers.IO) {
                            AppGraph.repo.ensureTodaySession(
                                halaqaId = halaqaId,
                                date = LocalDate.now().toString(),
                                assignmentKind = assignment?.kind ?: "hifz",
                            )
                        }
                        selectedStudent = null
                        directRecitation = Triple(student, session, snapshot)
                        message = null
                    } catch (e: Exception) {
                        message = e.message ?: "تعذر تجهيز جلسة التسميع"
                    }
                }
            },
        )
    }

    directRecitation?.let { (student, session, snapshot) ->
        val assignment = snapshot?.progress?.assignment
        RecitationDialog(
            student = student,
            session = session,
            close = { directRecitation = null },
            onSaved = {
                directRecitation = null
                scope.launch { reload(force = true) }
                onRefresh()
            },
            prefillStartPage = assignment?.startPage,
            prefillEndPage = assignment?.endPage,
            prefillPages = assignment?.pages?.takeIf { it > 0.0 },
            smartPlanId = snapshot?.plan?.id,
            smartPlanType = snapshot?.plan?.type,
            smartPlanDate = snapshot?.let { LocalDate.now().toString() },
            qcfLineKeys = assignment?.lineKeys.orEmpty(),
            activityTypeOverride = assignment?.kind?.let { kind ->
                when (kind) {
                    "sard" -> "sard"
                    "review" -> "review_near"
                    "tathbit" -> "review_far"
                    "test" -> "test"
                    else -> "new_hifz"
                }
            },
        )
    }
}

@Composable
private fun StudentDetailSheet(
    student: Student,
    onDismiss: () -> Unit,
    onChanged: () -> Unit,
    onStartRecitation: (PlanSnapshot?) -> Unit,
) {
    val scope = rememberCoroutineScope()
    var loading by remember(student.id) { mutableStateOf(true) }
    var online by remember(student.id) { mutableStateOf(true) }
    var saving by remember(student.id) { mutableStateOf(false) }
    var error by remember(student.id) { mutableStateOf<String?>(null) }
    var raw by remember(student.id) { mutableStateOf<JSONObject?>(null) }
    var recitations by remember(student.id) { mutableStateOf<List<JSONObject>>(emptyList()) }
    var attendance by remember(student.id) { mutableStateOf<List<JSONObject>>(emptyList()) }
    var snapshot by remember(student.id) { mutableStateOf<PlanSnapshot?>(null) }
    var track by remember(student.id) { mutableStateOf(student.track) }
    var status by remember(student.id) { mutableStateOf(student.status) }

    suspend fun reloadDetail() {
        loading = true
        try {
            val today = LocalDate.now()
            val from = today.withDayOfMonth(1).toString()
            val to = today.toString()
            online = withContext(Dispatchers.IO) { AppGraph.repo.online() }
            if (!online) {
                raw = null
                recitations = emptyList()
                attendance = emptyList()
                snapshot = null
                error = null
                track = student.track
                status = student.status
                return
            }
            val result = withContext(Dispatchers.IO) {
                val studentRaw = AppGraph.repo.table(
                    "students",
                    "select=*&id=eq.${student.id}&limit=1",
                ).optJSONObject(0)
                val recitationArray = AppGraph.repo.table(
                    "recitation_entries",
                    "select=id,activity_type,start_page,end_page,pages_count,evaluation,points,mistakes,prompts,created_at," +
                        "sessions!inner(session_date,session_type,title)" +
                        "&student_id=eq.${student.id}&sessions.session_date=gte.$from&sessions.session_date=lte.$to" +
                        "&order=created_at.desc&limit=1000",
                )
                val attendanceArray = AppGraph.repo.table(
                    "attendance_records",
                    "select=status,arrival_minutes_late,excuse_reason,recorded_at,sessions!inner(session_date)" +
                        "&student_id=eq.${student.id}&sessions.session_date=gte.$from&sessions.session_date=lte.$to" +
                        "&order=recorded_at.desc&limit=1000",
                )
                val planSnapshot = runCatching { AppGraph.repo.planSnapshots(today) }
                    .getOrDefault(emptyList())
                    .firstOrNull { it.student.id == student.id }
                Quadruple(
                    studentRaw,
                    (0 until recitationArray.length()).mapNotNull { recitationArray.optJSONObject(it) },
                    (0 until attendanceArray.length()).mapNotNull { attendanceArray.optJSONObject(it) },
                    planSnapshot,
                )
            }
            raw = result.first
            recitations = result.second
            attendance = result.third
            snapshot = result.fourth
            track = result.first?.optString("track_code").orEmpty().ifBlank { student.track }
            status = result.first?.optString("status").orEmpty().ifBlank { student.status }
            error = null
        } catch (e: Exception) {
            error = e.message ?: "تعذر تحميل تفاصيل الطالب"
        } finally {
            loading = false
        }
    }

    LaunchedEffect(student.id) { reloadDetail() }

    val hifz = recitations.filter { it.optString("activity_type") == "new_hifz" }.sumOf { it.optDouble("pages_count", 0.0) }
    val review = recitations.filter { it.optString("activity_type") in setOf("review_near", "review_far") }.sumOf { it.optDouble("pages_count", 0.0) }
    val sard = recitations.filter { it.optString("activity_type") == "sard" }.sumOf { it.optDouble("pages_count", 0.0) }
    val present = attendance.count { it.optString("status") in setOf("present", "late") }
    val absent = attendance.count { it.optString("status") == "absent" }
    val late = attendance.count { it.optString("status") == "late" }

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(Modifier.fillMaxWidth()) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Surface(
                    modifier = Modifier.size(52.dp),
                    shape = MaterialTheme.shapes.large,
                    color = MaterialTheme.colorScheme.primaryContainer,
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.Person, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    }
                }
                Column(Modifier.weight(1f)) {
                    Text(student.fullName, style = MaterialTheme.typography.titleLarge)
                    Text(
                        if (track == "tathbit") "مسار التثبيت" else "مسار الحفظ العام",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                Surface(
                    color = when (status) {
                        "active" -> MaterialTheme.colorScheme.primaryContainer
                        "suspended" -> MaterialTheme.colorScheme.tertiaryContainer
                        else -> MaterialTheme.colorScheme.surfaceVariant
                    },
                    shape = MaterialTheme.shapes.small,
                ) {
                    Text(
                        studentStatusAr(status),
                        style = MaterialTheme.typography.labelLarge,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp),
                    )
                }
            }

            error?.let { StateNotice(it, kind = "error", modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)) }
            if (!online) {
                StateNotice(
                    "بدون اتصال: تظهر البيانات الأساسية فقط. افتح الجلسة اليومية المسجلة مسبقًا للعمل أوفلاين.",
                    kind = "warning",
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp),
                )
            }
            if (loading) LoadingSkeleton(rows = 3, modifier = Modifier.padding(16.dp))

            if (!loading) {
                LazyColumn(
                    modifier = Modifier.weight(1f, fill = false).heightIn(max = 620.dp),
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    item {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            StudentMiniMetric("حفظ الشهر", "${plainNumber(hifz)} ص", Modifier.weight(1f))
                            StudentMiniMetric("مراجعة", "${plainNumber(review)} ص", Modifier.weight(1f))
                            StudentMiniMetric("سرد", "${plainNumber(sard)} ص", Modifier.weight(1f))
                        }
                        Spacer(Modifier.height(8.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            StudentMiniMetric("الحضور", present.toString(), Modifier.weight(1f))
                            StudentMiniMetric("الغياب", absent.toString(), Modifier.weight(1f))
                            StudentMiniMetric("التأخر", late.toString(), Modifier.weight(1f))
                        }
                    }

                    snapshot?.let { plan ->
                        item {
                            ElevatedCard(Modifier.fillMaxWidth()) {
                                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                        Column(Modifier.weight(1f)) {
                                            Text("الخطة الذكية", style = MaterialTheme.typography.titleMedium)
                                            Text(plan.plan.title.ifBlank { planTypeAr(plan.plan.type) }, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        }
                                        PlanHealthBadge(plan.progress.health, plan.progress.healthLabel)
                                    }
                                    LinearProgressIndicator(
                                        progress = { (plan.progress.percentage / 100.0).toFloat().coerceIn(0f, 1f) },
                                        modifier = Modifier.fillMaxWidth().height(8.dp).graphicsLayer(scaleX = -1f),
                                    )
                                    Text(
                                        "الإنجاز ${plainNumber(plan.progress.percentage)}% · المتبقي ${plainNumber(plan.progress.remaining)} صفحة · اليوم ${plainNumber(plan.progress.assignment.pages)} صفحة",
                                        style = MaterialTheme.typography.bodyMedium,
                                    )
                                }
                            }
                        }
                    }

                    item {
                        ElevatedCard(Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                Text("بيانات الطالب", style = MaterialTheme.typography.titleMedium)
                                StudentDetailLine("المرحلة", jsonText(raw, "school_grade"))
                                StudentDetailLine("جوال ولي الأمر", jsonText(raw, "guardian_phone"))
                                StudentDetailLine("بريد ولي الأمر", jsonText(raw, "guardian_email"))
                                StudentDetailLine("تاريخ الميلاد", jsonText(raw, "date_of_birth"))
                            }
                        }
                    }

                    item {
                        Text("آخر التسميعات", style = MaterialTheme.typography.titleMedium)
                        if (recitations.isEmpty()) {
                            EmptyState("لا توجد تسميعات مسجلة هذا الشهر")
                        } else {
                            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                recitations.take(6).forEach { row ->
                                    val session = row.optJSONObject("sessions")
                                    ElevatedCard(Modifier.fillMaxWidth()) {
                                        Row(
                                            Modifier.fillMaxWidth().padding(12.dp).heightIn(min = 48.dp),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                                        ) {
                                            Icon(Icons.Default.MenuBook, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                            Column(Modifier.weight(1f)) {
                                                Text(activityTypeAr(row.optString("activity_type")), style = MaterialTheme.typography.labelLarge)
                                                Text(
                                                    "${session?.optString("session_date").orEmpty()} · ${pageRangeLabel(nullableInt(row, "start_page"), nullableInt(row, "end_page"))}",
                                                    style = MaterialTheme.typography.bodySmall,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                )
                                            }
                                            Text("${plainNumber(row.optDouble("pages_count", 0.0))} ص", style = MaterialTheme.typography.labelLarge)
                                        }
                                    }
                                }
                            }
                        }
                    }

                    item {
                        ElevatedCard(Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                Text("تعديل سريع", style = MaterialTheme.typography.titleMedium)
                                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    ProFilterChip(track == "general_hifz", { track = "general_hifz" }, "الحفظ العام")
                                    ProFilterChip(track == "tathbit", { track = "tathbit" }, "التثبيت")
                                }
                                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    ProFilterChip(status == "active", { status = "active" }, "نشط")
                                    ProFilterChip(status == "inactive", { status = "inactive" }, "غير نشط")
                                    ProFilterChip(status == "suspended", { status = "suspended" }, "موقوف")
                                }
                                Button(
                                    onClick = {
                                        saving = true
                                        scope.launch {
                                            try {
                                                withContext(Dispatchers.IO) {
                                                    AppGraph.repo.patch(
                                                        "students",
                                                        "id=eq.${student.id}",
                                                        JSONObject().put("track_code", track).put("status", status),
                                                        dedupe = "student-quick-edit:${student.id}",
                                                    )
                                                }
                                                onChanged()
                                                reloadDetail()
                                            } catch (e: Exception) {
                                                error = e.message ?: "تعذر تحديث الطالب"
                                            } finally {
                                                saving = false
                                            }
                                        }
                                    },
                                    enabled = !saving && online,
                                    modifier = Modifier.fillMaxWidth().heightIn(min = HalaqatiUiTokens.TouchTarget),
                                ) { Text(if (saving) "جاري الحفظ…" else if (online) "حفظ التعديل" else "التعديل يحتاج اتصالاً") }
                            }
                        }
                    }
                }

                Surface(shadowElevation = 8.dp, tonalElevation = 2.dp) {
                    Button(
                        onClick = { onStartRecitation(snapshot) },
                        enabled = online,
                        modifier = Modifier.fillMaxWidth().padding(16.dp).heightIn(min = 52.dp),
                    ) {
                        Icon(Icons.Default.RecordVoiceOver, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text(if (online) "بدء تسميع ${student.fullName}" else "ابدأ من الجلسة المفتوحة للعمل دون اتصال")
                    }
                }
            }
        }
    }
}

private data class Quadruple<A, B, C, D>(val first: A, val second: B, val third: C, val fourth: D)

@Composable
private fun StudentMiniMetric(label: String, value: String, modifier: Modifier = Modifier) {
    Surface(modifier, shape = MaterialTheme.shapes.small, color = MaterialTheme.colorScheme.surfaceVariant) {
        Column(Modifier.padding(horizontal = 10.dp, vertical = 9.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(value, style = MaterialTheme.typography.titleMedium)
            Text(label, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun StudentDetailLine(label: String, value: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, style = MaterialTheme.typography.bodyMedium, fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold)
    }
}

private fun jsonText(row: JSONObject?, key: String): String {
    if (row == null || !row.has(key) || row.isNull(key)) return "—"
    return row.optString(key).takeUnless { it.isBlank() || it == "null" } ?: "—"
}

private fun activityTypeAr(value: String): String = when (value) {
    "new_hifz" -> "حفظ جديد"
    "review_near" -> "مراجعة قريبة"
    "review_far" -> "مراجعة بعيدة"
    "sard" -> "سرد"
    "tilawah" -> "تلاوة"
    "test" -> "اختبار"
    else -> value
}

private fun nullableInt(row: JSONObject, key: String): Int? =
    if (!row.has(key) || row.isNull(key)) null else row.optInt(key).takeIf { it > 0 }

private fun studentStatusAr(status: String): String = when (status) {
    "active" -> "نشط"
    "inactive" -> "غير نشط"
    "suspended" -> "موقوف"
    "withdrawn" -> "منسحب"
    else -> status
}

@Composable
private fun StudentDialog(close: () -> Unit, save: (String, String) -> Unit) {
    var name by remember { mutableStateOf("") }
    var track by remember { mutableStateOf("general_hifz") }

    AlertDialog(
        onDismissRequest = close,
        title = { Text("طالب جديد") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("اسم الطالب") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ProFilterChip(track == "general_hifz", { track = "general_hifz" }, "الحفظ العام")
                    ProFilterChip(track == "tathbit", { track = "tathbit" }, "التثبيت")
                }
            }
        },
        confirmButton = {
            Button(onClick = { save(name.trim(), track) }, enabled = name.trim().length >= 2) {
                Text("حفظ")
            }
        },
        dismissButton = { TextButton(onClick = close) { Text("إلغاء") } },
    )
}

@Composable
fun SessionsScreen(pending: Int, onRefresh: () -> Unit, openTodayOnLaunch: Boolean = false) {
    val scope = rememberCoroutineScope()
    var rows by remember { mutableStateOf<List<SessionRow>>(emptyList()) }
    var students by remember { mutableStateOf<List<Student>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var add by remember { mutableStateOf(false) }
    var active by remember { mutableStateOf<SessionRow?>(null) }
    var message by remember { mutableStateOf<String?>(null) }

    suspend fun reload(force: Boolean = false) {
        loading = true
        try {
            val result = withContext(Dispatchers.IO) {
                AppGraph.repo.sessions(forceRefresh = force) to AppGraph.repo.students(forceRefresh = force)
            }
            rows = result.first
            students = result.second
            message = null
        } catch (e: Exception) {
            message = e.message ?: "تعذر تحميل الجلسات"
        } finally {
            loading = false
        }
    }

    LaunchedEffect(openTodayOnLaunch) {
        reload()
        if (openTodayOnLaunch) {
            try {
                val session = withContext(Dispatchers.IO) {
                    val halaqaId = AppGraph.repo.firstHalaqaId()
                        ?: error("لا توجد حلقة مفعلة أو محفوظة محليًا لفتح جلسة اليوم")
                    AppGraph.repo.openOrCreateTodaySession(halaqaId, LocalDate.now().toString(), "hifz").getOrThrow()
                }
                rows = (listOf(session) + rows.filterNot { it.id == session.id }).sortedByDescending { it.date }
                students = withContext(Dispatchers.IO) { AppGraph.repo.students() }
                active = session
                message = null
            } catch (e: Exception) {
                message = e.message ?: "تعذر فتح جلسة اليوم"
            }
        }
    }

    fun openToday() {
        scope.launch {
            try {
                val session = withContext(Dispatchers.IO) {
                    val halaqaId = AppGraph.repo.firstHalaqaId()
                        ?: error("لا توجد حلقة مفعلة أو محفوظة محليًا لفتح جلسة اليوم")
                    AppGraph.repo.openOrCreateTodaySession(halaqaId, LocalDate.now().toString(), "hifz").getOrThrow()
                }
                rows = (listOf(session) + rows.filterNot { it.id == session.id }).sortedByDescending { it.date }
                active = session
                message = null
            } catch (e: Exception) {
                message = e.message ?: "تعذر فتح جلسة اليوم"
            }
        }
    }

    Column {
        AppTopBar(
            title = "الجلسات اليومية",
            onRefresh = {
                scope.launch { reload(force = true) }
                onRefresh()
            },
            pending = pending,
        )
        Row(
            Modifier.padding(12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Button(onClick = ::openToday) {
                Icon(Icons.Default.PlayArrow, contentDescription = null)
                Text(" ابدأ جلسة اليوم")
            }
            FilledIconButton(
                onClick = { add = true },
                modifier = Modifier.size(HalaqatiUiTokens.TouchTarget),
            ) {
                Icon(Icons.Default.Add, contentDescription = "جلسة مخصصة")
            }
            Surface(
                color = MaterialTheme.colorScheme.surfaceVariant,
                shape = MaterialTheme.shapes.small,
            ) {
                Text(
                    "تسميع · سرد · مراجعة · اختبار · نشاط",
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                )
            }
        }
        message?.let { StateNotice(it, kind = "error", modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)) }
        if (loading && rows.isEmpty()) LoadingSkeleton(rows = 3, modifier = Modifier.padding(12.dp))
        if (!loading && rows.isEmpty()) EmptyState("لا توجد جلسات حتى الآن")

        LazyColumn(
            contentPadding = PaddingValues(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            items(rows, key = { it.id }) { session ->
                ElevatedCard(onClick = { active = session }, modifier = Modifier.fillMaxWidth()) {
                    ListItem(
                        headlineContent = { Text(session.title.ifBlank { sessionTypeAr(session.type) }) },
                        supportingContent = {
                            Text(
                                "${session.date} · ${sessionTypeAr(session.type)} · " +
                                    if (session.status == "open") "مفتوحة" else "${session.status}",
                            )
                        },
                        leadingContent = { Icon(Icons.Default.Event, contentDescription = null) },
                        trailingContent = { Icon(Icons.Default.ChevronLeft, contentDescription = null) },
                    )
                }
            }
        }
    }

    if (add) {
        NewSessionDialog(
            close = { add = false },
            save = { date, type, title ->
                scope.launch {
                    try {
                        withContext(Dispatchers.IO) {
                            val halaqaId = AppGraph.repo.firstHalaqaId()
                                ?: error("لا توجد حلقة مفعلة لإنشاء الجلسة")
                            AppGraph.repo.createSession(halaqaId, date, type, title)
                        }
                        add = false
                        reload()
                    } catch (e: Exception) {
                        message = e.message ?: "تعذر إنشاء الجلسة"
                    }
                }
            },
        )
    }

    active?.let { session ->
        SessionRosterDialog(
            session = session,
            students = students.filter { it.halaqaId == null || it.halaqaId == session.halaqaId },
            pending = pending,
            close = { active = null },
            onChanged = { scope.launch { reload() } },
        )
    }
}

fun sessionTypeAr(type: String) = when (type) {
    "tasmee" -> "تسميع"
    "sard" -> "سرد"
    "review" -> "مراجعة"
    "test" -> "اختبار"
    "tajweed" -> "تجويد"
    "lesson" -> "نشاط تربوي"
    "other" -> "أخرى"
    else -> type
}

@Composable
private fun NewSessionDialog(close: () -> Unit, save: (String, String, String) -> Unit) {
    var date by remember { mutableStateOf(LocalDate.now().toString()) }
    var type by remember { mutableStateOf("tasmee") }
    var title by remember { mutableStateOf("") }
    val types = SessionWorkflowRules.manualSessionTypes

    AlertDialog(
        onDismissRequest = close,
        title = { Text("جلسة جديدة") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = date,
                    onValueChange = { date = it },
                    label = { Text("التاريخ YYYY-MM-DD") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                )
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("العنوان (اختياري)") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                )
                SingleChoiceSegmentedButtonRow(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                ) {
                    types.forEachIndexed { index, value ->
                        SegmentedButton(
                            selected = type == value,
                            onClick = { type = value },
                            shape = SegmentedButtonDefaults.itemShape(index, types.size),
                        ) { Text(sessionTypeAr(value)) }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { save(date, type, title.trim()) },
                enabled = runCatching { LocalDate.parse(date) }.isSuccess,
            ) { Text("حفظ وفتح") }
        },
        dismissButton = { TextButton(onClick = close) { Text("إلغاء") } },
    )
}

@Composable
private fun SessionRosterDialog(
    session: SessionRow,
    students: List<Student>,
    pending: Int,
    close: () -> Unit,
    onChanged: () -> Unit,
) {
    val scope = rememberCoroutineScope()
    var selected by remember { mutableStateOf<Student?>(null) }
    var noteStudent by remember { mutableStateOf<Student?>(null) }
    var attendanceDetails by remember { mutableStateOf<Pair<Student, String>?>(null) }
    var attendance by remember { mutableStateOf<Map<String, AttendanceRow>>(emptyMap()) }
    var notes by remember { mutableStateOf<Map<String, DailyNoteRow>>(emptyMap()) }
    var queuedStudents by remember { mutableStateOf<Set<String>>(emptySet()) }
    var blockedStudents by remember { mutableStateOf<Set<String>>(emptySet()) }
    var track by remember { mutableStateOf("all") }
    var loading by remember { mutableStateOf(true) }
    var message by remember { mutableStateOf<String?>(null) }

    suspend fun reloadRoster() {
        loading = true
        try {
            val result = withContext(Dispatchers.IO) {
                val q = AppGraph.repo.queueSnapshot(500)
                val a = if (AppGraph.repo.online()) runCatching { AppGraph.repo.attendanceForSession(session.id) }.getOrDefault(emptyMap()) else emptyMap()
                val n = if (AppGraph.repo.online()) runCatching { AppGraph.repo.notesForSession(session.id) }.getOrDefault(emptyMap()) else emptyMap()
                Triple(a.toMutableMap(), n.toMutableMap(), q)
            }
            val attendanceOverlay = result.first
            val notesOverlay = result.second
            val queued = mutableSetOf<String>()
            val blocked = mutableSetOf<String>()
            result.third.forEach { item ->
                val d = item.dedupe.orEmpty()
                val studentId = when {
                    d.startsWith("attendance:${session.id}:") -> d.substringAfter("attendance:${session.id}:").substringBefore(':')
                    d.startsWith("note:${session.id}:") -> d.substringAfter("note:${session.id}:").substringBefore(':')
                    d.startsWith("recitation:${session.id}:") -> d.substringAfter("recitation:${session.id}:").substringBefore(':')
                    else -> ""
                }
                if (studentId.isNotBlank()) {
                    if (item.blocked) blocked += studentId else queued += studentId
                    val body = item.body?.let { runCatching { JSONObject(it) }.getOrNull() }
                    when {
                        d.startsWith("attendance:${session.id}:") && body != null -> {
                            attendanceOverlay[studentId] = AttendanceRow.from(body)
                        }
                        d.startsWith("note:${session.id}:") && body != null -> {
                            notesOverlay[studentId] = DailyNoteRow.from(body)
                        }
                    }
                }
            }
            attendance = attendanceOverlay
            notes = notesOverlay
            queuedStudents = queued
            blockedStudents = blocked
            message = null
        } catch (e: Exception) {
            // Offline roster still remains usable; writes are queued by repository.
            message = e.message ?: "تعذر تحميل حالة الجلسة من الخادم"
        } finally {
            loading = false
        }
    }

    fun saveStatus(student: Student, status: String, reason: String = "", lateMinutes: Int = 0) {
        scope.launch {
            try {
                withContext(Dispatchers.IO) {
                    AppGraph.repo.saveAttendance(session.id, student.id, status, reason, lateMinutes)
                }
                attendance = attendance + (student.id to AttendanceRow(
                    id = "local:${session.id}:${student.id}",
                    sessionId = session.id,
                    studentId = student.id,
                    status = status,
                    excuseReason = reason,
                    arrivalMinutesLate = lateMinutes,
                ))
                if (!AppGraph.repo.online()) queuedStudents = queuedStudents + student.id
                message = null
                onChanged()
            } catch (e: Exception) {
                message = e.message ?: "تعذر حفظ الحضور"
            }
        }
    }

    LaunchedEffect(session.id) { reloadRoster() }

    val filtered = students.filter { track == "all" || it.track == track }
    val present = filtered.count { attendance[it.id]?.status == "present" }
    val absent = filtered.count { attendance[it.id]?.status == "absent" }
    val late = filtered.count { attendance[it.id]?.status == "late" }
    val done = filtered.count { attendance.containsKey(it.id) }

    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    ModalBottomSheet(
        onDismissRequest = close,
        sheetState = sheetState,
        modifier = Modifier.fillMaxHeight(0.96f),
    ) {
        Column(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp).padding(bottom = 12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Row(
                Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(Modifier.weight(1f)) {
                    Text(
                        session.title.ifBlank { sessionTypeAr(session.type) },
                        style = MaterialTheme.typography.titleLarge,
                    )
                    Text(
                        "${session.date} · ${sessionTypeAr(session.type)}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                IconButton(
                    onClick = close,
                    modifier = Modifier.size(HalaqatiUiTokens.TouchTarget),
                ) { Icon(Icons.Default.Close, contentDescription = "إغلاق") }
            }

            // This context block intentionally stays outside the scrolling roster.
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                PlanMetric("تم الرصد", "$done/${filtered.size}")
                PlanMetric("حاضر", present.toString())
                PlanMetric("غائب", absent.toString())
                PlanMetric("متأخر", late.toString())
            }

            if (pending > 0 || queuedStudents.isNotEmpty() || blockedStudents.isNotEmpty()) {
                StateNotice(
                    text = if (blockedStudents.isNotEmpty()) {
                        "${blockedStudents.size} طالب لديهم عملية مزامنة تحتاج مراجعة"
                    } else {
                        "${queuedStudents.size.coerceAtLeast(pending)} عملية محفوظة محليًا بانتظار الرفع"
                    },
                    kind = if (blockedStudents.isNotEmpty()) "error" else "warning",
                )
            }

            Row(
                Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                ProFilterChip(track == "all", { track = "all" }, "الكل")
                ProFilterChip(track == "general_hifz", { track = "general_hifz" }, "الحفظ العام")
                ProFilterChip(track == "tathbit", { track = "tathbit" }, "التثبيت")
            }

            message?.let { StateNotice(it, kind = "error") }
            if (loading) {
                LoadingSkeleton(rows = 3, modifier = Modifier.fillMaxWidth())
            } else {
                LazyColumn(
                    modifier = Modifier.weight(1f, fill = false).heightIn(min = 260.dp, max = 620.dp),
                    verticalArrangement = Arrangement.spacedBy(2.dp),
                ) {
                    items(filtered, key = { it.id }) { student ->
                        val status = attendance[student.id]?.status
                        val syncLabel = when {
                            student.id in blockedStudents -> "خطأ مزامنة"
                            student.id in queuedStudents -> "بانتظار المزامنة"
                            else -> null
                        }
                        Column(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                            Row(
                                Modifier.fillMaxWidth().padding(horizontal = 4.dp),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Column(Modifier.weight(1f)) {
                                    Text(student.fullName, style = MaterialTheme.typography.titleLarge)
                                    Text(
                                        listOfNotNull(
                                            attendanceStatusAr(status),
                                            syncLabel,
                                            if (notes.containsKey(student.id)) "ملاحظة محفوظة" else null,
                                        ).filter { it.isNotBlank() }.joinToString(" · "),
                                        style = MaterialTheme.typography.bodySmall,
                                        color = if (student.id in blockedStudents) {
                                            MaterialTheme.colorScheme.error
                                        } else {
                                            MaterialTheme.colorScheme.onSurfaceVariant
                                        },
                                    )
                                }
                                if (status != null) {
                                    Icon(
                                        imageVector = when (status) {
                                            "absent" -> Icons.Default.Cancel
                                            "late" -> Icons.Default.Schedule
                                            "excused" -> Icons.Default.Info
                                            else -> Icons.Default.CheckCircle
                                        },
                                        contentDescription = attendanceStatusAr(status),
                                        tint = if (status == "absent") MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary,
                                    )
                                }
                            }
                            Row(
                                modifier = Modifier.horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                            ) {
                                TextButton(
                                    onClick = { saveStatus(student, "present") },
                                    modifier = Modifier.heightIn(min = HalaqatiUiTokens.TouchTarget),
                                ) { Text("حاضر") }
                                TextButton(
                                    onClick = { saveStatus(student, "absent") },
                                    modifier = Modifier.heightIn(min = HalaqatiUiTokens.TouchTarget),
                                ) { Text("غائب") }
                                TextButton(
                                    onClick = { attendanceDetails = student to "late" },
                                    modifier = Modifier.heightIn(min = HalaqatiUiTokens.TouchTarget),
                                ) { Text("متأخر") }
                                TextButton(
                                    onClick = { attendanceDetails = student to "excused" },
                                    modifier = Modifier.heightIn(min = HalaqatiUiTokens.TouchTarget),
                                ) { Text("بعذر") }
                                FilledTonalButton(
                                    onClick = { selected = student },
                                    modifier = Modifier.heightIn(min = HalaqatiUiTokens.TouchTarget),
                                ) {
                                    Icon(Icons.Default.Mic, contentDescription = null)
                                    Spacer(Modifier.width(6.dp))
                                    Text("تسميع")
                                }
                                TextButton(
                                    onClick = { noteStudent = student },
                                    modifier = Modifier.heightIn(min = HalaqatiUiTokens.TouchTarget),
                                ) { Text("ملاحظة") }
                            }
                        }
                        HorizontalDivider()
                    }
                }
            }

            OutlinedButton(
                onClick = close,
                modifier = Modifier.fillMaxWidth().heightIn(min = HalaqatiUiTokens.TouchTarget),
            ) { Text("إغلاق الجلسة") }
        }
    }

    attendanceDetails?.let { (student, status) ->
        AttendanceDetailsDialog(
            student = student,
            status = status,
            close = { attendanceDetails = null },
            save = { reason, minutes ->
                saveStatus(student, status, reason, minutes)
                attendanceDetails = null
            },
        )
    }

    noteStudent?.let { student ->
        StudentNoteDialog(
            student = student,
            existing = notes[student.id],
            close = { noteStudent = null },
            save = { behavior, score, comment, homework, visible ->
                scope.launch {
                    try {
                        withContext(Dispatchers.IO) {
                            AppGraph.repo.saveDailyNote(
                                sessionId = session.id,
                                studentId = student.id,
                                behavior = behavior,
                                behaviorScore = score,
                                teacherComment = comment,
                                homework = homework,
                                parentVisible = visible,
                            )
                        }
                        notes = notes + (student.id to DailyNoteRow(
                            id = "local-note:${session.id}:${student.id}",
                            sessionId = session.id,
                            studentId = student.id,
                            behavior = behavior,
                            behaviorScore = score,
                            teacherComment = comment,
                            homework = homework,
                            parentVisible = visible,
                        ))
                        if (!AppGraph.repo.online()) queuedStudents = queuedStudents + student.id
                        noteStudent = null
                        onChanged()
                    } catch (e: Exception) {
                        message = e.message ?: "تعذر حفظ الملاحظة"
                    }
                }
            },
        )
    }

    selected?.let { student ->
        RecitationDialog(
            student = student,
            session = session,
            close = { selected = null },
            onSaved = {
                selected = null
                scope.launch { reloadRoster() }
                onChanged()
            },
        )
    }
}

@Composable
private fun AttendanceDetailsDialog(
    student: Student,
    status: String,
    close: () -> Unit,
    save: (String, Int) -> Unit,
) {
    var reason by remember { mutableStateOf("") }
    var minutes by remember { mutableStateOf("5") }
    AlertDialog(
        onDismissRequest = close,
        title = { Text(if (status == "late") "تأخر ${student.fullName}" else "غياب بعذر · ${student.fullName}") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (status == "late") {
                    OutlinedTextField(
                        value = minutes,
                        onValueChange = { minutes = it.filter(Char::isDigit) },
                        label = { Text("دقائق التأخر") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                    )
                } else {
                    OutlinedTextField(
                        value = reason,
                        onValueChange = { reason = it },
                        label = { Text("سبب العذر") },
                        minLines = 2,
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
            }
        },
        confirmButton = {
            Button(onClick = { save(reason.trim(), minutes.toIntOrNull() ?: 0) }) { Text("حفظ") }
        },
        dismissButton = { TextButton(onClick = close) { Text("إلغاء") } },
    )
}

@Composable
private fun StudentNoteDialog(
    student: Student,
    existing: DailyNoteRow?,
    close: () -> Unit,
    save: (String, Int?, String, String, Boolean) -> Unit,
) {
    var behavior by remember { mutableStateOf(existing?.behavior ?: "normal") }
    var score by remember { mutableStateOf(existing?.behaviorScore?.toString().orEmpty()) }
    var comment by remember { mutableStateOf(existing?.teacherComment.orEmpty()) }
    var homework by remember { mutableStateOf(existing?.homework.orEmpty()) }
    var visible by remember { mutableStateOf(existing?.parentVisible ?: true) }
    val behaviors = listOf(
        "excellent" to "ممتاز",
        "good" to "جيد",
        "normal" to "طبيعي",
        "needs_attention" to "يحتاج متابعة",
        "warning" to "تنبيه",
    )
    AlertDialog(
        onDismissRequest = close,
        title = { Text("ملاحظة ${student.fullName}") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    behaviors.forEach { (value, label) ->
                        ProFilterChip(behavior == value, { behavior = value }, label)
                    }
                }
                OutlinedTextField(
                    value = score,
                    onValueChange = { score = it.filter(Char::isDigit).take(1) },
                    label = { Text("درجة السلوك 1–5 (اختياري)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                OutlinedTextField(
                    value = comment,
                    onValueChange = { comment = it },
                    label = { Text("ملاحظة المحفظ") },
                    minLines = 2,
                    modifier = Modifier.fillMaxWidth(),
                )
                OutlinedTextField(
                    value = homework,
                    onValueChange = { homework = it },
                    label = { Text("الواجب") },
                    minLines = 2,
                    modifier = Modifier.fillMaxWidth(),
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Switch(checked = visible, onCheckedChange = { visible = it })
                    Spacer(Modifier.width(8.dp))
                    Text("تظهر الملاحظة لولي الأمر")
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { save(behavior, score.toIntOrNull()?.takeIf { it in 1..5 }, comment.trim(), homework.trim(), visible) },
            ) { Text("حفظ") }
        },
        dismissButton = { TextButton(onClick = close) { Text("إلغاء") } },
    )
}

private fun attendanceStatusAr(status: String?): String = when (status) {
    "present" -> "حاضر"
    "absent" -> "غائب"
    "late" -> "متأخر"
    "excused" -> "بعذر"
    else -> "لم يُرصد بعد"
}

@Composable
private fun RecitationDialog(
    student: Student,
    session: SessionRow,
    close: () -> Unit,
    onSaved: () -> Unit,
    prefillStartPage: Int? = null,
    prefillEndPage: Int? = null,
    prefillPages: Double? = null,
    smartPlanId: String? = null,
    smartPlanType: String? = null,
    smartPlanDate: String? = null,
    qcfLineKeys: List<String> = emptyList(),
    activityTypeOverride: String? = null,
) {
    val scope = rememberCoroutineScope()
    var start by remember(prefillStartPage) { mutableStateOf(prefillStartPage?.toString().orEmpty()) }
    var end by remember(prefillEndPage) { mutableStateOf(prefillEndPage?.toString().orEmpty()) }
    var pages by remember(prefillPages) { mutableStateOf(prefillPages?.let(::plainNumber) ?: "1") }
    var mistakes by remember { mutableStateOf("0") }
    var prompts by remember { mutableStateOf("0") }
    var evaluation by remember { mutableStateOf("good") }
    var note by remember { mutableStateOf("") }
    var saving by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var showQuranPicker by remember { mutableStateOf(false) }

    val evaluations = listOf(
        "excellent" to "ممتاز",
        "very_good" to "جيد جدًا",
        "good" to "جيد",
        "repeat" to "إعادة",
    )

    AlertDialog(
        onDismissRequest = { if (!saving) close() },
        title = { Text("تسميع ${student.fullName}") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                OutlinedButton(
                    onClick = { showQuranPicker = true },
                    modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp),
                ) {
                    Icon(Icons.Default.MenuBook, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("اختيار من المصحف: سورة / آية / صفحة / جزء / ربع")
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedTextField(
                        value = start,
                        onValueChange = { start = it.filter(Char::isDigit) },
                        label = { Text("من صفحة") },
                        modifier = Modifier.weight(1f),
                        singleLine = true,
                    )
                    OutlinedTextField(
                        value = end,
                        onValueChange = { end = it.filter(Char::isDigit) },
                        label = { Text("إلى صفحة") },
                        modifier = Modifier.weight(1f),
                        singleLine = true,
                    )
                }
                OutlinedTextField(
                    value = pages,
                    onValueChange = { pages = it.filter { ch -> ch.isDigit() || ch == '.' } },
                    label = { Text("عدد الصفحات") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                )
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedTextField(
                        value = mistakes,
                        onValueChange = { mistakes = it.filter(Char::isDigit) },
                        label = { Text("أخطاء") },
                        modifier = Modifier.weight(1f),
                        singleLine = true,
                    )
                    OutlinedTextField(
                        value = prompts,
                        onValueChange = { prompts = it.filter(Char::isDigit) },
                        label = { Text("تلقين") },
                        modifier = Modifier.weight(1f),
                        singleLine = true,
                    )
                }
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    evaluations.forEach { (value, label) ->
                        ProFilterChip(
                            selected = evaluation == value,
                            onClick = { evaluation = value },
                            label = label,
                        )
                    }
                }
                OutlinedTextField(
                    value = note,
                    onValueChange = { note = it },
                    label = { Text("ملاحظة المحفظ") },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 2,
                )
            }
        },
        confirmButton = {
            Button(
                enabled = !saving && (pages.toDoubleOrNull() ?: 0.0) > 0,
                onClick = {
                    saving = true
                    error = null
                    scope.launch {
                        try {
                            val startPage = start.toIntOrNull()
                            val endPage = end.toIntOrNull()
                            if (startPage != null && startPage !in 1..604) error("صفحة البداية يجب أن تكون بين 1 و604")
                            if (endPage != null && endPage !in 1..604) error("صفحة النهاية يجب أن تكون بين 1 و604")
                            withContext(Dispatchers.IO) {
                                AppGraph.repo.saveRecitation(
                                    RecitationDraft(
                                        studentId = student.id,
                                        sessionId = session.id,
                                        activityType = activityTypeOverride ?: when (session.type) {
                                            "sard" -> "sard"
                                            "review" -> "review_near"
                                            "test" -> "test"
                                            else -> "new_hifz"
                                        },
                                        startPage = startPage,
                                        endPage = endPage,
                                        pages = pages.toDoubleOrNull() ?: 0.0,
                                        mistakes = mistakes.toIntOrNull() ?: 0,
                                        prompts = prompts.toIntOrNull() ?: 0,
                                        evaluation = evaluation,
                                        notes = note.trim(),
                                        smartPlanId = smartPlanId,
                                        smartPlanType = smartPlanType,
                                        smartPlanDate = smartPlanDate,
                                        qcfLineKeys = qcfLineKeys,
                                    ),
                                )
                            }
                            onSaved()
                        } catch (e: Exception) {
                            error = e.message ?: "تعذر حفظ التسميع"
                        } finally {
                            saving = false
                        }
                    }
                },
            ) { Text(if (saving) "جاري الحفظ…" else "حفظ") }
        },
        dismissButton = { TextButton(onClick = close, enabled = !saving) { Text("إلغاء") } },
    )

    if (showQuranPicker) {
        QuranRangePickerDialog(
            initialStartPage = start.toIntOrNull(),
            initialEndPage = end.toIntOrNull(),
            onDismiss = { showQuranPicker = false },
            onConfirm = { selected ->
                start = selected.normalizedStartPage.toString()
                end = selected.normalizedEndPage.toString()
                pages = plainNumber(selected.pageCount.toDouble())
                showQuranPicker = false
            },
        )
    }
}

@Composable
fun PlansScreen(profile: Profile, pending: Int, onRefresh: () -> Unit) {
    val scope = rememberCoroutineScope()
    val canManage = profile.role !in setOf(UserRole.GUARDIAN, UserRole.STUDENT)
    var rows by remember { mutableStateOf<List<PlanSnapshot>>(emptyList()) }
    var allPlans by remember { mutableStateOf<List<PlanRow>>(emptyList()) }
    var students by remember { mutableStateOf<List<Student>>(emptyList()) }
    var halaqas by remember { mutableStateOf<List<JSONObject>>(emptyList()) }
    var categories by remember { mutableStateOf<List<JSONObject>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var online by remember { mutableStateOf(true) }
    var message by remember { mutableStateOf<String?>(null) }
    var query by remember { mutableStateOf("") }
    var track by remember { mutableStateOf("all") }
    var details by remember { mutableStateOf<PlanSnapshot?>(null) }
    var planRecitation by remember { mutableStateOf<Pair<PlanSnapshot, SessionRow>?>(null) }
    var preparing by remember { mutableStateOf<String?>(null) }
    var approvingMilestone by remember { mutableStateOf<String?>(null) }
    var showManager by remember { mutableStateOf(false) }
    var showEditor by remember { mutableStateOf(false) }
    var editPlan by remember { mutableStateOf<PlanRow?>(null) }

    suspend fun reload(force: Boolean = false) {
        loading = true
        try {
            online = withContext(Dispatchers.IO) { AppGraph.repo.online() }
            rows = withContext(Dispatchers.IO) { AppGraph.repo.planSnapshots(forceRefresh = force) }
            if (canManage) {
                allPlans = withContext(Dispatchers.IO) { AppGraph.repo.plans(forceRefresh = force) }
                students = withContext(Dispatchers.IO) { AppGraph.repo.students(forceRefresh = force) }
                halaqas = withContext(Dispatchers.IO) {
                    val arr = AppGraph.repo.table("halaqas", "select=id,name,active&order=name.asc&limit=200")
                    (0 until arr.length()).mapNotNull { arr.optJSONObject(it) }
                }
                categories = withContext(Dispatchers.IO) {
                    val arr = AppGraph.repo.table("student_categories", "select=id,halaqa_id,name,active&order=name.asc&limit=500")
                    (0 until arr.length()).mapNotNull { arr.optJSONObject(it) }
                }
            }
            message = null
        } catch (e: Exception) {
            message = e.message ?: "تعذر تحميل تقدم الخطط"
        } finally {
            loading = false
        }
    }

    LaunchedEffect(Unit) { reload() }

    val filtered = rows.filter { snapshot ->
        (track == "all" || snapshot.student.track == track) &&
            (query.isBlank() || snapshot.student.fullName.contains(query, ignoreCase = true) ||
                snapshot.plan.title.contains(query, ignoreCase = true))
    }

    Column {
        AppTopBar(
            title = if (profile.role == UserRole.GUARDIAN) "خطط الأبناء" else "الخطط الذكية",
            onRefresh = {
                scope.launch { reload(force = true) }
                onRefresh()
            },
            pending = pending,
        )

        Column(
            Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("بحث باسم الطالب أو الخطة") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                singleLine = true,
            )
            Row(
                Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                ProFilterChip(track == "all", { track = "all" }, "الكل")
                ProFilterChip(track == "general_hifz", { track = "general_hifz" }, "الحفظ العام")
                ProFilterChip(track == "tathbit", { track = "tathbit" }, "التثبيت")
            }
            if (canManage) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = { editPlan = null; showEditor = true },
                        modifier = Modifier.weight(1f).heightIn(min = 48.dp),
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text("خطة جديدة")
                    }
                    OutlinedButton(
                        onClick = { showManager = true },
                        modifier = Modifier.weight(1f).heightIn(min = 48.dp),
                    ) {
                        Icon(Icons.Default.Inventory2, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text("إدارة الخطط")
                    }
                }
            }
            Surface(
                color = if (online) MaterialTheme.colorScheme.secondaryContainer else MaterialTheme.colorScheme.tertiaryContainer,
                shape = MaterialTheme.shapes.small,
            ) {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 9.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Icon(
                        if (online) Icons.Default.CloudDone else Icons.Default.CloudOff,
                        contentDescription = null,
                        tint = if (online) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.onTertiaryContainer,
                    )
                    Text(
                        when {
                            !online && pending > 0 -> "بدون اتصال · تم حفظ $pending تغييرات محليًا"
                            !online -> "بدون اتصال · سيُحفظ أي تغيير محليًا"
                            pending > 0 -> "متصل · $pending عملية بانتظار المزامنة"
                            else -> "متصل · البيانات متزامنة"
                        },
                        style = MaterialTheme.typography.bodySmall,
                        color = if (online) MaterialTheme.colorScheme.onSecondaryContainer else MaterialTheme.colorScheme.onTertiaryContainer,
                    )
                }
            }
        }

        message?.let { StateNotice(it, kind = "error", modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)) }
        if (loading && rows.isEmpty()) LoadingSkeleton(rows = 3, modifier = Modifier.padding(12.dp))
        if (!loading && filtered.isEmpty()) EmptyState("لا توجد خطط فعالة مطابقة")

        LazyColumn(
            contentPadding = PaddingValues(12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            items(filtered, key = { "${it.student.id}:${it.plan.id}" }) { snapshot ->
                val progress = snapshot.progress
                ElevatedCard(
                    onClick = { details = snapshot },
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Column(
                        Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(9.dp),
                    ) {
                        Row(
                            Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                        ) {
                            Column(Modifier.weight(1f)) {
                                Text(snapshot.student.fullName, style = MaterialTheme.typography.titleMedium)
                                Text(
                                    snapshot.plan.title.ifBlank { planTypeAr(snapshot.plan.type) },
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            }
                            PlanHealthBadge(progress.health, progress.healthLabel)
                        }

                        LinearProgressIndicator(
                            progress = { (progress.percentage / 100.0).toFloat().coerceIn(0f, 1f) },
                            modifier = Modifier.fillMaxWidth().height(8.dp).graphicsLayer(scaleX = -1f),
                        )

                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            PlanMetric("الإنجاز", "${plainNumber(progress.percentage)}%")
                            PlanMetric("ورد اليوم", "${plainNumber(progress.assignment.pages)} ص")
                            PlanMetric("المتبقي", "${plainNumber(progress.remaining)} ص")
                        }

                        val assignment = progress.assignment
                        val assignmentText = when {
                            assignment.milestone != null -> assignment.milestone.label
                            assignment.blockedByRetry -> "إعادة تثبيت ${pageRangeLabel(assignment.startPage, assignment.endPage)}"
                            assignment.pages <= 0.0 -> if (progress.remaining <= 0.0) "تم إكمال الخطة" else "لا يوجد مقرر اليوم"
                            else -> "${assignmentKindAr(assignment.kind)} · ${pageRangeLabel(assignment.startPage, assignment.endPage)}"
                        }
                        Surface(
                            color = MaterialTheme.colorScheme.primaryContainer,
                            shape = MaterialTheme.shapes.small,
                        ) {
                            Row(
                                Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 9.dp),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Icon(Icons.Default.MenuBook, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                Spacer(Modifier.width(8.dp))
                                Text(assignmentText, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
                            }
                        }

                        if (progress.behindBy > 0.0) {
                            Text(
                                "متأخر ${plainNumber(progress.behindBy)} صفحة · التعويض اليوم ${plainNumber(progress.recoveryShare)} صفحة",
                                style = MaterialTheme.typography.labelLarge,
                                color = MaterialTheme.colorScheme.error,
                            )
                        } else if (progress.aheadBy > 0.0) {
                            Text(
                                "متقدم ${plainNumber(progress.aheadBy)} صفحة",
                                style = MaterialTheme.typography.labelLarge,
                                color = MaterialTheme.colorScheme.primary,
                            )
                        }

                        if (canManage) {
                            Button(
                                onClick = {
                                    preparing = snapshot.plan.id
                                    scope.launch {
                                        try {
                                            val session = withContext(Dispatchers.IO) {
                                                AppGraph.repo.ensureTodaySession(
                                                    halaqaId = snapshot.student.halaqaId ?: snapshot.plan.halaqaId,
                                                    date = LocalDate.now().toString(),
                                                    assignmentKind = assignment.kind,
                                                )
                                            }
                                            planRecitation = snapshot to session
                                            message = null
                                        } catch (e: Exception) {
                                            message = e.message ?: "تعذر تجهيز جلسة التسميع"
                                        } finally {
                                            preparing = null
                                        }
                                    }
                                },
                                enabled = preparing == null && approvingMilestone == null &&
                                    (assignment.pages > 0.0 || assignment.milestone != null),
                                modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp),
                            ) {
                                Icon(Icons.Default.RecordVoiceOver, contentDescription = null)
                                Spacer(Modifier.width(8.dp))
                                Text(if (preparing == snapshot.plan.id) "جاري التجهيز…" else "تسميع المقرر")
                            }
                            assignment.milestone?.let { milestone ->
                                OutlinedButton(
                                    onClick = {
                                        approvingMilestone = snapshot.plan.id
                                        scope.launch {
                                            try {
                                                withContext(Dispatchers.IO) {
                                                    AppGraph.repo.recordPlanEvent(
                                                        planId = snapshot.plan.id,
                                                        studentId = snapshot.student.id,
                                                        eventType = "milestone_approved",
                                                        payload = JSONObject()
                                                            .put("milestone_key", milestone.key)
                                                            .put("approved_at", java.time.Instant.now().toString()),
                                                    )
                                                }
                                                reload()
                                                message = "تم اعتماد ${milestone.label} وفتح المقرر التالي"
                                                onRefresh()
                                            } catch (e: Exception) {
                                                message = e.message ?: "تعذر اعتماد الاختبار"
                                            } finally {
                                                approvingMilestone = null
                                            }
                                        }
                                    },
                                    enabled = approvingMilestone == null && preparing == null,
                                    modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp),
                                ) {
                                    Icon(Icons.Default.Verified, contentDescription = null)
                                    Spacer(Modifier.width(8.dp))
                                    Text(if (approvingMilestone == snapshot.plan.id) "جاري الاعتماد…" else "اعتماد ${milestone.label}")
                                }
                            }
                        }
                    }
                }
            }
            item { Spacer(Modifier.height(120.dp)) }
        }
    }

    details?.let { snapshot ->
        PlanDetailDialog(snapshot = snapshot, close = { details = null })
    }

    planRecitation?.let { (snapshot, session) ->
        val assignment = snapshot.progress.assignment
        RecitationDialog(
            student = snapshot.student,
            session = session,
            close = { planRecitation = null },
            onSaved = {
                planRecitation = null
                scope.launch { reload(force = true) }
                onRefresh()
            },
            prefillStartPage = assignment.startPage,
            prefillEndPage = assignment.endPage,
            prefillPages = assignment.pages.takeIf { it > 0.0 },
            smartPlanId = snapshot.plan.id,
            smartPlanType = snapshot.plan.type,
            smartPlanDate = LocalDate.now().toString(),
            qcfLineKeys = assignment.lineKeys,
            activityTypeOverride = when (assignment.kind) {
                "sard" -> "sard"
                "review" -> "review_near"
                "tathbit" -> "review_far"
                "test" -> "test"
                else -> "new_hifz"
            },
        )
    }

    if (showManager) {
        PlansManagerSheet(
            plans = allPlans,
            students = students,
            halaqas = halaqas,
            categories = categories,
            onDismiss = { showManager = false },
            onAdd = { showManager = false; editPlan = null; showEditor = true },
            onEdit = { plan -> showManager = false; editPlan = plan; showEditor = true },
            onStatus = { plan, status ->
                scope.launch {
                    try {
                        withContext(Dispatchers.IO) { AppGraph.repo.setPlanStatus(plan.id, status) }
                        reload()
                        message = when (status) {
                            "archived" -> "تمت أرشفة الخطة"
                            "paused" -> "تم إيقاف الخطة مؤقتاً"
                            "active" -> "تم تفعيل الخطة"
                            else -> "تم تحديث حالة الخطة"
                        }
                        onRefresh()
                    } catch (e: Exception) {
                        message = e.message ?: "تعذر تحديث الخطة"
                    }
                }
            },
        )
    }

    if (showEditor) {
        SmartPlanEditorDialog(
            current = editPlan,
            students = students,
            halaqas = halaqas,
            categories = categories,
            onDismiss = { showEditor = false; editPlan = null },
            onSave = { draft ->
                scope.launch {
                    try {
                        withContext(Dispatchers.IO) { AppGraph.repo.saveSmartPlan(draft) }
                        showEditor = false
                        editPlan = null
                        reload()
                        message = "تم حفظ الخطة الذكية"
                        onRefresh()
                    } catch (e: Exception) {
                        message = e.message ?: "تعذر حفظ الخطة"
                    }
                }
            },
        )
    }
}

@Composable
private fun PlansManagerSheet(
    plans: List<PlanRow>,
    students: List<Student>,
    halaqas: List<JSONObject>,
    categories: List<JSONObject>,
    onDismiss: () -> Unit,
    onAdd: () -> Unit,
    onEdit: (PlanRow) -> Unit,
    onStatus: (PlanRow, String) -> Unit,
) {
    var status by remember { mutableStateOf("all") }
    val filtered = plans.filter { status == "all" || it.status == status }
    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("إدارة الخطط", style = MaterialTheme.typography.titleLarge)
                    Text("إنشاء وتعديل وإيقاف وأرشفة واستعادة الخطط", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                FilledIconButton(onClick = onAdd, modifier = Modifier.size(48.dp)) {
                    Icon(Icons.Default.Add, contentDescription = "خطة جديدة")
                }
            }
            Spacer(Modifier.height(8.dp))
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("all" to "الكل", "active" to "فعالة", "paused" to "موقفة", "completed" to "مكتملة", "archived" to "الأرشيف").forEach { (key, label) ->
                    ProFilterChip(status == key, { status = key }, label)
                }
            }
            Spacer(Modifier.height(8.dp))
            if (filtered.isEmpty()) {
                EmptyState("لا توجد خطط في هذه الحالة")
            } else {
                LazyColumn(
                    modifier = Modifier.heightIn(max = 610.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    contentPadding = PaddingValues(bottom = 28.dp),
                ) {
                    items(filtered, key = { it.id }) { plan ->
                        ElevatedCard(Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Column(Modifier.weight(1f)) {
                                        Text(plan.title.ifBlank { planTypeAr(plan.type) }, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold)
                                        Text(
                                            planScopeLabel(plan, students, halaqas, categories),
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        )
                                    }
                                    Surface(
                                        color = MaterialTheme.colorScheme.secondaryContainer,
                                        contentColor = MaterialTheme.colorScheme.onSecondaryContainer,
                                        shape = MaterialTheme.shapes.extraLarge,
                                    ) {
                                        Text(
                                            planStatusAr(plan.status),
                                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp),
                                            style = MaterialTheme.typography.labelLarge,
                                        )
                                    }
                                }
                                Text("${planTypeAr(plan.type)} · ${plainNumber(plan.target)} صفحة · ${plan.startDate} ← ${plan.endDate}", style = MaterialTheme.typography.bodySmall)
                                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    OutlinedButton(onClick = { onEdit(plan) }, modifier = Modifier.heightIn(min = 48.dp)) {
                                        Icon(Icons.Default.Edit, contentDescription = null)
                                        Spacer(Modifier.width(6.dp)); Text("تعديل")
                                    }
                                    when (plan.status) {
                                        "active" -> OutlinedButton(onClick = { onStatus(plan, "paused") }, modifier = Modifier.heightIn(min = 48.dp)) { Text("إيقاف مؤقت") }
                                        "paused", "archived", "draft" -> Button(onClick = { onStatus(plan, "active") }, modifier = Modifier.heightIn(min = 48.dp)) { Text(if (plan.status == "archived") "استعادة" else "تفعيل") }
                                    }
                                    if (plan.status != "archived") {
                                        TextButton(onClick = { onStatus(plan, "archived") }, modifier = Modifier.heightIn(min = 48.dp)) { Text("أرشفة") }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

private fun planStatusAr(value: String) = when (value) {
    "draft" -> "مسودة"
    "active" -> "فعالة"
    "paused" -> "موقفة"
    "completed" -> "مكتملة"
    "archived" -> "مؤرشفة"
    else -> value
}

private fun planScopeLabel(
    plan: PlanRow,
    students: List<Student>,
    halaqas: List<JSONObject>,
    categories: List<JSONObject>,
): String = when (plan.scopeType) {
    "student" -> students.firstOrNull { it.id == plan.studentId }?.fullName ?: "طالب محدد"
    "category" -> categories.firstOrNull { it.optString("id") == plan.categoryId }?.optString("name") ?: "فئة محددة"
    else -> halaqas.firstOrNull { it.optString("id") == plan.halaqaId }?.optString("name") ?: "الحلقة كلها"
}

@Composable
private fun SmartPlanEditorDialog(
    current: PlanRow?,
    students: List<Student>,
    halaqas: List<JSONObject>,
    categories: List<JSONObject>,
    onDismiss: () -> Unit,
    onSave: (SmartPlanDraft) -> Unit,
) {
    val today = LocalDate.now()
    val planKey = current?.id
    var scopeType by remember(planKey) { initialPlanScopeType(current) }
    var halaqaId by remember(planKey) { initialPlanHalaqaId(current, halaqas) }
    var studentId by remember(planKey) { initialPlanStudentId(current, students, halaqaId) }
    var categoryId by remember(planKey) { initialPlanCategoryId(current, categories, halaqaId) }
    var type by remember(planKey) { initialPlanType(current) }
    var title by remember(planKey) { initialPlanTitle(current) }
    var target by remember(planKey) { initialPlanTarget(current) }
    var startDate by remember(planKey) { initialPlanStartDate(current, today) }
    var endDate by remember(planKey) { initialPlanEndDate(current, today) }
    var weekdays by remember(planKey) { initialPlanWeekdays(current) }
    var catchUp by remember(planKey) { initialPlanCatchUp(current) }
    var rangeStartPage by remember(planKey) { initialPlanRangeStartPage(current) }
    var rangeEndPage by remember(planKey) { initialPlanRangeEndPage(current) }
    var rangeStartSurah by remember(planKey) { initialPlanRangeStartSurah(current) }
    var rangeStartAyah by remember(planKey) { initialPlanRangeStartAyah(current) }
    var rangeEndSurah by remember(planKey) { initialPlanRangeEndSurah(current) }
    var rangeEndAyah by remember(planKey) { initialPlanRangeEndAyah(current) }
    var reviewTier by remember(planKey) { initialPlanReviewTier(current) }
    var nearPages by remember(planKey) { initialPlanNearPages(current) }
    var farPages by remember(planKey) { initialPlanFarPages(current) }
    var minEvaluation by remember(planKey) { initialPlanMinEvaluation(current) }
    var dailyCap by remember(planKey) { initialPlanDailyCap(current) }
    var milestone by remember(planKey) { initialPlanMilestone(current) }
    var delayDays by remember(planKey) { initialPlanDelayDays(current) }
    var qualityGate by remember(planKey) { initialPlanQualityGate(current) }
    var autoExtend by remember(planKey) { initialPlanAutoExtend(current) }
    var milestoneApproval by remember(planKey) { initialPlanMilestoneApproval(current) }
    var homePrepPush by remember(planKey) { initialPlanHomePrepPush(current) }
    var note by remember(planKey) { initialPlanNote(current) }
    var routeDirection by remember(planKey) { initialPlanRouteDirection(current) }
    var showRangePicker by remember { mutableStateOf(false) }
    var showAdvanced by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    val scopedStudents = students.filter { it.halaqaId == halaqaId && it.status == "active" }
    val scopedCategories = categories.filter { it.optString("halaqa_id") == halaqaId && it.optBoolean("active", true) }
    val weekdayLabels = listOf("الأحد", "الاثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة", "السبت")

    fun buildDraft(): SmartPlanDraft {
        val parsedTarget = target.toDoubleOrNull() ?: error("أدخل هدفاً صحيحاً بالصفحات")
        val parsedDailyCap = dailyCap.toDoubleOrNull() ?: error("أقصى زيادة يومية غير صالحة")
        val parsedDelay = delayDays.toIntOrNull() ?: error("أيام تنبيه التأخر غير صالحة")
        val parsedNear = nearPages.toDoubleOrNull() ?: 0.0
        val parsedFar = farPages.toDoubleOrNull() ?: 0.0
        val settings = editorPlanSettings(current)
        return SmartPlanDraft(
            id = current?.id,
            scopeType = scopeType,
            halaqaId = halaqaId,
            studentId = studentId,
            categoryId = categoryId,
            parentPlanId = current?.parentPlanId,
            type = type,
            reviewTier = if (type == "review") reviewTier else "none",
            title = title,
            targetPages = parsedTarget,
            startDate = startDate,
            endDate = endDate,
            scheduleWeekdays = weekdays.sorted(),
            catchUpWeekday = catchUp,
            maxDailyMultiplier = parsedDailyCap,
            autoExtend = autoExtend,
            qualityGateEnabled = qualityGate,
            minimumEvaluation = minEvaluation,
            rangeStartPage = rangeStartPage,
            rangeEndPage = rangeEndPage,
            rangeStartSurah = rangeStartSurah,
            rangeStartAyah = rangeStartAyah,
            rangeEndSurah = rangeEndSurah,
            rangeEndAyah = rangeEndAyah,
            nearRevisionPages = parsedNear,
            farRevisionPages = parsedFar,
            milestoneMode = milestone,
            milestoneRequiresApproval = milestoneApproval,
            delayAlertDays = parsedDelay,
            homePrepPush = homePrepPush,
            status = current?.status?.takeUnless { it == "archived" } ?: "active",
            note = note,
            minimumDailyMode = settings.minimumDailyMode,
            minimumDailyPages = settings.minimumDailyPages,
            intensiveWeekFrom = settings.intensiveWeekFrom,
            intensiveWeekTo = settings.intensiveWeekTo,
            intensiveWeekdays = settings.intensiveWeekdays,
            memorizationLineKeys = settings.memorizationLineKeys,
            routeDirection = if (type in setOf("sard", "tathbit")) routeDirection else settings.routeDirection,
        )
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (current == null) "خطة ذكية جديدة" else "تعديل الخطة الذكية") },
        text = {
            LazyColumn(
                modifier = Modifier.heightIn(max = 620.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                item {
                    Text("نطاق التطبيق", style = MaterialTheme.typography.titleSmall)
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("student" to "طالب", "category" to "فئة", "halaqa" to "الحلقة").forEach { (key, label) ->
                            ProFilterChip(scopeType == key, { scopeType = key }, label)
                        }
                    }
                }
                item {
                    Text("الحلقة", style = MaterialTheme.typography.labelLarge)
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        halaqas.filter { it.optBoolean("active", true) || it.optString("id") == halaqaId }.forEach { h ->
                            val id = h.optString("id")
                            ProFilterChip(
                                selected = halaqaId == id,
                                onClick = {
                                    halaqaId = id
                                    studentId = students.firstOrNull { it.halaqaId == id && it.status == "active" }?.id
                                    categoryId = categories.firstOrNull { it.optString("halaqa_id") == id && it.optBoolean("active", true) }?.optString("id")
                                },
                                label = h.optString("name", "حلقة"),
                            )
                        }
                    }
                }
                if (scopeType == "student") item {
                    Text("الطالب", style = MaterialTheme.typography.labelLarge)
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        scopedStudents.forEach { st -> ProFilterChip(studentId == st.id, { studentId = st.id }, st.fullName) }
                    }
                    if (scopedStudents.isEmpty()) Text("لا يوجد طلاب فعالون في الحلقة", color = MaterialTheme.colorScheme.error)
                }
                if (scopeType == "category") item {
                    Text("الفئة", style = MaterialTheme.typography.labelLarge)
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        scopedCategories.forEach { c ->
                            val id = c.optString("id")
                            ProFilterChip(categoryId == id, { categoryId = id }, c.optString("name"))
                        }
                    }
                    if (scopedCategories.isEmpty()) Text("لا توجد فئات فعالة في الحلقة", color = MaterialTheme.colorScheme.error)
                }
                item {
                    Text("نوع الخطة", style = MaterialTheme.typography.labelLarge)
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("hifz" to "حفظ", "review" to "مراجعة", "sard" to "سرد", "tathbit" to "تثبيت").forEach { (key, label) ->
                            ProFilterChip(type == key, { type = key }, label)
                        }
                    }
                }
                item {
                    OutlinedTextField(title, { title = it }, label = { Text("عنوان الخطة") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                }
                item {
                    OutlinedTextField(target, { target = it.filter { ch -> ch.isDigit() || ch == '.' } }, label = { Text("المطلوب خلال الخطة بالصفحات") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                }
                item {
                    OutlinedButton(onClick = { showRangePicker = true }, modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp)) {
                        Icon(Icons.Default.MenuBook, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text("نطاق القرآن: ${pageRangeLabel(rangeStartPage, rangeEndPage)}")
                    }
                }
                if (type in setOf("sard", "tathbit")) item {
                    Text("اتجاه المسار", style = MaterialTheme.typography.labelLarge)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        ProFilterChip(routeDirection == "reverse_surahs_forward_ayahs", { routeDirection = "reverse_surahs_forward_ayahs" }, "الناس ← البقرة")
                        ProFilterChip(routeDirection == "forward_surahs_forward_ayahs", { routeDirection = "forward_surahs_forward_ayahs" }, "البقرة → الناس")
                    }
                }
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(startDate, { startDate = it }, label = { Text("تاريخ البدء") }, modifier = Modifier.weight(1f), singleLine = true)
                        OutlinedTextField(endDate, { endDate = it }, label = { Text("تاريخ الانتهاء") }, modifier = Modifier.weight(1f), singleLine = true)
                    }
                }
                item {
                    Text("أيام الدوام", style = MaterialTheme.typography.labelLarge)
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        weekdayLabels.forEachIndexed { index, label ->
                            ProFilterChip(
                                selected = index in weekdays,
                                onClick = { weekdays = if (index in weekdays) weekdays - index else weekdays + index },
                                label = label,
                            )
                        }
                    }
                }
                item {
                    Text("يوم الاستدراك", style = MaterialTheme.typography.labelLarge)
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        ProFilterChip(catchUp == null, { catchUp = null }, "بدون")
                        weekdayLabels.forEachIndexed { index, label -> ProFilterChip(catchUp == index, { catchUp = index }, label) }
                    }
                }
                if (type == "review") item {
                    Text("مسار المراجعة", style = MaterialTheme.typography.labelLarge)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("near" to "قريبة", "far" to "بعيدة", "both" to "قريبة + بعيدة").forEach { (key, label) ->
                            ProFilterChip(reviewTier == key, { reviewTier = key }, label)
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(nearPages, { nearPages = it.filter { ch -> ch.isDigit() || ch == '.' } }, label = { Text("قريبة يومياً") }, modifier = Modifier.weight(1f), singleLine = true)
                        OutlinedTextField(farPages, { farPages = it.filter { ch -> ch.isDigit() || ch == '.' } }, label = { Text("دورة بعيدة") }, modifier = Modifier.weight(1f), singleLine = true)
                    }
                }
                item {
                    TextButton(onClick = { showAdvanced = !showAdvanced }, modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp)) {
                        Text(if (showAdvanced) "إخفاء قواعد الخطة" else "قواعد الخطة الذكية")
                        Spacer(Modifier.width(6.dp))
                        Icon(if (showAdvanced) Icons.Default.ExpandLess else Icons.Default.ExpandMore, contentDescription = null)
                    }
                }
                if (showAdvanced) {
                    item {
                        Text("أقل تقييم للاجتياز", style = MaterialTheme.typography.labelLarge)
                        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf("excellent" to "ممتاز", "very_good" to "جيد جداً", "good" to "جيد").forEach { (key, label) ->
                                ProFilterChip(minEvaluation == key, { minEvaluation = key }, label)
                            }
                        }
                    }
                    item {
                        Text("أقصى زيادة يومية", style = MaterialTheme.typography.labelLarge)
                        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf("1.25", "1.5", "1.75", "2.0").forEach { value ->
                                ProFilterChip(dailyCap == value || dailyCap == value.removeSuffix(".0"), { dailyCap = value }, "${(value.toDouble() * 100).toInt()}%")
                            }
                        }
                    }
                    item {
                        Text("الاختبار المرحلي", style = MaterialTheme.typography.labelLarge)
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf("none" to "بدون", "hizb" to "حزب", "juz" to "جزء").forEach { (key, label) ->
                                ProFilterChip(milestone == key, { milestone = key }, label)
                            }
                        }
                    }
                    item { OutlinedTextField(delayDays, { delayDays = it.filter(Char::isDigit) }, label = { Text("تنبيه التأخر بعد أيام دوام") }, modifier = Modifier.fillMaxWidth(), singleLine = true) }
                    item { SwitchRow("لا يتقدم قبل اجتياز التقييم", qualityGate) { qualityGate = it } }
                    item { SwitchRow("تمديد نهاية الخطة تلقائياً", autoExtend) { autoExtend = it } }
                    item { SwitchRow("الاختبار المرحلي يحتاج اعتماد المحفّظ", milestoneApproval) { milestoneApproval = it } }
                    item { SwitchRow("تنبيه التحضير المنزلي لولي الأمر", homePrepPush) { homePrepPush = it } }
                }
                item { OutlinedTextField(note, { note = it }, label = { Text("ملاحظة للمحفّظ وولي الأمر") }, modifier = Modifier.fillMaxWidth(), minLines = 2) }
                error?.let { item { Text(it, color = MaterialTheme.colorScheme.error) } }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    try {
                        error = null
                        onSave(buildDraft())
                    } catch (e: Exception) {
                        error = e.message ?: "تحقق من بيانات الخطة"
                    }
                },
            ) { Text("حفظ الخطة") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } },
    )

    if (showRangePicker) {
        QuranRangePickerDialog(
            initialStartPage = rangeStartPage,
            initialEndPage = rangeEndPage,
            onDismiss = { showRangePicker = false },
            onConfirm = { selected ->
                rangeStartPage = selected.normalizedStartPage
                rangeEndPage = selected.normalizedEndPage
                rangeStartSurah = selected.start.surah
                rangeStartAyah = selected.start.ayah
                rangeEndSurah = selected.end.surah
                rangeEndAyah = selected.end.ayah
                showRangePicker = false
            },
        )
    }
}

@Composable
private fun SwitchRow(label: String, checked: Boolean, onChecked: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().heightIn(min = 48.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
        Switch(checked = checked, onCheckedChange = onChecked)
    }
}

@Composable
private fun PlanHealthBadge(health: String, label: String) {
    val colors = when (health) {
        "red" -> MaterialTheme.colorScheme.errorContainer to MaterialTheme.colorScheme.onErrorContainer
        "yellow" -> MaterialTheme.colorScheme.tertiaryContainer to MaterialTheme.colorScheme.onTertiaryContainer
        else -> MaterialTheme.colorScheme.primaryContainer to MaterialTheme.colorScheme.onPrimaryContainer
    }
    Surface(color = colors.first, contentColor = colors.second, shape = MaterialTheme.shapes.extraLarge) {
        Text(label, Modifier.padding(horizontal = 10.dp, vertical = 6.dp), style = MaterialTheme.typography.labelLarge)
    }
}

@Composable
private fun PlanMetric(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, style = MaterialTheme.typography.titleMedium)
        Text(label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun PlanDetailDialog(snapshot: PlanSnapshot, close: () -> Unit) {
    val p = snapshot.progress
    AlertDialog(
        onDismissRequest = close,
        title = { Text("${snapshot.student.fullName} · ${planTypeAr(snapshot.plan.type)}") },
        text = {
            LazyColumn(
                modifier = Modifier.heightIn(max = 560.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                item {
                    Text(snapshot.plan.title.ifBlank { planTypeAr(snapshot.plan.type) }, style = MaterialTheme.typography.titleMedium)
                    Text(
                        "${snapshot.plan.startDate} ← ${snapshot.plan.endDate}",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                item {
                    LinearProgressIndicator(
                        progress = { (p.percentage / 100.0).toFloat().coerceIn(0f, 1f) },
                        modifier = Modifier.fillMaxWidth().height(9.dp).graphicsLayer(scaleX = -1f),
                    )
                }
                item {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        PlanMetric("المكتمل", "${plainNumber(p.completed)} ص")
                        PlanMetric("المتبقي", "${plainNumber(p.remaining)} ص")
                        PlanMetric("النسبة", "${plainNumber(p.percentage)}%")
                    }
                }
                item { HorizontalDivider() }
                item { PlanDetailLine("الحالة", "${p.healthLabel} · ${p.paceLabel}") }
                item { PlanDetailLine("المقرر اليوم", "${plainNumber(p.assignment.pages)} صفحة") }
                item { PlanDetailLine("الحد اليومي", "${plainNumber(p.dailyCap)} صفحة") }
                item { PlanDetailLine("الحد الأدنى", "${plainNumber(p.minimumDaily)} صفحة") }
                item { PlanDetailLine("المخطط حتى اليوم", "${plainNumber(p.plannedByToday)} صفحة") }
                item { PlanDetailLine("العجز", "${plainNumber(p.deficit)} صفحة") }
                item { PlanDetailLine("أيام التأخر المتتالية", p.consecutiveMissed.toString()) }
                if (p.extensionNeeded) {
                    item { PlanDetailLine("التمديد المقترح", p.suggestedEndDate.toString()) }
                }
                item {
                    PlanDetailLine(
                        "النطاق",
                        pageRangeLabel(snapshot.plan.rangeStartPage, snapshot.plan.rangeEndPage),
                    )
                }
                if (p.retryPages.isNotEmpty()) {
                    item { PlanDetailLine("صفحات تحتاج إعادة", p.retryPages.joinToString(", ")) }
                }
                p.assignment.milestone?.let { milestone ->
                    item { PlanDetailLine("الاختبار المطلوب", milestone.label) }
                }
                snapshot.plan.note.takeIf { it.isNotBlank() }?.let { note ->
                    item { PlanDetailLine("ملاحظة الخطة", note) }
                }
            }
        },
        confirmButton = { Button(onClick = close) { Text("إغلاق") } },
    )
}

@Composable
private fun PlanDetailLine(label: String, value: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, style = MaterialTheme.typography.bodyMedium)
    }
}

private fun assignmentKindAr(value: String) = when (value) {
    "hifz" -> "حفظ جديد"
    "review" -> "مراجعة"
    "sard" -> "سرد"
    "tathbit" -> "تثبيت"
    "test" -> "اختبار"
    else -> value
}

private fun pageRangeLabel(start: Int?, end: Int?): String = when {
    start == null && end == null -> "يُحدد حسب الخطة"
    start != null && end != null && start == end -> "صفحة $start"
    start != null && end != null -> "من صفحة $start إلى $end"
    start != null -> "من صفحة $start"
    else -> "حتى صفحة $end"
}

internal fun plainNumber(value: Double): String {
    val rounded = kotlin.math.round(value * 100.0) / 100.0
    return if (kotlin.math.abs(rounded - rounded.toInt()) < 0.000001) rounded.toInt().toString()
    else rounded.toString().trimEnd('0').trimEnd('.')
}

fun planTypeAr(value: String) = when (value) {
    "hifz" -> "حفظ"
    "review" -> "مراجعة"
    "sard" -> "سرد"
    "tathbit" -> "تثبيت"
    else -> value
}


@Composable
fun UsersScreen(pending: Int, onRefresh: () -> Unit) {
    val scope = rememberCoroutineScope()
    var rows by remember { mutableStateOf<List<JSONObject>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var status by remember { mutableStateOf("pending") }
    var query by remember { mutableStateOf("") }
    var message by remember { mutableStateOf<String?>(null) }
    var rejectUser by remember { mutableStateOf<JSONObject?>(null) }
    var roleUser by remember { mutableStateOf<JSONObject?>(null) }
    var deleteUser by remember { mutableStateOf<JSONObject?>(null) }
    var linkGuardian by remember { mutableStateOf(false) }
    var busyId by remember { mutableStateOf<String?>(null) }

    suspend fun reload() {
        loading = true
        try {
            val arr = withContext(Dispatchers.IO) { AppGraph.repo.accountProfiles() }
            rows = (0 until arr.length()).mapNotNull { arr.optJSONObject(it) }
            message = null
        } catch (e: Exception) {
            message = e.message ?: "تعذر تحميل الحسابات"
        } finally {
            loading = false
        }
    }

    fun runAccountAction(userId: String, action: () -> Unit, success: String) {
        busyId = userId
        scope.launch {
            try {
                withContext(Dispatchers.IO) { action() }
                message = success
                reload()
                onRefresh()
            } catch (e: Exception) {
                message = e.message ?: "تعذر تنفيذ العملية"
            } finally {
                busyId = null
            }
        }
    }

    LaunchedEffect(Unit) { reload() }
    val filtered = rows.filter { row ->
        (status == "all" || row.optString("approval_status") == status) &&
            (query.isBlank() || row.optString("full_name").contains(query, true) || row.optString("email").contains(query, true))
    }

    Column {
        AppTopBar(
            title = "الحسابات والصلاحيات",
            onRefresh = { scope.launch { reload() }; onRefresh() },
            pending = pending,
        )
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("بحث بالاسم أو البريد") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                singleLine = true,
            )
            Row(
                Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                listOf("pending" to "بانتظار الاعتماد", "approved" to "معتمدة", "rejected" to "مرفوضة", "all" to "الكل")
                    .forEach { (value, label) ->
                        ProFilterChip(status == value, { status = value }, label)
                    }
            }
            OutlinedButton(
                onClick = { linkGuardian = true },
                modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp),
            ) {
                Icon(Icons.Default.FamilyRestroom, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("ربط ولي الأمر بالطالب")
            }
        }
        message?.let {
            StateNotice(
                it,
                kind = if (it.startsWith("تعذر") || it.contains("غير صالح")) "error" else "success",
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp),
            )
        }
        if (loading && rows.isEmpty()) LoadingSkeleton(rows = 4, modifier = Modifier.padding(12.dp))
        if (!loading && filtered.isEmpty()) EmptyState("لا توجد حسابات في هذا التصنيف")
        LazyColumn(
            contentPadding = PaddingValues(start = 12.dp, end = 12.dp, top = 12.dp, bottom = 96.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            items(filtered, key = { it.optString("id") }) { row ->
                val id = row.optString("id")
                val isAdmin = row.optString("role") == "admin"
                val approval = row.optString("approval_status")
                val active = row.optBoolean("active", true)
                val requested = row.optString("requested_role").ifBlank { row.optString("role", "guardian") }
                ElevatedCard(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.AccountCircle, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            Spacer(Modifier.width(8.dp))
                            Column(Modifier.weight(1f)) {
                                Text(row.optString("full_name").ifBlank { "مستخدم" }, style = MaterialTheme.typography.titleMedium)
                                Text(row.optString("email").ifBlank { "—" }, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            AccountStatusBadge(approval, active, isAdmin)
                        }
                        Text(
                            if (isAdmin) "مسؤول النظام" else "الصلاحية: ${roleAr(row.optString("role"))} · الطلب: ${roleAr(requested)}",
                            style = MaterialTheme.typography.labelLarge,
                        )
                        row.optString("rejection_reason").takeIf { it.isNotBlank() }?.let { reason ->
                            Text("سبب الرفض: $reason", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                        }
                        if (!isAdmin) {
                            Row(
                                Modifier.horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                            ) {
                                when (approval) {
                                    "pending" -> {
                                        Button(
                                            onClick = {
                                                runAccountAction(id, { AppGraph.repo.approveAccount(id, requested) }, "تم اعتماد الحساب")
                                            },
                                            enabled = busyId == null,
                                            modifier = Modifier.heightIn(min = 48.dp),
                                        ) { Text(if (busyId == id) "جاري…" else "اعتماد") }
                                        OutlinedButton(onClick = { rejectUser = row }, enabled = busyId == null, modifier = Modifier.heightIn(min = 48.dp)) { Text("رفض") }
                                    }
                                    "rejected" -> Button(
                                        onClick = { runAccountAction(id, { AppGraph.repo.approveAccount(id, requested) }, "تم اعتماد الحساب من جديد") },
                                        enabled = busyId == null,
                                        modifier = Modifier.heightIn(min = 48.dp),
                                    ) { Text("اعتماد من جديد") }
                                    else -> {
                                        FilledTonalButton(
                                            onClick = { runAccountAction(id, { AppGraph.repo.setAccountActive(id, !active) }, if (active) "تم إيقاف الحساب" else "تم تفعيل الحساب") },
                                            enabled = busyId == null,
                                            modifier = Modifier.heightIn(min = 48.dp),
                                        ) { Text(if (active) "إيقاف" else "تفعيل") }
                                        OutlinedButton(onClick = { roleUser = row }, enabled = busyId == null, modifier = Modifier.heightIn(min = 48.dp)) { Text("تغيير الصلاحية") }
                                    }
                                }
                                TextButton(onClick = { deleteUser = row }, enabled = busyId == null, modifier = Modifier.heightIn(min = 48.dp)) {
                                    Icon(Icons.Default.DeleteForever, contentDescription = null)
                                    Text(" حذف نهائي")
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    rejectUser?.let { row ->
        RejectAccountDialog(
            name = row.optString("full_name"),
            close = { rejectUser = null },
            save = { reason ->
                val id = row.optString("id")
                rejectUser = null
                runAccountAction(id, { AppGraph.repo.rejectAccount(id, reason) }, "تم رفض طلب الحساب")
            },
        )
    }
    roleUser?.let { row ->
        RoleAccountDialog(
            name = row.optString("full_name"),
            current = row.optString("role", "guardian"),
            close = { roleUser = null },
            save = { role ->
                val id = row.optString("id")
                roleUser = null
                runAccountAction(id, { AppGraph.repo.changeAccountRole(id, role) }, "تم تغيير الصلاحية")
            },
        )
    }
    deleteUser?.let { row ->
        DeleteAccountDialog(
            name = row.optString("full_name"),
            close = { deleteUser = null },
            confirm = {
                val id = row.optString("id")
                deleteUser = null
                runAccountAction(id, { AppGraph.repo.deleteAccountPermanently(id) }, "تم حذف الحساب نهائيًا")
            },
        )
    }
    if (linkGuardian) {
        GuardianLinkDialog(
            close = { linkGuardian = false },
            onSaved = {
                linkGuardian = false
                message = "تم تحديث ربط ولي الأمر"
                onRefresh()
            },
        )
    }
}

@Composable
private fun AccountStatusBadge(approval: String, active: Boolean, admin: Boolean) {
    val (label, container, content) = when {
        admin -> Triple("مسؤول", MaterialTheme.colorScheme.secondaryContainer, MaterialTheme.colorScheme.onSecondaryContainer)
        approval == "pending" -> Triple("بانتظار الاعتماد", MaterialTheme.colorScheme.tertiaryContainer, MaterialTheme.colorScheme.onTertiaryContainer)
        approval == "rejected" -> Triple("مرفوض", MaterialTheme.colorScheme.errorContainer, MaterialTheme.colorScheme.onErrorContainer)
        !active -> Triple("موقوف", MaterialTheme.colorScheme.errorContainer, MaterialTheme.colorScheme.onErrorContainer)
        else -> Triple("نشط", MaterialTheme.colorScheme.primaryContainer, MaterialTheme.colorScheme.onPrimaryContainer)
    }
    Surface(color = container, contentColor = content, shape = MaterialTheme.shapes.extraLarge) {
        Text(label, Modifier.padding(horizontal = 9.dp, vertical = 5.dp), style = MaterialTheme.typography.labelMedium)
    }
}

private fun roleAr(value: String) = when (value) {
    "admin" -> "مسؤول النظام"
    "supervisor" -> "مشرف الحلقات"
    "teacher" -> "محفّظ الحلقة"
    "guardian" -> "ولي أمر"
    "student" -> "طالب"
    else -> "غير محدد"
}

@Composable
private fun RejectAccountDialog(name: String, close: () -> Unit, save: (String) -> Unit) {
    var reason by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = close,
        title = { Text("رفض حساب $name") },
        text = { OutlinedTextField(value = reason, onValueChange = { reason = it }, label = { Text("سبب الرفض (اختياري)") }, minLines = 2, modifier = Modifier.fillMaxWidth()) },
        confirmButton = { Button(onClick = { save(reason.trim()) }, modifier = Modifier.heightIn(min = HalaqatiUiTokens.TouchTarget)) { Text("رفض الحساب") } },
        dismissButton = { TextButton(onClick = close, modifier = Modifier.heightIn(min = HalaqatiUiTokens.TouchTarget)) { Text("إلغاء") } },
    )
}

@Composable
private fun RoleAccountDialog(name: String, current: String, close: () -> Unit, save: (String) -> Unit) {
    var role by remember { mutableStateOf(current.takeIf { it in setOf("guardian", "teacher", "supervisor") } ?: "guardian") }
    val roles = listOf("guardian", "teacher", "supervisor")
    AlertDialog(
        onDismissRequest = close,
        title = { Text("صلاحية $name") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                roles.forEach { value ->
                    ProFilterChip(role == value, { role = value }, roleAr(value), modifier = Modifier.fillMaxWidth())
                }
            }
        },
        confirmButton = { Button(onClick = { save(role) }, modifier = Modifier.heightIn(min = HalaqatiUiTokens.TouchTarget)) { Text("حفظ") } },
        dismissButton = { TextButton(onClick = close, modifier = Modifier.heightIn(min = HalaqatiUiTokens.TouchTarget)) { Text("إلغاء") } },
    )
}

@Composable
private fun DeleteAccountDialog(name: String, close: () -> Unit, confirm: () -> Unit) {
    var typed by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = close,
        title = { Text("حذف الحساب نهائيًا") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("سيتم حذف حساب «$name» نهائيًا. اكتب حذف للتأكيد.", color = MaterialTheme.colorScheme.error)
                OutlinedTextField(value = typed, onValueChange = { typed = it }, label = { Text("اكتب: حذف") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            }
        },
        confirmButton = { Button(onClick = confirm, enabled = typed.trim() == "حذف", modifier = Modifier.heightIn(min = HalaqatiUiTokens.TouchTarget)) { Text("حذف نهائي") } },
        dismissButton = { TextButton(onClick = close, modifier = Modifier.heightIn(min = HalaqatiUiTokens.TouchTarget)) { Text("إلغاء") } },
    )
}

@Composable
private fun GuardianLinkDialog(close: () -> Unit, onSaved: () -> Unit) {
    val scope = rememberCoroutineScope()
    var students by remember { mutableStateOf<List<Student>>(emptyList()) }
    var guardians by remember { mutableStateOf<List<JSONObject>>(emptyList()) }
    var studentId by remember { mutableStateOf<String?>(null) }
    var guardianId by remember { mutableStateOf<String?>(null) }
    var loading by remember { mutableStateOf(true) }
    var saving by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(Unit) {
        try {
            val result = withContext(Dispatchers.IO) {
                val st = AppGraph.repo.students()
                val ga = AppGraph.repo.guardianAccounts()
                st to (0 until ga.length()).mapNotNull { ga.optJSONObject(it) }
            }
            students = result.first
            guardians = result.second
            studentId = students.firstOrNull()?.id
            guardianId = guardians.firstOrNull()?.optString("id")
        } catch (e: Exception) {
            error = e.message ?: "تعذر تحميل بيانات الربط"
        } finally {
            loading = false
        }
    }

    AlertDialog(
        onDismissRequest = { if (!saving) close() },
        title = { Text("ربط ولي الأمر بالطالب") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (loading) LoadingSkeleton(rows = 2)
                error?.let { StateNotice(it, "error") }
                Text("الطالب", style = MaterialTheme.typography.labelLarge)
                LazyColumn(Modifier.heightIn(max = 160.dp)) {
                    items(students, key = { it.id }) { student ->
                        ProFilterChip(
                            selected = studentId == student.id,
                            onClick = { studentId = student.id },
                            label = student.fullName,
                            modifier = Modifier.fillMaxWidth(),
                        )
                    }
                }
                if (!loading && students.isEmpty()) EmptyState("لا يوجد طلاب متاحون للربط")
                Text("ولي الأمر", style = MaterialTheme.typography.labelLarge)
                LazyColumn(Modifier.heightIn(max = 160.dp)) {
                    items(guardians, key = { it.optString("id") }) { guardian ->
                        ProFilterChip(
                            selected = guardianId == guardian.optString("id"),
                            onClick = { guardianId = guardian.optString("id") },
                            label = guardian.optString("full_name").ifBlank { guardian.optString("email", "ولي أمر") },
                            modifier = Modifier.fillMaxWidth(),
                        )
                    }
                }
                if (!loading && guardians.isEmpty()) EmptyState("لا توجد حسابات أولياء أمور معتمدة")
            }
        },
        confirmButton = {
            Button(
                enabled = !loading && !saving && !studentId.isNullOrBlank() && !guardianId.isNullOrBlank(),
                onClick = {
                    val st = studentId ?: return@Button
                    saving = true
                    scope.launch {
                        try {
                            withContext(Dispatchers.IO) { AppGraph.repo.linkPrimaryGuardian(st, guardianId) }
                            onSaved()
                        } catch (e: Exception) {
                            error = e.message ?: "تعذر ربط ولي الأمر"
                        } finally {
                            saving = false
                        }
                    }
                },
                modifier = Modifier.heightIn(min = HalaqatiUiTokens.TouchTarget),
            ) { Text(if (saving) "جاري الحفظ…" else "حفظ الربط") }
        },
        dismissButton = { TextButton(onClick = close, enabled = !saving, modifier = Modifier.heightIn(min = HalaqatiUiTokens.TouchTarget)) { Text("إلغاء") } },
    )
}

// Keep nullable field initialization in separate FIR control-flow graphs.
private fun initialPlanScopeType(current: PlanRow?): MutableState<String> =
    mutableStateOf(current?.scopeType ?: "student")

private fun initialPlanHalaqaId(current: PlanRow?, halaqas: List<JSONObject>): MutableState<String> =
    mutableStateOf(current?.halaqaId ?: halaqas.firstOrNull()?.optString("id").orEmpty())

private fun initialPlanStudentId(current: PlanRow?, students: List<Student>, halaqaId: String): MutableState<String?> =
    mutableStateOf(current?.studentId ?: students.firstOrNull { it.halaqaId == halaqaId }?.id)

private fun initialPlanCategoryId(current: PlanRow?, categories: List<JSONObject>, halaqaId: String): MutableState<String?> =
    mutableStateOf(current?.categoryId ?: categories.firstOrNull { it.optString("halaqa_id") == halaqaId }?.optString("id"))

private fun initialPlanType(current: PlanRow?): MutableState<String> =
    mutableStateOf(current?.type ?: "hifz")

private fun initialPlanTitle(current: PlanRow?): MutableState<String> =
    mutableStateOf(current?.title.orEmpty())

private fun initialPlanTarget(current: PlanRow?): MutableState<String> =
    mutableStateOf((current?.target ?: 20.0).toString())

private fun initialPlanStartDate(current: PlanRow?, today: LocalDate): MutableState<String> =
    mutableStateOf(current?.startDate ?: today.toString())

private fun initialPlanEndDate(current: PlanRow?, today: LocalDate): MutableState<String> =
    mutableStateOf(current?.endDate ?: today.plusMonths(1).toString())

private fun initialPlanWeekdays(current: PlanRow?): MutableState<Set<Int>> =
    mutableStateOf((current?.scheduleWeekdays?.toSet()?.takeIf { it.isNotEmpty() } ?: setOf(0, 1, 2, 3, 4)))

private fun initialPlanCatchUp(current: PlanRow?): MutableState<Int?> =
    mutableStateOf(current?.catchUpWeekday)

private fun initialPlanRangeStartPage(current: PlanRow?): MutableState<Int?> =
    mutableStateOf(current?.rangeStartPage)

private fun initialPlanRangeEndPage(current: PlanRow?): MutableState<Int?> =
    mutableStateOf(current?.rangeEndPage)

private fun initialPlanRangeStartSurah(current: PlanRow?): MutableState<Int?> =
    mutableStateOf(current?.rangeStartSurah)

private fun initialPlanRangeStartAyah(current: PlanRow?): MutableState<Int?> =
    mutableStateOf(current?.rangeStartAyah)

private fun initialPlanRangeEndSurah(current: PlanRow?): MutableState<Int?> =
    mutableStateOf(current?.rangeEndSurah)

private fun initialPlanRangeEndAyah(current: PlanRow?): MutableState<Int?> =
    mutableStateOf(current?.rangeEndAyah)

private fun initialPlanReviewTier(current: PlanRow?): MutableState<String> =
    mutableStateOf(current?.reviewTier ?: "none")

private fun initialPlanNearPages(current: PlanRow?): MutableState<String> =
    mutableStateOf((current?.nearRevisionPages ?: 7.0).toString())

private fun initialPlanFarPages(current: PlanRow?): MutableState<String> =
    mutableStateOf((current?.farRevisionPages ?: 20.0).toString())

private fun initialPlanMinEvaluation(current: PlanRow?): MutableState<String> =
    mutableStateOf(current?.minimumEvaluation ?: "good")

private fun initialPlanDailyCap(current: PlanRow?): MutableState<String> =
    mutableStateOf((current?.maxDailyMultiplier ?: 1.5).toString())

private fun initialPlanMilestone(current: PlanRow?): MutableState<String> =
    mutableStateOf(current?.milestoneMode ?: "juz")

private fun initialPlanDelayDays(current: PlanRow?): MutableState<String> =
    mutableStateOf((current?.delayAlertDays ?: 3).toString())

private fun initialPlanQualityGate(current: PlanRow?): MutableState<Boolean> =
    mutableStateOf(current?.qualityGateEnabled ?: true)

private fun initialPlanAutoExtend(current: PlanRow?): MutableState<Boolean> =
    mutableStateOf(current?.autoExtend ?: true)

private fun initialPlanMilestoneApproval(current: PlanRow?): MutableState<Boolean> =
    mutableStateOf(current?.milestoneRequiresApproval ?: true)

private fun initialPlanHomePrepPush(current: PlanRow?): MutableState<Boolean> =
    mutableStateOf(current?.homePrepPush ?: true)

private fun initialPlanNote(current: PlanRow?): MutableState<String> =
    mutableStateOf(current?.note.orEmpty())

private fun initialPlanRouteDirection(current: PlanRow?): MutableState<String> =
    mutableStateOf(current?.settings?.routeDirection ?: "reverse_surahs_forward_ayahs")

private fun editorPlanSettings(current: PlanRow?): PlanSettingsRow =
    current?.settings ?: PlanSettingsRow()
