package com.mohammedsamir.halaqati.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.mohammedsamir.halaqati.model.Profile
import com.mohammedsamir.halaqati.model.SyncState
import com.mohammedsamir.halaqati.ui.components.EmptyState
import com.mohammedsamir.halaqati.ui.components.LoadingSkeleton
import com.mohammedsamir.halaqati.ui.components.MetricCard
import com.mohammedsamir.halaqati.ui.components.StateNotice
import com.mohammedsamir.halaqati.ui.dashboard.DashboardRules
import com.mohammedsamir.halaqati.ui.dashboard.DashboardViewModel
import com.mohammedsamir.halaqati.ui.theme.HalaqatiUiTokens

@Composable
fun DashboardScreen(
    p: Profile,
    sync: SyncState,
    navigate: (String) -> Unit,
    onSync: () -> Unit,
    vm: DashboardViewModel = viewModel(),
) {
    val state by vm.state.collectAsState()
    LaunchedEffect(p.id, sync) { vm.bind(p, sync) }

    val previewLimit = 4
    val focus = state.notHeard.take(previewLimit)
    val hidden = DashboardRules.hiddenCount(state.notHeard.size, previewLimit)

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(HalaqatiUiTokens.SpaceLg),
        verticalArrangement = Arrangement.spacedBy(HalaqatiUiTokens.SpaceMd),
    ) {
        item {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("مرحبًا، ${p.fullName}", style = MaterialTheme.typography.headlineSmall)
                    Text(
                        "لوحة المتابعة اليومية",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                IconButton(
                    onClick = { vm.refresh(force = true) },
                    enabled = !state.refreshing,
                    modifier = Modifier.size(HalaqatiUiTokens.TouchTarget),
                ) {
                    if (state.refreshing) {
                        CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp)
                    } else {
                        Icon(Icons.Default.Refresh, contentDescription = "تحديث لوحة اليوم")
                    }
                }
                Surface(
                    color = if (sync.online) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.tertiaryContainer,
                    contentColor = if (sync.online) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onTertiaryContainer,
                    shape = MaterialTheme.shapes.extraLarge,
                ) {
                    Row(
                        Modifier.padding(horizontal = 10.dp, vertical = 7.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                    ) {
                        Icon(
                            if (sync.online) Icons.Default.Sync else Icons.Default.CloudOff,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp),
                        )
                        Text(if (sync.online) "متصل" else "أوفلاين", style = MaterialTheme.typography.labelMedium)
                    }
                }
            }
        }

        if (!sync.online) {
            item {
                StateNotice(
                    "البيانات المحفوظة متاحة الآن. أي تسجيل جديد يُحفظ محليًا ويُزامن عند عودة الاتصال.",
                    kind = "warning",
                )
            }
        } else if (sync.blocked > 0) {
            item { StateNotice("هناك ${sync.blocked} عمليات مزامنة تحتاج مراجعة.", "error") }
        }

        state.errors.values.firstOrNull()?.let { message ->
            item { StateNotice("بقيت البيانات السابقة ظاهرة. $message", kind = "warning") }
        }

        item {
            Button(
                onClick = { navigate("session_today") },
                modifier = Modifier.fillMaxWidth().heightIn(min = 52.dp),
            ) {
                Icon(Icons.Default.PlayArrow, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("ابدأ / افتح جلسة اليوم")
            }
        }

        if (!state.loaded) {
            item { LoadingSkeleton(rows = 2) }
        } else {
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Box(Modifier.weight(1f)) {
                        MetricCard(
                            "الطلاب النشطون",
                            state.progress.activeStudents.toString(),
                            onClick = { navigate("students") },
                        )
                    }
                    Box(Modifier.weight(1f)) {
                        MetricCard(
                            "جلسات اليوم",
                            state.todaySessions.toString(),
                            onClick = { navigate("sessions") },
                        )
                    }
                }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Box(Modifier.weight(1f)) {
                        MetricCard(
                            "صفحات اليوم",
                            "%.1f".format(state.progress.recordedPages),
                            onClick = { navigate("reports") },
                        )
                    }
                    Box(Modifier.weight(1f)) {
                        MetricCard(
                            "سمّع اليوم",
                            state.progress.heardStudents.toString(),
                            onClick = { navigate("reports") },
                        )
                    }
                }
            }
        }

        item {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("لم يسمّع اليوم", style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
                if (state.notHeard.isNotEmpty()) {
                    Text(
                        state.notHeard.size.toString(),
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.primary,
                    )
                }
            }
        }
        if (state.loaded && state.notHeard.isEmpty()) {
            item { EmptyState("لا توجد تنبيهات متابعة الآن") }
        }
        items(focus, key = { it.studentId }) { item ->
            ElevatedCard(onClick = { navigate("students") }, modifier = Modifier.fillMaxWidth()) {
                ListItem(
                    headlineContent = { Text(item.studentName, style = MaterialTheme.typography.titleMedium) },
                    supportingContent = { Text(item.reason, style = MaterialTheme.typography.bodyMedium) },
                    trailingContent = { Icon(Icons.Default.ChevronLeft, contentDescription = "فتح الطالب") },
                )
            }
        }
        if (hidden > 0) {
            item {
                OutlinedButton(
                    onClick = { navigate("students") },
                    modifier = Modifier.fillMaxWidth().heightIn(min = HalaqatiUiTokens.TouchTarget),
                ) {
                    Text("عرض $hidden طالبًا آخر")
                }
            }
        }

        item {
            OutlinedButton(
                onClick = { navigate("rankings") },
                modifier = Modifier.fillMaxWidth().heightIn(min = HalaqatiUiTokens.TouchTarget),
            ) { Text("الإحصائيات والترتيب") }
        }
        if (sync.pending > 0) {
            item {
                OutlinedButton(
                    onClick = onSync,
                    modifier = Modifier.fillMaxWidth().heightIn(min = HalaqatiUiTokens.TouchTarget),
                ) { Text("مزامنة ${sync.pending} عملية معلقة") }
            }
        }
        item { Spacer(Modifier.height(8.dp)) }
    }
}
