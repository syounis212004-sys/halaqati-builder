package com.mohammedsamir.halaqati.data

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

enum class ThemeMode { SYSTEM, LIGHT, DARK }
enum class UiDensity { COMFORTABLE, BALANCED, COMPACT }

data class UiPreferences(
    val themeMode: ThemeMode,
    val primaryArgb: Int,
    val accentArgb: Int,
    val density: UiDensity,
) {
    companion object {
        fun defaults() = UiPreferences(
            themeMode = ThemeMode.SYSTEM,
            primaryArgb = 0xFF147A78.toInt(),
            accentArgb = 0xFF0B4F4B.toInt(),
            density = UiDensity.BALANCED,
        )
    }
}

class UiPreferencesStore(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences("halaqati_ui_v1", Context.MODE_PRIVATE)
    private val _state = MutableStateFlow(read())
    val state: StateFlow<UiPreferences> = _state.asStateFlow()

    fun update(transform: (UiPreferences) -> UiPreferences) {
        val next = transform(_state.value)
        prefs.edit()
            .putString("theme_mode", next.themeMode.name)
            .putInt("primary_argb", next.primaryArgb)
            .putInt("accent_argb", next.accentArgb)
            .putString("density", next.density.name)
            .apply()
        _state.value = next
    }

    fun reset() = update { UiPreferences.defaults() }

    private fun read(): UiPreferences {
        val d = UiPreferences.defaults()
        return UiPreferences(
            themeMode = enumValueOrDefault(prefs.getString("theme_mode", null), d.themeMode),
            primaryArgb = prefs.getInt("primary_argb", d.primaryArgb),
            accentArgb = prefs.getInt("accent_argb", d.accentArgb),
            density = enumValueOrDefault(prefs.getString("density", null), d.density),
        )
    }

    private inline fun <reified T : Enum<T>> enumValueOrDefault(raw: String?, fallback: T): T =
        enumValues<T>().firstOrNull { it.name == raw } ?: fallback
}
