@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.mohammedsamir.halaqati.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.mohammedsamir.halaqati.ui.theme.HalaqatiUiTokens

@Composable
fun AppTopBar(
    title: String,
    onBack: (() -> Unit)? = null,
    onRefresh: (() -> Unit)? = null,
    pending: Int = 0,
) {
    CenterAlignedTopAppBar(
        title = { Text(title, fontWeight = FontWeight.Bold) },
        navigationIcon = {
            if (onBack != null) {
                IconButton(onClick = onBack, modifier = Modifier.size(HalaqatiUiTokens.TouchTarget)) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "رجوع")
                }
            }
        },
        actions = {
            if (pending > 0) {
                BadgedBox(badge = { Badge { Text("$pending") } }) {
                    Icon(Icons.Default.CloudUpload, contentDescription = "عمليات معلقة")
                }
            }
            if (onRefresh != null) {
                IconButton(onClick = onRefresh, modifier = Modifier.size(HalaqatiUiTokens.TouchTarget)) {
                    Icon(Icons.Default.Refresh, contentDescription = "تحديث")
                }
            }
        },
    )
}

@Composable
fun MetricCard(
    title: String,
    value: String,
    subtitle: String = "",
    onClick: (() -> Unit)? = null,
) {
    ElevatedCard(
        modifier = Modifier
            .fillMaxWidth()
            .then(if (onClick != null) Modifier.clickable { onClick() } else Modifier),
        shape = MaterialTheme.shapes.medium,
    ) {
        Column(Modifier.padding(14.dp)) {
            Text(
                title,
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.primary,
            )
            Spacer(Modifier.height(6.dp))
            Text(value, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            if (subtitle.isNotBlank()) {
                Text(
                    subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}

@Composable
fun SyncBanner(
    online: Boolean,
    pending: Int,
    blocked: Int = 0,
    error: String? = null,
    onSync: () -> Unit,
    onDetails: (() -> Unit)? = null,
) {
    AnimatedVisibility(
        visible = !online || pending > 0 || blocked > 0 || error != null,
        enter = fadeIn() + expandVertically(),
        exit = fadeOut() + shrinkVertically(),
    ) {
        Surface(
            color = when {
                error != null -> MaterialTheme.colorScheme.errorContainer
                !online -> Color(0xFFFFF3CD)
                else -> MaterialTheme.colorScheme.secondaryContainer
            },
        ) {
            Row(
                Modifier.fillMaxWidth().padding(10.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(
                    when {
                        error != null -> Icons.Default.ErrorOutline
                        online -> Icons.Default.Sync
                        else -> Icons.Default.CloudOff
                    },
                    contentDescription = null,
                )
                Spacer(Modifier.width(8.dp))
                Text(
                    when {
                        error != null -> error
                        blocked > 0 -> "هناك $blocked عمليات تحتاج مراجعة، و$pending بانتظار الرفع"
                        !online && pending > 0 -> "عدم اتصال — تم حفظ $pending تغييرات محليًا وستتم مزامنتها تلقائيًا"
                        !online -> "عدم اتصال — سيتم حفظ أي تغيير محليًا ثم مزامنته عند عودة الإنترنت"
                        else -> "لديك $pending تغييرات بانتظار المزامنة"
                    },
                    Modifier.weight(1f),
                )
                if (onDetails != null && blocked > 0) TextButton(onClick = onDetails) { Text("التفاصيل") }
                if (online && pending > 0) TextButton(onClick = onSync) { Text("مزامنة") }
            }
        }
    }
}

@Composable
fun EmptyState(
    text: String,
    actionLabel: String? = null,
    onAction: (() -> Unit)? = null,
    modifier: Modifier = Modifier,
) {
    Column(
        modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Icon(
            Icons.Default.SearchOff,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.size(36.dp),
        )
        Text(
            text,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            style = MaterialTheme.typography.bodyMedium,
        )
        if (actionLabel != null && onAction != null) {
            OutlinedButton(
                onClick = onAction,
                modifier = Modifier.heightIn(min = HalaqatiUiTokens.TouchTarget),
            ) { Text(actionLabel) }
        }
    }
}


@Composable
fun ProFilterChip(
    selected: Boolean,
    onClick: () -> Unit,
    label: String,
    modifier: Modifier = Modifier,
    leadingIcon: (@Composable (() -> Unit))? = null,
) {
    FilterChip(
        selected = selected,
        onClick = onClick,
        label = { Text(label, style = MaterialTheme.typography.labelLarge) },
        leadingIcon = leadingIcon ?: if (selected) {
            { Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(18.dp)) }
        } else null,
        modifier = modifier.heightIn(min = HalaqatiUiTokens.TouchTarget),
        colors = FilterChipDefaults.filterChipColors(
            selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
            selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer,
            selectedLeadingIconColor = MaterialTheme.colorScheme.primary,
        ),
    )
}

@Composable
fun StatusPill(
    text: String,
    kind: String = "info",
    modifier: Modifier = Modifier,
) {
    val colors = when (kind) {
        "error" -> MaterialTheme.colorScheme.errorContainer to MaterialTheme.colorScheme.onErrorContainer
        "success" -> MaterialTheme.colorScheme.primaryContainer to MaterialTheme.colorScheme.onPrimaryContainer
        "warning" -> MaterialTheme.colorScheme.tertiaryContainer to MaterialTheme.colorScheme.onTertiaryContainer
        else -> MaterialTheme.colorScheme.secondaryContainer to MaterialTheme.colorScheme.onSecondaryContainer
    }
    Surface(modifier = modifier, color = colors.first, contentColor = colors.second, shape = MaterialTheme.shapes.extraLarge) {
        Text(
            text,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp),
            style = MaterialTheme.typography.labelLarge,
        )
    }
}

@Composable
fun LoadingSkeleton(
    rows: Int = 3,
    modifier: Modifier = Modifier,
) {
    Column(modifier, verticalArrangement = Arrangement.spacedBy(10.dp)) {
        repeat(rows) { index ->
            ElevatedCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Box(Modifier.fillMaxWidth(if (index % 2 == 0) .58f else .72f).height(16.dp).background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(8.dp)))
                    Box(Modifier.fillMaxWidth(.9f).height(12.dp).background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = .72f), RoundedCornerShape(8.dp)))
                    Box(Modifier.fillMaxWidth(.68f).height(12.dp).background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = .52f), RoundedCornerShape(8.dp)))
                }
            }
        }
    }
}

@Composable
fun StateNotice(
    text: String,
    kind: String = "info",
    modifier: Modifier = Modifier,
) {
    val colors = when (kind) {
        "error" -> MaterialTheme.colorScheme.errorContainer to MaterialTheme.colorScheme.onErrorContainer
        "success" -> MaterialTheme.colorScheme.primaryContainer to MaterialTheme.colorScheme.onPrimaryContainer
        "warning" -> MaterialTheme.colorScheme.tertiaryContainer to MaterialTheme.colorScheme.onTertiaryContainer
        else -> MaterialTheme.colorScheme.secondaryContainer to MaterialTheme.colorScheme.onSecondaryContainer
    }
    Surface(modifier = modifier.fillMaxWidth(), color = colors.first, shape = MaterialTheme.shapes.medium) {
        Text(text, Modifier.padding(horizontal = 14.dp, vertical = 12.dp), style = MaterialTheme.typography.bodyMedium, color = colors.second)
    }
}
