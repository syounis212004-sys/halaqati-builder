package com.mohammedsamir.halaqati.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.mohammedsamir.halaqati.data.ThemeMode
import com.mohammedsamir.halaqati.data.UiDensity
import com.mohammedsamir.halaqati.data.UiPreferences

object HalaqatiUiTokens {
    val TouchTarget = 48.dp
    val RadiusSmall = 12.dp
    val RadiusMedium = 16.dp
    val RadiusLarge = 22.dp
    val SpaceXs = 4.dp
    val SpaceSm = 8.dp
    val SpaceMd = 12.dp
    val SpaceLg = 16.dp
    val SpaceXl = 24.dp
}

data class HalaqatiSpacing(val xs: Dp, val sm: Dp, val md: Dp, val lg: Dp, val xl: Dp)
val LocalHalaqatiSpacing = staticCompositionLocalOf { HalaqatiSpacing(4.dp, 8.dp, 12.dp, 16.dp, 24.dp) }

private fun spacing(density: UiDensity) = when (density) {
    UiDensity.COMFORTABLE -> HalaqatiSpacing(6.dp, 10.dp, 14.dp, 18.dp, 28.dp)
    UiDensity.BALANCED -> HalaqatiSpacing(4.dp, 8.dp, 12.dp, 16.dp, 24.dp)
    UiDensity.COMPACT -> HalaqatiSpacing(3.dp, 6.dp, 9.dp, 12.dp, 18.dp)
}

private val HalaqatiLight = lightColorScheme(
    primary = Color(0xFF147A78), onPrimary = Color.White,
    primaryContainer = Color(0xFFD2F0ED), onPrimaryContainer = Color(0xFF073F3D),
    secondary = Color(0xFF0B4F4B), onSecondary = Color.White,
    secondaryContainer = Color(0xFFD8E8E5), onSecondaryContainer = Color(0xFF073A37),
    tertiary = Color(0xFFB9954A), onTertiary = Color(0xFF1B1B1B),
    tertiaryContainer = Color(0xFFF4E7C6), onTertiaryContainer = Color(0xFF493715),
    background = Color(0xFFF7F7F5), onBackground = Color(0xFF18201E),
    surface = Color(0xFFFFFBFE), onSurface = Color(0xFF18201E),
    surfaceVariant = Color(0xFFE7EFEC), onSurfaceVariant = Color(0xFF374744),
    outline = Color(0xFF657572), error = Color(0xFFB3261E),
)
private val HalaqatiDark = darkColorScheme(
    primary = Color(0xFF7ED6D1), onPrimary = Color(0xFF003735),
    primaryContainer = Color(0xFF0D5754), onPrimaryContainer = Color(0xFFB7F0EC),
    secondary = Color(0xFF8BCFC8), onSecondary = Color(0xFF053A37),
    secondaryContainer = Color(0xFF1E4744), onSecondaryContainer = Color(0xFFD8E8E5),
    tertiary = Color(0xFFD8BA73), onTertiary = Color(0xFF3D2F10),
    tertiaryContainer = Color(0xFF5A4720), onTertiaryContainer = Color(0xFFF4E7C6),
    background = Color(0xFF101715), onBackground = Color(0xFFE7ECE9),
    surface = Color(0xFF151E1B), onSurface = Color(0xFFE7ECE9),
    surfaceVariant = Color(0xFF25332F), onSurfaceVariant = Color(0xFFC7D2CE),
    outline = Color(0xFF8A9B96), error = Color(0xFFFFB4AB),
)
private val HalaqatiShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp), small = RoundedCornerShape(HalaqatiUiTokens.RadiusSmall),
    medium = RoundedCornerShape(HalaqatiUiTokens.RadiusMedium), large = RoundedCornerShape(HalaqatiUiTokens.RadiusLarge),
    extraLarge = RoundedCornerShape(24.dp),
)
private fun readableOn(color: Color) = if (color.luminance() > .45f) Color(0xFF10201F) else Color.White

@Composable
fun HalaqatiTheme(preferences: UiPreferences = UiPreferences.defaults(), content: @Composable () -> Unit) {
    val dark = when (preferences.themeMode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.DARK -> true
        ThemeMode.LIGHT -> false
    }
    val primary = Color(preferences.primaryArgb)
    val accent = Color(preferences.accentArgb)
    val base = if (dark) HalaqatiDark else HalaqatiLight
    val scheme = base.copy(primary = primary, onPrimary = readableOn(primary), secondary = accent, onSecondary = readableOn(accent))
    CompositionLocalProvider(
        LocalLayoutDirection provides LayoutDirection.Rtl,
        LocalHalaqatiSpacing provides spacing(preferences.density),
    ) {
        MaterialTheme(colorScheme = scheme, typography = cairoTypography(), shapes = HalaqatiShapes, content = content)
    }
}
