package com.mohammedsamir.halaqati.ui.navigation
import com.mohammedsamir.halaqati.model.UserRole

data class MoreSection(val title: String, val items: List<AppDestination>)

object RoleNavigationPolicy {
    private val admin=listOf(AppDestination.Home,AppDestination.Notifications,AppDestination.Halaqas,AppDestination.Community,AppDestination.Sessions,AppDestination.SessionToday,AppDestination.Students,AppDestination.Plans,AppDestination.Certificates,AppDestination.Reports,AppDestination.Quran,AppDestination.Rankings,AppDestination.ImportExport,AppDestination.SyncCenter,AppDestination.Supervision,AppDestination.Users,AppDestination.Settings)
    private val supervisor=admin.filterNot { it==AppDestination.Users }
    private val teacher=supervisor.filterNot { it==AppDestination.Supervision }
    private val guardian=listOf(AppDestination.Home,AppDestination.Notifications,AppDestination.Community,AppDestination.Plans,AppDestination.Reports,AppDestination.GuardianCompetition,AppDestination.GuardianAchievements,AppDestination.GuardianProfile,AppDestination.SyncCenter,AppDestination.Settings)
    private val limited=listOf(AppDestination.Home,AppDestination.GuardianProfile,AppDestination.Settings)
    fun destinations(role:UserRole)=when(role){ UserRole.ADMIN->admin; UserRole.SUPERVISOR->supervisor; UserRole.TEACHER->teacher; UserRole.GUARDIAN->guardian; else->limited }
    fun bottom(role:UserRole)=if(role==UserRole.GUARDIAN) listOf(AppDestination.Home,AppDestination.Reports,AppDestination.Plans,AppDestination.GuardianProfile,AppDestination.More) else listOf(AppDestination.Home,AppDestination.Sessions,AppDestination.Students,AppDestination.Plans,AppDestination.More)
    fun moreSections(role:UserRole):List<MoreSection>{
        val allowed=destinations(role).toSet()
        fun sec(title:String,vararg c:AppDestination):MoreSection?{ val v=c.filter{it in allowed && it !in bottom(role)}; return v.takeIf{it.isNotEmpty()}?.let{MoreSection(title,it)} }
        return listOfNotNull(
            sec("إدارة الحلقة",AppDestination.Halaqas),
            sec("المتابعة والإنجاز",AppDestination.GuardianCompetition,AppDestination.GuardianAchievements,AppDestination.Rankings,AppDestination.Supervision,AppDestination.Certificates),
            sec("التقارير والأدوات",AppDestination.Reports,AppDestination.Quran,AppDestination.ImportExport),
            sec("التواصل",AppDestination.Notifications,AppDestination.Community),
            sec("الإدارة والصلاحيات",AppDestination.Users),
            sec("النظام",AppDestination.SyncCenter,AppDestination.Settings),
        )
    }
    fun canOpen(role:UserRole,destination:AppDestination)=destination in destinations(role)
}
