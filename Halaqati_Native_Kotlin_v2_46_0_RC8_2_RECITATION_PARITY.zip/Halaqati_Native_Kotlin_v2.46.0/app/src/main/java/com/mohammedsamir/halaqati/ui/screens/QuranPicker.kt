@file:OptIn(
    androidx.compose.material3.ExperimentalMaterial3Api::class,
    androidx.compose.foundation.layout.ExperimentalLayoutApi::class,
)

package com.mohammedsamir.halaqati.ui.screens

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.mohammedsamir.halaqati.quran.QuranCore
import com.mohammedsamir.halaqati.quran.QuranLocation
import com.mohammedsamir.halaqati.quran.QuranMetadata
import com.mohammedsamir.halaqati.quran.QuranRangeRequest
import com.mohammedsamir.halaqati.quran.QuranRangeResult
import com.mohammedsamir.halaqati.quran.QuranResolvedTraversal
import com.mohammedsamir.halaqati.quran.QuranSelection
import com.mohammedsamir.halaqati.quran.QuranTraversalDirection
import com.mohammedsamir.halaqati.ui.components.ProFilterChip
import java.util.Locale

private fun quranPagesLabel(value: Double): String {
    val raw = String.format(Locale.US, "%.2f", value)
    return raw.trimEnd('0').trimEnd('.').ifBlank { "0" }
}

private fun traversalLabel(value: QuranResolvedTraversal): String = when (value) {
    QuranResolvedTraversal.REVERSE_SURAH_ORDER -> "السور: من الأعلى رقمًا إلى الأقل · الآيات داخل السورة تصاعدية"
    QuranResolvedTraversal.REVERSE_WITHIN_SURAH -> "الآيات محفوظة بالاتجاه الذي أُدخل"
    QuranResolvedTraversal.PAGE_ORDER_REVERSE -> "ترتيب الصفحات تنازلي محفوظ"
    QuranResolvedTraversal.PAGE_ORDER_FORWARD -> "ترتيب الصفحات تصاعدي"
    QuranResolvedTraversal.EXPLICIT_SEGMENTS -> "مقاطع مختارة وفق النشاط والمسار"
    QuranResolvedTraversal.FORWARD_QURAN -> "ترتيب المصحف تصاعدي"
}

private fun surahsForJuz(juz: Int): List<Int> {
    val from = QuranMetadata.juzStart(juz).surah
    val to = QuranMetadata.juzEnd(juz).surah
    return (from..to).toList()
}

private fun pageEndpointText(page: Int): String {
    val start = QuranMetadata.pageStart(page)
    val end = QuranMetadata.pageEnd(page)
    return if (start.surah == end.surah) {
        "ص $page · ${QuranMetadata.surahName(start.surah)} ${start.ayah}→${end.ayah}"
    } else {
        "ص $page · ${start.label} → ${end.label}"
    }
}

@Composable
private fun PickerTab(selected: Boolean, label: String, onClick: () -> Unit, modifier: Modifier = Modifier) {
    if (selected) {
        Button(onClick = onClick, modifier = modifier.heightIn(min = 52.dp)) { Text(label, fontWeight = FontWeight.Bold) }
    } else {
        OutlinedButton(onClick = onClick, modifier = modifier.heightIn(min = 52.dp)) { Text(label) }
    }
}

@Composable
private fun QuranResultCard(range: QuranRangeResult) {
    ElevatedCard(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Text("📖 ${range.displayLabel}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Text("📄 ${quranPagesLabel(range.exactPages)} صفحة")
            Text("🔢 ${range.ayahCount} آية · ${range.surahCount} سورة")
            Text("↕ ${traversalLabel(range.resolvedTraversal)}", style = MaterialTheme.typography.bodySmall)
            Text("QCF4 · مصحف المدينة 604 صفحة · 15 سطرًا", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

/**
 * RC8.2 Quran picker — Compose port of the v2.44 recitation selector.
 * Four modes are kept deliberately: surah/ayah, full pages, arbitrary surahs and arbitrary juz.
 * All calculations still go through QuranRangeEngine; UI never calculates fractions itself.
 */
@Composable
fun QuranRangePickerDialog(
    initialStartPage: Int? = null,
    initialEndPage: Int? = null,
    track: String,
    activityType: String,
    direction: QuranTraversalDirection = QuranTraversalDirection.AUTO_BY_ACTIVITY,
    onDismiss: () -> Unit,
    onConfirm: (QuranRangeResult) -> Unit,
) {
    var mode by remember { mutableStateOf(if (initialStartPage != null || initialEndPage != null) "pages" else "ayahs") }
    var selectedJuzFilter by remember { mutableIntStateOf(30) }
    var ayahSurah by remember { mutableIntStateOf(surahsForJuz(30).firstOrNull() ?: 78) }
    var ayahRange by remember { mutableStateOf(1f..QuranMetadata.maxAyah(ayahSurah).toFloat()) }
    var startPageText by remember(initialStartPage) { mutableStateOf((initialStartPage ?: 1).toString()) }
    var endPageText by remember(initialEndPage) { mutableStateOf((initialEndPage ?: initialStartPage ?: 1).toString()) }
    val selectedSurahs = remember { mutableStateListOf<Int>() }
    val selectedJuz = remember { mutableStateListOf<Int>() }

    val maxAyah = QuranMetadata.maxAyah(ayahSurah)
    LaunchedEffect(ayahSurah) {
        ayahRange = 1f..QuranMetadata.maxAyah(ayahSurah).toFloat()
    }

    val selection = remember(mode, ayahSurah, ayahRange, startPageText, endPageText, selectedSurahs.toList(), selectedJuz.toList()) {
        when (mode) {
            "pages" -> {
                val start = startPageText.toIntOrNull()
                val end = endPageText.toIntOrNull()
                if (start != null && end != null && start in 1..604 && end in 1..604) QuranSelection.Pages(start, end) else null
            }
            "surahs" -> selectedSurahs.takeIf { it.isNotEmpty() }?.let { QuranSelection.Surahs(it.toList()) }
            "juz" -> selectedJuz.takeIf { it.isNotEmpty() }?.let { QuranSelection.Juz(it.toList()) }
            else -> {
                val start = ayahRange.start.toInt().coerceIn(1, maxAyah)
                val end = ayahRange.endInclusive.toInt().coerceIn(start, maxAyah)
                QuranSelection.Ayahs(QuranLocation(ayahSurah, start), QuranLocation(ayahSurah, end))
            }
        }
    }
    val attempt = remember(selection, track, activityType, direction) {
        runCatching {
            selection?.let {
                QuranCore.engine().calculate(QuranRangeRequest(track, activityType, it, direction))
            }
        }
    }
    val range = attempt.getOrNull()
    val rangeError = attempt.exceptionOrNull()?.message

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("اختيار المقرر من المصحف", fontWeight = FontWeight.Bold) },
        text = {
            Column(
                Modifier.fillMaxWidth().heightIn(max = 640.dp).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    PickerTab(mode == "ayahs", "السورة\nوالآية", { mode = "ayahs" }, Modifier.weight(1f))
                    PickerTab(mode == "pages", "الصفحات", { mode = "pages" }, Modifier.weight(1f))
                    PickerTab(mode == "surahs", "سور\nمتعددة", { mode = "surahs" }, Modifier.weight(1f))
                    PickerTab(mode == "juz", "الأجزاء", { mode = "juz" }, Modifier.weight(1f))
                }

                when (mode) {
                    "pages" -> {
                        Text("اختر صفحات كاملة. وللبداية أو النهاية من وسط الصفحة استخدم «السورة والآية».", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        OutlinedTextField(
                            value = startPageText,
                            onValueChange = { startPageText = it.filter(Char::isDigit).take(3) },
                            label = { Text("من صفحة") },
                            modifier = Modifier.fillMaxWidth(), singleLine = true,
                        )
                        startPageText.toIntOrNull()?.takeIf { it in 1..604 }?.let { Text(pageEndpointText(it), style = MaterialTheme.typography.bodySmall) }
                        OutlinedTextField(
                            value = endPageText,
                            onValueChange = { endPageText = it.filter(Char::isDigit).take(3) },
                            label = { Text("إلى صفحة") },
                            modifier = Modifier.fillMaxWidth(), singleLine = true,
                        )
                        endPageText.toIntOrNull()?.takeIf { it in 1..604 }?.let { Text(pageEndpointText(it), style = MaterialTheme.typography.bodySmall) }
                    }
                    "surahs" -> {
                        Text("يمكن اختيار سور غير متجاورة؛ اضغط السورة لإضافتها أو إزالتها.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        FlowRow(Modifier.fillMaxWidth(), maxItemsInEachRow = 2, horizontalArrangement = Arrangement.spacedBy(7.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                            (1..114).forEach { s ->
                                val selected = s in selectedSurahs
                                ProFilterChip(
                                    selected = selected,
                                    onClick = { if (selected) selectedSurahs.remove(s) else selectedSurahs.add(s) },
                                    label = "$s. ${QuranMetadata.surahName(s)}",
                                    modifier = Modifier.widthIn(min = 150.dp),
                                )
                            }
                        }
                        Text(if (selectedSurahs.isEmpty()) "لم يتم اختيار سور." else "المحدد: ${selectedSurahs.joinToString { QuranMetadata.surahName(it) }} · ${selectedSurahs.size} سورة")
                    }
                    "juz" -> {
                        Text("اختر جزءًا أو أكثر؛ يمكن اختيار أجزاء غير متجاورة.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        FlowRow(Modifier.fillMaxWidth(), maxItemsInEachRow = 5, horizontalArrangement = Arrangement.spacedBy(7.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                            (1..30).forEach { j ->
                                val selected = j in selectedJuz
                                ProFilterChip(
                                    selected = selected,
                                    onClick = { if (selected) selectedJuz.remove(j) else selectedJuz.add(j) },
                                    label = j.toString(),
                                    modifier = Modifier.widthIn(min = 56.dp),
                                )
                            }
                        }
                        Text(if (selectedJuz.isEmpty()) "لم يتم اختيار أجزاء." else "الأجزاء المحددة: ${selectedJuz.joinToString()} · ${selectedJuz.size} جزء")
                    }
                    else -> {
                        Text("الجزء", fontWeight = FontWeight.Bold)
                        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                            (1..30).forEach { j ->
                                ProFilterChip(selectedJuzFilter == j, {
                                    selectedJuzFilter = j
                                    ayahSurah = surahsForJuz(j).firstOrNull() ?: ayahSurah
                                }, j.toString())
                            }
                        }
                        Text("اختر الجزء لفلترة السور. إذا كانت السورة موزعة على جزئين فستظهر في كليهما.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text("السورة", fontWeight = FontWeight.Bold)
                        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                            surahsForJuz(selectedJuzFilter).forEach { s ->
                                ProFilterChip(ayahSurah == s, { ayahSurah = s }, "$s. ${QuranMetadata.surahName(s)}")
                            }
                        }
                        Text("الآيات", fontWeight = FontWeight.Bold)
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = ayahRange.start.toInt().toString(),
                                onValueChange = { text ->
                                    val v = text.filter(Char::isDigit).toIntOrNull()?.coerceIn(1, ayahRange.endInclusive.toInt()) ?: return@OutlinedTextField
                                    ayahRange = v.toFloat()..ayahRange.endInclusive
                                },
                                label = { Text("من آية") }, modifier = Modifier.weight(1f), singleLine = true,
                            )
                            OutlinedTextField(
                                value = ayahRange.endInclusive.toInt().toString(),
                                onValueChange = { text ->
                                    val v = text.filter(Char::isDigit).toIntOrNull()?.coerceIn(ayahRange.start.toInt(), maxAyah) ?: return@OutlinedTextField
                                    ayahRange = ayahRange.start..v.toFloat()
                                },
                                label = { Text("إلى آية") }, modifier = Modifier.weight(1f), singleLine = true,
                            )
                        }
                        RangeSlider(
                            value = ayahRange,
                            onValueChange = { r ->
                                val a = r.start.toInt().coerceIn(1, maxAyah)
                                val b = r.endInclusive.toInt().coerceIn(a, maxAyah)
                                ayahRange = a.toFloat()..b.toFloat()
                            },
                            valueRange = 1f..maxAyah.toFloat(),
                            steps = (maxAyah - 2).coerceAtLeast(0),
                        )
                        Text("${QuranMetadata.surahName(ayahSurah)}: من آية ${ayahRange.start.toInt()} إلى آية ${ayahRange.endInclusive.toInt()}")
                    }
                }

                HorizontalDivider()
                range?.let { QuranResultCard(it) } ?: Text(rangeError ?: "اختر نطاقًا صالحًا لحساب المقدار", color = if (rangeError != null) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant)
            }
        },
        confirmButton = {
            Button(onClick = { range?.let(onConfirm) }, enabled = range != null) { Text("اعتماد الاختيار") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } },
    )
}
