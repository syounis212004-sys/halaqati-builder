package com.mohammedsamir.halaqati.quran

/**
 * Small pure rules shared by RC8.2 recitation cards, rankings and Smart Plan context.
 * They mirror the v2.44 behaviour: QCF4 line keys are authoritative, and rankings
 * never mix program tracks or activity tracks.
 */
object RecitationParityRules {
    private val reviewActivities = setOf("review_near", "review_far", "review")

    fun effectivePages(storedPages: Double, qcfLineKeys: List<String>): Double =
        if (qcfLineKeys.isNotEmpty()) qcfLineKeys.distinct().size.toDouble() / 15.0
        else storedPages.coerceAtLeast(0.0)

    fun rankingTrackForActivity(activityType: String): String = when (activityType) {
        "new_hifz", "hifz" -> "hifz"
        in reviewActivities -> "review"
        "sard" -> "sard"
        else -> "other"
    }

    fun activityMatchesRanking(activityType: String, rankingTrack: String): Boolean =
        rankingTrackForActivity(activityType) == rankingTrack

    fun canonicalProgramTrack(track: String?): String =
        if (track == "tathbit") "tathbit" else "general_hifz"

    fun quranRangeLabel(
        startSurah: Int?,
        startAyah: Int?,
        endSurah: Int?,
        endAyah: Int?,
        startPage: Int?,
        endPage: Int?,
    ): String {
        if (startSurah != null && startAyah != null && endSurah != null && endAyah != null) {
            return if (startSurah == endSurah) {
                "${QuranMetadata.surahName(startSurah)} $startAyah→$endAyah"
            } else {
                "${QuranMetadata.surahName(startSurah)} $startAyah → ${QuranMetadata.surahName(endSurah)} $endAyah"
            }
        }
        return when {
            startPage != null && endPage != null && startPage == endPage -> "ص $startPage"
            startPage != null && endPage != null -> "ص $startPage→$endPage"
            startPage != null -> "من ص $startPage"
            endPage != null -> "إلى ص $endPage"
            else -> "نطاق محفوظ"
        }
    }
}
