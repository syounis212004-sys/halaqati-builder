import com.mohammedsamir.halaqati.quran.RecitationParityRules

fun main() {
    check(RecitationParityRules.effectivePages(79.41, listOf("506:1", "506:2", "506:3", "506:4", "506:5", "506:6", "506:7", "506:8")) == 8.0 / 15.0)
    check(RecitationParityRules.rankingTrackForActivity("new_hifz") == "hifz")
    check(RecitationParityRules.rankingTrackForActivity("review_far") == "review")
    check(RecitationParityRules.rankingTrackForActivity("sard") == "sard")
    check(!RecitationParityRules.activityMatchesRanking("sard", "hifz"))
    check(RecitationParityRules.canonicalProgramTrack("tathbit") == "tathbit")
    check(RecitationParityRules.canonicalProgramTrack(null) == "general_hifz")
    check(RecitationParityRules.quranRangeLabel(78, 1, 78, 40, 582, 583) == "النبأ 1→40")
    check(RecitationParityRules.quranRangeLabel(42, 27, 43, 18, 486, 491) == "الشورى 27 → الزخرف 18")
    check(RecitationParityRules.quranRangeLabel(null, null, null, null, 504, 505) == "ص 504→505")
    println("RecitationParityRulesSelfTest PASS")
}
