package com.mohammedsamir.halaqati.data

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Build
import androidx.work.Constraints
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import com.mohammedsamir.halaqati.BuildConfig
import com.mohammedsamir.halaqati.model.*
import com.mohammedsamir.halaqati.plans.SmartPlanEngine
import com.mohammedsamir.halaqati.plans.SmartPlanCoreStateEngine
import com.mohammedsamir.halaqati.plans.SmartPlanActivityRules
import com.mohammedsamir.halaqati.plans.SmartPlanPhaseEngine
import com.mohammedsamir.halaqati.quran.QuranCore
import com.mohammedsamir.halaqati.quran.QuranLocation
import com.mohammedsamir.halaqati.quran.QuranMetadata
import com.mohammedsamir.halaqati.quran.QuranRangeRequest
import com.mohammedsamir.halaqati.quran.QuranSelection
import com.mohammedsamir.halaqati.quran.QuranTraversalDirection
import com.mohammedsamir.halaqati.ui.sessions.SessionWorkflowRules
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.time.Duration
import java.time.LocalDate
import java.time.YearMonth
import java.time.ZoneId
import java.time.ZonedDateTime
import java.util.UUID
import kotlin.math.ceil
import kotlin.math.min

data class PlanWeekRequirement(
    val amount: Double,
    val startPage: Int?,
    val endPage: Int?,
)

data class PlanNextDuty(
    val date: LocalDate,
    val assignment: SmartPlanEngine.Assignment,
)

data class PlanActivitySnapshot(
    val key: String,
    val label: String,
    val scheduledToday: Boolean = false,
    val lastRecitation: SmartPlanEngine.Recitation? = null,
    val assignment: SmartPlanEngine.Assignment? = null,
    val nextDuty: PlanNextDuty? = null,
    val needsStart: Boolean = false,
    val targetPages: Double = 0.0,
    val routeDirection: String = "forward_surahs_forward_ayahs",
)

data class PlanSnapshot(
    val plan: PlanRow,
    val student: Student,
    val progress: SmartPlanEngine.Progress,
    val phase: SmartPlanPhaseRow? = null,
    val phaseState: SmartPlanPhaseStateRow? = null,
    val phaseProgress: SmartPlanPhaseEngine.Progress? = null,
    val lastRecitation: SmartPlanEngine.Recitation? = null,
    val weekRequirement: PlanWeekRequirement? = null,
    val nextDuty: PlanNextDuty? = null,
    val activities: List<PlanActivitySnapshot> = emptyList(),
    val coreState: SmartPlanCoreStateEngine.State,
)

private const val CACHE_STUDENTS = "students"
private const val CACHE_SESSIONS = "sessions"
private const val CACHE_PLANS = "plans"
private const val CACHE_DASHBOARD_RECITATIONS = "dashboard:recitations"
private const val CACHE_PLAN_RECITATIONS = "plans:recitations"
private const val CACHE_SESSION_RECITATIONS_PREFIX = "session:recitations:"
private const val CACHE_SESSION_ATTENDANCE_PREFIX = "session:attendance:"
private const val CACHE_SESSION_NOTES_PREFIX = "session:notes:"
private const val CACHE_PRIMARY_HALAQA = "meta:primary_halaqa"
private const val CACHE_PROFILE = "profile:self"
private const val CACHE_PLAN_EVENTS = "plans:events"
private const val CACHE_PLAN_PHASES = "plans:phases"
private const val CACHE_PLAN_PHASE_STATES = "plans:phase-states"
private const val CACHE_PLAN_PHASE_TEMPLATES = "plans:phase-templates"
private const val CACHE_RANKING_PREFIX = "ranking:"
private const val CACHE_RANKING_SOURCE = "ranking:source"
private const val CACHE_GUARDIAN_DASHBOARD_PREFIX = "guardian:dashboard:"
private const val CACHE_GUARDIAN_COMPETITION_PREFIX = "guardian:competition:"
private const val CACHE_REPORT_RECITATIONS_PREFIX = "reports:recitations:"
private const val CACHE_REPORT_SUMMARY_PREFIX = "reports:summary:"
private const val CACHE_ACCOUNTS = "accounts:profiles"
private const val CACHE_GUARDIAN_ACCOUNTS = "accounts:guardians"

class HalaqatiRepository(
    private val context: Context,
    val api: SupabaseApi,
    val store: SecureSessionStore,
    val queue: OfflineQueue,
    val cache: LocalCache,
    private val offlineDb: HalaqatiOfflineDatabase,
) {
    @Volatile private var planSnapshotMemoryDate: LocalDate? = null
    @Volatile private var planSnapshotMemory: List<PlanSnapshot> = emptyList()
    private val pushLock = Any()
    private val _localMutationEpoch = MutableStateFlow(0L)
    val localMutationEpoch = _localMutationEpoch.asStateFlow()

    private fun signalLocalMutation() {
        _localMutationEpoch.value = _localMutationEpoch.value + 1L
    }

    fun loggedIn() = store.load() != null

    fun signOut() = store.clear()

    fun authCallbackType(url: String): String = api.callbackType(url)

    fun updatePassword(newPassword: String) = api.updatePassword(newPassword)

    fun updateMyFullName(fullName: String) {
        val name = fullName.trim()
        require(name.length >= 3) { "الاسم الكامل قصير" }
        val userId = store.load()?.userId ?: error("لا توجد جلسة مستخدم")
        patch(
            "profiles",
            "id=eq.$userId",
            JSONObject().put("full_name", name),
            dedupe = "profile-name:$userId",
        )
    }

    fun online(): Boolean {
        val cm = context.getSystemService(ConnectivityManager::class.java)
        val network = cm.activeNetwork ?: return false
        val caps = cm.getNetworkCapabilities(network) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
            caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
    }

    fun login(email: String, password: String) = api.signIn(email, password)

    fun register(email: String, password: String, name: String, phone: String, role: String) =
        api.signUp(email, password, name, phone, role)

    fun googleOAuthUrl(): String = api.googleOAuthUrl()

    fun loginWithGoogleIdToken(idToken: String, rawNonce: String) = api.signInWithGoogleIdToken(idToken, rawNonce)

    fun acceptOAuthCallback(url: String): UserSession? = api.acceptOAuthCallback(url)

    fun requestPasswordReset(email: String) = api.requestPasswordReset(email)

    fun registerPushToken(token: String) {
        if (store.load()?.userId.isNullOrBlank() || token.isBlank()) return
        if (!online()) return
        api.function(
            "halaqati-notify",
            JSONObject()
                .put("action", "register_device")
                .put("push_token", token)
                .put("platform", "android")
                .put("device_name", "${Build.MANUFACTURER} ${Build.MODEL}".trim())
                .put("app_version", BuildConfig.VERSION_NAME),
        )
        store.savePushToken(token)
    }

    /**
     * Disable the current device on the notification service while the old user session is
     * still valid. The local token is cleared even when the network call fails; the ViewModel
     * also asks Firebase to rotate/delete the FCM token so a later account cannot inherit it.
     */
    fun unregisterPushDevice() {
        val token = store.loadPushToken() ?: return
        try {
            if (loggedIn() && online()) {
                api.function(
                    "halaqati-notify",
                    JSONObject()
                        .put("action", "unregister_device")
                        .put("push_token", token),
                )
            }
        } finally {
            store.clearPushToken()
        }
    }

    fun testPush(): JSONObject = JSONObject(
        api.function(
            "halaqati-notify",
            JSONObject().put("action", "test_push"),
        ),
    )

    fun sendStudentEvent(
        studentId: String,
        sourceKey: String,
        title: String,
        body: String,
        data: JSONObject = JSONObject(),
    ): JSONObject = JSONObject(
        api.function(
            "halaqati-notify",
            JSONObject()
                .put("action", "event_student")
                .put("kind", "system")
                .put("student_id", studentId)
                .put("source_key", sourceKey)
                .put("title", title)
                .put("body", body)
                .put("deep_link", "student:$studentId")
                .put("data", data),
        ),
    )

    /**
     * Native equivalent of the legacy checkSmartPlanAlerts() loop.
     * Server source_key de-duplication makes the periodic worker safe to run more than once.
     */
    fun runSmartPlanAlerts(now: ZonedDateTime = ZonedDateTime.now(ZoneId.of("Asia/Gaza"))): Int {
        if (!loggedIn() || !online()) return 0
        val profile = profileWithRefresh()
        if (profile.role !in setOf(UserRole.ADMIN, UserRole.SUPERVISOR, UserRole.TEACHER)) return 0

        val today = now.toLocalDate()
        var delivered = 0
        val todaySnapshots = planSnapshots(today)
        todaySnapshots.forEach { snapshot ->
            if (!SmartPlanAlertRules.shouldSendDelay(snapshot.progress.consecutiveMissed, snapshot.plan.delayAlertDays)) {
                return@forEach
            }
            val progress = snapshot.progress
            runCatching {
                sendStudentEvent(
                    studentId = snapshot.student.id,
                    sourceKey = "smart-plan-delay:${snapshot.plan.id}:${snapshot.student.id}:$today",
                    title = "تنبيه الخطة · ${snapshot.student.fullName}",
                    body = "الخطة متأخرة ${progress.consecutiveMissed} أيام دوام. المتبقي ${progress.remaining} صفحة، والحالة ${progress.healthLabel}.",
                    data = JSONObject()
                        .put("smart_plan_id", snapshot.plan.id)
                        .put("health", progress.health)
                        .put("missed_days", progress.consecutiveMissed),
                )
            }.onSuccess { delivered++ }
        }

        // RC11 phase notifications. All source keys are deterministic; the server's
        // source_key de-duplication makes this safe across worker reruns and sync retries.
        val phaseRows = planPhases()
        val phaseById = phaseRows.associateBy { it.id }
        planPhaseStates().forEach { state ->
            val phase = phaseById[state.phaseId] ?: return@forEach
            val planId = phase.planId
            when {
                phase.phaseType == "hifz" && state.status == "completed" -> runCatching {
                    val completed = state.frozenCompletedPages ?: 0.0
                    val target = state.frozenTargetPages
                    val percent = state.completionPercent ?: target?.takeIf { it > .001 }?.let { SmartPlanEngine.round(completed / it * 100.0, 1) }
                    sendStudentEvent(
                        studentId = state.studentId,
                        sourceKey = "smart-plan-phase-completed:$planId:${phase.id}:${state.studentId}",
                        title = "تم إنهاء مرحلة الحفظ",
                        body = buildString {
                            append("أُغلقت مرحلة الحفظ بإنجاز ${SmartPlanEngine.round(completed)} صفحة")
                            target?.let { append(" من ${SmartPlanEngine.round(it)}") }
                            percent?.let { append(" بنسبة ${SmartPlanEngine.round(it, 1)}%") }
                            append(".")
                        },
                        data = JSONObject().put("smart_plan_id", planId).put("phase_id", phase.id).put("phase_type", "hifz"),
                    )
                }.onSuccess { delivered++ }

                phase.phaseType == "sard" && state.status == "active" -> runCatching {
                    val goalText = when (phase.goalMode) {
                        "juz" -> "الهدف: ${phase.targetUnits ?: ((phase.targetPages ?: 0.0) / 20.0)} جزء."
                        "open" -> "الهدف: سرد مفتوح خلال الفترة."
                        else -> phase.targetPages?.let { "الهدف: ${SmartPlanEngine.round(it)} صفحة." } ?: ""
                    }
                    sendStudentEvent(
                        studentId = state.studentId,
                        sourceKey = "smart-plan-phase-started:$planId:${phase.id}:${state.studentId}",
                        title = "بدأت مرحلة السرد",
                        body = "مرحلة السرد من ${phase.startDate} إلى ${phase.endDate}. $goalText",
                        data = JSONObject().put("smart_plan_id", planId).put("phase_id", phase.id).put("phase_type", "sard"),
                    )
                }.onSuccess { delivered++ }

                phase.phaseType == "sard" && state.status == "completed" -> runCatching {
                    val percent = state.completionPercent
                    sendStudentEvent(
                        studentId = state.studentId,
                        sourceKey = "smart-plan-phase-completed:$planId:${phase.id}:${state.studentId}",
                        title = "اكتملت مرحلة السرد",
                        body = if (percent != null) "أُغلقت مرحلة السرد بنسبة ${SmartPlanEngine.round(percent, 1)}%." else "أُغلقت مرحلة السرد بنجاح.",
                        data = JSONObject().put("smart_plan_id", planId).put("phase_id", phase.id).put("phase_type", "sard"),
                    )
                }.onSuccess { delivered++ }
            }
        }
        todaySnapshots.forEach { snapshot ->
            val phase = snapshot.phase ?: return@forEach
            val last = snapshot.lastRecitation ?: return@forEach
            if (phase.phaseType != "sard" || last.date != today) return@forEach
            runCatching {
                val total = snapshot.phaseProgress?.completedPages ?: snapshot.progress.completed
                sendStudentEvent(
                    studentId = snapshot.student.id,
                    sourceKey = "smart-plan-sard-daily:${phase.id}:${last.id}",
                    title = "إنجاز السرد اليوم · ${snapshot.student.fullName}",
                    body = "سرد اليوم ${SmartPlanEngine.round(last.pagesCount)} صفحة. إجمالي المرحلة ${SmartPlanEngine.round(total)} صفحة.",
                    data = JSONObject().put("smart_plan_id", snapshot.plan.id).put("phase_id", phase.id).put("recitation_id", last.id),
                )
            }.onSuccess { delivered++ }
        }

        if (now.hour >= 17) {
            val tomorrow = today.plusDays(1)
            planSnapshots(tomorrow)
                .groupBy { it.student.id }
                .values
                .forEach { candidates ->
                    val student = candidates.firstOrNull()?.student ?: return@forEach
                    val preferred = SmartPlanAlertRules.preferredPlanType(student.track)
                    val next = candidates.firstOrNull { it.plan.type == preferred } ?: candidates.firstOrNull() ?: return@forEach
                    val assignment = next.progress.assignment
                    if (!SmartPlanAlertRules.shouldSendHomePrep(now.hour, next.plan.homePrepPush, assignment.startPage)) {
                        return@forEach
                    }
                    runCatching {
                        sendStudentEvent(
                            studentId = student.id,
                            sourceKey = "smart-plan-prep:${next.plan.id}:${student.id}:$tomorrow",
                            title = "تحضير الغد · ${student.fullName}",
                            body = "مطلوب غداً ${SmartPlanAlertRules.assignmentLabel(assignment.kind, assignment.startPage, assignment.endPage)}.",
                            data = JSONObject()
                                .put("smart_plan_id", next.plan.id)
                                .put("plan_date", tomorrow.toString())
                                .put("start_page", assignment.startPage)
                                .put("end_page", assignment.endPage),
                        )
                    }.onSuccess { delivered++ }
                }
        }
        return delivered
    }

    private fun profileFromJson(json: JSONObject, session: UserSession): Profile = Profile(
        id = json.optString("id").ifBlank { session.userId },
        fullName = json.optString("full_name").ifBlank { session.email },
        role = UserRole.from(json.optString("role")),
        approvalStatus = json.optString("approval_status", "pending"),
        email = json.optString("email", session.email),
        active = json.optBoolean("active", true),
        requestedRole = UserRole.from(json.optString("requested_role")),
        rejectionReason = json.optString("rejection_reason"),
    )

    fun cachedProfile(): Profile? {
        val session = store.load() ?: return null
        val cached = cache.get(session.userId, CACHE_PROFILE, maxAge = null)
            ?.let { runCatching { JSONObject(it) }.getOrNull() } ?: return null
        return profileFromJson(cached, session)
    }

    fun profile(): Profile {
        val session = store.load() ?: error("not signed in")
        val cached = cache.get(session.userId, CACHE_PROFILE, maxAge = null)
            ?.let { runCatching { JSONObject(it) }.getOrNull() }
        if (!online() && cached != null) return profileFromJson(cached, session)

        val json = runCatching {
            api.select(
                "profiles",
                "select=id,full_name,role,requested_role,approval_status,active,email,rejection_reason" +
                    "&id=eq.${session.userId}&limit=1",
            ).optJSONObject(0)
        }.getOrElse { error ->
            cached ?: throw error
        } ?: cached ?: JSONObject()
            .put("id", session.userId)
            .put("full_name", session.email)
            .put("role", "guardian")
            .put("requested_role", "guardian")
            .put("approval_status", "pending")
            .put("active", true)

        cache.put(session.userId, CACHE_PROFILE, json.toString())
        return profileFromJson(json, session)
    }

    fun profileWithRefresh(): Profile = try {
        profile()
    } catch (e: SupabaseException) {
        if (e.status != 401) throw e
        api.refresh() ?: throw e
        profile()
    }

    private val readCacheFreshness: Duration = Duration.ofMinutes(5)

    fun students(forceRefresh: Boolean = false): List<Student> {
        val owner = currentUserId() ?: return emptyList()
        val local = offlineDb.students().all(owner).map { Student.from(it.asJson()) }
        if (forceRefresh && online()) return refreshStudents()
        if (local.isNotEmpty()) {
            if (online()) scheduleSync()
            return local
        }
        cachedStudents(owner, null)?.let { cached ->
            cached.forEach { student -> upsertStudentLocal(owner, studentToJson(student), dirty = false) }
            if (!online()) return cached
        }
        return if (online()) refreshStudents() else emptyList()
    }

    fun cachedStudents(ownerId: String, maxAge: Duration? = null): List<Student>? =
        cache.get(ownerId, CACHE_STUDENTS, maxAge)?.let(::studentsFromJson)

    fun refreshStudents(): List<Student> {
        val owner = currentUserId() ?: return emptyList()
        val localFallback = { offlineDb.students().all(owner).map { Student.from(it.asJson()) } }
        if (!online()) return localFallback()
        val arr = runCatching { withAuthRetry {
            api.select("students", "select=*&order=full_name.asc&limit=1000")
        } }.getOrElse { return localFallback().ifEmpty { cachedStudents(owner, null).orEmpty() } }
        val dirtyIds = offlineDb.students().dirty(owner).mapTo(hashSetOf()) { it.id }
        offlineDb.students().clearClean(owner)
        for (index in 0 until arr.length()) {
            val row = arr.optJSONObject(index) ?: continue
            if (row.optString("id") !in dirtyIds) upsertStudentLocal(owner, row, dirty = false)
        }
        cache.put(owner, CACHE_STUDENTS, localStudentsJson(owner).toString())
        markPulled(owner)
        return localFallback()
    }

    fun studentRaw(studentId: String): JSONObject? {
        val owner = currentUserId() ?: return null
        return offlineDb.students().byId(owner, studentId)?.takeUnless { it.deleted }?.asJson()
    }

    private fun upsertStudentLocal(owner: String, row: JSONObject, dirty: Boolean) {
        if (row.optString("id").isBlank()) return
        offlineDb.students().upsert(StudentLocalEntity.fromJson(owner, row, dirty))
    }

    private fun localStudentsJson(owner: String): JSONArray = JSONArray().apply {
        offlineDb.students().all(owner).forEach { put(it.asJson()) }
    }

    private fun studentToJson(student: Student): JSONObject = JSONObject()
        .put("id", student.id).put("full_name", student.fullName).put("status", student.status)
        .put("track_code", student.track).put("category_id", student.categoryId ?: JSONObject.NULL)
        .put("halaqa_id", student.halaqaId ?: JSONObject.NULL).put("primary_teacher_id", student.primaryTeacherId ?: JSONObject.NULL)
        .put("national_id", student.nationalId ?: JSONObject.NULL)
        .put("phone", student.phone ?: JSONObject.NULL).put("date_of_birth", student.dateOfBirth ?: JSONObject.NULL)
        .put("school_grade", student.schoolGrade ?: JSONObject.NULL).put("guardian_phone", student.guardianPhone ?: JSONObject.NULL)
        .put("guardian_email", student.guardianEmail ?: JSONObject.NULL).put("gender", student.gender ?: JSONObject.NULL)
        .put("enrollment_date", student.enrollmentDate ?: JSONObject.NULL).put("program_name", student.programName ?: JSONObject.NULL)
        .put("address", student.address ?: JSONObject.NULL).put("notes", student.notes ?: JSONObject.NULL)
        .put("photo_path", student.photoPath ?: JSONObject.NULL).also { json ->
            student.targetPagesWeekly?.let { json.put("target_pages_weekly", it) }
            student.targetReviewPagesWeekly?.let { json.put("target_review_pages_weekly", it) }
            student.updatedAt?.let { json.put("updated_at", it) }
        }

    fun sessions(forceRefresh: Boolean = false): List<SessionRow> {
        val owner = currentUserId() ?: return emptyList()
        if (!forceRefresh) cachedSessions(owner, maxAge = null)?.let { cached ->
            if (cached.isNotEmpty()) { if (online()) scheduleSync(); return cached }
        }
        if (!online()) return cachedSessions(owner, maxAge = null).orEmpty()
        return refreshSessions()
    }

    fun cachedSessions(ownerId: String, maxAge: Duration? = null): List<SessionRow>? =
        cache.get(ownerId, CACHE_SESSIONS, maxAge)?.let(::sessionsFromJson)

    fun refreshSessions(): List<SessionRow> {
        val owner = currentUserId() ?: return emptyList()
        val stale = cachedSessions(owner, maxAge = null).orEmpty()
        if (!online()) return stale
        val arr = runCatching { withAuthRetry { api.select("sessions", "select=*&status=neq.cancelled&order=session_date.desc&limit=300") } }
            .getOrElse { return stale }
        cache.put(owner, CACHE_SESSIONS, arr.toString())
        return sessionsFromJson(arr.toString())
    }

    fun plans(forceRefresh: Boolean = false): List<PlanRow> {
        val owner = currentUserId() ?: return emptyList()
        if (!forceRefresh) cachedPlans(owner, maxAge = null)?.let { cached ->
            if (cached.isNotEmpty()) { if (online()) scheduleSync(); return cached }
        }
        if (!online()) return cachedPlans(owner, maxAge = null).orEmpty()
        return refreshPlans()
    }

    fun cachedPlans(ownerId: String, maxAge: Duration? = null): List<PlanRow>? =
        cache.get(ownerId, CACHE_PLANS, maxAge)?.let(::plansFromJson)

    fun refreshPlans(): List<PlanRow> {
        val owner = currentUserId() ?: return emptyList()
        val stale = cachedPlans(owner, maxAge = null).orEmpty()
        if (!online()) return stale
        val arr = runCatching { withAuthRetry { api.select("smart_plans", "select=*&order=updated_at.desc&limit=500") } }
            .getOrElse { return stale }
        cache.put(owner, CACHE_PLANS, arr.toString())
        return plansFromJson(arr.toString())
    }

    private fun studentsFromJson(raw: String): List<Student> {
        val arr = JSONArray(raw)
        return (0 until arr.length()).mapNotNull { arr.optJSONObject(it)?.let(Student::from) }
    }

    private fun sessionsFromJson(raw: String): List<SessionRow> {
        val arr = JSONArray(raw)
        return (0 until arr.length()).mapNotNull { arr.optJSONObject(it)?.let(SessionRow::from) }.filterNot { it.archived }
    }

    private fun plansFromJson(raw: String): List<PlanRow> {
        val arr = JSONArray(raw)
        return (0 until arr.length()).mapNotNull { arr.optJSONObject(it)?.let(PlanRow::from) }
    }


    private fun phasesFromJson(raw: String): List<SmartPlanPhaseRow> {
        val arr = JSONArray(raw)
        return (0 until arr.length()).mapNotNull { arr.optJSONObject(it)?.let(SmartPlanPhaseRow::from) }
    }

    private fun phaseStatesFromJson(raw: String): List<SmartPlanPhaseStateRow> {
        val arr = JSONArray(raw)
        return (0 until arr.length()).mapNotNull { arr.optJSONObject(it)?.let(SmartPlanPhaseStateRow::from) }
    }

    private fun phaseTemplatesFromJson(raw: String): List<SmartPlanPhaseTemplateRow> {
        val arr = JSONArray(raw)
        return (0 until arr.length()).mapNotNull { arr.optJSONObject(it)?.let(SmartPlanPhaseTemplateRow::from) }
    }

    fun planPhases(planId: String? = null, forceRefresh: Boolean = false): List<SmartPlanPhaseRow> {
        val owner = currentUserId() ?: return emptyList()
        val cached = cache.get(owner, CACHE_PLAN_PHASES, maxAge = null)?.let(::phasesFromJson).orEmpty()
        val all = if (!forceRefresh && cached.isNotEmpty()) {
            if (online()) scheduleSync()
            cached
        } else if (!online()) cached else {
            runCatching {
                val arr = withAuthRetry { api.select("smart_plan_phases", "select=*&order=plan_id.asc,phase_order.asc&limit=2000") }
                cache.put(owner, CACHE_PLAN_PHASES, arr.toString())
                phasesFromJson(arr.toString())
            }.getOrElse { cached }
        }
        return if (planId.isNullOrBlank()) all else all.filter { it.planId == planId }
    }

    fun planPhaseStates(studentId: String? = null, forceRefresh: Boolean = false): List<SmartPlanPhaseStateRow> {
        val owner = currentUserId() ?: return emptyList()
        val cached = cache.get(owner, CACHE_PLAN_PHASE_STATES, maxAge = null)?.let(::phaseStatesFromJson).orEmpty()
        val all = if (!forceRefresh && cached.isNotEmpty()) {
            if (online()) scheduleSync()
            cached
        } else if (!online()) cached else {
            runCatching {
                val arr = withAuthRetry { api.select("smart_plan_phase_states", "select=*&order=updated_at.desc&limit=5000") }
                cache.put(owner, CACHE_PLAN_PHASE_STATES, arr.toString())
                phaseStatesFromJson(arr.toString())
            }.getOrElse { cached }
        }
        return if (studentId.isNullOrBlank()) all else all.filter { it.studentId == studentId }
    }

    /** RC11.1: expose the independent historical Sard anchor to the phase editor. */
    fun latestSardRecitation(
        studentId: String,
        today: LocalDate = LocalDate.now(),
        forceRefresh: Boolean = false,
    ): SmartPlanEngine.Recitation? {
        if (studentId.isBlank()) return null
        val recitations = planRecitations(today.minusMonths(18).toString(), today.toString(), forceRefresh)
            .filter { it.studentId == studentId && it.date <= today }
        return SmartPlanActivityRules.latestAnchor(recitations, "sard")
    }

    /**
     * Detect the RC11 schema-cache failure before the UI creates more queued writes.
     * Offline use is still allowed; only the explicit PostgREST missing-table error is returned.
     */
    fun smartPlanPhaseSchemaIssue(): String? {
        if (!online()) return null
        return try {
            withAuthRetry { api.select("smart_plan_phases", "select=id&limit=1") }
            withAuthRetry { api.select("smart_plan_phase_states", "select=id&limit=1") }
            withAuthRetry { api.select("smart_plan_phase_templates", "select=id&limit=1") }
            null
        } catch (e: Exception) {
            val raw = e.message.orEmpty()
            if (raw.contains("schema cache", ignoreCase = true) ||
                raw.contains("Could not find the table", ignoreCase = true) ||
                raw.contains("PGRST205", ignoreCase = true)) {
                "قاعدة Supabase الحالية لم تُطبّق عليها Migration الخاصة بمراحل RC11 بعد. طبّق ملف migration/20260926_v2461_rc11_smart_plan_phases.sql ثم حدّث المخطط قبل إعادة المحاولة."
            } else null
        }
    }

    fun previousSardShortfalls(
        studentIds: Set<String>,
        beforeDate: LocalDate,
        forceRefresh: Boolean = false,
    ): Map<String, Double> {
        if (studentIds.isEmpty()) return emptyMap()
        val phases = planPhases(forceRefresh = forceRefresh)
            .filter { it.phaseType == "sard" && it.status != "archived" }
            .mapNotNull { phase ->
                val end = runCatching { LocalDate.parse(phase.endDate) }.getOrNull() ?: return@mapNotNull null
                if (end >= beforeDate) null else phase to end
            }
            .sortedByDescending { it.second }
        if (phases.isEmpty()) return emptyMap()
        val states = planPhaseStates(forceRefresh = forceRefresh)
            .filter { it.studentId in studentIds }
            .associateBy { it.phaseId to it.studentId }
        val result = linkedMapOf<String, Double>()
        studentIds.forEach { studentId ->
            for ((phase, _) in phases) {
                val state = states[phase.id to studentId] ?: continue
                val target = state.frozenTargetPages ?: state.targetPagesOverride ?: phase.targetPages
                    ?: if (phase.goalMode == "juz") phase.targetUnits?.times(20.0) else null
                val completed = state.frozenCompletedPages ?: continue
                if (target != null) {
                    result[studentId] = SmartPlanEngine.round((target - completed).coerceAtLeast(0.0))
                    break
                }
            }
        }
        return result
    }

    fun planPhaseTemplates(halaqaId: String? = null, forceRefresh: Boolean = false): List<SmartPlanPhaseTemplateRow> {
        val owner = currentUserId() ?: return emptyList()
        val cached = cache.get(owner, CACHE_PLAN_PHASE_TEMPLATES, maxAge = null)?.let(::phaseTemplatesFromJson).orEmpty()
        val all = if (!forceRefresh && cached.isNotEmpty()) cached else if (!online()) cached else {
            runCatching {
                val arr = withAuthRetry { api.select("smart_plan_phase_templates", "select=*&active=eq.true&order=updated_at.desc&limit=500") }
                cache.put(owner, CACHE_PLAN_PHASE_TEMPLATES, arr.toString())
                phaseTemplatesFromJson(arr.toString())
            }.getOrElse { cached }
        }
        return if (halaqaId.isNullOrBlank()) all else all.filter { it.halaqaId == halaqaId }
    }

    fun cachedDashboardRecitations(ownerId: String, maxAge: Duration? = null): JSONArray? =
        cache.get(ownerId, CACHE_DASHBOARD_RECITATIONS, maxAge)?.let(::JSONArray)

    fun refreshDashboardRecitations(): JSONArray {
        val owner = currentUserId()
        val cached = owner?.let { cachedDashboardRecitations(it, maxAge = null) } ?: JSONArray()
        val remote = if (online()) runCatching {
            withAuthRetry {
                api.select(
                    "recitation_entries",
                    "select=id,session_id,student_id,activity_type,pages_count,mistakes,prompts,evaluation,safety_percentage,created_at,sessions!inner(session_date)" +
                        "&order=created_at.desc&limit=1200",
                )
            }
        }.getOrElse { cached } else cached
        val byId = linkedMapOf<String, JSONObject>()
        for (i in 0 until remote.length()) {
            val row = remote.optJSONObject(i) ?: continue
            val id = row.optString("id")
            if (id.isNotBlank()) byId[id] = row
        }

        // Include optimistic offline writes. Their authoritative day is the session day, never
        // created_at (which can be hours/days later when the queue finally syncs).
        val sessionsById = owner?.let { cachedSessions(it, maxAge = null) }.orEmpty().associateBy { it.id }
        queueSnapshot(1500).forEach { item ->
            if (!item.dedupe.orEmpty().startsWith("recitation:")) return@forEach
            val body = item.body?.let { runCatching { JSONObject(it) }.getOrNull() } ?: return@forEach
            val id = body.optString("id")
            if (id.isBlank()) return@forEach
            val date = sessionsById[body.optString("session_id")]?.date
            if (!date.isNullOrBlank()) body.put("session_date", date)
            byId[id] = body
        }
        val arr = JSONArray()
        byId.values
            .sortedByDescending { it.optString("created_at") }
            .forEach(arr::put)
        owner?.let { cache.put(it, CACHE_DASHBOARD_RECITATIONS, arr.toString()) }
        return arr
    }

    fun attendanceForSession(sessionId: String, allowNetwork: Boolean = true): Map<String, AttendanceRow> {
        val owner = currentUserId()
        val key = CACHE_SESSION_ATTENDANCE_PREFIX + sessionId
        var source = owner?.let { cache.get(it, key, maxAge = null) }?.let { runCatching { JSONArray(it) }.getOrNull() }
        if (source == null && allowNetwork && online()) {
            source = runCatching {
                withAuthRetry {
                    api.select(
                        "attendance_records",
                        "select=id,session_id,student_id,status,excuse_reason,arrival_minutes_late" +
                            "&session_id=eq.$sessionId&limit=2000",
                    )
                }
            }.getOrNull() ?: source
            if (source != null && owner != null) cache.put(owner, key, source.toString())
        }
        if (source == null && owner != null) source = cache.get(owner, key, maxAge = null)?.let { runCatching { JSONArray(it) }.getOrNull() }
        val rows = linkedMapOf<String, AttendanceRow>()
        val arr = source ?: JSONArray()
        for (i in 0 until arr.length()) arr.optJSONObject(i)?.let(AttendanceRow::from)?.let { rows[it.studentId] = it }
        queueSnapshot(1200).forEach { item ->
            if (!item.dedupe.orEmpty().startsWith("attendance:$sessionId:")) return@forEach
            val body = item.body?.let { runCatching { JSONObject(it) }.getOrNull() } ?: return@forEach
            val row = AttendanceRow.from(body)
            if (row.studentId.isNotBlank()) rows[row.studentId] = row
        }
        return rows
    }

    fun notesForSession(sessionId: String, allowNetwork: Boolean = true): Map<String, DailyNoteRow> {
        val owner = currentUserId()
        val key = CACHE_SESSION_NOTES_PREFIX + sessionId
        var source = owner?.let { cache.get(it, key, maxAge = null) }?.let { runCatching { JSONArray(it) }.getOrNull() }
        if (source == null && allowNetwork && online()) {
            source = runCatching {
                withAuthRetry {
                    api.select(
                        "student_daily_notes",
                        "select=id,session_id,student_id,behavior,behavior_score,teacher_comment,homework,parent_visible,participation" +
                            "&session_id=eq.$sessionId&limit=2000",
                    )
                }
            }.getOrNull() ?: source
            if (source != null && owner != null) cache.put(owner, key, source.toString())
        }
        if (source == null && owner != null) source = cache.get(owner, key, maxAge = null)?.let { runCatching { JSONArray(it) }.getOrNull() }
        val rows = linkedMapOf<String, DailyNoteRow>()
        val arr = source ?: JSONArray()
        for (i in 0 until arr.length()) arr.optJSONObject(i)?.let(DailyNoteRow::from)?.let { rows[it.studentId] = it }
        queueSnapshot(1200).forEach { item ->
            if (!item.dedupe.orEmpty().startsWith("note:$sessionId:")) return@forEach
            val body = item.body?.let { runCatching { JSONObject(it) }.getOrNull() } ?: return@forEach
            val row = DailyNoteRow.from(body)
            if (row.studentId.isNotBlank()) rows[row.studentId] = row
        }
        return rows
    }

    fun recitationsForSession(sessionId: String, allowNetwork: Boolean = true): Map<String, List<RecitationRow>> {
        val owner = currentUserId()
        val cacheKey = CACHE_SESSION_RECITATIONS_PREFIX + sessionId
        var source: JSONArray? = null

        // Cache-first just like v2.44: opening a session never needs a network round-trip merely
        // to show recitations that were already synced on this device.
        if (owner != null) {
            source = cache.get(owner, cacheKey, maxAge = null)
                ?.let { runCatching { JSONArray(it) }.getOrNull() }
        }
        if (source == null && allowNetwork && online()) {
            source = runCatching {
                withAuthRetry {
                    api.select(
                        "recitation_entries",
                        "select=id,session_id,student_id,activity_type,input_method,start_surah,start_ayah,end_surah,end_ayah,start_page,end_page,pages_count,ayahs_count,surahs_count,mistakes,prompts,evaluation,safety_percentage,points,teacher_note,selected_surahs,selection_data,created_at" +
                            "&session_id=eq.$sessionId&order=created_at.asc&limit=2000",
                    )
                }
            }.getOrNull() ?: source
            if (source != null && owner != null) cache.put(owner, cacheKey, source.toString())
        }
        if (source == null && owner != null) {
            source = cache.get(owner, cacheKey, maxAge = null)
                ?.let { runCatching { JSONArray(it) }.getOrNull() }
        }

        val byId = linkedMapOf<String, RecitationRow>()
        val remoteOrCached = source ?: JSONArray()
        for (index in 0 until remoteOrCached.length()) {
            remoteOrCached.optJSONObject(index)?.let(RecitationRow::from)?.let { row ->
                if (row.id.isNotBlank()) byId[row.id] = row
            }
        }

        // Optimistic/local-first overlay. The exact object that will be uploaded is rendered now,
        // so "حفظ" immediately changes the roster even with no internet.
        queueSnapshot(1500).forEach { item ->
            val dedupe = item.dedupe.orEmpty()
            if (!dedupe.startsWith("recitation:$sessionId:")) return@forEach
            val body = item.body?.let { runCatching { JSONObject(it) }.getOrNull() } ?: return@forEach
            val row = RecitationRow.from(body)
            if (row.id.isNotBlank()) byId[row.id] = row
        }
        return byId.values
            .sortedBy { it.createdAt }
            .groupBy { it.studentId }
    }

    private fun activityAssignmentFromAnchor(
        row: PlanRow,
        plan: SmartPlanEngine.Plan,
        recitations: List<SmartPlanEngine.Recitation>,
        activity: String,
        requestedPages: Double,
        anchorOverride: QuranLocation? = null,
        startOverride: QuranLocation? = null,
    ): SmartPlanEngine.Assignment? {
        if (requestedPages <= 0.0) return null
        val route = SmartPlanActivityRules.routeFor(
            activity = activity,
            primaryPlanType = row.type,
            hifzRoute = row.settings.routeDirection,
            sardRoute = row.settings.sardRouteDirection,
        )
        val start = startOverride ?: run {
            val anchor = anchorOverride ?: SmartPlanActivityRules.latestAnchor(recitations, activity)?.let { last ->
                val surah = last.endSurah ?: return@let null
                val ayah = last.endAyah ?: return@let null
                QuranLocation(surah, ayah)
            } ?: return null
            SmartPlanActivityRules.nextLocation(anchor, route) ?: return null
        }
        val reverse = route == "reverse_surahs_forward_ayahs"
        val globalTerminalSurah = if (reverse) {
            if (activity == "hifz") 2 else 1
        } else 114
        if (reverse && start.surah < globalTerminalSurah) return null
        val configuredTerminal = if (activity == "sard") {
            when {
                row.rangeEndSurah != null && row.rangeEndAyah != null -> QuranLocation(row.rangeEndSurah, row.rangeEndAyah)
                row.rangeEndPage != null -> QuranMetadata.pageEnd(row.rangeEndPage)
                else -> null
            }
        } else null
        val terminal = configuredTerminal ?: QuranLocation(globalTerminalSurah, QuranMetadata.maxAyah(globalTerminalSurah))
        val direction = planTraversalDirection(route)
        val track = if (activity == "hifz" || row.type == "hifz") "general_hifz" else "tathbit"
        val activityType = SmartPlanActivityRules.activityTypeFor(activity)
        val full = runCatching {
            QuranCore.engine().calculate(
                QuranRangeRequest(
                    track = track,
                    activityType = activityType,
                    selection = QuranSelection.Ayahs(start, terminal),
                    direction = direction,
                ),
            )
        }.getOrNull() ?: return null
        val wantedLines = ceil(requestedPages * 15.0).toInt().coerceAtLeast(1)
        val keys = full.qcfLineKeys.take(wantedLines)
        if (keys.isEmpty()) return null
        val endpoints = QuranCore.engine().endpointsForLineKeys(keys) ?: return null
        return SmartPlanEngine.Assignment(
            kind = activity,
            pages = keys.size / 15.0,
            startPage = keys.first().substringBefore(':').toIntOrNull(),
            endPage = keys.last().substringBefore(':').toIntOrNull(),
            isCatchUp = false,
            blockedByRetry = false,
            lineKeys = keys,
        )
    }

    private fun projectedNextActivityDuty(
        row: PlanRow,
        plan: SmartPlanEngine.Plan,
        recitations: List<SmartPlanEngine.Recitation>,
        activity: String,
        todayAssignment: SmartPlanEngine.Assignment?,
        nextDate: LocalDate?,
        requestedPages: Double,
    ): PlanNextDuty? {
        val date = nextDate ?: return null
        val projectedAnchor = todayAssignment?.lineKeys?.takeIf { it.isNotEmpty() }
            ?.let { QuranCore.engine().endpointsForLineKeys(it)?.second }
        val assignment = activityAssignmentFromAnchor(
            row = row,
            plan = plan,
            recitations = recitations,
            activity = activity,
            requestedPages = requestedPages,
            anchorOverride = projectedAnchor,
        ) ?: return null
        return PlanNextDuty(date, assignment)
    }

    private fun activitySnapshotsForPlan(
        row: PlanRow,
        plan: SmartPlanEngine.Plan,
        student: Student,
        recitations: List<SmartPlanEngine.Recitation>,
        primaryProgress: SmartPlanEngine.Progress,
        today: LocalDate,
        activePhase: SmartPlanPhaseRow? = null,
        activePhaseState: SmartPlanPhaseStateRow? = null,
        phaseProgress: SmartPlanPhaseEngine.Progress? = null,
    ): List<PlanActivitySnapshot> {
        val enabled = SmartPlanActivityRules.enabledActivities(row.type, row.settings.enabledActivities)
        val passingRecitations = recitations.filter { SmartPlanEngine.isPassing(it, plan) }
        val schedule = SmartPlanEngine.planDates(plan)
        val nextDate = schedule.firstOrNull { it > today }
        val activeToday = today in schedule || primaryProgress.assignment.isCatchUp || primaryProgress.assignment.blockedByRetry
        return enabled.map { activity ->
            val globalLast = SmartPlanActivityRules.latestAnchor(passingRecitations.filter { it.date <= today }, activity)
            val currentPhaseRecitations = if (activity == "sard" && activePhase?.phaseType == "sard") {
                passingRecitations.filter { rec ->
                    rec.date >= plan.startDate && rec.date <= plan.endDate && rec.date <= today &&
                        (rec.taggedPhaseId == activePhase.id || rec.taggedPhaseId == null)
                }
            } else passingRecitations.filter { it.date <= today }
            val phaseLast = SmartPlanActivityRules.latestAnchor(currentPhaseRecitations, activity)
            val assignmentAnchorRecitations = when {
                activity != "sard" -> passingRecitations
                activePhase?.phaseType != "sard" -> passingRecitations
                activePhase.startMode == SmartPlanPhaseEngine.START_LAST_SARD -> passingRecitations
                else -> currentPhaseRecitations
            }
            val assignmentLast = SmartPlanActivityRules.latestAnchor(assignmentAnchorRecitations.filter { it.date <= today }, activity)
            val explicitPhaseStart = if (activity == "sard" && activePhase?.phaseType == "sard" && assignmentLast == null) {
                when {
                    activePhase.startMode in setOf(SmartPlanPhaseEngine.START_MANUAL, SmartPlanPhaseEngine.START_RANGE) -> when {
                        activePhase.rangeStartSurah != null && activePhase.rangeStartAyah != null -> QuranLocation(activePhase.rangeStartSurah, activePhase.rangeStartAyah)
                        activePhase.rangeStartPage != null -> QuranMetadata.pageStart(activePhase.rangeStartPage)
                        else -> null
                    }
                    activePhase.startMode == SmartPlanPhaseEngine.START_LAST_SARD && globalLast == null -> when {
                        activePhase.rangeStartSurah != null && activePhase.rangeStartAyah != null -> QuranLocation(activePhase.rangeStartSurah, activePhase.rangeStartAyah)
                        activePhase.rangeStartPage != null -> QuranMetadata.pageStart(activePhase.rangeStartPage)
                        else -> null
                    }
                    else -> null
                }
            } else null
            val target = when {
                activity == "sard" && activePhase?.phaseType == "sard" -> phaseProgress?.targetPages ?: 0.0
                activity == "sard" -> row.settings.sardTargetPages.takeIf { it > 0.0 } ?: 0.0
                else -> row.target
            }
            val scheduledDays = schedule.size.coerceAtLeast(1)
            val plannedDaily = if (target > 0.0) target / scheduledDays else 0.0
            val weeklyDaily = when (activity) {
                "hifz" -> student.targetPagesWeekly?.takeIf { it > 0.0 }?.div(plan.scheduleWeekdays.size.coerceAtLeast(1)) ?: 0.0
                "review" -> student.targetReviewPagesWeekly?.takeIf { it > 0.0 }?.div(plan.scheduleWeekdays.size.coerceAtLeast(1)) ?: 0.0
                else -> 0.0
            }
            val continueSurplus = activity == "sard" && activePhaseState?.settings?.optBoolean("continue_surplus", false) == true
            val daily = when {
                activity == "sard" && activePhase?.phaseType == "sard" && phaseProgress?.targetPages == null -> 0.0
                activity == "sard" && activePhase?.phaseType == "sard" && phaseProgress?.goalComplete == true && continueSurplus -> plannedDaily
                activity == "sard" && activePhase?.phaseType == "sard" -> phaseProgress?.suggestedTodayPages ?: 0.0
                else -> SmartPlanActivityRules.effectiveDailyPages(
                    activity = activity,
                    engineDaily = primaryProgress.dailyTarget,
                    originalDaily = primaryProgress.originalDaily,
                    minimumDaily = primaryProgress.minimumDaily,
                    plannedDaily = plannedDaily,
                    weeklyDaily = weeklyDaily,
                    assignmentPages = primaryProgress.assignment.pages,
                    assignmentKind = primaryProgress.assignment.kind,
                )
            }
            val assignment = when {
                !activeToday -> null
                activity == "hifz" && primaryProgress.assignment.kind != "hifz" -> primaryProgress.assignment
                activity == "sard" && phaseProgress?.goalComplete == true && !continueSurplus -> null
                activity == "sard" && assignmentLast == null && explicitPhaseStart == null -> null
                daily <= 0.001 -> null
                else -> activityAssignmentFromAnchor(
                    row = row,
                    plan = plan,
                    recitations = assignmentAnchorRecitations,
                    activity = activity,
                    requestedPages = daily,
                    startOverride = explicitPhaseStart,
                )
            }
            val next = projectedNextActivityDuty(
                row = row,
                plan = plan,
                recitations = assignmentAnchorRecitations,
                activity = activity,
                todayAssignment = assignment,
                nextDate = nextDate,
                requestedPages = daily.coerceAtLeast(1.0 / 15.0),
            )
            PlanActivitySnapshot(
                key = activity,
                label = when (activity) { "sard" -> "السرد"; "review" -> "المراجعة"; else -> "الحفظ" },
                scheduledToday = activeToday,
                lastRecitation = if (activity == "sard") (phaseLast ?: globalLast) else globalLast,
                assignment = assignment,
                nextDuty = next,
                needsStart = activity == "sard" && assignmentLast == null && explicitPhaseStart == null,
                targetPages = target,
                routeDirection = SmartPlanActivityRules.routeFor(activity, row.type, row.settings.routeDirection, row.settings.sardRouteDirection),
            )
        }
    }

    fun planSnapshots(today: LocalDate = LocalDate.now(), forceRefresh: Boolean = false): List<PlanSnapshot> {
        if (!forceRefresh && planSnapshotMemoryDate == today && planSnapshotMemory.isNotEmpty()) {
            if (online()) scheduleSync()
            return planSnapshotMemory
        }
        val students = students(forceRefresh = forceRefresh)
        val planRows = plans(forceRefresh = forceRefresh)
        if (students.isEmpty() || planRows.isEmpty()) return emptyList()
        val phaseRows = planPhases(forceRefresh = forceRefresh)
        val phaseStates = planPhaseStates(forceRefresh = forceRefresh)
        val phasesByPlan = phaseRows.groupBy { it.planId }
        val phaseStatesByStudent = phaseStates.groupBy { it.studentId }

        val enginePlansById = planRows.mapNotNull { row -> row.toEnginePlan()?.let { row.id to it } }.toMap()
        if (enginePlansById.isEmpty()) return emptyList()

        // RC11 needs the previous Sard anchor even when it belongs to the prior monthly plan.
        // Pull a bounded six-month history, then strictly scope progress to the active plan/phase below.
        val start = enginePlansById.values.minOf { it.startDate }.minusMonths(6).toString()
        val end = maxOf(today, enginePlansById.values.maxOf { it.endDate }).toString()
        val recitations = planRecitations(start, end, forceRefresh)
        // v2.30 Performance Core parity: filter once, then every plan works on the student's
        // short recitation list instead of rescanning thousands of rows per card.
        val recitationsByStudent = recitations.groupBy { it.studentId }
        val events = planEvents(forceRefresh)
        val rowsById = planRows.associateBy { it.id }

        val result = buildList {
            students.forEach { student ->
                val engineStudent = SmartPlanEngine.Student(
                    id = student.id,
                    halaqaId = student.halaqaId.orEmpty(),
                    categoryId = student.categoryId,
                )
                val studentRecitations = recitationsByStudent[student.id].orEmpty()
                SmartPlanEngine.effectivePlans(enginePlansById.values.toList(), engineStudent, today)
                    .forEach { enginePlan ->
                        val row = rowsById[enginePlan.id] ?: return@forEach
                        val candidatePhaseRows = phasesByPlan[enginePlan.id].orEmpty()
                        val candidatePhases = candidatePhaseRows.mapNotNull { it.toEnginePhase() }
                        val studentPhaseStates = phaseStatesByStudent[student.id].orEmpty()
                            .filter { state -> candidatePhaseRows.any { it.id == state.phaseId } }
                        val enginePhaseStates = studentPhaseStates.map { state ->
                            SmartPlanPhaseEngine.StudentState(
                                phaseId = state.phaseId,
                                studentId = state.studentId,
                                status = state.status,
                                targetPagesOverride = state.targetPagesOverride,
                                startDateOverride = state.startDateOverride?.let { runCatching { LocalDate.parse(it) }.getOrNull() },
                                endDateOverride = state.endDateOverride?.let { runCatching { LocalDate.parse(it) }.getOrNull() },
                                frozenCompletedPages = state.frozenCompletedPages,
                                frozenTargetPages = state.frozenTargetPages,
                                carriedShortfallPages = state.carryShortfallPages,
                                completionPercent = state.completionPercent,
                            )
                        }
                        val activePhaseEngine = SmartPlanPhaseEngine.effectiveActivePhase(candidatePhases, enginePhaseStates, student.id, today)
                        // Once RC11 phases exist, the parent plan is only a container. Never fall back
                        // to the legacy parent Hifz assignment during a gap or after the final phase.
                        if (candidatePhases.isNotEmpty() && activePhaseEngine == null) return@forEach
                        val activePhase = activePhaseEngine?.let { active -> candidatePhaseRows.firstOrNull { it.id == active.id } }
                        val activePhaseState = activePhase?.let { phase -> studentPhaseStates.firstOrNull { it.phaseId == phase.id } }
                        val (phaseRowForUi, phaseAwareEnginePlan) = phaseAwarePlan(row, enginePlan, activePhase, activePhaseState, activePhaseEngine)
                        val normalizedRow = phaseRowForUi.copy(
                            settings = phaseRowForUi.settings.copy(
                                memorizationLineKeys = phaseAwareEnginePlan.settings.memorizationLineKeys,
                                routeDirection = phaseAwareEnginePlan.settings.routeDirection,
                            ),
                        )
                        val progressRecitations = studentRecitations.filter { rec ->
                            rec.date >= phaseAwareEnginePlan.startDate && rec.date <= phaseAwareEnginePlan.endDate &&
                                (activePhase == null || rec.taggedPhaseId == activePhase.id || rec.taggedPhaseId == null)
                        }
                        val planEvents = events[enginePlan.id].orEmpty()
                        val rawProgress = SmartPlanEngine.calculateProgress(
                            plan = phaseAwareEnginePlan,
                            studentId = student.id,
                            recitations = progressRecitations,
                            events = planEvents,
                            today = today,
                        )
                        val phaseProgress = activePhaseEngine?.let { phase ->
                            val state = enginePhaseStates.firstOrNull { it.phaseId == phase.id }
                            SmartPlanPhaseEngine.progress(phase, rawProgress.completed, today, state)
                        }
                        // Activity anchors intentionally see bounded history so Sard can resume from the
                        // previous monthly Sard anchor without counting that history toward this phase.
                        // RC11 phaseProgress is passed into Sard assignment generation so the actual ward,
                        // not only the UI hint, follows equal/flexible rebalancing.
                        val activities = activitySnapshotsForPlan(
                            normalizedRow,
                            phaseAwareEnginePlan,
                            student,
                            studentRecitations,
                            rawProgress,
                            today,
                            activePhase,
                            activePhaseState,
                            phaseProgress,
                        )
                        val hifzActivity = activities.firstOrNull { it.key == "hifz" }
                        val sardActivity = activities.firstOrNull { it.key == "sard" }
                        val progress = when {
                            phaseAwareEnginePlan.planType == "hifz" && rawProgress.assignment.kind == "hifz" && hifzActivity?.assignment != null -> rawProgress.copy(assignment = hifzActivity.assignment)
                            phaseAwareEnginePlan.planType == "sard" && sardActivity?.assignment != null -> rawProgress.copy(assignment = sardActivity.assignment)
                            else -> rawProgress
                        }
                        val last = when (phaseAwareEnginePlan.planType) {
                            "hifz" -> hifzActivity?.lastRecitation
                            "sard" -> sardActivity?.lastRecitation
                            else -> progressRecitations
                                .asSequence()
                                .filter { recitationMatchesPlanType(phaseAwareEnginePlan.planType, it.activityType) }
                                .filter { it.date <= today }
                                .maxWithOrNull(compareBy<SmartPlanEngine.Recitation> { it.date }.thenBy { it.createdAt })
                        }
                        val week = smartPlanWeekRequirement(phaseAwareEnginePlan, progress, today)
                        val next = when (phaseAwareEnginePlan.planType) {
                            "hifz" -> hifzActivity?.nextDuty
                            "sard" -> sardActivity?.nextDuty
                            else -> smartPlanNextDuty(phaseAwareEnginePlan, student.id, studentRecitations, planEvents, today)
                        }
                        val weeklyTargetOverride = when (phaseAwareEnginePlan.planType) {
                            "hifz" -> student.targetPagesWeekly
                            "review", "tathbit" -> student.targetReviewPagesWeekly
                            else -> null
                        }
                        val coreState = SmartPlanCoreStateEngine.build(
                            plan = phaseAwareEnginePlan,
                            progress = progress,
                            recitations = progressRecitations,
                            today = today,
                            weeklyTargetOverride = weeklyTargetOverride,
                        )
                        add(PlanSnapshot(
                            plan = normalizedRow,
                            student = student,
                            progress = progress,
                            phase = activePhase,
                            phaseState = activePhaseState,
                            phaseProgress = phaseProgress,
                            lastRecitation = last,
                            weekRequirement = week,
                            nextDuty = next,
                            activities = activities,
                            coreState = coreState,
                        ))
                    }
            }
        }.sortedWith(
            compareBy<PlanSnapshot> { healthPriority(it.progress.health) }
                .thenByDescending { it.progress.behindBy }
                .thenBy { it.student.fullName },
        )
        planSnapshotMemoryDate = today
        planSnapshotMemory = result
        return result
    }

    private fun recitationMatchesPlanType(planType: String, activityType: String): Boolean = when (planType) {
        "hifz" -> activityType in setOf("new_hifz", "hifz")
        "review" -> activityType in setOf("review", "review_near", "review_far")
        "sard" -> activityType in setOf("sard", "test")
        "tathbit" -> activityType in setOf("tathbit", "review_far")
        else -> false
    }

    private fun smartPlanWeekRequirement(
        plan: SmartPlanEngine.Plan,
        progress: SmartPlanEngine.Progress,
        today: LocalDate,
    ): PlanWeekRequirement {
        val weekEnd = today.plusDays(6)
        val weekDays = SmartPlanEngine.planDates(plan, today, weekEnd).size
        val futureDays = SmartPlanEngine.planDates(plan, today, plan.endDate).size
        var amount = min(
            progress.remaining,
            weekDays * progress.originalDaily + if (futureDays > 0) progress.deficit * weekDays / futureDays else 0.0,
        )
        if (plan.rangeStartPage != null && amount > 0.0) amount = min(progress.remaining, ceil(amount))
        val startPage = if (progress.assignment.blockedByRetry || progress.assignment.milestone != null) {
            progress.assignment.startPage
        } else progress.nextPage
        val endPage = if (startPage != null && amount > 0.0) {
            val steps = maxOf(1, ceil(amount).toInt()) - 1
            val descendingPages = plan.rangeStartPage != null && plan.rangeEndPage != null && plan.rangeStartPage > plan.rangeEndPage
            if (descendingPages) maxOf(plan.rangeEndPage ?: 1, startPage - steps)
            else min(plan.rangeEndPage ?: 604, startPage + steps)
        } else null
        return PlanWeekRequirement(SmartPlanEngine.round(amount), startPage, endPage)
    }

    private fun smartPlanNextDuty(
        plan: SmartPlanEngine.Plan,
        studentId: String,
        recitations: List<SmartPlanEngine.Recitation>,
        events: List<SmartPlanEngine.Event>,
        today: LocalDate,
    ): PlanNextDuty? {
        val candidates = SmartPlanEngine.planDates(plan, today.plusDays(1), plan.endDate).take(4)
        for (date in candidates) {
            val progress = SmartPlanEngine.calculateProgress(plan, studentId, recitations, events, date)
            val assignment = progress.assignment
            val milestone = assignment.milestone
            if (milestone != null) {
                // RC8.3: the milestone/test remains visible as its own requirement, while
                // "next duty" must tell the teacher what Quran range follows after approval.
                val afterApproval = SmartPlanEngine.calculateProgress(
                    plan = plan,
                    studentId = studentId,
                    recitations = recitations,
                    events = events + SmartPlanEngine.Event(type = "milestone_approved", milestoneKey = milestone.key),
                    today = date,
                ).assignment
                if (afterApproval.pages > 0.001 || afterApproval.blockedByRetry || afterApproval.lineKeys.isNotEmpty()) {
                    return PlanNextDuty(date, afterApproval)
                }
                continue
            }
            if (progress.dailyTarget > 0.001 || assignment.pages > 0.001 || assignment.blockedByRetry || assignment.lineKeys.isNotEmpty()) {
                return PlanNextDuty(date, assignment)
            }
        }
        return null
    }

    private fun planRecitations(from: String, to: String, forceRefresh: Boolean = false): List<SmartPlanEngine.Recitation> {
        val owner = currentUserId()
        var arr: JSONArray? = null
        if (!forceRefresh && owner != null) {
            arr = cache.get(owner, CACHE_PLAN_RECITATIONS, maxAge = null)?.let { runCatching { JSONArray(it) }.getOrNull() }
        }
        if (arr == null && online()) {
            arr = runCatching {
                val query = "select=id,session_id,student_id,phase_id,activity_type,start_surah,start_ayah,end_surah,end_ayah,start_page,end_page,pages_count,evaluation,mistakes,prompts," +
                    "selection_data,created_at,sessions!inner(session_date)" +
                    "&sessions.session_date=gte.$from&sessions.session_date=lte.$to&order=created_at.asc&limit=10000"
                withAuthRetry { api.select("recitation_entries", query) }
            }.getOrNull()
            if (arr != null && owner != null) cache.put(owner, CACHE_PLAN_RECITATIONS, arr.toString())
        }
        if (arr == null && owner != null) {
            arr = cache.get(owner, CACHE_PLAN_RECITATIONS, maxAge = null)?.let { runCatching { JSONArray(it) }.getOrNull() }
        }
        val sessionsById = owner?.let { cachedSessions(it, maxAge = null) }.orEmpty().associateBy { it.id }
        val byId = linkedMapOf<String, SmartPlanEngine.Recitation>()
        fun toEngine(row: JSONObject, fallbackDate: String? = null): SmartPlanEngine.Recitation? {
            val dateText = row.optJSONObject("sessions")?.optString("session_date")
                ?.takeIf { it.isNotBlank() }
                ?: fallbackDate
                ?: row.optString("smart_plan_date").takeIf { it.isNotBlank() }
                ?: return null
            val date = runCatching { LocalDate.parse(dateText) }.getOrNull() ?: return null
            val selection = row.optJSONObject("selection_data") ?: JSONObject()
            val lines = selection.optJSONArray("qcf_line_keys")?.let { a ->
                (0 until a.length()).mapNotNull { a.optString(it).takeIf(String::isNotBlank) }
            }.orEmpty()
            return SmartPlanEngine.Recitation(
                id = row.optString("id"),
                studentId = row.optString("student_id"),
                activityType = row.optString("activity_type"),
                date = date,
                startPage = nullablePage(row, "start_page"),
                endPage = nullablePage(row, "end_page"),
                startSurah = if (!row.has("start_surah") || row.isNull("start_surah")) null else row.optInt("start_surah").takeIf { it in 1..114 },
                startAyah = if (!row.has("start_ayah") || row.isNull("start_ayah")) null else row.optInt("start_ayah").takeIf { it > 0 },
                endSurah = if (!row.has("end_surah") || row.isNull("end_surah")) null else row.optInt("end_surah").takeIf { it in 1..114 },
                endAyah = if (!row.has("end_ayah") || row.isNull("end_ayah")) null else row.optInt("end_ayah").takeIf { it > 0 },
                pagesCount = com.mohammedsamir.halaqati.quran.RecitationParityRules.effectivePages(row.optDouble("pages_count", 0.0), lines),
                evaluation = row.optString("evaluation").ifBlank { null },
                mistakes = row.optInt("mistakes", 0),
                prompts = row.optInt("prompts", 0),
                taggedPlanId = selection.optString("smart_plan_id")
                    .ifBlank { selection.optString("plan_id") }
                    .ifBlank { null },
                taggedPhaseId = selection.optString("smart_plan_phase_id")
                    .ifBlank { row.optString("phase_id") }
                    .ifBlank { null },
                qcfLineKeys = lines,
                createdAt = row.optString("created_at"),
            )
        }
        val source = arr ?: JSONArray()
        for (index in 0 until source.length()) {
            val row = source.optJSONObject(index) ?: continue
            val rec = toEngine(row) ?: continue
            if (rec.id.isNotBlank()) byId[rec.id] = rec
        }
        // Overlay local outbox mutations so Smart Plans rebuild from the same history the
        // teacher currently sees, even before the server round-trip succeeds.
        queueSnapshot(1500).forEach { item ->
            val dedupe = item.dedupe.orEmpty()
            if (dedupe.startsWith("recitation-delete:")) {
                val recitationId = dedupe.substringAfterLast(':')
                if (recitationId.isNotBlank()) byId.remove(recitationId)
                return@forEach
            }
            if (!dedupe.startsWith("recitation:")) return@forEach
            val body = item.body?.let { runCatching { JSONObject(it) }.getOrNull() } ?: return@forEach
            val sessionDate = sessionsById[body.optString("session_id")]?.date
            val rec = toEngine(body, sessionDate) ?: return@forEach
            if (rec.date.toString() < from || rec.date.toString() > to) return@forEach
            if (rec.id.isNotBlank()) byId[rec.id] = rec
        }
        return byId.values.sortedWith(compareBy<SmartPlanEngine.Recitation> { it.date }.thenBy { it.createdAt })
    }

    private fun cachedPlanEvents(owner: String): JSONArray? =
        cache.get(owner, CACHE_PLAN_EVENTS, maxAge = null)?.let { runCatching { JSONArray(it) }.getOrNull() }

    private fun planEvents(forceRefresh: Boolean = false): Map<String, List<SmartPlanEngine.Event>> {
        val owner = currentUserId()
        var arr = if (!forceRefresh) owner?.let(::cachedPlanEvents) ?: JSONArray() else JSONArray()
        if ((forceRefresh || arr.length() == 0) && online()) {
            runCatching {
                withAuthRetry {
                    api.select(
                        "smart_plan_events",
                        "select=client_event_id,plan_id,phase_id,student_id,event_type,payload,event_date,created_at&order=created_at.asc&limit=5000",
                    )
                }
            }.onSuccess { remote ->
                arr = remote
                owner?.let { cache.put(it, CACHE_PLAN_EVENTS, remote.toString()) }
            }
        }

        val rowsByIdentity = linkedMapOf<String, JSONObject>()
        fun addRow(row: JSONObject) {
            val planId = row.optString("plan_id")
            if (planId.isBlank()) return
            val payload = row.optJSONObject("payload") ?: JSONObject()
            val milestone = payload.optString("milestone_key").ifBlank { payload.optString("key") }
            val identity = row.optString("client_event_id").ifBlank {
                listOf(planId, row.optString("student_id"), row.optString("event_type"), milestone, row.optString("event_date")).joinToString("|")
            }
            rowsByIdentity[identity] = row
        }
        for (index in 0 until arr.length()) arr.optJSONObject(index)?.let(::addRow)
        queueSnapshot(2000).forEach { item ->
            if (!item.dedupe.orEmpty().startsWith("plan-event:")) return@forEach
            item.body?.let { runCatching { JSONObject(it) }.getOrNull() }?.let(::addRow)
        }

        val output = linkedMapOf<String, MutableList<SmartPlanEngine.Event>>()
        rowsByIdentity.values.forEach { row ->
            val planId = row.optString("plan_id")
            val payload = row.optJSONObject("payload") ?: JSONObject()
            val pages = when {
                payload.has("pages") -> payload.optDouble("pages", 0.0)
                payload.has("delta_pages") -> payload.optDouble("delta_pages", 0.0)
                payload.has("value") -> payload.optDouble("value", 0.0)
                else -> 0.0
            }
            val milestone = payload.optString("milestone_key").ifBlank { payload.optString("key") }.ifBlank { null }
            output.getOrPut(planId) { mutableListOf() } += SmartPlanEngine.Event(
                type = row.optString("event_type"),
                pages = pages,
                milestoneKey = milestone,
            )
        }
        return output
    }

    private fun defaultPlanRouteDirection(planType: String): String = when (planType) {
        "hifz" -> "reverse_surahs_forward_ayahs" // الناس إلى البقرة
        "tathbit", "review" -> "forward_surahs_forward_ayahs" // البقرة إلى الناس
        else -> "forward_surahs_forward_ayahs"
    }

    private fun planTraversalDirection(routeDirection: String?): QuranTraversalDirection = when (routeDirection) {
        "reverse_surahs_forward_ayahs" -> QuranTraversalDirection.REVERSE_SURAH_ORDER
        "forward_surahs_forward_ayahs" -> QuranTraversalDirection.FORWARD_QURAN
        else -> QuranTraversalDirection.AUTO_BY_ACTIVITY
    }

    private fun canonicalPlanLineKeys(row: PlanRow): List<String> {
        val stored = row.settings.memorizationLineKeys
        val startSurah = row.rangeStartSurah ?: return stored
        val startAyah = row.rangeStartAyah ?: return stored
        val endSurah = row.rangeEndSurah ?: return stored
        val endAyah = row.rangeEndAyah ?: return stored
        val route = row.settings.routeDirection ?: defaultPlanRouteDirection(row.type)
        val track = if (row.type == "hifz") "general_hifz" else "tathbit"
        val activity = when (row.type) {
            "hifz" -> "new_hifz"
            "sard" -> "sard"
            "tathbit" -> "review_far"
            else -> "review_near"
        }
        return runCatching {
            QuranCore.engine().calculate(
                QuranRangeRequest(
                    track = track,
                    activityType = activity,
                    selection = QuranSelection.Ayahs(
                        QuranLocation(startSurah, startAyah),
                        QuranLocation(endSurah, endAyah),
                    ),
                    direction = planTraversalDirection(route),
                ),
            ).qcfLineKeys
        }.getOrElse { stored }
    }

    private fun PlanRow.toEnginePlan(): SmartPlanEngine.Plan? {
        val start = runCatching { LocalDate.parse(startDate) }.getOrNull() ?: return null
        val end = runCatching { LocalDate.parse(endDate) }.getOrNull() ?: return null
        if (id.isBlank() || halaqaId.isBlank() || target <= 0.0 || end < start) return null
        val pauses = settings.pauseRanges.mapNotNull { (fromRaw, toRaw) ->
            val from = runCatching { LocalDate.parse(fromRaw) }.getOrNull() ?: return@mapNotNull null
            val to = runCatching { LocalDate.parse(toRaw) }.getOrNull() ?: return@mapNotNull null
            if (to < from) null else SmartPlanEngine.PauseRange(from, to)
        }
        val weekdays = scheduleWeekdays.filter { it in 0..6 }.toSet().ifEmpty { setOf(0, 1, 2, 3, 4) }
        val effectiveRouteDirection = settings.routeDirection ?: defaultPlanRouteDirection(type)
        val canonicalLineKeys = canonicalPlanLineKeys(this)
        return SmartPlanEngine.Plan(
            id = id,
            scopeType = scopeType,
            halaqaId = halaqaId,
            studentId = studentId,
            categoryId = categoryId,
            parentPlanId = parentPlanId,
            planType = type,
            targetPages = target,
            startDate = start,
            endDate = end,
            scheduleWeekdays = weekdays,
            catchUpWeekday = catchUpWeekday,
            maxDailyMultiplier = maxDailyMultiplier.coerceIn(1.0, 3.0),
            autoExtend = autoExtend,
            qualityGateEnabled = qualityGateEnabled,
            minimumEvaluation = minimumEvaluation,
            rangeStartPage = rangeStartPage,
            rangeEndPage = rangeEndPage,
            milestoneMode = milestoneMode,
            milestoneRequiresApproval = milestoneRequiresApproval,
            delayAlertDays = delayAlertDays,
            status = status,
            updatedAt = updatedAt,
            createdAt = createdAt,
            settings = SmartPlanEngine.Settings(
                minimumDailyMode = settings.minimumDailyMode,
                minimumDailyPages = settings.minimumDailyPages,
                pauseRanges = pauses,
                intensiveWeekFrom = settings.intensiveWeekFrom?.let { runCatching { LocalDate.parse(it) }.getOrNull() },
                intensiveWeekTo = settings.intensiveWeekTo?.let { runCatching { LocalDate.parse(it) }.getOrNull() },
                intensiveWeekdays = settings.intensiveWeekdays.filter { it in 0..6 }.toSet(),
                memorizationLineKeys = canonicalLineKeys,
                routeDirection = effectiveRouteDirection,
            ),
        )
    }


    private fun SmartPlanPhaseRow.toEnginePhase(): SmartPlanPhaseEngine.Phase? {
        val start = runCatching { LocalDate.parse(startDate) }.getOrNull() ?: return null
        val end = runCatching { LocalDate.parse(endDate) }.getOrNull() ?: return null
        if (id.isBlank() || planId.isBlank() || end < start) return null
        return SmartPlanPhaseEngine.Phase(
            id = id,
            planId = planId,
            order = phaseOrder,
            type = phaseType,
            startDate = start,
            endDate = end,
            scheduleWeekdays = scheduleWeekdays.filter { it in 0..6 }.toSet().ifEmpty { setOf(0,1,2,3,4) },
            goalMode = goalMode,
            targetPages = targetPages,
            targetUnits = targetUnits,
            goalUnit = goalUnit,
            distributionMode = distributionMode,
            startMode = startMode,
            rangeStartPage = rangeStartPage,
            rangeEndPage = rangeEndPage,
            rangeStartSurah = rangeStartSurah,
            rangeStartAyah = rangeStartAyah,
            rangeEndSurah = rangeEndSurah,
            rangeEndAyah = rangeEndAyah,
            allowSurplus = allowSurplus,
            status = status,
        )
    }

    private fun phaseAwarePlan(
        baseRow: PlanRow,
        basePlan: SmartPlanEngine.Plan,
        phaseRow: SmartPlanPhaseRow?,
        phaseState: SmartPlanPhaseStateRow?,
        phaseEngineOverride: SmartPlanPhaseEngine.Phase? = null,
    ): Pair<PlanRow, SmartPlanEngine.Plan> {
        val phase = phaseEngineOverride ?: phaseRow?.toEnginePhase() ?: return baseRow to basePlan
        val state = phaseState?.let {
            SmartPlanPhaseEngine.StudentState(
                phaseId = it.phaseId,
                studentId = it.studentId,
                status = it.status,
                targetPagesOverride = it.targetPagesOverride,
                startDateOverride = it.startDateOverride?.let { raw -> runCatching { LocalDate.parse(raw) }.getOrNull() },
                endDateOverride = it.endDateOverride?.let { raw -> runCatching { LocalDate.parse(raw) }.getOrNull() },
                frozenCompletedPages = it.frozenCompletedPages,
                frozenTargetPages = it.frozenTargetPages,
                carriedShortfallPages = it.carryShortfallPages,
                completionPercent = it.completionPercent,
            )
        }
        val resolvedTarget = SmartPlanPhaseEngine.resolvedTargetPages(phase, state)
        val effectiveTarget = ((resolvedTarget ?: 0.0) + (phaseState?.carryShortfallPages ?: 0.0)).coerceAtLeast(0.0)
        val phaseRoute = if (phase.type == "sard") {
            baseRow.settings.sardRouteDirection ?: "forward_surahs_forward_ayahs"
        } else basePlan.settings.routeDirection ?: defaultPlanRouteDirection("hifz")
        val phaseLineKeys = if (phase.type == "hifz") basePlan.settings.memorizationLineKeys else emptyList()
        val phaseRowForUi = baseRow.copy(
            type = phase.type,
            target = effectiveTarget,
            startDate = phase.startDate.toString(),
            endDate = phase.endDate.toString(),
            // phaseEngineOverride may be present even when no backing row is available.
            title = phaseRow?.title?.takeIf { it.isNotBlank() } ?: baseRow.title,
            rangeStartPage = phase.rangeStartPage ?: if (phase.type == "hifz") baseRow.rangeStartPage else null,
            rangeEndPage = phase.rangeEndPage ?: if (phase.type == "hifz") baseRow.rangeEndPage else null,
            rangeStartSurah = phase.rangeStartSurah ?: if (phase.type == "hifz") baseRow.rangeStartSurah else null,
            rangeStartAyah = phase.rangeStartAyah ?: if (phase.type == "hifz") baseRow.rangeStartAyah else null,
            rangeEndSurah = phase.rangeEndSurah ?: if (phase.type == "hifz") baseRow.rangeEndSurah else null,
            rangeEndAyah = phase.rangeEndAyah ?: if (phase.type == "hifz") baseRow.rangeEndAyah else null,
            scheduleWeekdays = phase.scheduleWeekdays.toList(),
            settings = baseRow.settings.copy(
                memorizationLineKeys = phaseLineKeys,
                routeDirection = phaseRoute,
                enabledActivities = listOf(if (phase.type == "sard") "sard" else "hifz"),
                // A Sard phase owns its target. An open phase must never inherit a legacy
                // parent-plan Sard target, otherwise it silently becomes a fixed-goal phase.
                sardTargetPages = if (phase.type == "sard") effectiveTarget else baseRow.settings.sardTargetPages,
            ),
        )
        val engine = basePlan.copy(
            planType = phase.type,
            targetPages = effectiveTarget,
            startDate = phase.startDate,
            endDate = phase.endDate,
            scheduleWeekdays = phase.scheduleWeekdays,
            catchUpWeekday = null,
            rangeStartPage = phaseRowForUi.rangeStartPage,
            rangeEndPage = phaseRowForUi.rangeEndPage,
            milestoneMode = if (phase.type == "hifz") basePlan.milestoneMode else "none",
            milestoneRequiresApproval = phase.type == "hifz" && basePlan.milestoneRequiresApproval,
            settings = basePlan.settings.copy(
                memorizationLineKeys = phaseLineKeys,
                routeDirection = phaseRoute,
            ),
        )
        return phaseRowForUi to engine
    }

    private fun nullablePage(row: JSONObject, name: String): Int? =
        if (!row.has(name) || row.isNull(name)) null else row.optInt(name).takeIf { it in 1..604 }

    private fun healthPriority(value: String): Int = when (value) {
        "red" -> 0
        "yellow" -> 1
        else -> 2
    }

    /**
     * Stale-while-revalidate table reader. Ordinary screen opens are local-first;
     * only an explicit refresh waits for the server. The background sync worker
     * refreshes these snapshots after connectivity returns.
     */
    fun table(
        table: String,
        query: String = "select=*&order=created_at.desc&limit=250",
        forceRefresh: Boolean = false,
    ): JSONArray {
        val owner = currentUserId() ?: return JSONArray()
        if (table == "students") {
            Regex("(?:^|&)id=eq\\.([^&]+)").find(query)?.groupValues?.getOrNull(1)?.let { id ->
                studentRaw(id)?.let { return JSONArray().put(it) }
            }
        }
        val key = "table:$table:${query.hashCode()}"
        val cached = cache.get(owner, key, null)?.let { runCatching { JSONArray(it) }.getOrNull() }
        if (!forceRefresh && cached != null) {
            if (online()) scheduleSync()
            return cached
        }
        if (!online()) return cached ?: JSONArray()
        return runCatching { withAuthRetry { api.select(table, query) } }
            .onSuccess { cache.put(owner, key, it.toString()) }
            .getOrElse { cached ?: JSONArray() }
    }

    fun accountProfiles(forceRefresh: Boolean = false): JSONArray {
        val owner = currentUserId() ?: return JSONArray()
        val cached = cache.get(owner, CACHE_ACCOUNTS, null)?.let { runCatching { JSONArray(it) }.getOrNull() }
        if (!forceRefresh && cached != null) {
            if (online()) scheduleSync()
            return cached
        }
        if (!online()) return cached ?: JSONArray()
        return runCatching {
            withAuthRetry {
                api.select(
                    "profiles",
                    "select=id,full_name,email,phone,role,requested_role,approval_status,active,approved_at,rejection_reason,created_at" +
                        "&order=created_at.desc&limit=1000",
                )
            }
        }.onSuccess { cache.put(owner, CACHE_ACCOUNTS, it.toString()) }
            .getOrElse { cached ?: JSONArray() }
    }

    private fun requireDirectAccountConnection() {
        require(online()) { "تعديل الحسابات يحتاج اتصالاً مباشراً بالخادم" }
    }

    fun approveAccount(userId: String, role: String) {
        requireDirectAccountConnection()
        require(role in setOf("guardian", "teacher", "supervisor")) { "الصلاحية المطلوبة غير صالحة" }
        val uid = store.load()?.userId ?: error("الجلسة غير صالحة")
        withAuthRetry {
            api.patch(
                "profiles",
                "id=eq.$userId",
                JSONObject()
                    .put("role", role)
                    .put("requested_role", role)
                    .put("approval_status", "approved")
                    .put("active", true)
                    .put("approved_at", java.time.Instant.now().toString())
                    .put("approved_by", uid)
                    .put("rejection_reason", JSONObject.NULL),
            )
        }
    }

    fun rejectAccount(userId: String, reason: String) {
        requireDirectAccountConnection()
        withAuthRetry {
            api.patch(
                "profiles",
                "id=eq.$userId",
                JSONObject()
                    .put("approval_status", "rejected")
                    .put("active", false)
                    .put("rejection_reason", reason.trim().takeIf { it.isNotBlank() } ?: JSONObject.NULL),
            )
        }
    }

    fun setAccountActive(userId: String, active: Boolean) {
        requireDirectAccountConnection()
        withAuthRetry { api.patch("profiles", "id=eq.$userId", JSONObject().put("active", active)) }
    }

    fun changeAccountRole(userId: String, role: String) {
        requireDirectAccountConnection()
        require(role in setOf("guardian", "teacher", "supervisor")) { "الصلاحية المطلوبة غير صالحة" }
        withAuthRetry {
            api.patch(
                "profiles",
                "id=eq.$userId&role=neq.admin",
                JSONObject().put("role", role).put("requested_role", role),
            )
        }
    }

    fun deleteAccountPermanently(userId: String) {
        requireDirectAccountConnection()
        val raw = withAuthRetry { api.rpc("admin_delete_account", JSONObject().put("target_user", userId)) }.trim()
        if (raw.equals("false", true) || raw.isBlank()) error("تعذر حذف الحساب نهائياً")
    }

    fun guardianAccounts(forceRefresh: Boolean = false): JSONArray {
        val owner = currentUserId() ?: return JSONArray()
        val cached = cache.get(owner, CACHE_GUARDIAN_ACCOUNTS, null)?.let { runCatching { JSONArray(it) }.getOrNull() }
        if (!forceRefresh && cached != null) return cached
        if (!online()) return cached ?: JSONArray()
        return runCatching {
            val raw = withAuthRetry { api.rpc("list_guardian_accounts") }
            JSONArray(raw)
        }.onSuccess { cache.put(owner, CACHE_GUARDIAN_ACCOUNTS, it.toString()) }
            .getOrElse { cached ?: JSONArray() }
    }

    private fun pendingPrimaryGuardianId(studentId: String): Pair<Boolean, String?> {
        val pending = queueSnapshot(2_000)
            .asSequence()
            .filter { it.path == "/rest/v1/rpc/set_student_primary_guardian" }
            .mapNotNull { item ->
                val body = item.body?.let { runCatching { JSONObject(it) }.getOrNull() } ?: return@mapNotNull null
                if (body.optString("p_student_id") != studentId) return@mapNotNull null
                item.created to if (!body.has("p_guardian_id") || body.isNull("p_guardian_id")) null
                else body.optString("p_guardian_id").takeIf { it.isNotBlank() }
            }
            .maxByOrNull { it.first }
        return if (pending == null) false to null else true to pending.second
    }

    fun primaryGuardianId(studentId: String, forceRefresh: Boolean = false): String? {
        if (studentId.isBlank()) return null
        pendingPrimaryGuardianId(studentId).let { pending -> if (pending.first) return pending.second }
        val rows = table(
            "student_guardians",
            "select=guardian_id,is_primary&student_id=eq.$studentId&is_primary=eq.true&limit=1",
            forceRefresh = forceRefresh,
        )
        return rows.optJSONObject(0)?.optString("guardian_id")?.takeIf { it.isNotBlank() }
    }

    fun linkPrimaryGuardian(studentId: String, guardianId: String?) {
        require(studentId.isNotBlank()) { "الطالب غير صالح" }
        val args = JSONObject().put("p_student_id", studentId)
        if (guardianId.isNullOrBlank()) args.put("p_guardian_id", JSONObject.NULL) else args.put("p_guardian_id", guardianId)
        // Always use the same durable outbox as the student write. For a new student this guarantees
        // that the student INSERT is uploaded before the guardian FK/RPC, while existing students still
        // update optimistically through pendingPrimaryGuardianId().
        queued(
            "POST",
            "/rest/v1/rpc/set_student_primary_guardian",
            args,
            dedupe = "student-guardian:$studentId",
        )
        currentUserId()?.let { owner ->
            cache.invalidate(owner, "table:student_guardians:")
            cache.invalidate(owner, CACHE_GUARDIAN_ACCOUNTS)
        }
    }


    fun reportRecitations(
        from: String,
        to: String,
        track: String = "all",
        halaqaId: String = "all",
        sessionType: String = "all",
        forceRefresh: Boolean = false,
    ): JSONArray {
        require(track in setOf("all", "general_hifz", "tathbit")) { "المسار غير صالح" }
        require(sessionType in setOf("all", "tasmee", "sard", "review", "test", "tajweed", "lesson", "other")) { "نوع اللقاء غير صالح" }
        val trackFilter = if (track == "all") "" else "&${StudentTrackRules.postgrestFilter("students.track_code", track)}"
        val halaqaFilter = if (halaqaId == "all") "" else "&sessions.halaqa_id=eq.$halaqaId"
        val typeFilter = if (sessionType == "all") "" else "&sessions.session_type=eq.$sessionType"
        val query = "select=student_id,activity_type,pages_count,mistakes,prompts,evaluation,safety_percentage,points,created_at," +
            "students!inner(full_name,track_code,halaqa_id),sessions!inner(session_date,halaqa_id,session_type,status)" +
            "&sessions.session_date=gte.$from&sessions.session_date=lte.$to&sessions.status=neq.cancelled" +
            "$trackFilter$halaqaFilter$typeFilter&order=created_at.asc&limit=10000"
        return table("recitation_entries", query, forceRefresh = forceRefresh)
    }

    /** Native parity with the legacy reportStatsRows engine.
     * Keeps all active RLS-visible students in the selected track, including zero-activity rows.
     */
    fun reportSummary(
        from: String,
        to: String,
        track: String = "all",
        halaqaId: String = "all",
        sessionType: String = "all",
        forceRefresh: Boolean = false,
    ): JSONArray {
        val start = runCatching { LocalDate.parse(from) }.getOrElse { error("تاريخ البداية غير صالح") }
        val end = runCatching { LocalDate.parse(to) }.getOrElse { error("تاريخ النهاية غير صالح") }
        require(end >= start) { "الفترة غير صالحة" }
        require(track in setOf("all", "general_hifz", "tathbit")) { "المسار غير صالح" }
        require(sessionType in setOf("all", "tasmee", "sard", "review", "test", "tajweed", "lesson", "other")) { "نوع اللقاء غير صالح" }

        val studentTrack = if (track == "all") "" else "&${StudentTrackRules.postgrestFilter("track_code", track)}"
        val studentHalaqa = if (halaqaId == "all") "" else "&halaqa_id=eq.$halaqaId"
        val students = table(
            "students",
            "select=id,full_name,track_code,category_id,halaqa_id,status&status=eq.active$studentTrack$studentHalaqa&order=full_name.asc&limit=2000",
            forceRefresh = forceRefresh,
        )
        val categories = table("student_categories", "select=id,name&limit=1000", forceRefresh = forceRefresh)
        val categoryNames = buildMap<String, String> {
            for (i in 0 until categories.length()) {
                categories.optJSONObject(i)?.let { row ->
                    row.optString("id").takeIf { it.isNotBlank() }?.let { put(it, row.optString("name")) }
                }
            }
        }

        val sessionHalaqa = if (halaqaId == "all") "" else "&sessions.halaqa_id=eq.$halaqaId"
        val sessionTypeFilter = if (sessionType == "all") "" else "&sessions.session_type=eq.$sessionType"
        val sessionFilters = "&sessions.session_date=gte.$from&sessions.session_date=lte.$to&sessions.status=neq.cancelled$sessionHalaqa$sessionTypeFilter"
        val recitations = table(
            "recitation_entries",
            "select=student_id,activity_type,pages_count,mistakes,prompts,points,safety_percentage," +
                "sessions!inner(session_date,halaqa_id,session_type,status)$sessionFilters&limit=20000",
            forceRefresh = forceRefresh,
        )
        val attendance = table(
            "attendance_records",
            "select=student_id,status,sessions!inner(session_date,halaqa_id,session_type,status)$sessionFilters&limit=20000",
            forceRefresh = forceRefresh,
        )
        val extraPoints = table(
            "student_points",
            "select=student_id,points&awarded_at=gte.$from&awarded_at=lte.$to&limit=10000",
            forceRefresh = forceRefresh,
        )

        data class Aggregate(
            val student: JSONObject,
            var hifz: Double = 0.0,
            var tathbit: Double = 0.0,
            var review: Double = 0.0,
            var sard: Double = 0.0,
            var tilawah: Double = 0.0,
            var mistakes: Int = 0,
            var prompts: Int = 0,
            var recitationPoints: Double = 0.0,
            var bonusPoints: Double = 0.0,
            var safetySum: Double = 0.0,
            var safetyCount: Int = 0,
            var present: Int = 0,
            var absent: Int = 0,
            var excused: Int = 0,
            var late: Int = 0,
        )

        val byStudent = linkedMapOf<String, Aggregate>()
        for (i in 0 until students.length()) {
            val student = students.optJSONObject(i) ?: continue
            val id = student.optString("id")
            if (id.isNotBlank()) byStudent[id] = Aggregate(student)
        }
        for (i in 0 until attendance.length()) {
            val row = attendance.optJSONObject(i) ?: continue
            val aggregate = byStudent[row.optString("student_id")] ?: continue
            when (row.optString("status")) {
                "present" -> aggregate.present++
                "absent" -> aggregate.absent++
                "excused" -> aggregate.excused++
                "late" -> aggregate.late++
            }
        }
        for (i in 0 until recitations.length()) {
            val row = recitations.optJSONObject(i) ?: continue
            val aggregate = byStudent[row.optString("student_id")] ?: continue
            val pages = row.optDouble("pages_count", 0.0).coerceAtLeast(0.0)
            when {
                row.optString("activity_type") == "new_hifz" && aggregate.student.optString("track_code") == "tathbit" -> aggregate.tathbit += pages
                row.optString("activity_type") == "new_hifz" -> aggregate.hifz += pages
                row.optString("activity_type").contains("review") -> aggregate.review += pages
                row.optString("activity_type") == "sard" -> aggregate.sard += pages
                else -> aggregate.tilawah += pages
            }
            aggregate.mistakes += row.optInt("mistakes", 0).coerceAtLeast(0)
            aggregate.prompts += row.optInt("prompts", 0).coerceAtLeast(0)
            aggregate.recitationPoints += row.optDouble("points", 0.0)
            if (row.has("safety_percentage") && !row.isNull("safety_percentage")) {
                aggregate.safetySum += row.optDouble("safety_percentage", 0.0).coerceIn(0.0, 100.0)
                aggregate.safetyCount++
            }
        }
        for (i in 0 until extraPoints.length()) {
            val row = extraPoints.optJSONObject(i) ?: continue
            byStudent[row.optString("student_id")]?.let { it.bonusPoints += row.optDouble("points", 0.0) }
        }

        // RC11: enrich monthly rows with separate Hifz/Sard phase targets. This keeps
        // Sard achievement out of the Hifz total while preserving the existing activity totals.
        val reportPlans = plans(forceRefresh = forceRefresh).filter { plan ->
            plan.status != "archived" && plan.startDate <= to && plan.endDate >= from &&
                (halaqaId == "all" || plan.halaqaId == halaqaId)
        }
        val reportPhases = planPhases(forceRefresh = forceRefresh).filter { phase ->
            phase.status != "archived" && phase.startDate <= to && phase.endDate >= from
        }
        val reportPhasesByPlan = reportPhases.groupBy { it.planId }
        val reportPhaseStates = planPhaseStates(forceRefresh = forceRefresh).associateBy { it.phaseId to it.studentId }
        fun phasesForStudent(student: JSONObject): List<SmartPlanPhaseRow> {
            val sid = student.optString("id")
            val hid = student.optString("halaqa_id")
            val cid = student.optString("category_id")
            val matches = reportPlans.filter { plan ->
                plan.halaqaId == hid && when (plan.scopeType) {
                    "student" -> plan.studentId == sid
                    "category" -> !plan.categoryId.isNullOrBlank() && plan.categoryId == cid
                    else -> true
                } && reportPhasesByPlan[plan.id].orEmpty().isNotEmpty()
            }
            val priority = mapOf("halaqa" to 1, "category" to 2, "student" to 3)
            val selected = matches.maxByOrNull { priority[it.scopeType] ?: 0 } ?: return emptyList()
            return reportPhasesByPlan[selected.id].orEmpty()
        }

        val ordered = byStudent.values.sortedWith(
            compareByDescending<Aggregate> { it.recitationPoints + it.bonusPoints }
                .thenByDescending { it.hifz + it.tathbit + it.review + it.sard + it.tilawah }
                .thenBy { it.student.optString("full_name") },
        )
        return JSONArray().apply {
            ordered.forEach { a ->
                val categoryId = a.student.optString("category_id")
                val totalPages = a.hifz + a.tathbit + a.review + a.sard + a.tilawah
                val studentId = a.student.optString("id")
                val studentPhases = phasesForStudent(a.student)
                val hifzPhase = studentPhases.firstOrNull { it.phaseType == "hifz" }
                val sardPhase = studentPhases.firstOrNull { it.phaseType == "sard" }
                fun targetFor(phase: SmartPlanPhaseRow?): Double? {
                    phase ?: return null
                    val state = reportPhaseStates[phase.id to studentId]
                    state?.frozenTargetPages?.let { return it }
                    val base = state?.targetPagesOverride ?: phase.targetPages
                        ?: if (phase.goalMode == "juz") phase.targetUnits?.times(20.0) else null
                    return base?.plus(state?.carryShortfallPages ?: 0.0)
                }
                fun completedFor(phase: SmartPlanPhaseRow?, fallback: Double): Double {
                    phase ?: return fallback
                    val state = reportPhaseStates[phase.id to studentId]
                    return state?.frozenCompletedPages ?: fallback
                }
                val hifzTarget = targetFor(hifzPhase)
                val sardTarget = targetFor(sardPhase)
                val hifzCompleted = completedFor(hifzPhase, a.hifz)
                val sardCompleted = completedFor(sardPhase, a.sard)
                val qualityPercent = if (a.safetyCount > 0) a.safetySum / a.safetyCount else 0.0
                val qualityLabel = when {
                    a.safetyCount == 0 -> "—"
                    qualityPercent >= 90.0 -> "ممتاز"
                    qualityPercent >= 80.0 -> "جيد جدًا"
                    qualityPercent >= 70.0 -> "جيد"
                    else -> "يحتاج متابعة"
                }
                put(
                    JSONObject()
                        .put("student_id", a.student.optString("id"))
                        .put("student_name", a.student.optString("full_name", "طالب"))
                        .put("track_code", StudentTrackRules.canonicalStored(a.student.optString("track_code", "general_hifz")))
                        .put("category_name", categoryNames[categoryId].orEmpty())
                        .put("hifz_pages", kotlin.math.round(hifzCompleted * 100.0) / 100.0)
                        .put("tathbit_pages", kotlin.math.round(a.tathbit * 100.0) / 100.0)
                        .put("review_pages", kotlin.math.round(a.review * 100.0) / 100.0)
                        .put("sard_pages", kotlin.math.round(sardCompleted * 100.0) / 100.0)
                        .put("tilawah_pages", kotlin.math.round(a.tilawah * 100.0) / 100.0)
                        .put("total_pages", kotlin.math.round(totalPages * 100.0) / 100.0)
                        .put("hifz_target_pages", hifzTarget ?: JSONObject.NULL)
                        .put("sard_target_pages", sardTarget ?: JSONObject.NULL)
                        .put("hifz_phase_percent", hifzTarget?.takeIf { it > .001 }?.let { kotlin.math.round(hifzCompleted / it * 1000.0) / 10.0 } ?: JSONObject.NULL)
                        .put("sard_phase_percent", sardTarget?.takeIf { it > .001 }?.let { kotlin.math.round(sardCompleted / it * 1000.0) / 10.0 } ?: JSONObject.NULL)
                        .put("quality_percent", kotlin.math.round(qualityPercent * 10.0) / 10.0)
                        .put("quality_label", qualityLabel)
                        .put("mistakes", a.mistakes)
                        .put("prompts", a.prompts)
                        .put("present", a.present)
                        .put("absent", a.absent)
                        .put("excused", a.excused)
                        .put("late", a.late)
                        .put("sessions", a.present + a.absent + a.excused + a.late)
                        .put("recitation_points", kotlin.math.round(a.recitationPoints * 100.0) / 100.0)
                        .put("bonus_points", kotlin.math.round(a.bonusPoints * 100.0) / 100.0)
                        .put("points", kotlin.math.round((a.recitationPoints + a.bonusPoints) * 100.0) / 100.0),
                )
            }
        }
    }

    fun rankingRange(
        from: String,
        to: String,
        programTrack: String = "general_hifz",
        rankingTrack: String = "hifz",
    ): JSONArray {
        val canonicalProgram = com.mohammedsamir.halaqati.quran.RecitationParityRules.canonicalProgramTrack(programTrack)
        require(rankingTrack in setOf("hifz", "review", "sard")) { "مسار الترتيب غير صالح" }
        val query = "select=student_id,pages_count,mistakes,prompts,points,activity_type,selection_data," +
            "students!inner(full_name,category_id,track_code),sessions!inner(session_date)" +
            "&sessions.session_date=gte.$from&sessions.session_date=lte.$to&limit=10000"
        val owner = currentUserId()
        val rankingCacheKey = "$CACHE_RANKING_PREFIX$from:$to:$canonicalProgram:$rankingTrack"
        var source = owner?.let { cache.get(it, CACHE_RANKING_SOURCE, maxAge = null) }
            ?.let { runCatching { JSONArray(it) }.getOrNull() }
            ?: JSONArray()
        if (source.length() == 0) source = table("recitation_entries", query)
        data class Aggregate(
            val student: JSONObject,
            var points: Double = 0.0,
            var pages: Double = 0.0,
            var mistakes: Int = 0,
            var prompts: Int = 0,
        )
        val byStudent = linkedMapOf<String, Aggregate>()
        for (index in 0 until source.length()) {
            val row = source.optJSONObject(index) ?: continue
            val sessionDate = row.optJSONObject("sessions")?.optString("session_date").orEmpty()
            if (sessionDate.isNotBlank() && (sessionDate < from || sessionDate > to)) continue
            val student = row.optJSONObject("students") ?: JSONObject()
            val studentTrack = com.mohammedsamir.halaqati.quran.RecitationParityRules.canonicalProgramTrack(student.optString("track_code"))
            if (studentTrack != canonicalProgram) continue
            if (!com.mohammedsamir.halaqati.quran.RecitationParityRules.activityMatchesRanking(row.optString("activity_type"), rankingTrack)) continue
            val id = row.optString("student_id")
            if (id.isBlank()) continue
            val selection = row.optJSONObject("selection_data") ?: JSONObject()
            val lines = selection.optJSONArray("qcf_line_keys")?.let { a ->
                (0 until a.length()).mapNotNull { a.optString(it).takeIf(String::isNotBlank) }
            }.orEmpty()
            val effectivePages = com.mohammedsamir.halaqati.quran.RecitationParityRules.effectivePages(row.optDouble("pages_count", 0.0), lines)
            val aggregate = byStudent.getOrPut(id) { Aggregate(student) }
            aggregate.points += row.optDouble("points", 0.0)
            aggregate.pages += effectivePages
            aggregate.mistakes += row.optInt("mistakes", 0)
            aggregate.prompts += row.optInt("prompts", 0)
        }
        val ordered = byStudent.entries.sortedWith(
            compareByDescending<Map.Entry<String, Aggregate>> { it.value.points }
                .thenByDescending { it.value.pages }
                .thenBy { (it.value.mistakes + it.value.prompts * 0.5) / it.value.pages.coerceAtLeast(0.0001) },
        )
        val result = JSONArray().apply {
            ordered.forEach { (id, aggregate) ->
                put(
                    JSONObject()
                        .put("student_id", id)
                        .put("students", aggregate.student)
                        .put("student_name", aggregate.student.optString("full_name", "طالب"))
                        .put("points", kotlin.math.round(aggregate.points * 100.0) / 100.0)
                        .put("pages", kotlin.math.round(aggregate.pages * 100.0) / 100.0)
                        .put("mistakes", aggregate.mistakes)
                        .put("prompts", aggregate.prompts)
                        .put("track", rankingTrack)
                        .put("program_track", canonicalProgram),
                )
            }
        }
        if (result.length() > 0) owner?.let { cache.put(it, rankingCacheKey, result.toString()) }
        if (result.length() == 0) {
            owner?.let { cache.get(it, rankingCacheKey, maxAge = null) }?.let { raw ->
                runCatching { JSONArray(raw) }.getOrNull()?.let { return it }
            }
        }
        return result
    }

    fun firstHalaqaId(): String? {
        val owner = currentUserId() ?: return null
        val cached = cache.get(owner, CACHE_PRIMARY_HALAQA, maxAge = null)
            ?.let { runCatching { JSONObject(it).optString("id") }.getOrNull() }
            ?.takeIf { it.isNotBlank() }
        val localStudentHalaqa = offlineDb.students().all(owner).firstOrNull { !it.halaqaId.isNullOrBlank() }?.halaqaId
        val fallback = cached ?: localStudentHalaqa
        if (!online()) return fallback
        return runCatching {
            withAuthRetry {
                api.select("halaqas", "select=id&active=eq.true&order=created_at.asc&limit=1")
            }.optJSONObject(0)?.optString("id")?.takeIf { it.isNotBlank() }
        }.getOrNull()?.also { id -> cache.put(owner, CACHE_PRIMARY_HALAQA, JSONObject().put("id", id).toString()) }
            ?: fallback
    }

    private fun queueOwnerId(): String = store.load()?.userId?.takeIf { it.isNotBlank() }
        ?: error("لا يمكن حفظ عملية محلية دون جلسة مستخدم صالحة")

    private fun queued(
        method: String,
        path: String,
        obj: JSONObject?,
        dedupe: String,
        baseUpdatedAt: String? = null,
        entityTable: String? = null,
        entityId: String? = null,
    ) {
        queue.add(queueOwnerId(), method, path, obj?.toString(), dedupe, baseUpdatedAt, entityTable, entityId)
        signalLocalMutation()
        if (entityTable in setOf("smart_plans", "smart_plan_events", "smart_plan_phases", "smart_plan_phase_states", "recitation_entries", "sessions")) {
            planSnapshotMemoryDate = null
            planSnapshotMemory = emptyList()
        }
        // WorkManager is the durable fallback. While the app is open and Android has already
        // validated the network, also kick the lightweight Outbox flusher immediately instead of
        // waiting for WorkManager scheduling latency.
        scheduleSync()
        if (online()) runCatching { AppGraph.connectivity.requestImmediateSync() }
    }

    private fun shouldQueue(error: Exception): Boolean = when (error) {
        is IOException -> true
        is SupabaseException -> error.status == 0 || error.status == 408 || error.status == 429 || error.status >= 500
        else -> false
    }

    private inline fun <T> withAuthRetry(block: () -> T): T = try {
        block()
    } catch (e: SupabaseException) {
        if (e.status != 401) throw e
        api.refresh() ?: throw e
        block()
    }

    private fun studentIdFromFilter(filter: String): String? =
        Regex("(?:^|&)id=eq\\.([^&]+)").find(filter)?.groupValues?.getOrNull(1)?.takeIf { it.isNotBlank() }

    private fun upsertPlanCache(owner: String, id: String, patch: JSONObject) {
        val current = cache.get(owner, CACHE_PLANS, maxAge = null)
            ?.let { runCatching { JSONArray(it) }.getOrNull() } ?: JSONArray()
        val output = JSONArray()
        var matched = false
        for (index in 0 until current.length()) {
            val row = current.optJSONObject(index) ?: continue
            if (row.optString("id") == id) {
                val merged = JSONObject(row.toString())
                patch.keys().forEach { key -> merged.put(key, patch.opt(key)) }
                merged.put("id", id)
                output.put(merged)
                matched = true
            } else output.put(row)
        }
        if (!matched) {
            val created = JSONObject(patch.toString()).put("id", id)
            output.put(created)
        }
        cache.put(owner, CACHE_PLANS, output.toString())
        planSnapshotMemoryDate = null
        planSnapshotMemory = emptyList()
    }

    private fun mergeStudentPatch(owner: String, id: String, patch: JSONObject): String? {
        val existing = offlineDb.students().byId(owner, id) ?: return null
        val base = existing.remoteUpdatedAt
        val merged = existing.asJson()
        patch.keys().forEach { key -> merged.put(key, patch.opt(key)) }
        merged.put("id", id)
        upsertStudentLocal(owner, merged, dirty = true)
        cache.put(owner, CACHE_STUDENTS, localStudentsJson(owner).toString())
        return base
    }

    /** RC7 writes are optimistic/local-first: Room commits before any network attempt. */
    fun write(
        table: String,
        obj: JSONObject,
        onConflict: String? = null,
        dedupe: String = "${table}:${obj.optString("id", UUID.randomUUID().toString())}",
    ): JSONArray {
        val owner = queueOwnerId()
        val id = obj.optString("id").ifBlank { UUID.randomUUID().toString().also { obj.put("id", it) } }
        val base = if (table == "students") offlineDb.students().byId(owner, id)?.remoteUpdatedAt else null
        if (table == "students") {
            val current = offlineDb.students().byId(owner, id)?.asJson() ?: JSONObject()
            obj.keys().forEach { key -> current.put(key, obj.opt(key)) }
            current.put("id", id)
            upsertStudentLocal(owner, current, dirty = true)
            cache.put(owner, CACHE_STUDENTS, localStudentsJson(owner).toString())
        }
        if (table == "smart_plans") upsertPlanCache(owner, id, obj)
        if (table == "smart_plan_phases") upsertJsonArrayCache(owner, CACHE_PLAN_PHASES, obj)
        if (table == "smart_plan_phase_states") upsertJsonArrayCache(owner, CACHE_PLAN_PHASE_STATES, obj)
        if (table == "smart_plan_phase_templates") upsertJsonArrayCache(owner, CACHE_PLAN_PHASE_TEMPLATES, obj)
        val queuedBody = if (table == "students") StudentSchemaContract.sanitize(offlineDb.students().byId(owner, id)?.asJson() ?: obj) else obj
        val path = if (table == "students") "/rest/v1/students?on_conflict=id"
        else "/rest/v1/$table${onConflict?.let { "?on_conflict=$it" }.orEmpty()}"
        queued("POST", path, queuedBody, if (table == "students") "student:$id" else dedupe, base, table, id)
        return JSONArray().put(queuedBody)
    }

    fun patch(
        table: String,
        filter: String,
        obj: JSONObject,
        dedupe: String = "$table:$filter",
    ): JSONArray {
        val owner = queueOwnerId()
        val id = if (table == "students") studentIdFromFilter(filter) else null
        val base = if (id != null) mergeStudentPatch(owner, id, obj) else null
        if (table == "students" && id != null) {
            val full = StudentSchemaContract.sanitize(offlineDb.students().byId(owner, id)?.asJson() ?: obj)
            queued("POST", "/rest/v1/students?on_conflict=id", full, "student:$id", base, table, id)
            return JSONArray().put(full)
        }
        if (table == "smart_plans") {
            Regex("(?:^|&)id=eq\\.([^&]+)").find(filter)?.groupValues?.getOrNull(1)?.let { planId ->
                upsertPlanCache(owner, planId, obj)
            }
        }
        val genericId = Regex("(?:^|&)id=eq\\.([^&]+)").find(filter)?.groupValues?.getOrNull(1)
        if (!genericId.isNullOrBlank()) {
            val cachedPatch = JSONObject(obj.toString()).put("id", genericId)
            when (table) {
                "smart_plan_phases" -> upsertJsonArrayCache(owner, CACHE_PLAN_PHASES, cachedPatch)
                "smart_plan_phase_states" -> upsertJsonArrayCache(owner, CACHE_PLAN_PHASE_STATES, cachedPatch)
                "smart_plan_phase_templates" -> upsertJsonArrayCache(owner, CACHE_PLAN_PHASE_TEMPLATES, cachedPatch)
            }
        }
        queued("PATCH", "/rest/v1/$table?$filter", obj, dedupe, base, table, id)
        return JSONArray().put(obj)
    }

    fun delete(
        table: String,
        filter: String,
        dedupe: String = "$table:$filter:delete",
    ): JSONArray {
        val owner = queueOwnerId()
        val id = if (table == "students") studentIdFromFilter(filter) else null
        val base = id?.let { offlineDb.students().byId(owner, it)?.remoteUpdatedAt }
        if (id != null) {
            offlineDb.students().tombstone(owner, id)
            cache.put(owner, CACHE_STUDENTS, localStudentsJson(owner).toString())
        }
        queued("DELETE", "/rest/v1/$table?$filter", null, if (table == "students" && id != null) "student:$id" else dedupe, base, table, id)
        return JSONArray()
    }

    /** Queue-safe mutation RPC. RPC calls that represent state changes use the same
     * durable offline queue as REST writes instead of failing when connectivity drops. */
    fun rpcWrite(
        name: String,
        args: JSONObject = JSONObject(),
        dedupe: String = "rpc:$name:${UUID.randomUUID()}",
    ): String {
        val path = "/rest/v1/rpc/$name"
        if (!online()) {
            queued("POST", path, args, dedupe)
            return ""
        }
        return try {
            withAuthRetry { api.rpc(name, args) }
        } catch (e: Exception) {
            if (!shouldQueue(e)) throw e
            queued("POST", path, args, dedupe)
            ""
        }
    }

    private fun upsertPlanEventCache(owner: String, obj: JSONObject) {
        val current = cachedPlanEvents(owner) ?: JSONArray()
        val clientId = obj.optString("client_event_id")
        val output = JSONArray()
        var replaced = false
        for (index in 0 until current.length()) {
            val row = current.optJSONObject(index) ?: continue
            if (clientId.isNotBlank() && row.optString("client_event_id") == clientId) {
                output.put(JSONObject(obj.toString()))
                replaced = true
            } else output.put(row)
        }
        if (!replaced) output.put(JSONObject(obj.toString()))
        cache.put(owner, CACHE_PLAN_EVENTS, output.toString())
    }


    private fun upsertJsonArrayCache(owner: String, key: String, obj: JSONObject, idField: String = "id") {
        val current = cache.get(owner, key, maxAge = null)?.let { runCatching { JSONArray(it) }.getOrNull() } ?: JSONArray()
        val id = obj.optString(idField)
        val output = JSONArray()
        var replaced = false
        for (index in 0 until current.length()) {
            val row = current.optJSONObject(index) ?: continue
            if (id.isNotBlank() && row.optString(idField) == id) {
                val merged = JSONObject(row.toString())
                obj.keys().forEach { keyName -> merged.put(keyName, obj.opt(keyName)) }
                output.put(merged)
                replaced = true
            } else output.put(row)
        }
        if (!replaced) output.put(JSONObject(obj.toString()))
        cache.put(owner, key, output.toString())
    }

    fun recordPlanEvent(
        planId: String,
        studentId: String,
        eventType: String,
        payload: JSONObject = JSONObject(),
    ) {
        require(eventType in setOf(
            "milestone_approved", "auto_extension", "manual_credit", "manual_debit",
            "pause", "resume", "notification_sent", "retry_required", "catch_up",
            "phase_started", "phase_completed", "phase_reopened", "phase_shortfall_carried",
        )) { "نوع حدث الخطة غير صالح" }
        val milestoneKey = payload.optString("milestone_key").ifBlank { payload.optString("key") }
        val clientEventId = if (eventType == "milestone_approved" && milestoneKey.isNotBlank()) {
            RuntimeStabilityRules.milestoneEventKey(planId, studentId, milestoneKey)
        } else UUID.randomUUID().toString()
        val obj = JSONObject()
            .put("id", clientEventId)
            .put("client_event_id", clientEventId)
            .put("plan_id", planId)
            .put("student_id", studentId)
            .put("event_type", eventType)
            .put("event_date", LocalDate.now().toString())
            .put("payload", payload)
        payload.optString("phase_id").takeIf { it.isNotBlank() }?.let { obj.put("phase_id", it) }
        val owner = store.load()?.userId
        owner?.let { obj.put("created_by", it) }
        if (!owner.isNullOrBlank()) upsertPlanEventCache(owner, obj)
        write(
            "smart_plan_events",
            obj,
            onConflict = "client_event_id",
            dedupe = "plan-event:$clientEventId",
        )
        invalidatePlanSnapshotMemory()
    }


    fun savePlanPhase(draft: SmartPlanPhaseDraft): String {
        require(draft.planId.isNotBlank()) { "الخطة الأم غير صالحة" }
        require(draft.phaseOrder > 0) { "ترتيب المرحلة غير صالح" }
        require(draft.phaseType in setOf("hifz", "sard")) { "نوع المرحلة غير صالح" }
        require(draft.goalMode in setOf("pages", "juz", "quran_range", "open")) { "نوع هدف المرحلة غير صالح" }
        require(draft.distributionMode in setOf("equal", "flexible")) { "طريقة توزيع الهدف غير صالحة" }
        require(draft.startMode in setOf("last_sard", "manual", "range_start", "plan_start")) { "بداية المرحلة غير صالحة" }
        require(draft.status in setOf("draft", "active", "completed", "archived")) { "حالة المرحلة غير صالحة" }
        val start = runCatching { LocalDate.parse(draft.startDate) }.getOrElse { error("تاريخ بداية المرحلة غير صالح") }
        val end = runCatching { LocalDate.parse(draft.endDate) }.getOrElse { error("تاريخ نهاية المرحلة غير صالح") }
        require(end >= start) { "تاريخ نهاية المرحلة يسبق البداية" }
        val weekdays = draft.scheduleWeekdays.distinct().filter { it in 0..6 }
        require(weekdays.isNotEmpty()) { "اختر يوم مرحلة واحدًا على الأقل" }
        if (draft.goalMode != "open") require((draft.targetPages ?: draft.targetUnits ?: 0.0) > 0.0) { "حدد هدف المرحلة" }
        if (draft.phaseType == "sard" && draft.startMode in setOf("manual", "range_start")) {
            require((draft.rangeStartSurah != null && draft.rangeStartAyah != null) || draft.rangeStartPage != null) {
                "حدد نقطة بداية السرد"
            }
        }
        if (draft.goalMode == "quran_range") {
            require((draft.rangeStartSurah != null && draft.rangeStartAyah != null) || draft.rangeStartPage != null) { "حدد بداية النطاق القرآني" }
            require((draft.rangeEndSurah != null && draft.rangeEndAyah != null) || draft.rangeEndPage != null) { "حدد نهاية النطاق القرآني" }
        }
        val id = draft.id?.takeIf { it.isNotBlank() } ?: UUID.randomUUID().toString()
        val now = java.time.Instant.now().toString()
        val obj = JSONObject()
            .put("id", id)
            .put("plan_id", draft.planId)
            .put("phase_order", draft.phaseOrder)
            .put("phase_type", draft.phaseType)
            .put("title", draft.title.ifBlank { if (draft.phaseType == "sard") "مرحلة السرد" else "مرحلة الحفظ" })
            .put("start_date", draft.startDate)
            .put("end_date", draft.endDate)
            .put("schedule_weekdays", JSONArray(weekdays))
            .put("goal_mode", draft.goalMode)
            .put("goal_unit", draft.goalUnit)
            .put("target_units", draft.targetUnits ?: JSONObject.NULL)
            .put("target_pages", draft.targetPages ?: JSONObject.NULL)
            .put("distribution_mode", draft.distributionMode)
            .put("start_mode", draft.startMode)
            .put("range_start_page", draft.rangeStartPage ?: JSONObject.NULL)
            .put("range_end_page", draft.rangeEndPage ?: JSONObject.NULL)
            .put("range_start_surah", draft.rangeStartSurah ?: JSONObject.NULL)
            .put("range_start_ayah", draft.rangeStartAyah ?: JSONObject.NULL)
            .put("range_end_surah", draft.rangeEndSurah ?: JSONObject.NULL)
            .put("range_end_ayah", draft.rangeEndAyah ?: JSONObject.NULL)
            .put("allow_surplus", draft.allowSurplus)
            .put("status", draft.status)
            .put("settings", draft.settings)
            .put("updated_at", now)
        store.load()?.userId?.let { obj.put("created_by", it) }
        if (draft.id.isNullOrBlank()) {
            write("smart_plan_phases", obj, onConflict = "id", dedupe = "plan-phase:$id")
        } else {
            obj.remove("created_by")
            obj.remove("id")
            patch("smart_plan_phases", "id=eq.$id", obj, dedupe = "plan-phase-update:$id")
        }
        return id
    }

    fun upsertPlanPhaseState(
        phaseId: String,
        studentId: String,
        status: String,
        targetPagesOverride: Double? = null,
        startDateOverride: String? = null,
        endDateOverride: String? = null,
        frozenCompletedPages: Double? = null,
        frozenTargetPages: Double? = null,
        completionPercent: Double? = null,
        carryShortfallPages: Double = 0.0,
        settings: JSONObject = JSONObject(),
    ): String {
        require(status in setOf("not_started", "active", "completed", "skipped")) { "حالة الطالب داخل المرحلة غير صالحة" }
        require(carryShortfallPages >= 0.0) { "العجز المرحل غير صالح" }
        val id = UUID.nameUUIDFromBytes("phase-state:$phaseId:$studentId".toByteArray()).toString()
        val now = java.time.Instant.now().toString()
        val obj = JSONObject()
            .put("id", id)
            .put("phase_id", phaseId)
            .put("student_id", studentId)
            .put("status", status)
            .put("target_pages_override", targetPagesOverride ?: JSONObject.NULL)
            .put("start_date_override", startDateOverride ?: JSONObject.NULL)
            .put("end_date_override", endDateOverride ?: JSONObject.NULL)
            .put("frozen_completed_pages", frozenCompletedPages ?: JSONObject.NULL)
            .put("frozen_target_pages", frozenTargetPages ?: JSONObject.NULL)
            .put("completion_percent", completionPercent ?: JSONObject.NULL)
            .put("carry_shortfall_pages", carryShortfallPages)
            .put("settings", settings)
            .put("updated_at", now)
        if (status == "completed") obj.put("completed_at", now)
        store.load()?.userId?.let { obj.put("updated_by", it) }
        write("smart_plan_phase_states", obj, onConflict = "phase_id,student_id", dedupe = "phase-state:$phaseId:$studentId")
        return id
    }

    fun transitionPlanStudentPhase(
        planId: String,
        studentId: String,
        fromPhaseId: String,
        toPhaseId: String,
        completedPages: Double,
        targetPages: Double?,
        carryShortfallPages: Double = 0.0,
        toTargetPagesOverride: Double? = null,
    ) {
        val percent = targetPages?.takeIf { it > 0.0 }?.let { SmartPlanEngine.round(completedPages / it * 100.0, 1) }
        upsertPlanPhaseState(
            phaseId = fromPhaseId,
            studentId = studentId,
            status = "completed",
            frozenCompletedPages = completedPages,
            frozenTargetPages = targetPages,
            completionPercent = percent,
        )
        upsertPlanPhaseState(
            phaseId = toPhaseId,
            studentId = studentId,
            status = "active",
            targetPagesOverride = toTargetPagesOverride,
            carryShortfallPages = carryShortfallPages,
        )
        recordPlanEvent(
            planId,
            studentId,
            "phase_completed",
            JSONObject().put("phase_id", fromPhaseId).put("completed_pages", completedPages).put("target_pages", targetPages ?: JSONObject.NULL),
        )
        recordPlanEvent(
            planId,
            studentId,
            "phase_started",
            JSONObject().put("phase_id", toPhaseId)
                .put("carry_shortfall_pages", carryShortfallPages)
                .put("target_pages_override", toTargetPagesOverride ?: JSONObject.NULL),
        )
    }

    fun completePlanPhaseForStudent(
        planId: String,
        phaseId: String,
        studentId: String,
        completedPages: Double,
        targetPages: Double?,
    ) {
        val percent = targetPages?.takeIf { it > .001 }?.let { SmartPlanEngine.round(completedPages / it * 100.0, 1) }
        upsertPlanPhaseState(
            phaseId = phaseId,
            studentId = studentId,
            status = "completed",
            frozenCompletedPages = completedPages,
            frozenTargetPages = targetPages,
            completionPercent = percent,
        )
        recordPlanEvent(
            planId = planId,
            studentId = studentId,
            eventType = "phase_completed",
            payload = JSONObject()
                .put("phase_id", phaseId)
                .put("completed_pages", completedPages)
                .put("target_pages", targetPages ?: JSONObject.NULL)
                .put("completion_percent", percent ?: JSONObject.NULL),
        )
    }

    fun setPlanPhaseStatus(phaseId: String, status: String) {
        require(status in setOf("draft", "active", "completed", "archived")) { "حالة المرحلة غير صالحة" }
        patch(
            "smart_plan_phases",
            "id=eq.$phaseId",
            JSONObject().put("status", status).put("updated_at", java.time.Instant.now().toString()),
            dedupe = "phase-status:$phaseId",
        )
    }

    fun savePlanPhaseTemplate(
        halaqaId: String,
        name: String,
        mode: String,
        definition: JSONObject,
        id: String? = null,
    ): String {
        require(mode in setOf("dates", "weeks", "manual")) { "نوع قالب المراحل غير صالح" }
        val templateId = id?.takeIf { it.isNotBlank() } ?: UUID.randomUUID().toString()
        val obj = JSONObject()
            .put("id", templateId)
            .put("halaqa_id", halaqaId)
            .put("name", name.trim().ifBlank { "خطة الحفظ الشهرية" })
            .put("template_mode", mode)
            .put("definition", definition)
            .put("active", true)
            .put("updated_at", java.time.Instant.now().toString())
        store.load()?.userId?.let { obj.put("created_by", it) }
        write("smart_plan_phase_templates", obj, onConflict = "id", dedupe = "phase-template:$templateId")
        return templateId
    }

    fun applyPlanPhaseTemplate(plan: PlanRow, template: SmartPlanPhaseTemplateRow): List<String> {
        require(template.halaqaId == plan.halaqaId) { "القالب لا يخص هذه الحلقة" }
        require(template.templateMode in setOf("dates", "weeks", "manual")) { "نوع قالب المراحل غير صالح" }
        require(planPhases(plan.id).none { it.status != "archived" }) { "الخطة تحتوي مراحل بالفعل" }
        val planStart = LocalDate.parse(plan.startDate)
        val planEnd = LocalDate.parse(plan.endDate)
        val month = YearMonth.from(planStart)
        val definitions = mutableListOf<SmartPlanPhaseDraft>()

        fun clamp(date: LocalDate): LocalDate = when {
            date < planStart -> planStart
            date > planEnd -> planEnd
            else -> date
        }
        fun monthDay(day: Int, fallback: LocalDate): LocalDate {
            if (day <= 0) return clamp(month.atEndOfMonth())
            return clamp(month.atDay(day.coerceIn(1, month.lengthOfMonth())))
        }
        fun addDefaultPair(hifzStart: LocalDate, hifzEnd: LocalDate, sardStart: LocalDate, sardEnd: LocalDate, source: JSONObject = template.definition) {
            val safeHifzStart = clamp(hifzStart)
            val safeHifzEnd = clamp(maxOf(safeHifzStart, hifzEnd))
            val safeSardStart = clamp(maxOf(safeHifzEnd.plusDays(1), sardStart))
            val safeSardEnd = clamp(maxOf(safeSardStart, sardEnd))
            definitions += SmartPlanPhaseDraft(
                planId = plan.id, phaseOrder = 1, phaseType = "hifz", title = "مرحلة الحفظ",
                startDate = safeHifzStart.toString(), endDate = safeHifzEnd.toString(),
                scheduleWeekdays = plan.scheduleWeekdays.ifEmpty { listOf(0, 1, 2, 3, 4) },
                goalMode = "pages", goalUnit = "pages", targetPages = plan.target,
                distributionMode = source.optString("hifz_distribution", "flexible"), startMode = "plan_start",
                rangeStartPage = plan.rangeStartPage, rangeEndPage = plan.rangeEndPage,
                rangeStartSurah = plan.rangeStartSurah, rangeStartAyah = plan.rangeStartAyah,
                rangeEndSurah = plan.rangeEndSurah, rangeEndAyah = plan.rangeEndAyah,
            )
            val sardMode = source.optString("sard_goal_mode", "juz").takeIf { it in setOf("pages", "juz", "quran_range", "open") } ?: "juz"
            val sardUnits = if (sardMode == "open") null else source.optDouble("sard_target_units", if (sardMode == "juz") 3.0 else 60.0).takeIf { it > 0.0 }
            val sardPages = when (sardMode) {
                "open" -> null
                "juz" -> sardUnits?.times(20.0)
                else -> source.optDouble("sard_target_pages", sardUnits ?: 60.0).takeIf { it > 0.0 }
            }
            definitions += SmartPlanPhaseDraft(
                planId = plan.id, phaseOrder = 2, phaseType = "sard", title = "مرحلة السرد",
                startDate = safeSardStart.toString(), endDate = safeSardEnd.toString(),
                scheduleWeekdays = listOf(0, 1, 2, 3, 4, 5),
                goalMode = sardMode, goalUnit = when (sardMode) { "juz" -> "juz"; "quran_range" -> "range"; "open" -> "open"; else -> "pages" },
                targetUnits = sardUnits, targetPages = sardPages,
                distributionMode = source.optString("sard_distribution", "flexible"),
                startMode = source.optString("sard_start_mode", "last_sard"),
            )
        }

        when (template.templateMode) {
            "dates" -> {
                val hifzStart = monthDay(template.definition.optInt("hifz_start_day", 1), planStart)
                val hifzEnd = monthDay(template.definition.optInt("hifz_end_day", 24), planStart.plusDays(23))
                val sardStart = monthDay(template.definition.optInt("sard_start_day", hifzEnd.dayOfMonth + 1), hifzEnd.plusDays(1))
                val sardEnd = monthDay(template.definition.optInt("sard_end_day", 0), planEnd)
                addDefaultPair(hifzStart, hifzEnd, sardStart, sardEnd)
            }
            "weeks" -> {
                val sardWeeks = template.definition.optInt("sard_weeks", 1).coerceAtLeast(1)
                val sardStart = maxOf(planStart.plusDays(1), planEnd.minusDays(sardWeeks * 7L - 1L))
                addDefaultPair(planStart, sardStart.minusDays(1), sardStart, planEnd)
            }
            else -> {
                val array = template.definition.optJSONArray("phases") ?: JSONArray()
                for (i in 0 until array.length()) {
                    val row = array.optJSONObject(i) ?: continue
                    val order = row.optInt("phase_order", i + 1).coerceAtLeast(1)
                    val type = row.optString("phase_type", if (order == 1) "hifz" else "sard")
                    val startOffset = row.optLong("start_offset_days", Long.MIN_VALUE)
                    val endOffset = row.optLong("end_offset_days", Long.MIN_VALUE)
                    val start = if (startOffset != Long.MIN_VALUE) clamp(planStart.plusDays(startOffset)) else clamp(runCatching { LocalDate.parse(row.optString("start_date")) }.getOrDefault(planStart))
                    val end = if (endOffset != Long.MIN_VALUE) clamp(planStart.plusDays(endOffset)) else clamp(runCatching { LocalDate.parse(row.optString("end_date")) }.getOrDefault(planEnd))
                    val mode = row.optString("goal_mode", if (type == "sard") "juz" else "pages")
                    val units = if (row.has("target_units") && !row.isNull("target_units")) row.optDouble("target_units") else null
                    val pages = if (row.has("target_pages") && !row.isNull("target_pages")) row.optDouble("target_pages") else if (type == "hifz") plan.target else null
                    val weekdays = row.optJSONArray("schedule_weekdays")?.let { a -> (0 until a.length()).map { a.optInt(it) }.filter { it in 0..6 } }
                        ?: if (type == "sard") listOf(0, 1, 2, 3, 4, 5) else plan.scheduleWeekdays
                    definitions += SmartPlanPhaseDraft(
                        planId = plan.id, phaseOrder = order, phaseType = type, title = row.optString("title", if (type == "sard") "مرحلة السرد" else "مرحلة الحفظ"),
                        startDate = start.toString(), endDate = maxOf(start, end).toString(), scheduleWeekdays = weekdays,
                        goalMode = mode, goalUnit = row.optString("goal_unit", when (mode) { "juz" -> "juz"; "quran_range" -> "range"; "open" -> "open"; else -> "pages" }),
                        targetUnits = units, targetPages = pages,
                        distributionMode = row.optString("distribution_mode", "flexible"), startMode = row.optString("start_mode", if (type == "sard") "last_sard" else "plan_start"),
                        rangeStartPage = row.optInt("range_start_page").takeIf { row.has("range_start_page") && !row.isNull("range_start_page") && it in 1..604 },
                        rangeEndPage = row.optInt("range_end_page").takeIf { row.has("range_end_page") && !row.isNull("range_end_page") && it in 1..604 },
                        rangeStartSurah = row.optInt("range_start_surah").takeIf { row.has("range_start_surah") && !row.isNull("range_start_surah") && it in 1..114 },
                        rangeStartAyah = row.optInt("range_start_ayah").takeIf { row.has("range_start_ayah") && !row.isNull("range_start_ayah") && it > 0 },
                        rangeEndSurah = row.optInt("range_end_surah").takeIf { row.has("range_end_surah") && !row.isNull("range_end_surah") && it in 1..114 },
                        rangeEndAyah = row.optInt("range_end_ayah").takeIf { row.has("range_end_ayah") && !row.isNull("range_end_ayah") && it > 0 },
                        allowSurplus = row.optBoolean("allow_surplus", true),
                    )
                }
                require(definitions.isNotEmpty()) { "القالب اليدوي لا يحتوي مراحل" }
            }
        }
        return definitions.sortedBy { it.phaseOrder }.map(::savePlanPhase)
    }

    fun setPlanStatus(planId: String, status: String) {
        require(status in setOf("draft", "active", "paused", "completed", "archived")) { "حالة الخطة غير صالحة" }
        patch(
            "smart_plans",
            "id=eq.$planId",
            JSONObject()
                .put("status", status)
                .put("updated_at", java.time.Instant.now().toString()),
            dedupe = "plan-status:$planId",
        )
    }

    fun saveSmartPlan(draft: SmartPlanDraft): String {
        require(draft.scopeType in setOf("student", "category", "halaqa")) { "نطاق الخطة غير صالح" }
        require(draft.type in setOf("hifz", "review", "sard", "tathbit")) { "نوع الخطة غير صالح" }
        require(draft.reviewTier in setOf("none", "near", "far", "both")) { "مسار المراجعة غير صالح" }
        require(draft.minimumEvaluation in setOf("excellent", "very_good", "good", "repeat")) { "أقل تقييم غير صالح" }
        require(draft.milestoneMode in setOf("none", "hizb", "juz")) { "نوع الاختبار المرحلي غير صالح" }
        require(draft.status in setOf("draft", "active", "paused", "completed", "archived")) { "حالة الخطة غير صالحة" }
        require(draft.halaqaId.isNotBlank()) { "اختر الحلقة" }
        when (draft.scopeType) {
            "student" -> require(!draft.studentId.isNullOrBlank()) { "اختر الطالب" }
            "category" -> require(!draft.categoryId.isNullOrBlank()) { "اختر الفئة" }
        }
        val start = runCatching { LocalDate.parse(draft.startDate) }.getOrElse { error("تاريخ البداية غير صالح") }
        val end = runCatching { LocalDate.parse(draft.endDate) }.getOrElse { error("تاريخ النهاية غير صالح") }
        require(end >= start) { "تاريخ النهاية يجب ألا يسبق البداية" }
        require(draft.targetPages > 0.0 && draft.targetPages <= 604.0) { "هدف الخطة يجب أن يكون بين 0 و604 صفحة" }
        val weekdays = draft.scheduleWeekdays.distinct().filter { it in 0..6 }
        require(weekdays.isNotEmpty()) { "اختر يوم دوام واحداً على الأقل" }
        require(draft.catchUpWeekday == null || draft.catchUpWeekday in 0..6) { "يوم الاستدراك غير صالح" }
        require(draft.maxDailyMultiplier in 1.0..3.0) { "أقصى زيادة يومية غير صالحة" }
        require(draft.delayAlertDays in 1..30) { "عدد أيام تنبيه التأخر غير صالح" }
        require(draft.nearRevisionPages in 0.0..30.0) { "المراجعة القريبة غير صالحة" }
        require(draft.farRevisionPages in 0.0..604.0) { "المراجعة البعيدة غير صالحة" }
        require(draft.rangeStartPage == null || draft.rangeStartPage in 1..604)
        require(draft.rangeEndPage == null || draft.rangeEndPage in 1..604)

        val now = java.time.Instant.now().toString()
        val planId = draft.id?.takeIf { it.isNotBlank() } ?: UUID.randomUUID().toString()
        val settings = JSONObject()
            .put("minimum_daily_mode", draft.minimumDailyMode.ifBlank { "dynamic" })
            .put("minimum_daily_pages", draft.minimumDailyPages.coerceAtLeast(0.0))
            .put("intensive_weekdays", JSONArray(draft.intensiveWeekdays.distinct().filter { it in 0..6 }))
            .put("memorization_line_keys", JSONArray(draft.memorizationLineKeys.filter { it.isNotBlank() }))
            .put("enabled_activities", JSONArray(SmartPlanActivityRules.enabledActivities(draft.type, draft.enabledActivities)))
            .put("sard_target_pages", draft.sardTargetPages.coerceIn(0.0, 604.0))
        draft.intensiveWeekFrom?.takeIf { it.isNotBlank() }?.let { settings.put("intensive_week_from", it) }
        draft.intensiveWeekTo?.takeIf { it.isNotBlank() }?.let { settings.put("intensive_week_to", it) }
        draft.routeDirection?.takeIf { it.isNotBlank() }?.let { settings.put("route_direction", it) }
        draft.sardRouteDirection?.takeIf { it.isNotBlank() }?.let { settings.put("sard_route_direction", it) }

        val obj = JSONObject()
            .put("id", planId)
            .put("scope_type", draft.scopeType)
            .put("halaqa_id", draft.halaqaId)
            .put("student_id", draft.studentId?.takeIf { it.isNotBlank() } ?: JSONObject.NULL)
            .put("category_id", draft.categoryId?.takeIf { it.isNotBlank() } ?: JSONObject.NULL)
            .put("parent_plan_id", draft.parentPlanId?.takeIf { it.isNotBlank() } ?: JSONObject.NULL)
            .put("plan_type", draft.type)
            .put("review_tier", if (draft.type == "review") draft.reviewTier else "none")
            .put("title", draft.title.trim().ifBlank { "${draft.type.uppercase()} ${draft.startDate}" })
            .put("goal_unit", "pages")
            .put("target_units", draft.targetPages)
            .put("target_pages", draft.targetPages)
            .put("start_date", draft.startDate)
            .put("end_date", draft.endDate)
            .put("schedule_weekdays", JSONArray(weekdays))
            .put("catch_up_weekday", draft.catchUpWeekday ?: JSONObject.NULL)
            .put("max_daily_multiplier", draft.maxDailyMultiplier)
            .put("auto_extend", draft.autoExtend)
            .put("quality_gate_enabled", draft.qualityGateEnabled)
            .put("minimum_evaluation", draft.minimumEvaluation)
            .put("range_start_page", draft.rangeStartPage ?: JSONObject.NULL)
            .put("range_end_page", draft.rangeEndPage ?: JSONObject.NULL)
            .put("range_start_surah", draft.rangeStartSurah ?: JSONObject.NULL)
            .put("range_start_ayah", draft.rangeStartAyah ?: JSONObject.NULL)
            .put("range_end_surah", draft.rangeEndSurah ?: JSONObject.NULL)
            .put("range_end_ayah", draft.rangeEndAyah ?: JSONObject.NULL)
            .put("near_revision_pages", draft.nearRevisionPages)
            .put("far_revision_pages", draft.farRevisionPages)
            .put("milestone_mode", draft.milestoneMode)
            .put("milestone_requires_approval", draft.milestoneRequiresApproval)
            .put("delay_alert_days", draft.delayAlertDays)
            .put("home_prep_push", draft.homePrepPush)
            .put("status", draft.status)
            .put("note", draft.note.trim().takeIf { it.isNotBlank() } ?: JSONObject.NULL)
            .put("settings", settings)
            .put("updated_at", now)
        store.load()?.userId?.let { obj.put("created_by", it) }

        if (draft.id.isNullOrBlank()) {
            write("smart_plans", obj, onConflict = "id", dedupe = "smart-plan:$planId")
        } else {
            obj.remove("created_by")
            obj.remove("id")
            patch("smart_plans", "id=eq.$planId", obj, dedupe = "smart-plan-update:$planId")
        }
        return planId
    }

    fun guardianDashboard(studentId: String, from: String, to: String): JSONObject {
        require(studentId.isNotBlank()) { "معرّف الطالب غير صالح" }
        val start = runCatching { LocalDate.parse(from) }.getOrElse { error("تاريخ البداية غير صالح") }
        val end = runCatching { LocalDate.parse(to) }.getOrElse { error("تاريخ النهاية غير صالح") }
        require(end >= start) { "الفترة غير صالحة" }
        val owner = currentUserId()
        val key = "$CACHE_GUARDIAN_DASHBOARD_PREFIX$studentId:$from:$to"
        val cached = owner?.let { cache.get(it, key, maxAge = null) }?.let { runCatching { JSONObject(it) }.getOrNull() }
        if (!online()) return cached ?: JSONObject()
        val result = runCatching {
            val raw = withAuthRetry {
                api.rpc(
                    "guardian_student_dashboard_range",
                    JSONObject()
                        .put("p_student_id", studentId)
                        .put("p_from", start.toString())
                        .put("p_to", end.toString()),
                )
            }
            JSONObject(raw)
        }.getOrElse { cached ?: JSONObject() }
        if (result.length() > 0) owner?.let { cache.put(it, key, result.toString()) }
        return result
    }

    fun guardianCompetition(
        studentId: String,
        track: String,
        scope: String,
        from: String,
        to: String,
    ): JSONArray {
        require(studentId.isNotBlank()) { "معرّف الطالب غير صالح" }
        require(track in setOf("hifz", "review", "sard")) { "نوع الترتيب غير صالح" }
        require(scope in setOf("center", "category", "halaqa")) { "نطاق الترتيب غير صالح" }
        val start = runCatching { LocalDate.parse(from) }.getOrElse { error("تاريخ البداية غير صالح") }
        val end = runCatching { LocalDate.parse(to) }.getOrElse { error("تاريخ النهاية غير صالح") }
        require(end >= start) { "الفترة غير صالحة" }
        val owner = currentUserId()
        val key = "$CACHE_GUARDIAN_COMPETITION_PREFIX$studentId:$track:$scope:$from:$to"
        val cached = owner?.let { cache.get(it, key, maxAge = null) }?.let { runCatching { JSONArray(it) }.getOrNull() }
        if (!online()) return cached ?: JSONArray()
        val result = runCatching {
            val raw = withAuthRetry {
                api.rpc(
                    "guardian_competition_board_range",
                    JSONObject()
                        .put("p_student_id", studentId)
                        .put("p_track", track)
                        .put("p_scope", scope)
                        .put("p_from", start.toString())
                        .put("p_to", end.toString()),
                )
            }
            JSONArray(raw)
        }.getOrElse { cached ?: JSONArray() }
        if (result.length() > 0) owner?.let { cache.put(it, key, result.toString()) }
        return result
    }

    fun openOrCreateTodaySession(halaqaId: String, date: String, assignmentKind: String): Result<SessionRow> =
        runCatching { ensureTodaySession(halaqaId, date, assignmentKind) }

    fun ensureTodaySession(halaqaId: String, date: String, assignmentKind: String): SessionRow {
        require(halaqaId.isNotBlank()) { "معرّف الحلقة غير صالح" }
        LocalDate.parse(date)
        val owner = currentUserId() ?: error("لا توجد جلسة مستخدم صالحة")
        val sessionType = SessionWorkflowRules.sessionTypeForAssignment(assignmentKind)

        cachedSessions(owner)?.firstOrNull {
            it.halaqaId == halaqaId && it.date == date && it.type == sessionType && it.status in setOf("open", "planned")
        }?.let { return it }

        if (online()) {
            val existing = runCatching {
                withAuthRetry {
                    api.select(
                        "sessions",
                        "select=*&halaqa_id=eq.$halaqaId&session_date=eq.$date&session_type=eq.$sessionType" +
                            "&status=in.(open,planned)&order=created_at.asc&limit=1",
                    )
                }.optJSONObject(0)
            }.getOrNull()
            if (existing != null) {
                return SessionRow.from(existing).also(::cacheSession)
            }
        }

        val title = when (sessionType) {
            "sard" -> "جلسة السرد"
            "review" -> "جلسة المراجعة والتثبيت"
            "test" -> "جلسة اختبار الخطة"
            else -> "جلسة تسميع اليوم"
        }
        val deterministicId = UUID.nameUUIDFromBytes(
            "today-session:$owner:$halaqaId:$date:$sessionType".toByteArray(),
        ).toString()
        val id = createSession(halaqaId, date, sessionType, title, deterministicId)
        return SessionRow(id, halaqaId, date, sessionType, title, "open")
    }

    fun createSession(
        halaqaId: String,
        date: String,
        type: String,
        title: String,
        id: String = UUID.randomUUID().toString(),
    ): String {
        require(type in SessionWorkflowRules.manualSessionTypes) { "نوع الجلسة غير صالح" }
        LocalDate.parse(date)
        val obj = JSONObject()
            .put("id", id)
            .put("halaqa_id", halaqaId)
            .put("session_date", date)
            .put("session_type", type)
            .put("title", title.takeIf { it.isNotBlank() })
            .put("status", "open")
        store.load()?.userId?.let { obj.put("created_by", it) }

        // Session work is local-first even when online. The queue preserves ordering so the
        // session row reaches Supabase before attendance/recitation rows created immediately after it.
        queued(
            method = "POST",
            path = "/rest/v1/sessions?on_conflict=id",
            obj = obj,
            dedupe = "session:$id",
        )
        cacheSession(SessionRow(id, halaqaId, date, type, title, "open"))
        return id
    }

    /** Merge an optimistic local mutation into a session-scoped JSONArray cache immediately. */
    private fun upsertSessionScopedCache(prefix: String, sessionId: String, row: JSONObject) {
        val owner = currentUserId() ?: return
        val key = prefix + sessionId
        val current = cache.get(owner, key, maxAge = null)
            ?.let { runCatching { JSONArray(it) }.getOrNull() } ?: JSONArray()
        val id = row.optString("id")
        val merged = JSONArray()
        var replaced = false
        for (index in 0 until current.length()) {
            val existing = current.optJSONObject(index) ?: continue
            if (id.isNotBlank() && existing.optString("id") == id) {
                merged.put(JSONObject(row.toString()))
                replaced = true
            } else {
                merged.put(existing)
            }
        }
        if (!replaced) merged.put(JSONObject(row.toString()))
        cache.put(owner, key, merged.toString())
    }

    private fun removeSessionScopedCacheRow(prefix: String, sessionId: String, rowId: String) {
        val owner = currentUserId() ?: return
        if (rowId.isBlank()) return
        val key = prefix + sessionId
        val current = cache.get(owner, key, maxAge = null)
            ?.let { runCatching { JSONArray(it) }.getOrNull() } ?: return
        val remaining = JSONArray()
        for (index in 0 until current.length()) {
            val existing = current.optJSONObject(index) ?: continue
            if (existing.optString("id") != rowId) remaining.put(existing)
        }
        cache.put(owner, key, remaining.toString())
    }

    private fun upsertPlanRecitationCacheRow(row: JSONObject, sessionId: String) {
        val owner = currentUserId() ?: return
        val id = row.optString("id")
        if (id.isBlank()) return
        val enriched = JSONObject(row.toString())
        if (enriched.optJSONObject("sessions") == null) {
            cachedSessions(owner, maxAge = null).orEmpty().firstOrNull { it.id == sessionId }?.date?.let { date ->
                enriched.put("sessions", JSONObject().put("session_date", date))
            }
        }
        val current = cache.get(owner, CACHE_PLAN_RECITATIONS, maxAge = null)
            ?.let { runCatching { JSONArray(it) }.getOrNull() } ?: JSONArray()
        val merged = JSONArray()
        var replaced = false
        for (index in 0 until current.length()) {
            val existing = current.optJSONObject(index) ?: continue
            if (existing.optString("id") == id) {
                merged.put(enriched)
                replaced = true
            } else merged.put(existing)
        }
        if (!replaced) merged.put(enriched)
        cache.put(owner, CACHE_PLAN_RECITATIONS, merged.toString())
    }

    private fun removePlanRecitationCacheRow(recitationId: String) {
        val owner = currentUserId() ?: return
        if (recitationId.isBlank()) return
        val current = cache.get(owner, CACHE_PLAN_RECITATIONS, maxAge = null)
            ?.let { runCatching { JSONArray(it) }.getOrNull() } ?: return
        val remaining = JSONArray()
        for (index in 0 until current.length()) {
            val existing = current.optJSONObject(index) ?: continue
            if (existing.optString("id") != recitationId) remaining.put(existing)
        }
        cache.put(owner, CACHE_PLAN_RECITATIONS, remaining.toString())
    }

    private fun invalidatePlanSnapshotMemory() {
        planSnapshotMemoryDate = null
        planSnapshotMemory = emptyList()
    }

    private fun cacheSession(row: SessionRow) {
        val owner = currentUserId() ?: return
        val current = cachedSessions(owner).orEmpty().filterNot { it.id == row.id }
        val merged = (listOf(row) + current).sortedByDescending { it.date }
        val json = JSONArray()
        merged.forEach { session ->
            json.put(
                JSONObject()
                    .put("id", session.id)
                    .put("halaqa_id", session.halaqaId)
                    .put("session_date", session.date)
                    .put("session_type", session.type)
                    .put("title", session.title)
                    .put("status", session.status)
                    .put("activity_data", JSONObject().put("archived", session.archived)),
            )
        }
        cache.put(owner, CACHE_SESSIONS, json.toString())
    }


    private fun removeSessionFromLocalCache(sessionId: String) {
        val owner = currentUserId() ?: return
        val remaining = cachedSessions(owner, maxAge = null).orEmpty().filterNot { it.id == sessionId }
        val arr = JSONArray()
        remaining.forEach { session ->
            arr.put(
                JSONObject()
                    .put("id", session.id)
                    .put("halaqa_id", session.halaqaId)
                    .put("session_date", session.date)
                    .put("session_type", session.type)
                    .put("title", session.title)
                    .put("status", session.status)
                    .put("activity_data", JSONObject().put("archived", session.archived)),
            )
        }
        cache.put(owner, CACHE_SESSIONS, arr.toString())
        cache.invalidate(owner, CACHE_SESSION_RECITATIONS_PREFIX + sessionId)
        cache.invalidate(owner, CACHE_SESSION_ATTENDANCE_PREFIX + sessionId)
        cache.invalidate(owner, CACHE_SESSION_NOTES_PREFIX + sessionId)
    }

    fun cancelSession(sessionId: String) {
        require(sessionId.isNotBlank()) { "معرّف الجلسة غير صالح" }
        patch("sessions", "id=eq.$sessionId", JSONObject().put("status", "cancelled"), dedupe = "session-cancel:$sessionId")
        removeSessionFromLocalCache(sessionId)
    }

    fun archiveSession(sessionId: String) {
        require(sessionId.isNotBlank()) { "معرّف الجلسة غير صالح" }
        patch(
            "sessions",
            "id=eq.$sessionId",
            JSONObject().put("status", "closed").put("activity_data", JSONObject().put("archived", true)),
            dedupe = "session-archive:$sessionId",
        )
        removeSessionFromLocalCache(sessionId)
    }

    fun deleteSession(sessionId: String) {
        require(sessionId.isNotBlank()) { "معرّف الجلسة غير صالح" }
        // Supabase schema has ON DELETE CASCADE from attendance_records, recitation_entries,
        // student_daily_notes and notifications to sessions. Queue one mutation instead of four;
        // this is materially faster on weak/VPN mobile links and remains atomic on the server.
        delete("sessions", "id=eq.$sessionId", dedupe = "session-delete:$sessionId")
        removeSessionFromLocalCache(sessionId)
    }

    /** RC8.6: one reconnect refresh warms recent rosters in three batched requests instead of
     * forcing every opened session to perform its own attendance/notes/recitations round-trips. */
    private fun warmRecentSessionDetails(owner: String, sessionIds: List<String>) {
        val ids = sessionIds.filter { it.isNotBlank() }.distinct().take(24)
        if (ids.isEmpty() || !online()) return
        val filter = ids.joinToString(",")
        fun distribute(rows: JSONArray, keyPrefix: String) {
            val grouped = linkedMapOf<String, JSONArray>()
            ids.forEach { grouped[it] = JSONArray() }
            for (i in 0 until rows.length()) {
                val row = rows.optJSONObject(i) ?: continue
                grouped[row.optString("session_id")]?.put(row)
            }
            grouped.forEach { (sessionId, arr) -> cache.put(owner, keyPrefix + sessionId, arr.toString()) }
        }
        runCatching {
            distribute(
                withAuthRetry {
                    api.select(
                        "attendance_records",
                        "select=id,session_id,student_id,status,excuse_reason,arrival_minutes_late&session_id=in.($filter)&limit=10000",
                    )
                },
                CACHE_SESSION_ATTENDANCE_PREFIX,
            )
        }
        runCatching {
            distribute(
                withAuthRetry {
                    api.select(
                        "student_daily_notes",
                        "select=id,session_id,student_id,behavior,behavior_score,teacher_comment,homework,parent_visible,participation&session_id=in.($filter)&limit=10000",
                    )
                },
                CACHE_SESSION_NOTES_PREFIX,
            )
        }
        runCatching {
            distribute(
                withAuthRetry {
                    api.select(
                        "recitation_entries",
                        "select=id,session_id,student_id,activity_type,input_method,start_surah,start_ayah,end_surah,end_ayah,start_page,end_page,pages_count,ayahs_count,surahs_count,mistakes,prompts,evaluation,safety_percentage,points,teacher_note,selected_surahs,selection_data,created_at&session_id=in.($filter)&order=created_at.asc&limit=10000",
                    )
                },
                CACHE_SESSION_RECITATIONS_PREFIX,
            )
        }
    }

    fun refreshSessionDetails(sessionId: String) {
        val owner = currentUserId() ?: return
        if (!online() || sessionId.isBlank()) return
        warmRecentSessionDetails(owner, listOf(sessionId))
    }

    fun saveAttendance(
        sessionId: String,
        studentId: String,
        status: String,
        excuseReason: String = "",
        arrivalMinutesLate: Int = 0,
    ) = saveAttendanceLocalFirst(sessionId, studentId, status, excuseReason, arrivalMinutesLate)

    fun saveAttendanceLocalFirst(
        sessionId: String,
        studentId: String,
        status: String,
        excuseReason: String = "",
        arrivalMinutesLate: Int = 0,
    ) {
        require(status in setOf("present", "absent", "excused", "late")) { "حالة حضور غير صالحة" }
        require(arrivalMinutesLate >= 0) { "دقائق التأخر غير صالحة" }
        val id = UUID.nameUUIDFromBytes("$sessionId:$studentId".toByteArray()).toString()
        val obj = JSONObject()
            .put("id", id)
            .put("session_id", sessionId)
            .put("student_id", studentId)
            .put("status", status)
            .put("arrival_minutes_late", if (status == "late") arrivalMinutesLate else 0)
        if (status == "excused" && excuseReason.isNotBlank()) obj.put("excuse_reason", excuseReason.trim())
        store.load()?.userId?.let { obj.put("recorded_by", it) }
        queued(
            "POST",
            "/rest/v1/attendance_records?on_conflict=session_id,student_id",
            obj,
            "attendance:$sessionId:$studentId",
        )
        // Persist the optimistic value in the same cache read by the roster. The Outbox is then
        // durability/sync metadata, not the only place where the UI can rediscover this write.
        upsertSessionScopedCache(CACHE_SESSION_ATTENDANCE_PREFIX, sessionId, obj)
    }

    fun saveDailyNote(
        sessionId: String,
        studentId: String,
        behavior: String = "normal",
        behaviorScore: Int? = null,
        teacherComment: String = "",
        homework: String = "",
        parentVisible: Boolean = true,
        participation: String = "",
    ) = saveDailyNoteLocalFirst(
        sessionId, studentId, behavior, behaviorScore, teacherComment, homework, parentVisible, participation,
    )

    fun saveDailyNoteLocalFirst(
        sessionId: String,
        studentId: String,
        behavior: String = "normal",
        behaviorScore: Int? = null,
        teacherComment: String = "",
        homework: String = "",
        parentVisible: Boolean = true,
        participation: String = "",
    ) {
        require(behavior in setOf("excellent", "good", "normal", "needs_attention", "warning")) { "تقييم السلوك غير صالح" }
        require(behaviorScore == null || behaviorScore in 1..5) { "درجة السلوك يجب أن تكون من 1 إلى 5" }
        val id = UUID.nameUUIDFromBytes("note:$sessionId:$studentId".toByteArray()).toString()
        val obj = JSONObject()
            .put("id", id)
            .put("session_id", sessionId)
            .put("student_id", studentId)
            .put("behavior", behavior)
            .put("teacher_comment", teacherComment.trim().takeIf { it.isNotBlank() })
            .put("homework", homework.trim().takeIf { it.isNotBlank() })
            .put("parent_visible", parentVisible)
        behaviorScore?.let { obj.put("behavior_score", it) }
        participation.trim().takeIf { it.isNotBlank() }?.let { obj.put("participation", it) }
        store.load()?.userId?.let { obj.put("created_by", it) }
        queued(
            "POST",
            "/rest/v1/student_daily_notes?on_conflict=session_id,student_id",
            obj,
            "note:$sessionId:$studentId",
        )
        upsertSessionScopedCache(CACHE_SESSION_NOTES_PREFIX, sessionId, obj)
    }

    fun saveRecitation(draft: RecitationDraft) = saveRecitationLocalFirst(draft)

    fun saveRecitationLocalFirst(draft: RecitationDraft): String {
        require(draft.activityType in setOf("new_hifz", "review_near", "review_far", "sard", "tilawah", "test")) {
            "نوع التسميع غير صالح"
        }
        require(draft.pages >= 0) { "عدد الصفحات غير صالح" }
        require(draft.mistakes >= 0 && draft.prompts >= 0) { "عدد الأخطاء أو التلقين غير صالح" }
        require(draft.evaluation in setOf("not_rated", "excellent", "very_good", "good", "repeat")) {
            "التقييم غير صالح"
        }
        require(draft.inputMethod in setOf("pages", "ayahs", "surahs", "juz", "import")) { "طريقة الإدخال غير صالحة" }
        require(draft.ayahsCount >= 0 && draft.surahsCount >= 0) { "إحصاءات النطاق غير صالحة" }
        draft.startSurah?.let { require(it in 1..114) { "سورة البداية غير صالحة" } }
        draft.endSurah?.let { require(it in 1..114) { "سورة النهاية غير صالحة" } }
        draft.startAyah?.let { require(it > 0) { "آية البداية غير صالحة" } }
        draft.endAyah?.let { require(it > 0) { "آية النهاية غير صالحة" } }
        draft.startPage?.let { require(it in 1..604) { "صفحة البداية غير صالحة" } }
        draft.endPage?.let { require(it in 1..604) { "صفحة النهاية غير صالحة" } }
        draft.selectedSurahs.forEach { require(it in 1..114) { "رقم سورة مختارة غير صالح" } }
        draft.selectedJuz.forEach { require(it in 1..30) { "رقم جزء مختار غير صالح" } }
        draft.traversalDirection?.let {
            require(it in setOf("FORWARD_QURAN", "REVERSE_SURAH_ORDER", "REVERSE_WITHIN_SURAH", "PAGE_ORDER_FORWARD", "PAGE_ORDER_REVERSE", "EXPLICIT_SEGMENTS")) {
                "اتجاه النطاق غير صالح"
            }
        }

        val normalizedQcfLines = draft.qcfLineKeys.distinct().also { keys ->
            keys.forEach { key ->
                val parts = key.split(':')
                val page = parts.getOrNull(0)?.toIntOrNull()
                val line = parts.getOrNull(1)?.toIntOrNull()
                require(parts.size == 2 && page in 1..604 && line in 1..15) { "مفتاح QCF4 غير صالح: $key" }
            }
        }
        // QCF4 line keys are the authoritative unit for partial-page selections.
        // Never round here: 1 line = 1/15 page. Display rounding belongs to the UI only.
        val actualPages = if (normalizedQcfLines.isNotEmpty()) {
            normalizedQcfLines.distinct().size.toDouble() / 15.0
        } else draft.pages
        require(actualPages in 0.0..80.0) { "عدد الصفحات خارج النطاق المعتمد" }

        val id = draft.clientId?.takeIf { it.isNotBlank() } ?: UUID.randomUUID().toString()
        val safety = SafetyScoring.calculate(actualPages, draft.mistakes, draft.prompts)
        val evaluation = SafetyScoring.inferredEvaluation(safety, actualPages > 0.0)
        val points = SafetyScoring.points(actualPages, draft.mistakes, draft.prompts)
        val penaltyUnits = SafetyScoring.penaltyUnits(draft.mistakes, draft.prompts)
        val penaltyPerPage = if (actualPages > 0.0) penaltyUnits / actualPages else 0.0
        val selectionData = JSONObject()
            .put("native", true)
            .put("quran_engine", "rc8.2")
            .put("line_model", 15)
            .put("mode", draft.inputMethod)
            .put("input_method", draft.inputMethod)
        if (draft.inputMethod == "import") selectionData.put("imported", true)
        if (draft.startSurah != null && draft.startAyah != null) {
            selectionData.put("start_global", runCatching { com.mohammedsamir.halaqati.quran.QuranMetadata.globalAyah(draft.startSurah, draft.startAyah) }.getOrNull())
        }
        if (draft.endSurah != null && draft.endAyah != null) {
            selectionData.put("end_global", runCatching { com.mohammedsamir.halaqati.quran.QuranMetadata.globalAyah(draft.endSurah, draft.endAyah) }.getOrNull())
        }
        draft.smartPlanId?.takeIf { it.isNotBlank() }?.let { selectionData.put("smart_plan_id", it) }
        draft.smartPlanPhaseId?.takeIf { it.isNotBlank() }?.let { selectionData.put("smart_plan_phase_id", it) }
        draft.smartPlanType?.takeIf { it.isNotBlank() }?.let { selectionData.put("smart_plan_type", it) }
        draft.smartPlanDate?.takeIf { it.isNotBlank() }?.let { selectionData.put("smart_plan_date", it) }
        if (normalizedQcfLines.isNotEmpty()) selectionData.put("qcf_line_keys", JSONArray(normalizedQcfLines))
        draft.traversalDirection?.takeIf { it.isNotBlank() }?.let { selectionData.put("quran_traversal_direction", it) }
        if (draft.quranSegments.isNotEmpty()) selectionData.put("quran_segments", JSONArray(draft.quranSegments))
        if (draft.selectedSurahs.isNotEmpty()) selectionData.put("selected_surahs", JSONArray(draft.selectedSurahs))
        if (draft.selectedJuz.isNotEmpty()) selectionData.put("selected_juz", JSONArray(draft.selectedJuz))

        val obj = JSONObject()
            .put("id", id)
            .put("student_id", draft.studentId)
            .put("session_id", draft.sessionId)
            .put("activity_type", draft.activityType)
            .put("input_method", draft.inputMethod)
            .put("pages_count", actualPages)
            .put("ayahs_count", draft.ayahsCount)
            .put("surahs_count", draft.surahsCount)
            .put("mistakes", draft.mistakes)
            .put("prompts", draft.prompts)
            .put("evaluation", evaluation)
            .put("safety_percentage", safety)
            .put("penalty_units", penaltyUnits)
            .put("penalty_per_page", penaltyPerPage)
            .put("points", points)
            .put("scoring_version", "V6")
            .put("selection_data", selectionData)
        draft.smartPlanPhaseId?.takeIf { it.isNotBlank() }?.let { obj.put("phase_id", it) }
        if (draft.notes.isNotBlank()) obj.put("teacher_note", draft.notes)
        draft.startSurah?.let { obj.put("start_surah", it) }
        draft.startAyah?.let { obj.put("start_ayah", it) }
        draft.endSurah?.let { obj.put("end_surah", it) }
        draft.endAyah?.let { obj.put("end_ayah", it) }
        draft.startPage?.let { obj.put("start_page", it) }
        draft.endPage?.let { obj.put("end_page", it) }
        if (draft.selectedSurahs.isNotEmpty()) obj.put("selected_surahs", JSONArray(draft.selectedSurahs))
        store.load()?.userId?.let { obj.put("created_by", it) }

        queued(
            "POST",
            "/rest/v1/recitation_entries?on_conflict=id",
            obj,
            "recitation:${draft.sessionId}:${draft.studentId}:$id",
        )
        val cachedRow = JSONObject(obj.toString()).put("created_at", draft.createdAt?.takeIf { it.isNotBlank() } ?: java.time.Instant.now().toString())
        upsertSessionScopedCache(CACHE_SESSION_RECITATIONS_PREFIX, draft.sessionId, cachedRow)
        upsertPlanRecitationCacheRow(cachedRow, draft.sessionId)
        invalidatePlanSnapshotMemory()
        return id
    }

    /**
     * Immediate RC10 Undo. It only succeeds while every operation created by the quick-save
     * is still pending in this account's durable Outbox. If sync already consumed any part,
     * nothing is deleted locally; the caller can fall back to the full session editor.
     */
    fun undoPendingQuickSave(sessionId: String, studentId: String, recitationId: String? = null): Boolean {
        val owner = currentUserId() ?: return false
        val dedupes = buildList {
            add("attendance:$sessionId:$studentId")
            recitationId?.takeIf { it.isNotBlank() }?.let { add("recitation:$sessionId:$studentId:$it") }
        }
        val discarded = queue.discardPendingDedupesIfComplete(owner, dedupes)
        if (discarded && !recitationId.isNullOrBlank()) {
            removeSessionScopedCacheRow(CACHE_SESSION_RECITATIONS_PREFIX, sessionId, recitationId)
            removePlanRecitationCacheRow(recitationId)
            invalidatePlanSnapshotMemory()
        }
        return discarded
    }

    /** RC9.3 historical recitation delete. The mutation is idempotent, removes the local
     * session cache row immediately after commit, and invalidates the derived Smart Plan state
     * so anchors/month/week totals are rebuilt from the remaining authoritative history. */
    fun deleteRecitation(sessionId: String, studentId: String, recitationId: String) {
        require(sessionId.isNotBlank()) { "معرّف الجلسة غير صالح" }
        require(studentId.isNotBlank()) { "معرّف الطالب غير صالح" }
        require(recitationId.isNotBlank()) { "معرّف التسميع غير صالح" }
        delete(
            "recitation_entries",
            "id=eq.$recitationId",
            dedupe = "recitation-delete:$sessionId:$studentId:$recitationId",
        )
        removeSessionScopedCacheRow(CACHE_SESSION_RECITATIONS_PREFIX, sessionId, recitationId)
        removePlanRecitationCacheRow(recitationId)
        invalidatePlanSnapshotMemory()
    }

    /** RC9.2 roster Undo for a newly-created recitation. Synced historical entries are edited,
     * never destructively recreated. */
    fun undoPendingRecitation(sessionId: String, studentId: String, recitationId: String): Boolean {
        val owner = currentUserId() ?: return false
        if (recitationId.isBlank()) return false
        val dedupe = "recitation:$sessionId:$studentId:$recitationId"
        val discarded = queue.discardPendingDedupesIfComplete(owner, listOf(dedupe))
        if (discarded) {
            removeSessionScopedCacheRow(CACHE_SESSION_RECITATIONS_PREFIX, sessionId, recitationId)
            removePlanRecitationCacheRow(recitationId)
            invalidatePlanSnapshotMemory()
        }
        return discarded
    }

    fun currentUserId(): String? = store.load()?.userId?.takeIf { it.isNotBlank() }

    fun pendingQueueSize(): Int = currentUserId()?.let { queue.size(it) } ?: 0
    fun blockedQueueSize(): Int = currentUserId()?.let { queue.blockedSize(it) } ?: 0
    fun conflictQueueSize(): Int = currentUserId()?.let { queue.conflictSize(it) } ?: 0

    fun queueSnapshot(limit: Int = 200): List<OfflineQueue.SnapshotItem> =
        currentUserId()?.let { queue.snapshot(it, limit) } ?: emptyList()

    fun retryBlockedQueueItem(id: Long) { currentUserId()?.let { queue.retryBlocked(id, it); signalLocalMutation() } }
    fun discardQueueItem(id: Long) { currentUserId()?.let { queue.discard(id, it); signalLocalMutation() } }

    fun retryAllBlockedQueueItems() {
        val owner = currentUserId() ?: return
        queue.snapshot(owner, 1000).filter { it.blocked && !it.conflict }.forEach { queue.retryBlocked(it.id, owner) }
        signalLocalMutation()
        scheduleSync()
    }

    fun resolveConflictUseLocal(id: Long) {
        val owner = currentUserId() ?: return
        queue.forceLocal(id, owner)
        signalLocalMutation()
        scheduleSync()
    }

    fun resolveConflictUseServer(id: Long) {
        val owner = currentUserId() ?: return
        val item = queue.item(id, owner) ?: return
        val server = item.serverJson?.let { runCatching { JSONObject(it) }.getOrNull() }
        if (item.entityTable == "students" && !item.entityId.isNullOrBlank()) {
            if (server != null) upsertStudentLocal(owner, server, dirty = false)
            else offlineDb.students().deleteAny(owner, item.entityId)
            cache.put(owner, CACHE_STUDENTS, localStudentsJson(owner).toString())
        }
        queue.discard(id, owner)
        signalLocalMutation()
    }

    private fun fetchServerStudent(id: String): JSONObject? = withAuthRetry {
        api.select("students", "select=*&id=eq.$id&limit=1")
    }.optJSONObject(0)

    private fun detectConflict(owner: String, item: OfflineQueue.Item): Boolean {
        if (item.forceLocal || item.entityTable != "students" || item.entityId.isNullOrBlank() || item.baseUpdatedAt.isNullOrBlank()) return false
        val server = fetchServerStudent(item.entityId)
        val serverUpdated = server?.optString("updated_at")?.ifBlank { null }
        if (!ConflictRules.changedSinceBase(item.baseUpdatedAt, serverUpdated)) return false
        queue.markConflict(
            item.id, owner,
            "تعارض: نسخة الخادم تغيّرت بعد بدء تعديلك. اختر اعتماد تعديلي أو اعتماد نسخة الخادم.",
            server?.toString(),
        )
        return true
    }

    /**
     * RC8.6 V3 migration: older builds queued four mutations for one session deletion.
     * The live database uses ON DELETE CASCADE, so if the parent session delete is pending,
     * the three child deletes are redundant. Compact them before upload so existing devices
     * immediately benefit from the one-request path after upgrading.
     */
    private fun compactLegacySessionDeletes(owner: String) {
        val snapshot = queue.snapshot(owner, 2_000)
        val parentIds = snapshot.asSequence()
            .mapNotNull { item -> item.dedupe?.takeIf { it.startsWith("session-delete:") }?.substringAfter("session-delete:") }
            .filter(String::isNotBlank)
            .toSet()
        if (parentIds.isEmpty()) return
        val obsoletePrefixes = listOf("session-recitation-delete:", "session-attendance-delete:", "session-notes-delete:")
        snapshot.forEach { item ->
            val dedupe = item.dedupe.orEmpty()
            val obsolete = obsoletePrefixes.any { prefix ->
                dedupe.startsWith(prefix) && dedupe.substringAfter(prefix) in parentIds
            }
            if (obsolete && !item.blocked) queue.discard(item.id, owner)
        }
    }

    private fun backgroundRefreshDue(owner: String, minimumAgeMs: Long = 120_000L): Boolean {
        val last = offlineDb.syncMeta().get(owner)?.lastPullAt ?: return true
        return System.currentTimeMillis() - last >= minimumAgeMs
    }

    private fun repairLegacyStudentSchemaQueue(owner: String) {
        queue.snapshot(owner, 2_000).forEach { item ->
            if (!item.path.contains("/rest/v1/students")) return@forEach
            val raw = item.body?.let { runCatching { JSONObject(it) }.getOrNull() } ?: return@forEach
            if (!StudentSchemaContract.containsUnsupported(raw)) return@forEach
            val clean = StudentSchemaContract.sanitize(raw)
            val entityId = item.entityId ?: clean.optString("id").takeIf { it.isNotBlank() }
            queue.add(
                ownerUserId = owner,
                method = item.method,
                path = item.path,
                body = clean.toString(),
                dedupe = item.dedupe ?: entityId?.let { "student:$it" },
                baseUpdatedAt = item.baseUpdatedAt,
                entityTable = "students",
                entityId = entityId,
            )
        }
    }

    fun flushQueue(): Int {
        if (!online()) return 0
        val owner = currentUserId() ?: return 0
        repairLegacyStudentSchemaQueue(owner)
        compactLegacySessionDeletes(owner)
        var pushed = 0
        for (item in queue.all(owner)) {
            if (detectConflict(owner, item)) continue
            try {
                withAuthRetry { api.raw(item.method, item.path, item.body) }
                if (item.entityTable == "students" && !item.entityId.isNullOrBlank()) {
                    val server = runCatching { fetchServerStudent(item.entityId) }.getOrNull()
                    if (server != null) upsertStudentLocal(owner, server, dirty = false)
                    else if (item.method == "DELETE") offlineDb.students().deleteClean(owner, item.entityId)
                    cache.put(owner, CACHE_STUDENTS, localStudentsJson(owner).toString())
                }
                queue.done(item.id, owner)
                signalLocalMutation()
                pushed += 1
            } catch (e: Exception) {
                queue.fail(item.id, owner, e.message ?: e::class.java.simpleName)
                signalLocalMutation()
                if (e is SupabaseException && e.status in 400..499 && e.status != 408 && e.status != 429) {
                    queue.markBlocked(item.id, owner, e.message ?: "HTTP ${e.status}")
                    continue
                }
                throw e
            }
        }
        markPushed(owner)
        return pushed
    }

    /**
     * Foreground sync path: upload durable local mutations only and return quickly.
     * Expensive pulls are scheduled separately so a tap on "مزامنة" never waits for reports,
     * rankings, supervision and every historical session to download again.
     */
    fun syncNow() {
        if (!online()) return
        val owner = currentUserId() ?: return
        val pushed = synchronized(pushLock) { flushQueue() }
        // Foreground/manual sync is an Outbox flush. A full account reconciliation is opportunistic
        // and throttled, never part of the user's spinner path.
        if (pushed > 0 || backgroundRefreshDue(owner)) scheduleBackgroundRefresh()
    }

    /** Periodic/background reconciliation. Never used as the blocking foreground sync path. */
    fun fullRefreshNow() {
        if (!online()) return
        val owner = currentUserId() ?: return
        synchronized(pushLock) { flushQueue() }
        runCatching { refreshStudents() }
        runCatching { refreshSessions() }
        runCatching { warmRecentSessionDetails(owner, cachedSessions(owner, maxAge = null).orEmpty().map { it.id }) }
        runCatching { refreshPlans() }
        runCatching { accountProfiles(forceRefresh = true) }
        runCatching { guardianAccounts(forceRefresh = true) }
        runCatching { table("halaqas", "select=id,name,active&order=name.asc&limit=200", forceRefresh = true) }
        runCatching { table("student_categories", "select=id,halaqa_id,name,active&order=name.asc&limit=500", forceRefresh = true) }
        runCatching {
            val rankingSource = withAuthRetry {
                api.select(
                    "recitation_entries",
                    "select=student_id,pages_count,mistakes,prompts,points,activity_type,selection_data," +
                        "students!inner(full_name,category_id,track_code),sessions!inner(session_date)&limit=10000",
                )
            }
            cache.put(owner, CACHE_RANKING_SOURCE, rankingSource.toString())
        }
        runCatching { planEvents(forceRefresh = true) }
        // Warm the screens that must remain useful after connectivity/DNS disappears.
        runCatching { planSnapshots(LocalDate.now(), forceRefresh = true) }
        val today = LocalDate.now()
        val monthStart = YearMonth.from(today).atDay(1).toString()
        runCatching { reportRecitations(monthStart, today.toString(), "all", forceRefresh = true) }
        runCatching { reportSummary(monthStart, today.toString(), "all", "all", "all", forceRefresh = true) }
        runCatching { table("supervisor_visits", "select=*&order=visit_date.desc&limit=300", forceRefresh = true) }
        runCatching { table("student_goals", "select=*&period_start=lte.$today&period_end=gte.$today&limit=1000", forceRefresh = true) }
        // Supervision dashboard uses these exact projections; warm them so it can reopen fully offline.
        val supervisionSessions = runCatching { table("sessions", "select=*&order=session_date.desc&limit=300", forceRefresh = true) }.getOrElse { JSONArray() }
        runCatching {
            table(
                "smart_plans",
                "select=id,scope_type,halaqa_id,student_id,category_id,plan_type,start_date,end_date,status,settings&status=neq.archived&limit=1000",
                forceRefresh = true,
            )
        }
        runCatching { table("halaqas", "select=id,name&active=eq.true&order=name.asc&limit=100", forceRefresh = true) }
        val todaySessionIds = (0 until supervisionSessions.length()).mapNotNull { index ->
            supervisionSessions.optJSONObject(index)?.takeIf {
                it.optString("session_date") == today.toString() && it.optString("status") != "cancelled"
            }?.optString("id")?.takeIf(String::isNotBlank)
        }
        if (todaySessionIds.isNotEmpty()) {
            runCatching {
                table(
                    "attendance_records",
                    "select=student_id,status&session_id=in.(${todaySessionIds.joinToString(",")})&limit=3000",
                    forceRefresh = true,
                )
            }
        }
        runCatching { table("announcements", "select=*&order=pinned.desc&order=publish_at.desc&limit=200", forceRefresh = true) }
        runCatching { table("forum_posts", "select=*&order=pinned.desc&order=created_at.desc&limit=200", forceRefresh = true) }
        runCatching { table("forum_comments", "select=*&order=created_at.asc&limit=1000", forceRefresh = true) }
        offlineDb.syncMeta().put(
            (offlineDb.syncMeta().get(owner) ?: SyncMetaEntity(owner)).copy(
                lastPushAt = System.currentTimeMillis(), lastPullAt = System.currentTimeMillis(), lastError = null,
            ),
        )
    }

    fun scheduleBackgroundRefresh() {
        WorkManager.getInstance(context).enqueueUniqueWork(
            "halaqati-background-refresh",
            ExistingWorkPolicy.KEEP,
            OneTimeWorkRequestBuilder<FullSyncWorker>()
                .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
                .setInitialDelay(5, java.util.concurrent.TimeUnit.SECONDS)
                .setBackoffCriteria(androidx.work.BackoffPolicy.EXPONENTIAL, 30, java.util.concurrent.TimeUnit.SECONDS)
                .build(),
        )
    }

    fun lastSyncInstant(): String? {
        val owner = currentUserId() ?: return null
        val meta = offlineDb.syncMeta().get(owner) ?: return null
        val millis = listOfNotNull(meta.lastPushAt, meta.lastPullAt).maxOrNull() ?: return null
        return java.time.Instant.ofEpochMilli(millis).toString()
    }

    private fun markPushed(owner: String) {
        val old = offlineDb.syncMeta().get(owner) ?: SyncMetaEntity(owner)
        offlineDb.syncMeta().put(old.copy(lastPushAt = System.currentTimeMillis(), lastError = null))
    }

    private fun markPulled(owner: String) {
        val old = offlineDb.syncMeta().get(owner) ?: SyncMetaEntity(owner)
        offlineDb.syncMeta().put(old.copy(lastPullAt = System.currentTimeMillis(), lastError = null))
    }

    fun scheduleSync() {
        WorkManager.getInstance(context).enqueueUniqueWork(
            "halaqati-sync-now",
            ExistingWorkPolicy.KEEP,
            OneTimeWorkRequestBuilder<SyncWorker>()
                .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
                .setBackoffCriteria(androidx.work.BackoffPolicy.EXPONENTIAL, 30, java.util.concurrent.TimeUnit.SECONDS)
                .build(),
        )
    }

}
