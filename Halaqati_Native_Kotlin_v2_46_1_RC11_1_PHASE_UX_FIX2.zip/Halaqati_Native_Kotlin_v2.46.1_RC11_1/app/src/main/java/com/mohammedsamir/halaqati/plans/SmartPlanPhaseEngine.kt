package com.mohammedsamir.halaqati.plans

import com.mohammedsamir.halaqati.quran.QuranLocation
import com.mohammedsamir.halaqati.quran.QuranMetadata
import java.time.LocalDate
import kotlin.math.max

/**
 * RC11 Smart Plan Phases 2.0.
 *
 * The phase layer does not replace SmartPlanEngine or QuranRangeEngine. It decides
 * which activity is active, freezes phase results, keeps Hifz/Sard anchors separate,
 * and redistributes the remaining target over the remaining scheduled days.
 */
object SmartPlanPhaseEngine {
    const val TYPE_HIFZ = "hifz"
    const val TYPE_SARD = "sard"

    const val STATUS_DRAFT = "draft"
    const val STATUS_ACTIVE = "active"
    const val STATUS_COMPLETED = "completed"
    const val STATUS_ARCHIVED = "archived"

    const val STATE_NOT_STARTED = "not_started"
    const val STATE_ACTIVE = "active"
    const val STATE_COMPLETED = "completed"
    const val STATE_SKIPPED = "skipped"

    const val GOAL_PAGES = "pages"
    const val GOAL_JUZ = "juz"
    const val GOAL_RANGE = "quran_range"
    const val GOAL_OPEN = "open"

    const val DISTRIBUTION_EQUAL = "equal"
    const val DISTRIBUTION_FLEXIBLE = "flexible"

    const val START_LAST_SARD = "last_sard"
    const val START_MANUAL = "manual"
    const val START_RANGE = "range_start"
    const val START_PLAN = "plan_start"

    data class Anchor(
        val recitationId: String,
        val date: LocalDate,
        val surah: Int,
        val ayah: Int,
        val page: Int,
    )

    data class Phase(
        val id: String,
        val planId: String,
        val order: Int,
        val type: String,
        val startDate: LocalDate,
        val endDate: LocalDate,
        val scheduleWeekdays: Set<Int>,
        val goalMode: String,
        val targetPages: Double?,
        val targetUnits: Double?,
        val goalUnit: String,
        val distributionMode: String,
        val startMode: String,
        val rangeStartPage: Int? = null,
        val rangeEndPage: Int? = null,
        val rangeStartSurah: Int? = null,
        val rangeStartAyah: Int? = null,
        val rangeEndSurah: Int? = null,
        val rangeEndAyah: Int? = null,
        val allowSurplus: Boolean = true,
        val status: String = STATUS_ACTIVE,
    )

    data class StudentState(
        val phaseId: String,
        val studentId: String,
        val status: String = STATE_NOT_STARTED,
        val targetPagesOverride: Double? = null,
        val startDateOverride: LocalDate? = null,
        val endDateOverride: LocalDate? = null,
        val frozenCompletedPages: Double? = null,
        val frozenTargetPages: Double? = null,
        val carriedShortfallPages: Double = 0.0,
        val completionPercent: Double? = null,
    )

    data class Progress(
        val targetPages: Double?,
        val completedPages: Double,
        val remainingPages: Double?,
        val percentage: Double?,
        val scheduledDays: Int,
        val elapsedScheduledDays: Int,
        val remainingScheduledDays: Int,
        val suggestedTodayPages: Double?,
        val surplusPages: Double,
        val completedEarly: Boolean,
        val goalComplete: Boolean,
    )

    fun weekday(date: LocalDate): Int = date.dayOfWeek.value % 7

    fun scheduledDates(phase: Phase, from: LocalDate? = null, to: LocalDate? = null): List<LocalDate> {
        val start = maxOf(phase.startDate, from ?: phase.startDate)
        val end = minOf(phase.endDate, to ?: phase.endDate)
        if (start > end) return emptyList()
        return generateSequence(start) { it.plusDays(1) }
            .takeWhile { it <= end }
            .filter { weekday(it) in phase.scheduleWeekdays }
            .toList()
    }

    fun resolvedTargetPages(phase: Phase, state: StudentState? = null): Double? {
        state?.targetPagesOverride?.takeIf { it > 0.0 }?.let { return SmartPlanEngine.round(it) }
        phase.targetPages?.takeIf { it > 0.0 }?.let { return SmartPlanEngine.round(it) }
        return when (phase.goalMode) {
            GOAL_JUZ -> phase.targetUnits?.takeIf { it > 0.0 }?.let { SmartPlanEngine.round(it * 20.0) }
            GOAL_OPEN -> null
            else -> null
        }
    }

    fun progress(
        phase: Phase,
        completedPages: Double,
        today: LocalDate,
        state: StudentState? = null,
    ): Progress {
        val baseTarget = resolvedTargetPages(phase, state)
        val carried = state?.carriedShortfallPages?.coerceAtLeast(0.0) ?: 0.0
        val target = when {
            baseTarget != null -> SmartPlanEngine.round(baseTarget + carried)
            carried > EPSILON -> SmartPlanEngine.round(carried)
            else -> null
        }
        val completed = state?.frozenCompletedPages ?: completedPages.coerceAtLeast(0.0)
        val allDates = scheduledDates(phase)
        val elapsed = allDates.count { it <= today }
        val remainingDates = allDates.count { it >= today && it <= phase.endDate }
        val remaining = target?.let { max(0.0, it - completed) }
        val surplus = target?.let { max(0.0, completed - it) } ?: 0.0
        val complete = target != null && remaining != null && remaining <= EPSILON
        val completedEarly = complete && today < phase.endDate
        val suggested = when {
            target == null -> null
            complete -> if (phase.allowSurplus) 0.0 else null
            remainingDates <= 0 -> remaining
            phase.distributionMode == DISTRIBUTION_EQUAL -> SmartPlanEngine.round(target / allDates.size.coerceAtLeast(1))
            else -> SmartPlanEngine.round((remaining ?: 0.0) / remainingDates)
        }
        return Progress(
            targetPages = target,
            completedPages = SmartPlanEngine.round(completed),
            remainingPages = remaining?.let(SmartPlanEngine::round),
            percentage = target?.takeIf { it > EPSILON }?.let { SmartPlanEngine.round((completed / it * 100.0).coerceAtLeast(0.0), 1) },
            scheduledDays = allDates.size,
            elapsedScheduledDays = elapsed,
            remainingScheduledDays = remainingDates,
            suggestedTodayPages = suggested,
            surplusPages = SmartPlanEngine.round(surplus),
            completedEarly = completedEarly,
            goalComplete = complete,
        )
    }

    fun latestSardAnchor(
        recitations: List<SmartPlanEngine.Recitation>,
        today: LocalDate,
    ): Anchor? {
        val latest = recitations.asSequence()
            .filter { it.date <= today }
            .filter { it.activityType.lowercase() in SARD_ACTIVITIES }
            .filter { it.endSurah != null && it.endAyah != null }
            .maxWithOrNull(compareBy<SmartPlanEngine.Recitation> { it.date }.thenBy { it.createdAt })
            ?: return null
        val surah = latest.endSurah ?: return null
        val ayah = latest.endAyah ?: return null
        if (surah !in 1..114 || ayah !in 1..QuranMetadata.maxAyah(surah)) return null
        return Anchor(
            recitationId = latest.id,
            date = latest.date,
            surah = surah,
            ayah = ayah,
            page = latest.endPage?.takeIf { it in 1..604 } ?: QuranMetadata.pageFor(surah, ayah),
        )
    }

    fun effectiveActivePhase(
        phases: List<Phase>,
        states: List<StudentState>,
        studentId: String,
        today: LocalDate,
    ): Phase? {
        val byPhase = states.filter { it.studentId == studentId }.associateBy { it.phaseId }
        fun effective(phase: Phase): Phase {
            val state = byPhase[phase.id]
            val start = state?.startDateOverride ?: phase.startDate
            val end = state?.endDateOverride ?: phase.endDate
            return phase.copy(startDate = start, endDate = maxOf(start, end))
        }
        return phases.asSequence()
            .filter { it.status == STATUS_ACTIVE }
            .map(::effective)
            .filter { today >= it.startDate && today <= it.endDate }
            .filter { byPhase[it.id]?.status !in setOf(STATE_COMPLETED, STATE_SKIPPED) }
            .sortedBy { it.order }
            .firstOrNull()
    }


    fun configuredStart(phase: Phase): QuranLocation? = when {
        phase.rangeStartSurah != null && phase.rangeStartAyah != null -> QuranLocation(phase.rangeStartSurah, phase.rangeStartAyah)
        phase.rangeStartPage != null -> QuranMetadata.pageStart(phase.rangeStartPage)
        else -> null
    }

    fun usesHistoricalSardAnchor(phase: Phase): Boolean = phase.type == TYPE_SARD && phase.startMode == START_LAST_SARD

    /** Shortfall is never automatically carried. This returns the optional suggestion only. */
    fun previousShortfall(previous: Progress): Double = SmartPlanEngine.round(previous.remainingPages ?: 0.0)

    private val SARD_ACTIVITIES = setOf("sard", "test")
    private const val EPSILON = 0.001
}
