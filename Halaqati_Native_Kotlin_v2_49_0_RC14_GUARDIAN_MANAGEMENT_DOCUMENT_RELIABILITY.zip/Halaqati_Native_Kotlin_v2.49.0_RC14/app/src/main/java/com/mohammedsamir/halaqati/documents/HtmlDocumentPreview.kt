package com.mohammedsamir.halaqati.documents

import android.graphics.Color
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView

private data class PreviewRenderState(
    val htmlHash: Int,
    val zoom: Float,
)

/**
 * RC13 preview renderer.
 *
 * v2.44 did not depend on WebView's mobile zoom heuristics for certificate/report previews.
 * It kept the A4 document at its real desktop width and scaled that document explicitly into
 * the preview viewport. We do the same here: the original HTML/CSS is left intact for PDF,
 * while the preview copy receives a tiny display-only fit script. This avoids OEM/WebView
 * combinations that honour `initial-scale=1` literally and show only a cropped slice of A4.
 */
@Composable
fun HtmlDocumentPreview(
    html: String,
    modifier: Modifier = Modifier,
    zoom: Float = 1f,
) {
    val safeZoom = zoom.coerceIn(.7f, 1.2f)
    AndroidView(
        modifier = modifier,
        factory = { context ->
            WebView(context).apply {
                setBackgroundColor(Color.TRANSPARENT)
                settings.javaScriptEnabled = true
                settings.domStorageEnabled = false
                settings.allowContentAccess = false
                settings.allowFileAccess = true
                settings.blockNetworkLoads = true
                settings.cacheMode = WebSettings.LOAD_NO_CACHE
                settings.loadWithOverviewMode = false
                settings.useWideViewPort = true
                settings.setSupportZoom(false)
                settings.builtInZoomControls = false
                settings.displayZoomControls = false
                settings.defaultTextEncodingName = "UTF-8"
                settings.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
                isHorizontalScrollBarEnabled = false
                webViewClient = object : WebViewClient() {
                    override fun onPageFinished(view: WebView, url: String?) {
                        val state = view.tag as? PreviewRenderState ?: return
                        view.post { applyPreviewFit(view, state.zoom) }
                    }
                }
            }
        },
        update = { view ->
            val previous = view.tag as? PreviewRenderState
            val next = PreviewRenderState(html.hashCode(), safeZoom)
            if (previous?.htmlHash != next.htmlHash) {
                view.tag = next
                view.loadDataWithBaseURL(
                    "file:///android_asset/documents/",
                    previewHtml(html),
                    "text/html",
                    "UTF-8",
                    null,
                )
            } else if (previous == null || kotlin.math.abs(previous.zoom - next.zoom) > .001f) {
                view.tag = next
                view.post { applyPreviewFit(view, next.zoom) }
            }
        },
    )
}

private fun applyPreviewFit(view: WebView, zoom: Float) {
    val z = zoom.coerceIn(.7f, 1.2f)
    view.evaluateJavascript(
        "window.__HALAQATI_APPLY_PREVIEW_FIT__ && window.__HALAQATI_APPLY_PREVIEW_FIT__(${z});",
        null,
    )
}

/** Display-only wrapper; the PDF renderer receives the unmodified [html]. */
private fun previewHtml(html: String): String {
    val viewport = "<meta name=\"viewport\" content=\"width=device-width,initial-scale=1,user-scalable=no\">"
    val viewportRegex = Regex("<meta\\s+name=[\\\"']viewport[\\\"'][^>]*>", RegexOption.IGNORE_CASE)
    val base = if (viewportRegex.containsMatchIn(html)) html.replace(viewportRegex, viewport) else html.replace("<head>", "<head>$viewport")
    val bridge = """
      <style id="halaqati-preview-fit-style">
        html,body{margin:0!important;padding:0!important;min-width:0!important;max-width:none!important;background:transparent!important;overflow-x:auto!important;direction:ltr!important;}
        body{display:block!important;justify-content:initial!important;align-items:initial!important;min-height:0!important;}
        .halaqati-certificate{margin:0!important;max-width:none!important;transform-origin:top left!important;direction:rtl!important;}
        .pro-report{margin:0!important;padding:0!important;max-width:none!important;transform-origin:top left!important;direction:rtl!important;}
        .pro-report-page{max-width:none!important;}
      </style>
      <script>
      (function(){
        function num(v,d){v=Number(v);return Number.isFinite(v)?v:d}
        function applyPreviewFit(zoom){
          try{
            zoom=Math.max(.7,Math.min(1.2,num(zoom,1)));
            window.__HALAQATI_PREVIEW_ZOOM__=zoom;
            var cert=document.querySelector('.halaqati-certificate');
            var report=document.querySelector('.pro-report');
            var target=cert||report;
            if(!target)return false;
            target.style.transform='none';
            target.style.left='0px';
            target.style.top='0px';
            target.style.position='relative';
            var page=cert||document.querySelector('.pro-report-page');
            var baseW=cert?1122:Math.max(1,(page&&page.offsetWidth)||1120);
            var rawH=Math.max(target.scrollHeight,target.offsetHeight,1);
            var viewportW=Math.max(1,document.documentElement.clientWidth||window.innerWidth||360);
            var pad=8;
            var available=Math.max(1,viewportW-pad*2);
            var fit=Math.min(1,available/baseW);
            var scale=fit*zoom;
            var visualW=baseW*scale;
            var left=visualW<available?Math.max(0,(available-visualW)/2):0;
            target.style.width=baseW+'px';
            target.style.transformOrigin='top left';
            target.style.transform='scale('+scale+')';
            target.style.left=(pad+left)+'px';
            var h=Math.max(1,Math.ceil(rawH*scale)+16);
            document.body.style.height=h+'px';
            document.documentElement.style.minHeight=h+'px';
            document.body.style.width=Math.max(viewportW,Math.ceil(visualW+pad*2))+'px';
            document.documentElement.dataset.previewFit='1';
            document.documentElement.dataset.previewScale=String(scale);
            window.scrollTo(0,0);
            return true;
          }catch(_e){return false}
        }
        window.__HALAQATI_APPLY_PREVIEW_FIT__=applyPreviewFit;
        window.addEventListener('resize',function(){applyPreviewFit(window.__HALAQATI_PREVIEW_ZOOM__||1)});
        var run=function(){requestAnimationFrame(function(){requestAnimationFrame(function(){applyPreviewFit(window.__HALAQATI_PREVIEW_ZOOM__||1)})})};
        if(document.fonts&&document.fonts.ready)document.fonts.ready.then(run).catch(run);else run();
      })();
      </script>
    """.trimIndent()
    return if (base.contains("</body>", ignoreCase = true)) base.replace(Regex("</body>", RegexOption.IGNORE_CASE), "$bridge</body>") else "$base$bridge"
}
