from pathlib import Path
import json, shutil, hashlib
apk=Path('app/build/outputs/apk/release/app-release.apk')
out=Path('update-publish');out.mkdir(exist_ok=True)
shutil.copy2(apk,out/'Halaqati-latest.apk')
sha=hashlib.sha256(apk.read_bytes()).hexdigest()
(out/'version.json').write_text(json.dumps({'version':'2.47.2-RC12.2','versionCode':24720,'apk':'Halaqati-latest.apk','sha256':sha,'native':True},ensure_ascii=False,indent=2),encoding='utf-8')
