#!/usr/bin/env python3
from pathlib import Path
root=Path(__file__).resolve().parents[1]

def read(rel):
    p=root/rel
    if not p.exists(): raise SystemExit('RC12.2 FAIL: missing '+rel)
    return p.read_text(encoding='utf-8',errors='ignore')

def need(cond,msg):
    if not cond: raise SystemExit('RC12.2 FAIL: '+msg)

build=read('app/build.gradle.kts')
ui=read('app/src/main/java/com/mohammedsamir/halaqati/ui/screens/ReportsAndTools.kt')
repo=read('app/src/main/java/com/mohammedsamir/halaqati/data/HalaqatiRepository.kt')
core=read('app/src/main/java/com/mohammedsamir/halaqati/model/CertificateCore.kt')
contract=read('migration/source-contract.json')
need('versionCode = 24720' in build and 'versionName = "2.47.2-RC12.2"' in build,'version')
need('"native_version": "2.47.2-RC12.2"' in contract,'source contract version')
for value,label in [('emerald','الرسمي الفيروزي'),('royal','الملكي الأخضر'),('gold','الذهبي الفاخر'),('blue','الأزرق الرسمي'),('minimal','الكلاسيكي الهادئ')]:
    need(f'"{value}" to "{label}"' in ui, f'legacy template {value}')
for kind in ('"sard" to "إتمام سرد"','"khatam" to "ختم القرآن"','"monthly" to "التميز الشهري"','"ideal" to "الطالب المثالي"','"rank" to "المراكز الأولى"'):
    need(kind in ui,'legacy certificate types')
need('drawCertificateOrnaments' in ui and 'drawOctagram' in ui,'vector Girih/octagram ornaments')
need('96-unit rhythm' in ui and 'No downloaded' in ui,'ornament provenance/no bundled downloads')
need('studentCategoryFilter' in ui and 'categoryNameOf' in ui and 'ترتيب/فلترة حسب الفئة' in ui,'category aware selection')
need('sortedWith(compareBy' in ui,'category/name sorting')
need('issueOfficialCertificate' in ui and 'repo.issueCertificate' in ui,'official server numbering')
need('metadata_only_no_pdf_no_assets' in ui,'metadata-only Supabase policy')
need('exportToDownloads' in ui and 'Downloads/Halaqati/Certificates' in ui,'independent local PDF export')
need('for (student in chosen)' in ui and 'NativeCertificate.exportToDownloads' in ui,'independent batch PDFs')
need('serverArchive' in ui and 'student_name' in ui,'lightweight official archive UI')
need('teacherName' in ui and 'supervisorName' in ui and 'halaqaName' in ui and 'centerName' in ui,'non-hardcoded identity fields')
need('certificateHijriDate' in ui and 'الهجري:' in ui,'dual dates')
need('fun studentCategories' in repo,'category repository source')
need('data class CertificateRecord' in core and 'CertificateCoreDraft' in core,'server certificate core retained')
# Guard against accidental binary/file upload code in certificate path.
for bad in ('storage.from(', 'uploadCertificatePdf', 'pdf_base64', 'logo_base64', 'signature_base64', 'stamp_base64'):
    need(bad not in ui, 'binary upload path detected: '+bad)
print('RC12.2 Certificates Studio gate PASS')
