package com.mohammedsamir.halaqati.documents

import android.app.Activity
import android.content.ContentValues
import android.content.Context
import android.content.ContextWrapper
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.ParcelFileDescriptor
import android.print.HalaqatiWebViewPdfWriter
import android.print.PageRange
import android.print.PrintAttributes
import android.print.PrintDocumentAdapter
import android.print.PrintDocumentInfo
import android.provider.MediaStore
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStream
import java.io.OutputStream
import java.util.UUID
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

enum class DocumentOrientation { LANDSCAPE, PORTRAIT }

data class VectorPdfResult(
    val pageCount: Int,
    val bytes: Long,
    val engine: String = "chromium-webview-vector",
    val uri: String? = null,
    val directory: String? = null,
)

/**
 * One-source Chromium document renderer.
 *
 * The proven v2.44 Android path is deliberately restored here for user-visible PDF saves:
 * Chromium writes first to an app-owned seekable temp file. Only after that file is validated
 * as a real non-empty PDF do we create/publish the Downloads entry. This is important because
 * ACTION_CREATE_DOCUMENT creates the destination placeholder before rendering; when numbering,
 * layout or WebView printing fails, some OEM file providers leave that placeholder as 0 bytes.
 */
object VectorDocumentRenderer {
    private const val READY_TIMEOUT_MS = 30_000L
    private const val WRITE_TIMEOUT_MS = 120_000L
    private const val MIN_VALID_PDF_BYTES = 512L
    private const val MAX_PDF_BYTES = 32L * 1024L * 1024L
    private val PDF_MAGIC = byteArrayOf('%'.code.toByte(), 'P'.code.toByte(), 'D'.code.toByte(), 'F'.code.toByte(), '-'.code.toByte())

    /** Compatibility path for existing SAF callers. New certificate/report actions use Downloads directly. */
    suspend fun saveHtmlPdf(
        context: Context,
        uri: Uri,
        html: String,
        documentName: String,
        orientation: DocumentOrientation,
    ): VectorPdfResult {
        require(html.isNotBlank()) { "محتوى المستند فارغ" }
        val temp = newTempPdf(context)
        return try {
            val rendered = renderToSeekableFile(context, temp, html, documentName, orientation)
            val copied = copyValidatedPdfToUri(context, temp, uri)
            rendered.copy(bytes = copied, uri = uri.toString())
        } finally {
            withContext(Dispatchers.IO) { runCatching { temp.delete() } }
        }
    }

    /**
     * v2.44-style direct save: render completely first, then publish to Downloads/Halaqati.
     * No empty destination is exposed to the user while Chromium is still working.
     */
    suspend fun saveHtmlPdfToDownloads(
        context: Context,
        html: String,
        fileName: String,
        subdirectory: String,
        documentName: String,
        orientation: DocumentOrientation,
    ): VectorPdfResult {
        require(html.isNotBlank()) { "محتوى المستند فارغ" }
        val temp = newTempPdf(context)
        return try {
            val rendered = renderToSeekableFile(context, temp, html, documentName, orientation)
            val stored = withContext(Dispatchers.IO) {
                persistCompletedPdfToDownloads(context, temp, safePdfName(fileName), safeSubdirectory(subdirectory))
            }
            rendered.copy(
                bytes = stored.bytes,
                engine = stored.engine,
                uri = stored.uri,
                directory = stored.directory,
            )
        } finally {
            withContext(Dispatchers.IO) { runCatching { temp.delete() } }
        }
    }

    suspend fun saveHtmlPdfToFile(
        context: Context,
        file: File,
        html: String,
        documentName: String,
        orientation: DocumentOrientation,
    ): VectorPdfResult {
        require(html.isNotBlank()) { "محتوى المستند فارغ" }
        return renderToSeekableFile(context, file, html, documentName, orientation)
    }

    private suspend fun renderToSeekableFile(
        context: Context,
        file: File,
        html: String,
        documentName: String,
        orientation: DocumentOrientation,
    ): VectorPdfResult {
        withContext(Dispatchers.IO) {
            file.parentFile?.mkdirs()
            if (file.exists() && !file.delete()) error("تعذر استبدال ملف PDF المؤقت")
        }
        val descriptor = withContext(Dispatchers.IO) {
            ParcelFileDescriptor.open(
                file,
                ParcelFileDescriptor.MODE_CREATE or
                    ParcelFileDescriptor.MODE_TRUNCATE or
                    ParcelFileDescriptor.MODE_READ_WRITE,
            )
        }
        val result = renderToDescriptor(context, descriptor, html, documentName, orientation)
        val bytes = withContext(Dispatchers.IO) {
            validatePdfFile(file)
            file.length()
        }
        return result.copy(bytes = bytes)
    }

    private suspend fun renderToDescriptor(
        context: Context,
        descriptor: ParcelFileDescriptor,
        html: String,
        documentName: String,
        orientation: DocumentOrientation,
    ): VectorPdfResult {
        val activity = context.findActivity() ?: error("يلزم فتح المستند من واجهة التطبيق")
        return try {
            withTimeout(WRITE_TIMEOUT_MS) {
                withContext(Dispatchers.Main.immediate) {
                    val webView = createPdfWebView(activity)
                    try {
                        loadAndAwaitReady(webView, html)
                        val adapter = webView.createPrintDocumentAdapter(documentName)
                        writeAdapter(adapter, descriptor, orientation)
                    } finally {
                        runCatching { webView.stopLoading() }
                        runCatching { webView.loadUrl("about:blank") }
                        runCatching { webView.removeAllViews() }
                        runCatching { webView.destroy() }
                    }
                }
            }
        } catch (t: Throwable) {
            runCatching { descriptor.close() }
            throw t
        }
    }

    private suspend fun copyValidatedPdfToUri(context: Context, source: File, uri: Uri): Long = withContext(Dispatchers.IO) {
        validatePdfFile(source)
        val resolver = context.contentResolver
        val output = resolver.openOutputStream(uri, "w") ?: error("تعذر فتح الملف المختار للكتابة")
        output.use { out ->
            FileInputStream(source).use { input -> copyPdfStream(input, out) }
            out.flush()
            if (out is FileOutputStream) runCatching { out.fd.sync() }
        }
        verifyStoredPdf(resolver = resolver, uri = uri)
    }

    private data class StoredPdf(val bytes: Long, val uri: String, val directory: String, val engine: String)

    private fun persistCompletedPdfToDownloads(context: Context, source: File, fileName: String, subdirectory: String): StoredPdf {
        validatePdfFile(source)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val resolver = context.contentResolver
            val relative = buildString {
                append(Environment.DIRECTORY_DOWNLOADS).append("/Halaqati")
                if (subdirectory.isNotBlank()) append('/').append(subdirectory)
            }
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                put(MediaStore.MediaColumns.MIME_TYPE, "application/pdf")
                put(MediaStore.MediaColumns.RELATIVE_PATH, relative)
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            }
            var uri: Uri? = null
            try {
                uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                    ?: error("تعذر إنشاء ملف PDF داخل التنزيلات")
                resolver.openOutputStream(uri, "w")?.use { output ->
                    FileInputStream(source).use { input -> copyPdfStream(input, output) }
                    output.flush()
                    if (output is FileOutputStream) runCatching { output.fd.sync() }
                } ?: error("تعذر فتح ملف PDF داخل التنزيلات")

                val bytes = verifyStoredPdf(resolver, uri)
                val published = resolver.update(
                    uri,
                    ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) },
                    null,
                    null,
                )
                require(published > 0) { "تم إنشاء PDF لكن تعذر نشره في التنزيلات" }
                return StoredPdf(
                    bytes = bytes,
                    uri = uri.toString(),
                    directory = relative,
                    engine = "chromium-webview-direct-mediastore-v244",
                )
            } catch (t: Throwable) {
                uri?.let { runCatching { resolver.delete(it, null, null) } }
                throw t
            }
        }

        // Android 6-9: preserve public Downloads when permission already exists; otherwise use
        // the app's external Downloads directory instead of leaving a broken 0-byte placeholder.
        val publicAllowed = context.checkSelfPermission(android.Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
        val base = if (publicAllowed) {
            @Suppress("DEPRECATION")
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
        } else {
            context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) ?: context.filesDir
        }
        val dir = File(base, "Halaqati${if (subdirectory.isBlank()) "" else "/$subdirectory"}").apply {
            if (!exists() && !mkdirs()) error("تعذر إنشاء مجلد PDF")
        }
        val target = uniqueFile(dir, fileName)
        try {
            FileInputStream(source).use { input ->
                FileOutputStream(target, false).use { output ->
                    copyPdfStream(input, output)
                    output.flush()
                    output.fd.sync()
                }
            }
            validatePdfFile(target)
            return StoredPdf(
                bytes = target.length(),
                uri = Uri.fromFile(target).toString(),
                directory = dir.absolutePath,
                engine = "chromium-webview-direct-file-v244",
            )
        } catch (t: Throwable) {
            runCatching { target.delete() }
            throw t
        }
    }

    private fun verifyStoredPdf(resolver: android.content.ContentResolver, uri: Uri): Long {
        var queried = 0L
        runCatching {
            resolver.query(uri, arrayOf(MediaStore.MediaColumns.SIZE), null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) queried = cursor.getLong(0)
            }
        }
        resolver.openInputStream(uri)?.use { input ->
            val buffer = ByteArray(16 * 1024)
            var total = 0L
            var signatureChecked = false
            while (true) {
                val read = input.read(buffer)
                if (read < 0) break
                if (read == 0) continue
                if (!signatureChecked) {
                    require(read >= PDF_MAGIC.size && buffer.copyOf(PDF_MAGIC.size).contentEquals(PDF_MAGIC)) {
                        "الملف المحفوظ ليس PDF صالحًا"
                    }
                    signatureChecked = true
                }
                total += read
                require(total <= MAX_PDF_BYTES) { "ملف PDF أكبر من الحد الآمن" }
            }
            require(signatureChecked && total >= MIN_VALID_PDF_BYTES) { "فشل التحقق بعد الحفظ؛ تم منع ملف 0 بايت" }
            return maxOf(total, queried)
        }
        error("تعذر قراءة ملف PDF بعد الحفظ")
    }

    private fun copyPdfStream(input: InputStream, output: OutputStream): Long {
        val buffer = ByteArray(64 * 1024)
        var total = 0L
        while (true) {
            val read = input.read(buffer)
            if (read < 0) break
            if (read == 0) continue
            total += read
            require(total <= MAX_PDF_BYTES) { "ملف PDF أكبر من الحد الآمن" }
            output.write(buffer, 0, read)
        }
        require(total >= MIN_VALID_PDF_BYTES) { "ملف PDF الناتج فارغ أو غير مكتمل" }
        return total
    }

    private fun validatePdfFile(file: File) {
        require(file.exists() && file.length() in MIN_VALID_PDF_BYTES..MAX_PDF_BYTES) {
            "فشل محرك PDF: الملف الناتج فارغ أو غير مكتمل"
        }
        val header = ByteArray(PDF_MAGIC.size)
        val read = FileInputStream(file).use { it.read(header) }
        require(read == PDF_MAGIC.size && header.contentEquals(PDF_MAGIC)) {
            "فشل محرك PDF: الناتج ليس ملف PDF صالحًا"
        }
    }

    private fun newTempPdf(context: Context): File = File(context.cacheDir, "halaqati_pdf/${UUID.randomUUID()}.pdf").apply {
        parentFile?.mkdirs()
        if (exists()) delete()
    }

    private fun safePdfName(raw: String): String {
        val base = raw.trim().ifBlank { "halaqati.pdf" }
            .replace(Regex("[\\\\/:*?\"<>|\\u0000-\\u001F]"), "_")
            .take(180)
        return if (base.endsWith(".pdf", true)) base else "$base.pdf"
    }

    private fun safeSubdirectory(raw: String): String = raw.trim()
        .replace(Regex("[^\\p{L}\\p{N} _.-]"), "_")
        .trim(' ', '.', '_')
        .take(48)

    private fun uniqueFile(dir: File, fileName: String): File {
        val direct = File(dir, fileName)
        if (!direct.exists()) return direct
        val stem = fileName.substringBeforeLast('.', fileName)
        val ext = fileName.substringAfterLast('.', "pdf")
        var i = 2
        while (i < 1000) {
            val candidate = File(dir, "$stem ($i).$ext")
            if (!candidate.exists()) return candidate
            i++
        }
        return File(dir, "$stem-${System.currentTimeMillis()}.$ext")
    }

    private fun createPdfWebView(activity: Activity): WebView = WebView(activity).apply {
        setBackgroundColor(android.graphics.Color.WHITE)
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = false
        settings.allowContentAccess = false
        settings.allowFileAccess = true
        settings.blockNetworkLoads = true
        settings.cacheMode = WebSettings.LOAD_NO_CACHE
        settings.loadWithOverviewMode = false
        settings.useWideViewPort = true
        settings.defaultTextEncodingName = "UTF-8"
        settings.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
    }

    private suspend fun loadAndAwaitReady(webView: WebView, html: String) {
        suspendCancellableCoroutine<Unit> { cont ->
            val terminal = AtomicBoolean(false)
            webView.webViewClient = object : WebViewClient() {
                override fun onPageFinished(view: WebView, url: String?) {
                    if (terminal.get()) return
                    view.post {
                        if (terminal.compareAndSet(false, true) && cont.isActive) cont.resume(Unit)
                    }
                }
            }
            cont.invokeOnCancellation {
                terminal.set(true)
                runCatching { webView.stopLoading() }
            }
            webView.loadDataWithBaseURL(
                "file:///android_asset/documents/",
                html,
                "text/html",
                "UTF-8",
                null,
            )
        }
        withTimeout(READY_TIMEOUT_MS) {
            while (true) {
                when (evaluateReady(webView)) {
                    1 -> break
                    -1 -> error("فشل فحص تخطيط المستند: يوجد تداخل أو محتوى خارج حدود A4")
                    else -> delay(80)
                }
            }
        }
    }

    /** 1=ready, 0=waiting, -1=layout rejected by the document preflight. */
    private suspend fun evaluateReady(webView: WebView): Int = suspendCancellableCoroutine { cont ->
        val js = """
            (function(){
              try {
                var fonts = (!document.fonts || document.fonts.status === 'loaded');
                var images = Array.prototype.every.call(document.images || [], function(i){return i.complete;});
                var app = (window.__HALAQATI_READY__ === true || window.__HALAQATI_READY__ === 'READY');
                if (!(document.readyState === 'complete' && fonts && images && app)) return 'WAIT';
                if (window.__HALAQATI_LAYOUT_OK__ === false || document.documentElement.dataset.layoutOk === '0') return 'LAYOUT_ERROR';
                return 'READY';
              } catch(e) { return 'WAIT'; }
            })();
        """.trimIndent()
        webView.evaluateJavascript(js) { raw ->
            if (cont.isActive) {
                when (raw?.replace("\"", "")) {
                    "READY" -> cont.resume(1)
                    "LAYOUT_ERROR" -> cont.resume(-1)
                    else -> cont.resume(0)
                }
            }
        }
    }

    private suspend fun writeAdapter(
        adapter: PrintDocumentAdapter,
        descriptor: ParcelFileDescriptor,
        orientation: DocumentOrientation,
    ): VectorPdfResult = suspendCancellableCoroutine { cont ->
        val media = when (orientation) {
            DocumentOrientation.PORTRAIT -> PrintAttributes.MediaSize.ISO_A4.asPortrait()
            DocumentOrientation.LANDSCAPE -> PrintAttributes.MediaSize.ISO_A4.asLandscape()
        }
        val attrs = PrintAttributes.Builder()
            .setMediaSize(media)
            .setResolution(PrintAttributes.Resolution("halaqati-vector", "Halaqati Vector", 600, 600))
            .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
            .setColorMode(PrintAttributes.COLOR_MODE_COLOR)
            .build()
        val done = AtomicBoolean(false)
        cont.invokeOnCancellation {
            if (done.compareAndSet(false, true)) {
                runCatching { descriptor.close() }
                runCatching { adapter.onFinish() }
            }
        }
        HalaqatiWebViewPdfWriter.write(adapter, attrs, descriptor, object : HalaqatiWebViewPdfWriter.Callback {
            override fun onSuccess(info: PrintDocumentInfo?, pages: Array<PageRange>?) {
                if (!done.compareAndSet(false, true) || !cont.isActive) return
                val pageCount = info?.pageCount ?: -1
                cont.resume(VectorPdfResult(pageCount = pageCount, bytes = -1L))
            }

            override fun onFailure(message: String?) {
                if (!done.compareAndSet(false, true) || !cont.isActive) return
                cont.resumeWithException(IllegalStateException(message ?: "تعذر إنشاء PDF المتجهي"))
            }

            override fun onCancelled() {
                if (!done.compareAndSet(false, true) || !cont.isActive) return
                cont.resumeWithException(IllegalStateException("تم إلغاء إنشاء PDF"))
            }
        })
    }
}

private tailrec fun Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
}
