# RC8 Third-Party Notices

## quran-qcf4 JSON data

RC8 derives compact page/line metadata from `verses.json` in:
`MohamadHajjRabee/quran-qcf4`.

Pinned source commit: `5130511027e769f0a8f4eeb7f00f46bde3788d60`  
Pinned `verses.json` Git blob: `568f4820cefe142ccd3f75b89fa99b1a2ad01fe9`

The upstream repository states that its JSON Data & Schema (including `verses.json`) are licensed under the MIT License:

MIT License

Copyright (c) 2026 Mohamad Hajj Rabee

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

RC8 does **not** copy or redistribute the upstream QCF4 font files.
