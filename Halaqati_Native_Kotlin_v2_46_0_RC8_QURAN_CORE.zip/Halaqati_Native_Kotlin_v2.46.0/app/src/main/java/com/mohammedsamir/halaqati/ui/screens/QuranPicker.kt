@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.mohammedsamir.halaqati.ui.screens

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.mohammedsamir.halaqati.quran.QuranCore
import com.mohammedsamir.halaqati.quran.QuranLocation
import com.mohammedsamir.halaqati.quran.QuranMetadata
import com.mohammedsamir.halaqati.quran.QuranRangeRequest
import com.mohammedsamir.halaqati.quran.QuranRangeResult
import com.mohammedsamir.halaqati.quran.QuranResolvedTraversal
import com.mohammedsamir.halaqati.quran.QuranSelection
import com.mohammedsamir.halaqati.quran.QuranTraversalDirection
import com.mohammedsamir.halaqati.ui.components.ProFilterChip
import java.util.Locale

private data class PickerOption(val value: Int, val label: String)

@Composable
private fun NumberDropdown(
    label: String,
    selected: Int,
    options: List<PickerOption>,
    onSelected: (Int) -> Unit,
    modifier: Modifier = Modifier,
) {
    var expanded by remember { mutableStateOf(false) }
    Box(modifier) {
        OutlinedButton(
            onClick = { expanded = true },
            modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp),
        ) {
            Text("$label: ${options.firstOrNull { it.value == selected }?.label ?: selected}", modifier = Modifier.weight(1f))
            Icon(Icons.Default.KeyboardArrowDown, contentDescription = null)
        }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            options.forEach { option ->
                DropdownMenuItem(
                    text = { Text(option.label) },
                    onClick = {
                        onSelected(option.value)
                        expanded = false
                    },
                    modifier = Modifier.heightIn(min = 48.dp),
                )
            }
        }
    }
}

private fun quranPagesLabel(value: Double): String {
    val raw = String.format(Locale.US, "%.2f", value)
    return raw.trimEnd('0').trimEnd('.').ifBlank { "0" }
}

private fun traversalLabel(value: QuranResolvedTraversal): String = when (value) {
    QuranResolvedTraversal.REVERSE_SURAH_ORDER -> "من السورة الأعلى رقمًا إلى الأقل · والآيات داخل كل سورة تصاعدية"
    QuranResolvedTraversal.REVERSE_WITHIN_SURAH -> "ترتيب الآيات محفوظ تنازليًا كما أُدخل"
    QuranResolvedTraversal.PAGE_ORDER_REVERSE -> "ترتيب الصفحات محفوظ تنازليًا"
    QuranResolvedTraversal.PAGE_ORDER_FORWARD -> "ترتيب الصفحات تصاعدي"
    QuranResolvedTraversal.EXPLICIT_SEGMENTS -> "مقاطع مختارة بالترتيب المقصود"
    QuranResolvedTraversal.FORWARD_QURAN -> "ترتيب المصحف تصاعدي"
}

@Composable
private fun SelectedNumberChips(
    values: List<Int>,
    labelFor: (Int) -> String,
    onRemove: (Int) -> Unit,
) {
    if (values.isEmpty()) return
    Row(
        modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        values.forEach { value ->
            InputChip(
                selected = true,
                onClick = { onRemove(value) },
                label = { Text(labelFor(value)) },
                trailingIcon = { Icon(Icons.Default.Close, contentDescription = "حذف") },
            )
        }
    }
}

/**
 * RC8 Quran editor. It delegates all ordering and page-fraction decisions to the
 * shared QuranRangeEngine; this UI never swaps start/end using min/max.
 */
@Composable
fun QuranRangePickerDialog(
    initialStartPage: Int? = null,
    initialEndPage: Int? = null,
    track: String = "tathbit",
    activityType: String = "review_near",
    direction: QuranTraversalDirection = QuranTraversalDirection.AUTO_BY_ACTIVITY,
    onDismiss: () -> Unit,
    onConfirm: (QuranRangeResult) -> Unit,
) {
    val generalHifz = track == "general_hifz" && activityType in setOf("new_hifz", "hifz")
    val defaultSurah = if (generalHifz) 114 else 1
    var mode by remember { mutableStateOf(if (initialStartPage != null || initialEndPage != null) "pages" else "ayahs") }
    var startPageText by remember { mutableStateOf((initialStartPage ?: if (generalHifz) 604 else 1).toString()) }
    var endPageText by remember { mutableStateOf((initialEndPage ?: initialStartPage ?: if (generalHifz) 604 else 1).toString()) }
    var startSurah by remember { mutableIntStateOf(defaultSurah) }
    var startAyah by remember { mutableIntStateOf(1) }
    var endSurah by remember { mutableIntStateOf(defaultSurah) }
    var endAyah by remember { mutableIntStateOf(QuranMetadata.maxAyah(defaultSurah)) }
    var candidateSurah by remember { mutableIntStateOf(defaultSurah) }
    var candidateJuz by remember { mutableIntStateOf(if (generalHifz) 30 else 1) }
    val selectedSurahs = remember { mutableStateListOf<Int>() }
    val selectedJuz = remember { mutableStateListOf<Int>() }

    val surahOptions = remember {
        (1..QuranMetadata.SURAH_COUNT).map { PickerOption(it, "$it. ${QuranMetadata.surahName(it)}") }
    }
    val juzOptions = remember { (1..QuranMetadata.JUZ_COUNT).map { PickerOption(it, "الجزء $it") } }

    val surahSnapshot = selectedSurahs.toList()
    val juzSnapshot = selectedJuz.toList()
    val attempt = runCatching {
        val selection = when (mode) {
            "pages" -> QuranSelection.Pages(startPageText.toInt(), endPageText.toInt())
            "surahs" -> QuranSelection.Surahs(surahSnapshot)
            "juz" -> QuranSelection.Juz(juzSnapshot)
            else -> QuranSelection.Ayahs(QuranLocation(startSurah, startAyah), QuranLocation(endSurah, endAyah))
        }
        QuranCore.engine().calculate(
            QuranRangeRequest(
                track = track,
                activityType = activityType,
                selection = selection,
                direction = direction,
            ),
        )
    }
    val range = attempt.getOrNull()
    val rangeError = attempt.exceptionOrNull()?.message

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("اختيار المقرر من المصحف") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    listOf(
                        "ayahs" to "سورة وآية",
                        "pages" to "صفحات",
                        "surahs" to "سور متعددة",
                        "juz" to "أجزاء متعددة",
                    ).forEach { (value, title) ->
                        ProFilterChip(
                            selected = mode == value,
                            onClick = { mode = value },
                            label = title,
                        )
                    }
                }

                when (mode) {
                    "pages" -> {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = startPageText,
                                onValueChange = { startPageText = it.filter(Char::isDigit).take(3) },
                                label = { Text("صفحة البداية") },
                                modifier = Modifier.weight(1f),
                                singleLine = true,
                            )
                            OutlinedTextField(
                                value = endPageText,
                                onValueChange = { endPageText = it.filter(Char::isDigit).take(3) },
                                label = { Text("صفحة النهاية") },
                                modifier = Modifier.weight(1f),
                                singleLine = true,
                            )
                        }
                        Text("النطاق 1–604. لن يُقلب ترتيب الصفحتين تلقائيًا.", style = MaterialTheme.typography.bodySmall)
                    }

                    "surahs" -> {
                        NumberDropdown("السورة", candidateSurah, surahOptions, { candidateSurah = it })
                        OutlinedButton(
                            onClick = { if (candidateSurah !in selectedSurahs) selectedSurahs += candidateSurah },
                            modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp),
                        ) {
                            Icon(Icons.Default.Add, contentDescription = null)
                            Spacer(Modifier.width(8.dp))
                            Text("إضافة السورة")
                        }
                        SelectedNumberChips(
                            values = surahSnapshot,
                            labelFor = { "${QuranMetadata.surahName(it)} ($it)" },
                            onRemove = { selectedSurahs.remove(it) },
                        )
                        Text("يمكن اختيار سور غير متجاورة؛ الترتيب يحدده النشاط والمسار.", style = MaterialTheme.typography.bodySmall)
                    }

                    "juz" -> {
                        NumberDropdown("الجزء", candidateJuz, juzOptions, { candidateJuz = it })
                        OutlinedButton(
                            onClick = { if (candidateJuz !in selectedJuz) selectedJuz += candidateJuz },
                            modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp),
                        ) {
                            Icon(Icons.Default.Add, contentDescription = null)
                            Spacer(Modifier.width(8.dp))
                            Text("إضافة الجزء")
                        }
                        SelectedNumberChips(
                            values = juzSnapshot,
                            labelFor = { "الجزء $it" },
                            onRemove = { selectedJuz.remove(it) },
                        )
                        Text("يمكن اختيار أكثر من جزء، ويحفظ النظام الاختيار في سجل التسميع.", style = MaterialTheme.typography.bodySmall)
                    }

                    else -> {
                        Text("البداية", style = MaterialTheme.typography.titleSmall)
                        NumberDropdown("السورة", startSurah, surahOptions, {
                            startSurah = it
                            startAyah = startAyah.coerceAtMost(QuranMetadata.maxAyah(it))
                        })
                        NumberDropdown(
                            "الآية",
                            startAyah,
                            (1..QuranMetadata.maxAyah(startSurah)).map { PickerOption(it, it.toString()) },
                            { startAyah = it },
                        )
                        HorizontalDivider()
                        Text("النهاية", style = MaterialTheme.typography.titleSmall)
                        NumberDropdown("السورة", endSurah, surahOptions, {
                            endSurah = it
                            endAyah = endAyah.coerceAtMost(QuranMetadata.maxAyah(it))
                        })
                        NumberDropdown(
                            "الآية",
                            endAyah,
                            (1..QuranMetadata.maxAyah(endSurah)).map { PickerOption(it, it.toString()) },
                            { endAyah = it },
                        )
                    }
                }

                range?.let { selected ->
                    ElevatedCard(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                            Text("📖 ${selected.displayLabel}", style = MaterialTheme.typography.titleSmall)
                            Text("📄 ${quranPagesLabel(selected.exactPages)} صفحة", style = MaterialTheme.typography.bodyLarge)
                            Text("🔢 ${selected.ayahCount} آية · ${selected.surahCount} سورة", style = MaterialTheme.typography.bodyMedium)
                            Text("↕ ${traversalLabel(selected.resolvedTraversal)}", style = MaterialTheme.typography.bodySmall)
                            Text("QCF4 · مصحف المدينة 604 صفحة · 15 سطرًا", style = MaterialTheme.typography.labelSmall)
                        }
                    }
                } ?: Text(
                    rangeError ?: "الاختيار غير صالح. تحقق من القيم.",
                    color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.bodyMedium,
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { range?.let(onConfirm) },
                enabled = range != null,
                modifier = Modifier.heightIn(min = 48.dp),
            ) { Text("اعتماد الاختيار") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss, modifier = Modifier.heightIn(min = 48.dp)) { Text("إلغاء") }
        },
    )
}
