@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.mohammedsamir.halaqati.ui

import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.core.tween
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.mohammedsamir.halaqati.data.DeepLinkRules
import com.mohammedsamir.halaqati.model.Profile
import com.mohammedsamir.halaqati.model.SyncState
import com.mohammedsamir.halaqati.ui.components.SyncBanner
import com.mohammedsamir.halaqati.ui.components.EmptyState
import com.mohammedsamir.halaqati.ui.components.GoldenBottomBar
import com.mohammedsamir.halaqati.ui.components.GoldenDrawerContent
import com.mohammedsamir.halaqati.ui.components.GoldenShellActions
import com.mohammedsamir.halaqati.ui.components.LocalGoldenShellActions
import com.mohammedsamir.halaqati.ui.components.roleTitle
import com.mohammedsamir.halaqati.ui.navigation.AppDestination
import com.mohammedsamir.halaqati.ui.navigation.RoleNavigationPolicy
import com.mohammedsamir.halaqati.ui.screens.*
import kotlinx.coroutines.launch

@Composable
fun HalaqatiApp(
    initialDeepLink: String? = null,
    vm: AppViewModel = viewModel(),
) {
    val auth by vm.auth.collectAsState()
    val sync by vm.sync.collectAsState()

    LaunchedEffect(initialDeepLink) { vm.handleDeepLink(initialDeepLink) }

    when (val state = auth) {
        AuthState.Loading -> androidx.compose.foundation.layout.Box(
            Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center,
        ) { CircularProgressIndicator() }

        AuthState.SignedOut -> AuthScreen(
            onLogin = vm::login,
            onRegister = vm::register,
            onGoogleIdToken = vm::loginWithGoogleIdToken,
            onGoogleOAuthUrl = vm::googleOAuthUrl,
            onResetPassword = vm::requestPasswordReset,
        )
        is AuthState.Error -> AuthScreen(
            error = state.message,
            onLogin = vm::login,
            onRegister = vm::register,
            onGoogleIdToken = vm::loginWithGoogleIdToken,
            onGoogleOAuthUrl = vm::googleOAuthUrl,
            onResetPassword = vm::requestPasswordReset,
        )

        is AuthState.Pending -> PendingApprovalScreen(state.profile, vm::bootstrap, vm::logout)
        is AuthState.Recovery -> PasswordRecoveryScreen(
            email = state.email,
            onSubmit = vm::completePasswordRecovery,
            onCancel = vm::cancelPasswordRecovery,
        )
        is AuthState.Ready -> MainShell(state.profile, sync, vm::sync, vm::logout, initialDeepLink)
    }
}

@Composable
private fun MainShell(
    profile: Profile,
    sync: SyncState,
    onSync: () -> Unit,
    onLogout: () -> Unit,
    initialDeepLink: String?,
) {
    val nav = rememberNavController()
    val destinations = remember(profile.role) { RoleNavigationPolicy.destinations(profile.role) }
    val destinationRoutes = remember(destinations) { destinations.map { it.route }.toSet() }
    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    var deepLinkedStudentId by remember { mutableStateOf<String?>(null) }
    val current = nav.currentBackStackEntryAsState().value?.destination?.route ?: AppDestination.Home.route

    fun navigateTo(destination: AppDestination) {
        if (!RoleNavigationPolicy.canOpen(profile.role, destination)) return
        nav.navigate(destination.route) {
            launchSingleTop = true
            restoreState = true
            popUpTo(AppDestination.Home.route) { saveState = true }
        }
    }

    fun drawerNavigate(destination: AppDestination) {
        scope.launch { drawerState.close() }
        navigateTo(destination)
    }

    LaunchedEffect(initialDeepLink, profile.role) {
        val parsed = DeepLinkRules.navigation(initialDeepLink)
        deepLinkedStudentId = parsed?.studentId
        AppDestination.fromRoute(parsed?.route)
            ?.takeIf { RoleNavigationPolicy.canOpen(profile.role, it) }
            ?.let { nav.navigate(it.route) { launchSingleTop = true } }
    }

    CompositionLocalProvider(
        LocalGoldenShellActions provides GoldenShellActions(
            roleLabel = roleTitle(profile.role),
            online = sync.online,
            pending = sync.pending,
            openDrawer = { scope.launch { drawerState.open() } },
            openNotifications = { navigateTo(AppDestination.Notifications) },
            openSyncCenter = { navigateTo(AppDestination.SyncCenter) },
        ),
    ) {
    ModalNavigationDrawer(
        drawerState = drawerState,
        gesturesEnabled = true,
        drawerContent = {
            ModalDrawerSheet(
                drawerShape = androidx.compose.ui.graphics.RectangleShape,
                drawerContainerColor = MaterialTheme.colorScheme.surface,
                modifier = Modifier.widthIn(max = 340.dp).fillMaxWidth(.88f),
            ) {
                GoldenDrawerContent(
                    profile = profile,
                    currentRoute = current,
                    onNavigate = ::drawerNavigate,
                    onClose = { scope.launch { drawerState.close() } },
                    onLogout = onLogout,
                )
            }
        },
    ) {
        Scaffold(
            containerColor = MaterialTheme.colorScheme.background,
            bottomBar = {
                GoldenBottomBar(
                    role = profile.role,
                    currentRoute = current,
                    drawerOpen = drawerState.isOpen,
                    onNavigate = ::navigateTo,
                    onMore = { scope.launch { drawerState.open() } },
                )
            },
        ) { padding ->
            Column(Modifier.padding(padding).fillMaxSize()) {
                SyncBanner(
                    sync.online,
                    sync.pending,
                    sync.blocked,
                    sync.error,
                    onSync,
                    onDetails = { navigateTo(AppDestination.SyncCenter) },
                )
                NavHost(
                    navController = nav,
                    startDestination = AppDestination.Home.route,
                    modifier = Modifier.weight(1f),
                    enterTransition = { fadeIn(animationSpec = tween(180)) + slideInHorizontally(animationSpec = tween(180)) { it / 12 } },
                    exitTransition = { fadeOut(animationSpec = tween(150)) },
                ) {
                    destinations.forEach { destination ->
                        composable(destination.route) {
                            FeatureRouter(
                                destination,
                                profile,
                                sync,
                                onSync,
                                { raw -> AppDestination.fromRoute(raw)?.takeIf { it.route in destinationRoutes }?.let(::navigateTo) },
                                onLogout,
                                deepLinkedStudentId,
                            )
                        }
                    }
                }
            }
        }
    }
    }
}

@Composable
private fun FeatureRouter(destination:AppDestination,profile:Profile,sync:SyncState,onSync:()->Unit,navigate:(String)->Unit,onLogout:()->Unit,deepLinkedStudentId:String?){
    when(destination.route){
        "home"->DashboardScreen(profile,sync,navigate,onSync)
        "students"->StudentsScreen(sync.pending,onSync)
        "sessions"->SessionsScreen(sync.pending,onSync)
        "session_today"->SessionsScreen(sync.pending,onSync,openTodayOnLaunch=true)
        "quick_memorization"->QuickMemorizationScreen(sync.pending,onSync)
        "plans"->PlansScreen(profile,sync.pending,onSync)
        "reports"->ReportsScreen(profile,sync.pending,onSync)
        "certificates"->CertificatesScreen(profile,sync.pending,onSync)
        "notifications"->NotificationsNativeScreen(profile,sync.pending,onSync)
        "halaqas"->HalaqasManagementScreen(profile,sync.pending,onSync)
        "community"->CommunityNativeScreen(profile,sync.pending,onSync)
        "rankings"->RankingsScreen(profile,sync.pending,onSync)
        "guardian_competition"->GuardianCompetitionNativeScreen(profile,sync.pending,onSync)
        "guardian_achievements"->GuardianAchievementsNativeScreen(profile,sync.pending,onSync)
        "importexport"->ImportExportScreen(profile,sync.pending,onSync)
        "sync_center"->SyncCenterScreen(sync,onSync)
        "supervision"->SupervisionNativeScreen(profile,sync.pending,onSync,navigate)
        "users"->UsersScreen(sync.pending,onSync)
        "quran"->QuranCalculatorScreen()
        "guardian_profile"->GuardianProfileNativeScreen(profile,sync.online,sync.pending,onSync,initialStudentId=deepLinkedStudentId)
        "settings"->SettingsScreen(profile,onLogout)
        else->UnknownRouteScreen(destination.route){navigate(AppDestination.Home.route)}
    }
}

@Composable
private fun UnknownRouteScreen(route: String, onHome: () -> Unit) {
    Column(Modifier.fillMaxSize()) {
        TopAppBar(title = { Text("صفحة غير متاحة") })
        EmptyState(
            text = "تعذر فتح المسار: $route",
            actionLabel = "العودة للرئيسية",
            onAction = onHome,
        )
    }
}


fun iconFor(key: String) = when (key) {
    "home" -> Icons.Default.Home
    "notifications" -> Icons.Default.Notifications
    "group" -> Icons.Default.Groups
    "forum" -> Icons.Default.Forum
    "event" -> Icons.Default.Event
    "person" -> Icons.Default.Person
    "timeline" -> Icons.Default.Timeline
    "award" -> Icons.Default.EmojiEvents
    "report" -> Icons.Default.Assessment
    "book" -> Icons.Default.MenuBook
    "leaderboard" -> Icons.Default.Leaderboard
    "competition" -> Icons.Default.BarChart
    "importexport" -> Icons.Default.ImportExport
    "sync" -> Icons.Default.Sync
    "supervisor" -> Icons.Default.SupervisorAccount
    "users" -> Icons.Default.ManageAccounts
    "profile" -> Icons.Default.AccountCircle
    "settings" -> Icons.Default.Settings
    "sessions" -> Icons.Default.Event
    "students" -> Icons.Default.Groups
    "plans" -> Icons.Default.Timeline
    "reports" -> Icons.Default.Assessment
    "more" -> Icons.Default.MoreHoriz
    else -> Icons.Default.Apps
}
