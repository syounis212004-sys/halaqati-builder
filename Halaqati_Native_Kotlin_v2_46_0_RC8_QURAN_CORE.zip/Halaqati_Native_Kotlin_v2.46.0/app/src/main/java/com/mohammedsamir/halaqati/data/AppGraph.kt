package com.mohammedsamir.halaqati.data

import android.content.Context
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import java.util.concurrent.TimeUnit

object AppGraph {
    lateinit var store: SecureSessionStore
        private set
    lateinit var api: SupabaseApi
        private set
    lateinit var queue: OfflineQueue
        private set
    lateinit var cache: LocalCache
        private set
    lateinit var offlineDb: HalaqatiOfflineDatabase
        private set
    lateinit var repo: HalaqatiRepository
        private set
    lateinit var uiPreferences: UiPreferencesStore
        private set

    private val appScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    fun init(context: Context) {
        val appContext = context.applicationContext
        store = SecureSessionStore(appContext)
        uiPreferences = UiPreferencesStore(appContext)
        offlineDb = HalaqatiOfflineDatabase.get(appContext)
        queue = OfflineQueue(offlineDb)
        cache = LocalCache(offlineDb)
        api = SupabaseApi(store)
        repo = HalaqatiRepository(appContext, api, store, queue, cache, offlineDb)

        // Never block first frame on migration; the old SQLite files remain untouched for rollback.
        appScope.launch { OfflineLegacyImporter.importIfNeeded(appContext, offlineDb) }

        val constraints = Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()
        val work = PeriodicWorkRequestBuilder<SyncWorker>(15, TimeUnit.MINUTES)
            .setConstraints(constraints)
            .build()
        val workManager = WorkManager.getInstance(appContext)
        workManager.enqueueUniquePeriodicWork(
            "halaqati-sync",
            ExistingPeriodicWorkPolicy.KEEP,
            work,
        )
        val alertWork = PeriodicWorkRequestBuilder<SmartPlanAlertsWorker>(6, TimeUnit.HOURS)
            .setConstraints(constraints)
            .build()
        workManager.enqueueUniquePeriodicWork(
            "halaqati-smart-plan-alerts",
            ExistingPeriodicWorkPolicy.KEEP,
            alertWork,
        )
    }
}

class SyncWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result = try {
        AppGraph.repo.syncNow()
        Result.success()
    } catch (_: Exception) {
        Result.retry()
    }
}

class SmartPlanAlertsWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result = try {
        AppGraph.repo.runSmartPlanAlerts()
        Result.success()
    } catch (_: Exception) {
        Result.retry()
    }
}
