@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.mohammedsamir.halaqati.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.mohammedsamir.halaqati.data.AppGraph
import com.mohammedsamir.halaqati.data.PlanSnapshot
import com.mohammedsamir.halaqati.data.SafetyScoring
import com.mohammedsamir.halaqati.data.OfflineQueue
import com.mohammedsamir.halaqati.model.*
import com.mohammedsamir.halaqati.quran.QuranCore
import com.mohammedsamir.halaqati.quran.QuranMetadata
import com.mohammedsamir.halaqati.quran.QuranRangeRequest
import com.mohammedsamir.halaqati.quran.QuranRangeResult
import com.mohammedsamir.halaqati.quran.QuranSelection
import com.mohammedsamir.halaqati.ui.components.*
import com.mohammedsamir.halaqati.ui.sessions.SessionWorkflowRules
import com.mohammedsamir.halaqati.ui.theme.HalaqatiUiTokens
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.time.LocalDate
import java.time.Period
import java.time.YearMonth

@Composable
fun StudentsScreen(pending: Int, onRefresh: () -> Unit) {
    val scope = rememberCoroutineScope()
    var rows by remember { mutableStateOf<List<Student>>(emptyList()) }
    var halaqas by remember { mutableStateOf<List<JSONObject>>(emptyList()) }
    var categories by remember { mutableStateOf<List<JSONObject>>(emptyList()) }
    var snapshotsByStudent by remember { mutableStateOf<Map<String, PlanSnapshot>>(emptyMap()) }
    var monthStatsByStudent by remember { mutableStateOf<Map<String, JSONObject>>(emptyMap()) }
    var loading by remember { mutableStateOf(true) }
    var query by remember { mutableStateOf("") }
    var trackFilter by remember { mutableStateOf("all") }
    var statusFilter by remember { mutableStateOf("active") }
    var halaqaFilter by remember { mutableStateOf("all") }
    var categoryFilter by remember { mutableStateOf("all") }
    var sortMode by remember { mutableStateOf("alpha") }
    var add by remember { mutableStateOf(false) }
    var selectedStudent by remember { mutableStateOf<Student?>(null) }
    var directRecitation by remember { mutableStateOf<Triple<Student, SessionRow, PlanSnapshot?>?>(null) }
    var message by remember { mutableStateOf<String?>(null) }

    suspend fun reload(force: Boolean = false) {
        loading = true
        try {
            val loaded = withContext(Dispatchers.IO) {
                val studentRows = AppGraph.repo.students(forceRefresh = force)
                val h = AppGraph.repo.table("halaqas", "select=id,name,active&order=name.asc&limit=200")
                val c = AppGraph.repo.table("student_categories", "select=id,halaqa_id,name,active&order=name.asc&limit=500")
                Triple(
                    studentRows,
                    (0 until h.length()).mapNotNull { h.optJSONObject(it) },
                    (0 until c.length()).mapNotNull { c.optJSONObject(it) },
                )
            }
            rows = loaded.first
            halaqas = loaded.second
            categories = loaded.third
            message = null
        } catch (e: Exception) {
            message = e.message ?: "تعذر تحميل الطلاب"
        } finally {
            loading = false
        }
    }

    fun startTodayRecitation(student: Student) {
        scope.launch {
            try {
                val snapshot = snapshotsByStudent[student.id] ?: withContext(Dispatchers.IO) {
                    AppGraph.repo.planSnapshots(LocalDate.now()).firstOrNull { it.student.id == student.id }
                }
                val halaqaId = student.halaqaId ?: snapshot?.plan?.halaqaId ?: error("الطالب غير مرتبط بحلقة")
                val assignment = snapshot?.progress?.assignment
                val session = withContext(Dispatchers.IO) {
                    AppGraph.repo.ensureTodaySession(
                        halaqaId = halaqaId,
                        date = LocalDate.now().toString(),
                        assignmentKind = assignment?.kind ?: "hifz",
                    )
                }
                directRecitation = Triple(student, session, snapshot)
                message = null
            } catch (e: Exception) {
                message = e.message ?: "تعذر تجهيز جلسة التسميع"
            }
        }
    }

    LaunchedEffect(Unit) { reload() }

    LaunchedEffect(rows.map { it.id }.joinToString("|")) {
        if (rows.isEmpty()) {
            snapshotsByStudent = emptyMap()
            monthStatsByStudent = emptyMap()
        } else {
            runCatching {
                withContext(Dispatchers.IO) {
                    val snapshots = AppGraph.repo.planSnapshots(LocalDate.now()).associateBy { it.student.id }
                    val ym = YearMonth.now()
                    val summary = AppGraph.repo.reportSummary(ym.atDay(1).toString(), LocalDate.now().toString(), "all", "all", "all")
                    val stats = buildMap<String, JSONObject> {
                        for (i in 0 until summary.length()) summary.optJSONObject(i)?.let { row ->
                            row.optString("student_id").takeIf { it.isNotBlank() }?.let { put(it, row) }
                        }
                    }
                    snapshots to stats
                }
            }.onSuccess { (snapshots, stats) ->
                snapshotsByStudent = snapshots
                monthStatsByStudent = stats
            }
        }
    }

    Column {
        AppTopBar(
            title = "الطلاب",
            onRefresh = {
                scope.launch { reload(force = true) }
                onRefresh()
            },
            pending = pending,
        )

        Row(
            Modifier.padding(horizontal = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                label = { Text("بحث بالاسم أو الهوية أو الهاتف") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                modifier = Modifier.weight(1f),
                singleLine = true,
            )
            Spacer(Modifier.width(8.dp))
            FilledIconButton(
                onClick = { add = true },
                modifier = Modifier.size(HalaqatiUiTokens.TouchTarget),
            ) {
                Icon(Icons.Default.Add, contentDescription = "إضافة")
            }
        }

        Column(
            Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ProFilterChip(statusFilter == "active", { statusFilter = "active" }, "الطلاب الحاليون")
                ProFilterChip(statusFilter == "all", { statusFilter = "all" }, "كل الحالات")
                ProFilterChip(statusFilter == "inactive", { statusFilter = "inactive" }, "غير نشط")
                ProFilterChip(statusFilter == "suspended", { statusFilter = "suspended" }, "موقوف")
                ProFilterChip(statusFilter == "withdrawn", { statusFilter = "withdrawn" }, "المنسحبون / الأرشيف")
            }
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ProFilterChip(trackFilter == "all", { trackFilter = "all" }, "كل المسارات")
                ProFilterChip(trackFilter == "general_hifz", { trackFilter = "general_hifz" }, "الحفظ العام")
                ProFilterChip(trackFilter == "tathbit", { trackFilter = "tathbit" }, "التثبيت")
            }
            if (halaqas.size > 1) {
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ProFilterChip(halaqaFilter == "all", { halaqaFilter = "all"; categoryFilter = "all" }, "كل الحلقات")
                    halaqas.filter { it.optBoolean("active", true) }.forEach { h ->
                        val id = h.optString("id")
                        ProFilterChip(halaqaFilter == id, { halaqaFilter = id; categoryFilter = "all" }, h.optString("name", "حلقة"))
                    }
                }
            }
            val visibleCategories = categories.filter {
                it.optBoolean("active", true) && (halaqaFilter == "all" || it.optString("halaqa_id") == halaqaFilter)
            }
            if (visibleCategories.isNotEmpty()) {
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ProFilterChip(categoryFilter == "all", { categoryFilter = "all" }, "كل الفئات")
                    ProFilterChip(categoryFilter == "none", { categoryFilter = "none" }, "بدون فئة")
                    visibleCategories.forEach { c ->
                        val id = c.optString("id")
                        ProFilterChip(categoryFilter == id, { categoryFilter = id }, c.optString("name", "فئة"))
                    }
                }
            }
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ProFilterChip(sortMode == "alpha", { sortMode = "alpha" }, "ترتيب أبجدي")
                ProFilterChip(sortMode == "recent", { sortMode = "recent" }, "الأحدث")
                ProFilterChip(sortMode == "progress", { sortMode = "progress" }, "حسب المسار")
            }
        }

        message?.let { StateNotice(it, kind = "error", modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)) }

        val filteredBase = rows.filter { student ->
            val needle = query.trim()
            val searchOk = needle.isBlank() || listOfNotNull(
                student.fullName, student.nationalId, student.phone, student.guardianPhone, student.guardianName,
            ).any { it.contains(needle, ignoreCase = true) }
            val statusOk = statusFilter == "all" || student.status == statusFilter
            val trackOk = trackFilter == "all" || student.track == trackFilter
            val halaqaOk = halaqaFilter == "all" || student.halaqaId == halaqaFilter
            val categoryOk = when (categoryFilter) {
                "all" -> true
                "none" -> student.categoryId.isNullOrBlank()
                else -> student.categoryId == categoryFilter
            }
            searchOk && statusOk && trackOk && halaqaOk && categoryOk
        }
        val filtered = when (sortMode) {
            "progress" -> filteredBase.sortedWith(compareBy<Student> { it.track }.thenBy { it.fullName })
            "recent" -> filteredBase.reversed()
            else -> filteredBase.sortedBy { it.fullName }
        }
        if (loading && rows.isEmpty()) {
            LoadingSkeleton(rows = 4, modifier = Modifier.padding(12.dp))
        }
        if (!loading && filtered.isEmpty()) {
            EmptyState(
                text = if (query.isBlank()) "لا يوجد طلاب حتى الآن" else "لا توجد نتائج مطابقة للبحث",
                actionLabel = "إعادة تعيين الفلاتر",
                onAction = {
                    query = ""
                    trackFilter = "all"
                    statusFilter = "active"
                    halaqaFilter = "all"
                    categoryFilter = "all"
                },
            )
        }

        PullToRefreshBox(
            isRefreshing = loading,
            onRefresh = { scope.launch { reload(force = true) }; onRefresh() },
            modifier = Modifier.weight(1f),
        ) {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(start = 12.dp, end = 12.dp, top = 12.dp, bottom = 120.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                items(filtered, key = { it.id }, contentType = { "student" }) { student ->
                    val halaqaName = halaqas.firstOrNull { it.optString("id") == student.halaqaId }?.optString("name")
                    val categoryName = categories.firstOrNull { it.optString("id") == student.categoryId }?.optString("name")
                    GoldenStudentCard(
                        student = student,
                        halaqaName = halaqaName,
                        categoryName = categoryName,
                        snapshot = snapshotsByStudent[student.id],
                        monthStats = monthStatsByStudent[student.id],
                        onOpenProfile = { selectedStudent = student },
                        onRecitation = { startTodayRecitation(student) },
                        onPlan = { selectedStudent = student },
                        onEdit = { selectedStudent = student },
                    )
                }
            }
        }
    }

    if (add) {
        StudentDialog(
            close = { add = false },
            onSaved = {
                add = false
                scope.launch { reload() }
                onRefresh()
            },
        )
    }


    selectedStudent?.let { student ->
        StudentDetailSheet(
            student = student,
            onDismiss = { selectedStudent = null },
            onChanged = {
                scope.launch { reload(force = true) }
                onRefresh()
            },
            onStartRecitation = { snapshot ->
                scope.launch {
                    try {
                        val halaqaId = student.halaqaId ?: snapshot?.plan?.halaqaId
                            ?: error("الطالب غير مرتبط بحلقة")
                        val assignment = snapshot?.progress?.assignment
                        val session = withContext(Dispatchers.IO) {
                            AppGraph.repo.ensureTodaySession(
                                halaqaId = halaqaId,
                                date = LocalDate.now().toString(),
                                assignmentKind = assignment?.kind ?: "hifz",
                            )
                        }
                        selectedStudent = null
                        directRecitation = Triple(student, session, snapshot)
                        message = null
                    } catch (e: Exception) {
                        message = e.message ?: "تعذر تجهيز جلسة التسميع"
                    }
                }
            },
        )
    }

    directRecitation?.let { (student, session, snapshot) ->
        val assignment = snapshot?.progress?.assignment
        RecitationDialog(
            student = student,
            session = session,
            close = { directRecitation = null },
            onSaved = {
                directRecitation = null
                scope.launch { reload(force = true) }
                onRefresh()
            },
            prefillStartPage = assignment?.startPage,
            prefillEndPage = assignment?.endPage,
            prefillPages = assignment?.pages?.takeIf { it > 0.0 },
            smartPlanId = snapshot?.plan?.id,
            smartPlanType = snapshot?.plan?.type,
            smartPlanDate = snapshot?.let { LocalDate.now().toString() },
            qcfLineKeys = assignment?.lineKeys.orEmpty(),
            activityTypeOverride = assignment?.kind?.let { kind ->
                when (kind) {
                    "sard" -> "sard"
                    "review" -> "review_near"
                    "tathbit" -> "review_far"
                    "test" -> "test"
                    else -> "new_hifz"
                }
            },
        )
    }
}

@Composable
private fun StudentDetailSheet(
    student: Student,
    onDismiss: () -> Unit,
    onChanged: () -> Unit,
    onStartRecitation: (PlanSnapshot?) -> Unit,
) {
    val scope = rememberCoroutineScope()
    var loading by remember(student.id) { mutableStateOf(true) }
    var online by remember(student.id) { mutableStateOf(true) }
    var saving by remember(student.id) { mutableStateOf(false) }
    var error by remember(student.id) { mutableStateOf<String?>(null) }
    var raw by remember(student.id) { mutableStateOf<JSONObject?>(null) }
    var recitations by remember(student.id) { mutableStateOf<List<JSONObject>>(emptyList()) }
    var attendance by remember(student.id) { mutableStateOf<List<JSONObject>>(emptyList()) }
    var snapshot by remember(student.id) { mutableStateOf<PlanSnapshot?>(null) }
    var track by remember(student.id) { mutableStateOf(student.track) }
    var status by remember(student.id) { mutableStateOf(student.status) }
    var showFullEdit by remember(student.id) { mutableStateOf(false) }
    var showGuardianLink by remember(student.id) { mutableStateOf(false) }
    var showArchiveConfirm by remember(student.id) { mutableStateOf(false) }

    suspend fun reloadDetail() {
        loading = true
        try {
            val today = LocalDate.now()
            val from = today.withDayOfMonth(1).toString()
            val to = today.toString()
            online = withContext(Dispatchers.IO) { AppGraph.repo.online() }
            if (!online) {
                raw = withContext(Dispatchers.IO) { AppGraph.repo.studentRaw(student.id) }
                recitations = emptyList()
                attendance = emptyList()
                snapshot = runCatching {
                    withContext(Dispatchers.IO) { AppGraph.repo.planSnapshots(today).firstOrNull { it.student.id == student.id } }
                }.getOrNull()
                error = null
                track = raw?.optString("track_code").orEmpty().ifBlank { student.track }
                status = raw?.optString("status").orEmpty().ifBlank { student.status }
                return
            }
            val result = withContext(Dispatchers.IO) {
                val studentRaw = AppGraph.repo.table(
                    "students",
                    "select=*&id=eq.${student.id}&limit=1",
                ).optJSONObject(0)
                val recitationArray = AppGraph.repo.table(
                    "recitation_entries",
                    "select=id,activity_type,start_page,end_page,pages_count,evaluation,points,mistakes,prompts,created_at," +
                        "sessions!inner(session_date,session_type,title)" +
                        "&student_id=eq.${student.id}&sessions.session_date=gte.$from&sessions.session_date=lte.$to" +
                        "&order=created_at.desc&limit=1000",
                )
                val attendanceArray = AppGraph.repo.table(
                    "attendance_records",
                    "select=status,arrival_minutes_late,excuse_reason,recorded_at,sessions!inner(session_date)" +
                        "&student_id=eq.${student.id}&sessions.session_date=gte.$from&sessions.session_date=lte.$to" +
                        "&order=recorded_at.desc&limit=1000",
                )
                val planSnapshot = runCatching { AppGraph.repo.planSnapshots(today) }
                    .getOrDefault(emptyList())
                    .firstOrNull { it.student.id == student.id }
                Quadruple(
                    studentRaw,
                    (0 until recitationArray.length()).mapNotNull { recitationArray.optJSONObject(it) },
                    (0 until attendanceArray.length()).mapNotNull { attendanceArray.optJSONObject(it) },
                    planSnapshot,
                )
            }
            raw = result.first
            recitations = result.second
            attendance = result.third
            snapshot = result.fourth
            track = result.first?.optString("track_code").orEmpty().ifBlank { student.track }
            status = result.first?.optString("status").orEmpty().ifBlank { student.status }
            error = null
        } catch (e: Exception) {
            error = e.message ?: "تعذر تحميل تفاصيل الطالب"
        } finally {
            loading = false
        }
    }

    LaunchedEffect(student.id) { reloadDetail() }

    val hifz = recitations.filter { it.optString("activity_type") == "new_hifz" }.sumOf { it.optDouble("pages_count", 0.0) }
    val review = recitations.filter { it.optString("activity_type") in setOf("review_near", "review_far") }.sumOf { it.optDouble("pages_count", 0.0) }
    val sard = recitations.filter { it.optString("activity_type") == "sard" }.sumOf { it.optDouble("pages_count", 0.0) }
    val present = attendance.count { it.optString("status") in setOf("present", "late") }
    val absent = attendance.count { it.optString("status") == "absent" }
    val late = attendance.count { it.optString("status") == "late" }

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(Modifier.fillMaxWidth()) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Surface(
                    modifier = Modifier.size(52.dp),
                    shape = MaterialTheme.shapes.large,
                    color = MaterialTheme.colorScheme.primaryContainer,
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.Person, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    }
                }
                Column(Modifier.weight(1f)) {
                    Text(student.fullName, style = MaterialTheme.typography.titleLarge)
                    Text(
                        if (track == "tathbit") "مسار التثبيت" else "مسار الحفظ العام",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                Surface(
                    color = when (status) {
                        "active" -> MaterialTheme.colorScheme.primaryContainer
                        "suspended" -> MaterialTheme.colorScheme.tertiaryContainer
                        else -> MaterialTheme.colorScheme.surfaceVariant
                    },
                    shape = MaterialTheme.shapes.small,
                ) {
                    Text(
                        studentStatusAr(status),
                        style = MaterialTheme.typography.labelLarge,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp),
                    )
                }
            }

            error?.let { StateNotice(it, kind = "error", modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)) }
            if (!online) {
                StateNotice(
                    "وضع الأوفلاين: بيانات الطالب محفوظة محليًا، وأي تعديل أو تسميع سيُضاف إلى صندوق المزامنة تلقائيًا.",
                    kind = "warning",
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp),
                )
            }
            if (loading) LoadingSkeleton(rows = 3, modifier = Modifier.padding(16.dp))

            if (!loading) {
                LazyColumn(
                    modifier = Modifier.weight(1f, fill = false).heightIn(max = 620.dp),
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    item {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            StudentMiniMetric("حفظ الشهر", "${plainNumber(hifz)} ص", Modifier.weight(1f))
                            StudentMiniMetric("مراجعة", "${plainNumber(review)} ص", Modifier.weight(1f))
                            StudentMiniMetric("سرد", "${plainNumber(sard)} ص", Modifier.weight(1f))
                        }
                        Spacer(Modifier.height(8.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            StudentMiniMetric("الحضور", present.toString(), Modifier.weight(1f))
                            StudentMiniMetric("الغياب", absent.toString(), Modifier.weight(1f))
                            StudentMiniMetric("التأخر", late.toString(), Modifier.weight(1f))
                        }
                    }

                    snapshot?.let { plan ->
                        item {
                            ElevatedCard(Modifier.fillMaxWidth()) {
                                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                        Column(Modifier.weight(1f)) {
                                            Text("الخطة الذكية", style = MaterialTheme.typography.titleMedium)
                                            Text(plan.plan.title.ifBlank { planTypeAr(plan.plan.type) }, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        }
                                        PlanHealthBadge(plan.progress.health, plan.progress.healthLabel)
                                    }
                                    LinearProgressIndicator(
                                        progress = { (plan.progress.percentage / 100.0).toFloat().coerceIn(0f, 1f) },
                                        modifier = Modifier.fillMaxWidth().height(8.dp).graphicsLayer(scaleX = -1f),
                                    )
                                    Text(
                                        "الإنجاز ${plainNumber(plan.progress.percentage)}% · المتبقي ${plainNumber(plan.progress.remaining)} صفحة · اليوم ${plainNumber(plan.progress.assignment.pages)} صفحة",
                                        style = MaterialTheme.typography.bodyMedium,
                                    )
                                }
                            }
                        }
                    }

                    item {
                        ElevatedCard(Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                Text("البيانات الأساسية", style = MaterialTheme.typography.titleMedium)
                                StudentDetailLine("المرحلة", jsonText(raw, "school_grade"))
                                StudentDetailLine("جوال ولي الأمر", jsonText(raw, "guardian_phone"))
                                StudentDetailLine("بريد ولي الأمر", jsonText(raw, "guardian_email"))
                                StudentDetailLine("تاريخ الميلاد", jsonText(raw, "date_of_birth"))
                            }
                        }
                    }

                    item {
                        ElevatedCard(Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                Text("إدارة الطالب", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    OutlinedButton(
                                        onClick = { showFullEdit = true },
                                        modifier = Modifier.weight(1f).heightIn(min = HalaqatiUiTokens.TouchTarget),
                                    ) { Text("تعديل البيانات") }
                                    OutlinedButton(
                                        onClick = { showGuardianLink = true },
                                        modifier = Modifier.weight(1f).heightIn(min = HalaqatiUiTokens.TouchTarget),
                                    ) { Text("ولي الأمر") }
                                }
                                Button(
                                    onClick = { showArchiveConfirm = true },
                                    enabled = !saving,
                                    colors = if (status == "withdrawn") ButtonDefaults.buttonColors()
                                    else ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                                    modifier = Modifier.fillMaxWidth().heightIn(min = HalaqatiUiTokens.TouchTarget),
                                ) { Text(if (status == "withdrawn") "استعادة الطالب" else "أرشفة / سحب الطالب") }
                                Text(
                                    "الأرشفة لا تحذف الجلسات أو التسميعات أو التقارير؛ ويمكن استعادة الطالب لاحقًا.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            }
                        }
                    }

                    item {
                        Text("آخر التسميعات", style = MaterialTheme.typography.titleMedium)
                        if (recitations.isEmpty()) {
                            EmptyState("لا توجد تسميعات مسجلة هذا الشهر")
                        } else {
                            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                recitations.take(6).forEach { row ->
                                    val session = row.optJSONObject("sessions")
                                    ElevatedCard(Modifier.fillMaxWidth()) {
                                        Row(
                                            Modifier.fillMaxWidth().padding(12.dp).heightIn(min = 48.dp),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                                        ) {
                                            Icon(Icons.Default.MenuBook, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                            Column(Modifier.weight(1f)) {
                                                Text(activityTypeAr(row.optString("activity_type")), style = MaterialTheme.typography.labelLarge)
                                                Text(
                                                    "${session?.optString("session_date").orEmpty()} · ${pageRangeLabel(nullableInt(row, "start_page"), nullableInt(row, "end_page"))}",
                                                    style = MaterialTheme.typography.bodySmall,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                )
                                            }
                                            Text("${plainNumber(row.optDouble("pages_count", 0.0))} ص", style = MaterialTheme.typography.labelLarge)
                                        }
                                    }
                                }
                            }
                        }
                    }

                    item {
                        ElevatedCard(Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                Text("تعديل سريع", style = MaterialTheme.typography.titleMedium)
                                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    ProFilterChip(track == "general_hifz", { track = "general_hifz" }, "الحفظ العام")
                                    ProFilterChip(track == "tathbit", { track = "tathbit" }, "التثبيت")
                                }
                                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    ProFilterChip(status == "active", { status = "active" }, "نشط")
                                    ProFilterChip(status == "inactive", { status = "inactive" }, "غير نشط")
                                    ProFilterChip(status == "suspended", { status = "suspended" }, "موقوف")
                                    ProFilterChip(status == "withdrawn", { status = "withdrawn" }, "منسحب")
                                }
                                Button(
                                    onClick = {
                                        saving = true
                                        scope.launch {
                                            try {
                                                withContext(Dispatchers.IO) {
                                                    AppGraph.repo.patch(
                                                        "students",
                                                        "id=eq.${student.id}",
                                                        JSONObject().put("track_code", track).put("status", status),
                                                        dedupe = "student-quick-edit:${student.id}",
                                                    )
                                                }
                                                onChanged()
                                                reloadDetail()
                                            } catch (e: Exception) {
                                                error = e.message ?: "تعذر تحديث الطالب"
                                            } finally {
                                                saving = false
                                            }
                                        }
                                    },
                                    enabled = !saving,
                                    modifier = Modifier.fillMaxWidth().heightIn(min = HalaqatiUiTokens.TouchTarget),
                                ) { Text(if (saving) "جاري الحفظ…" else if (online) "حفظ التعديل" else "حفظ محليًا") }
                            }
                        }
                    }
                }

                Surface(shadowElevation = 8.dp, tonalElevation = 2.dp) {
                    Button(
                        onClick = { onStartRecitation(snapshot) },
                        enabled = !saving,
                        modifier = Modifier.fillMaxWidth().padding(16.dp).heightIn(min = 52.dp),
                    ) {
                        Icon(Icons.Default.RecordVoiceOver, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text(if (online) "بدء تسميع ${student.fullName}" else "بدء تسميع أوفلاين · ${student.fullName}")
                    }
                }
            }
        }
    }

    if (showFullEdit) {
        StudentFullEditDialog(
            student = student,
            raw = raw,
            close = { showFullEdit = false },
            onSaved = { showFullEdit = false; onChanged(); scope.launch { reloadDetail() } },
        )
    }
    if (showGuardianLink) {
        GuardianLinkDialog(
            close = { showGuardianLink = false },
            onSaved = { showGuardianLink = false; onChanged(); scope.launch { reloadDetail() } },
            initialStudentId = student.id,
        )
    }
    if (showArchiveConfirm) {
        AlertDialog(
            onDismissRequest = { showArchiveConfirm = false },
            title = { Text(if (status == "withdrawn") "استعادة الطالب" else "أرشفة الطالب") },
            text = { Text(if (status == "withdrawn") "سيعود الطالب إلى قائمة الطلاب الحاليين مع بقاء سجله كاملًا." else "سيُنقل الطالب إلى المنسحبين / الأرشيف دون حذف الجلسات أو التسميعات أو التقارير.") },
            confirmButton = {
                Button(onClick = {
                    showArchiveConfirm = false
                    saving = true
                    scope.launch {
                        try {
                            val newStatus = if (status == "withdrawn") "active" else "withdrawn"
                            withContext(Dispatchers.IO) {
                                AppGraph.repo.patch("students", "id=eq.${student.id}", JSONObject().put("status", newStatus), dedupe = "student-archive:${student.id}:$newStatus")
                            }
                            status = newStatus
                            onChanged(); reloadDetail()
                        } catch (e: Exception) { error = e.message ?: "تعذر تحديث حالة الطالب" }
                        finally { saving = false }
                    }
                }) { Text(if (status == "withdrawn") "استعادة" else "أرشفة") }
            },
            dismissButton = { TextButton(onClick = { showArchiveConfirm = false }) { Text("إلغاء") } },
        )
    }
}

@Composable
private fun StudentFullEditDialog(student: Student, raw: JSONObject?, close: () -> Unit, onSaved: () -> Unit) {
    StudentEditorDialog(student = student, raw = raw, close = close, onSaved = onSaved)
}

@Composable
private fun StudentDialog(close: () -> Unit, onSaved: () -> Unit) {
    StudentEditorDialog(student = null, raw = null, close = close, onSaved = onSaved)
}

@Composable
private fun StudentEditorDialog(student: Student?, raw: JSONObject?, close: () -> Unit, onSaved: () -> Unit) {
    val scope = rememberCoroutineScope()
    var fullName by remember(student?.id) { mutableStateOf(raw?.optString("full_name").orEmpty().ifBlank { student?.fullName.orEmpty() }) }
    var nationalId by remember(student?.id) { mutableStateOf(raw?.optString("national_id").orEmpty().ifBlank { student?.nationalId.orEmpty() }) }
    var phone by remember(student?.id) { mutableStateOf(raw?.optString("phone").orEmpty().ifBlank { student?.phone.orEmpty() }) }
    var schoolGrade by remember(student?.id) { mutableStateOf(raw?.optString("school_grade").orEmpty().ifBlank { student?.schoolGrade.orEmpty() }) }
    var dateOfBirth by remember(student?.id) { mutableStateOf(raw?.optString("date_of_birth").orEmpty().ifBlank { student?.dateOfBirth.orEmpty() }) }
    var gender by remember(student?.id) { mutableStateOf(raw?.optString("gender").orEmpty().ifBlank { student?.gender.orEmpty() }) }
    var guardianPhone by remember(student?.id) { mutableStateOf(raw?.optString("guardian_phone").orEmpty().ifBlank { student?.guardianPhone.orEmpty() }) }
    var guardianEmail by remember(student?.id) { mutableStateOf(raw?.optString("guardian_email").orEmpty().ifBlank { student?.guardianEmail.orEmpty() }) }
    var track by remember(student?.id) { mutableStateOf(raw?.optString("track_code").orEmpty().ifBlank { student?.track ?: "general_hifz" }) }
    var halaqaId by remember(student?.id) { mutableStateOf(raw?.optString("halaqa_id").orEmpty().ifBlank { student?.halaqaId.orEmpty() }) }
    var categoryId by remember(student?.id) { mutableStateOf(raw?.optString("category_id").orEmpty().ifBlank { student?.categoryId.orEmpty() }) }
    var status by remember(student?.id) { mutableStateOf(raw?.optString("status").orEmpty().ifBlank { student?.status ?: "active" }) }
    var enrollmentDate by remember(student?.id) { mutableStateOf(raw?.optString("enrollment_date").orEmpty().ifBlank { student?.enrollmentDate ?: LocalDate.now().toString() }) }
    var programName by remember(student?.id) { mutableStateOf(raw?.optString("program_name").orEmpty().ifBlank { student?.programName.orEmpty() }) }
    var address by remember(student?.id) { mutableStateOf(raw?.optString("address").orEmpty().ifBlank { student?.address.orEmpty() }) }
    var notes by remember(student?.id) { mutableStateOf(raw?.optString("notes").orEmpty().ifBlank { student?.notes.orEmpty() }) }
    var photoPath by remember(student?.id) { mutableStateOf(raw?.optString("photo_path").orEmpty().ifBlank { student?.photoPath.orEmpty() }) }
    var halaqas by remember { mutableStateOf<List<JSONObject>>(emptyList()) }
    var categories by remember { mutableStateOf<List<JSONObject>>(emptyList()) }
    var saving by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(Unit) {
        val master = withContext(Dispatchers.IO) {
            val h = AppGraph.repo.table("halaqas", "select=id,name,active&order=name.asc&limit=200")
            val c = AppGraph.repo.table("student_categories", "select=id,halaqa_id,name,active&order=name.asc&limit=500")
            Pair(
                (0 until h.length()).mapNotNull { h.optJSONObject(it) },
                (0 until c.length()).mapNotNull { c.optJSONObject(it) },
            )
        }
        halaqas = master.first
        categories = master.second
        if (halaqaId.isBlank()) halaqaId = halaqas.firstOrNull { it.optBoolean("active", true) }?.optString("id").orEmpty()
    }

    val visibleCategories = categories.filter { it.optBoolean("active", true) && (halaqaId.isBlank() || it.optString("halaqa_id") == halaqaId) }
    LaunchedEffect(halaqaId, categories.size) {
        if (categoryId.isNotBlank() && visibleCategories.none { it.optString("id") == categoryId }) categoryId = ""
    }

    AlertDialog(
        onDismissRequest = { if (!saving) close() },
        title = { Text(if (student == null) "إضافة طالب" else "تعديل بيانات الطالب") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                error?.let { StateNotice(it, "error") }
                if (!AppGraph.repo.online()) StateNotice("سيُحفظ التعديل على هذا الجهاز ويُرفع تلقائيًا عند عودة الإنترنت.", "warning")
                OutlinedTextField(fullName, { fullName = it }, label = { Text("الاسم الكامل") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                OutlinedTextField(nationalId, { nationalId = it }, label = { Text("رقم الهوية") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                OutlinedTextField(phone, { phone = it }, label = { Text("هاتف الطالب") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ProFilterChip(gender == "male", { gender = "male" }, "ذكر")
                    ProFilterChip(gender == "female", { gender = "female" }, "أنثى")
                }
                StudentDateField("تاريخ الميلاد", dateOfBirth, onDate = { dateOfBirth = it })
                OutlinedTextField(schoolGrade, { schoolGrade = it }, label = { Text("المرحلة / الصف") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                StudentNamedDropdown(
                    label = "الحلقة",
                    selectedId = halaqaId,
                    items = halaqas.filter { it.optBoolean("active", true) || it.optString("id") == halaqaId },
                    onSelected = { halaqaId = it; categoryId = "" },
                )
                StudentNamedDropdown(
                    label = "الفئة", selectedId = categoryId, items = visibleCategories, allowEmpty = true,
                    onSelected = { categoryId = it },
                )
                Text("المسار", style = MaterialTheme.typography.labelLarge)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ProFilterChip(track == "general_hifz", { track = "general_hifz" }, "الحفظ العام")
                    ProFilterChip(track == "tathbit", { track = "tathbit" }, "التثبيت")
                }
                Text("الحالة", style = MaterialTheme.typography.labelLarge)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ProFilterChip(status == "active", { status = "active" }, "نشط")
                    ProFilterChip(status == "inactive", { status = "inactive" }, "غير نشط")
                    ProFilterChip(status == "suspended", { status = "suspended" }, "موقوف")
                    ProFilterChip(status == "withdrawn", { status = "withdrawn" }, "منسحب")
                }
                StudentDateField("تاريخ الالتحاق", enrollmentDate, onDate = { enrollmentDate = it })
                OutlinedTextField(programName, { programName = it }, label = { Text("البرنامج") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                OutlinedTextField(guardianPhone, { guardianPhone = it }, label = { Text("جوال ولي الأمر") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                OutlinedTextField(guardianEmail, { guardianEmail = it }, label = { Text("بريد ولي الأمر") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                OutlinedTextField(address, { address = it }, label = { Text("العنوان") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                OutlinedTextField(notes, { notes = it }, label = { Text("ملاحظات") }, modifier = Modifier.fillMaxWidth(), minLines = 2)
                if (photoPath.isNotBlank()) {
                    Text("الصورة محفوظة في سجل الطالب. تغيير ملف الصورة نفسه يحتاج اتصالًا مستقرًا بالخادم.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        },
        confirmButton = {
            Button(
                enabled = !saving && fullName.trim().length >= 2 && halaqaId.isNotBlank(),
                onClick = {
                    saving = true
                    scope.launch {
                        try {
                            val payload = JSONObject()
                                .put("full_name", fullName.trim())
                                .putNullableUi("national_id", nationalId)
                                .putNullableUi("phone", phone)
                                .putNullableUi("school_grade", schoolGrade)
                                .putNullableUi("date_of_birth", dateOfBirth)
                                .putNullableUi("gender", gender)
                                .putNullableUi("guardian_phone", guardianPhone)
                                .putNullableUi("guardian_email", guardianEmail)
                                .put("track_code", track)
                                .put("halaqa_id", halaqaId)
                                .put("category_id", categoryId.takeIf { it.isNotBlank() } ?: JSONObject.NULL)
                                .put("status", status)
                                .putNullableUi("enrollment_date", enrollmentDate)
                                .putNullableUi("program_name", programName)
                                .putNullableUi("address", address)
                                .putNullableUi("notes", notes)
                            if (photoPath.isNotBlank()) payload.put("photo_path", photoPath)
                            withContext(Dispatchers.IO) {
                                if (student == null) {
                                    payload.put("id", java.util.UUID.randomUUID().toString())
                                    AppGraph.repo.write("students", payload, onConflict = "id", dedupe = "student-create:${payload.optString("id")}")
                                } else {
                                    AppGraph.repo.patch("students", "id=eq.${student.id}", payload, dedupe = "student-full-edit:${student.id}")
                                }
                            }
                            onSaved()
                        } catch (e: Exception) { error = e.message ?: "تعذر حفظ بيانات الطالب" }
                        finally { saving = false }
                    }
                },
            ) { Text(if (saving) "جاري الحفظ…" else if (AppGraph.repo.online()) "حفظ" else "حفظ محليًا") }
        },
        dismissButton = { TextButton(onClick = close, enabled = !saving) { Text("إلغاء") } },
    )
}

@Composable
private fun StudentNamedDropdown(
    label: String,
    selectedId: String,
    items: List<JSONObject>,
    allowEmpty: Boolean = false,
    onSelected: (String) -> Unit,
) {
    var expanded by remember { mutableStateOf(false) }
    val selectedName = items.firstOrNull { it.optString("id") == selectedId }?.optString("name").orEmpty()
    ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = !expanded }) {
        OutlinedTextField(
            value = selectedName.ifBlank { if (allowEmpty) "بدون $label" else "اختر $label" },
            onValueChange = {}, readOnly = true, label = { Text(label) },
            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) },
            modifier = Modifier.menuAnchor().fillMaxWidth(),
        )
        ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            if (allowEmpty) DropdownMenuItem(text = { Text("بدون $label") }, onClick = { onSelected(""); expanded = false })
            items.forEach { row ->
                DropdownMenuItem(text = { Text(row.optString("name", label)) }, onClick = { onSelected(row.optString("id")); expanded = false })
            }
        }
    }
}

@Composable
private fun StudentDateField(label: String, value: String, onDate: (String) -> Unit) {
    var open by remember { mutableStateOf(false) }
    OutlinedTextField(
        value = value, onValueChange = {}, readOnly = true, label = { Text(label) },
        placeholder = { Text("اختر التاريخ") },
        trailingIcon = {
            IconButton(onClick = { open = true }, modifier = Modifier.size(HalaqatiUiTokens.TouchTarget)) {
                Icon(Icons.Default.CalendarMonth, contentDescription = label)
            }
        },
        modifier = Modifier.fillMaxWidth(),
    )
    if (open) {
        val initialMillis = remember(value) {
            runCatching { LocalDate.parse(value).atStartOfDay(java.time.ZoneOffset.UTC).toInstant().toEpochMilli() }.getOrNull()
        }
        val picker = rememberDatePickerState(initialSelectedDateMillis = initialMillis)
        DatePickerDialog(
            onDismissRequest = { open = false },
            confirmButton = {
                TextButton(onClick = {
                    picker.selectedDateMillis?.let { millis ->
                        onDate(java.time.Instant.ofEpochMilli(millis).atZone(java.time.ZoneOffset.UTC).toLocalDate().toString())
                    }
                    open = false
                }) { Text("اختيار") }
            },
            dismissButton = { TextButton(onClick = { open = false }) { Text("إلغاء") } },
        ) { DatePicker(state = picker) }
    }
}

private fun JSONObject.putNullableUi(key: String, value: String): JSONObject = apply {
    put(key, value.trim().takeIf { it.isNotBlank() } ?: JSONObject.NULL)
}

private data class Quadruple<A, B, C, D>(val first: A, val second: B, val third: C, val fourth: D)

@Composable
private fun StudentMiniMetric(label: String, value: String, modifier: Modifier = Modifier) {
    Surface(modifier, shape = MaterialTheme.shapes.small, color = MaterialTheme.colorScheme.surfaceVariant) {
        Column(Modifier.padding(horizontal = 10.dp, vertical = 9.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(value, style = MaterialTheme.typography.titleMedium)
            Text(label, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun StudentDetailLine(label: String, value: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, style = MaterialTheme.typography.bodyMedium, fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold)
    }
}

private fun jsonText(row: JSONObject?, key: String): String {
    if (row == null || !row.has(key) || row.isNull(key)) return "—"
    return row.optString(key).takeUnless { it.isBlank() || it == "null" } ?: "—"
}

private fun activityTypeAr(value: String): String = when (value) {
    "new_hifz" -> "حفظ جديد"
    "review_near" -> "مراجعة قريبة"
    "review_far" -> "مراجعة بعيدة"
    "sard" -> "سرد"
    "tilawah" -> "تلاوة"
    "test" -> "اختبار"
    else -> value
}

private fun nullableInt(row: JSONObject, key: String): Int? =
    if (!row.has(key) || row.isNull(key)) null else row.optInt(key).takeIf { it > 0 }

private fun studentStatusAr(status: String): String = when (status) {
    "active" -> "نشط"
    "inactive" -> "غير نشط"
    "suspended" -> "موقوف"
    "withdrawn" -> "منسحب"
    else -> status
}

@Composable
fun SessionsScreen(pending: Int, onRefresh: () -> Unit, openTodayOnLaunch: Boolean = false) {
    val scope = rememberCoroutineScope()
    var rows by remember { mutableStateOf<List<SessionRow>>(emptyList()) }
    var students by remember { mutableStateOf<List<Student>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var add by remember { mutableStateOf(false) }
    var active by remember { mutableStateOf<SessionRow?>(null) }
    var message by remember { mutableStateOf<String?>(null) }

    suspend fun reload(force: Boolean = false) {
        loading = true
        try {
            val result = withContext(Dispatchers.IO) {
                AppGraph.repo.sessions(forceRefresh = force) to AppGraph.repo.students(forceRefresh = force)
            }
            rows = result.first
            students = result.second
            message = null
        } catch (e: Exception) {
            message = e.message ?: "تعذر تحميل الجلسات"
        } finally {
            loading = false
        }
    }

    LaunchedEffect(openTodayOnLaunch) {
        reload()
        if (openTodayOnLaunch) {
            try {
                val session = withContext(Dispatchers.IO) {
                    val halaqaId = AppGraph.repo.firstHalaqaId()
                        ?: error("لا توجد حلقة مفعلة أو محفوظة محليًا لفتح جلسة اليوم")
                    AppGraph.repo.openOrCreateTodaySession(halaqaId, LocalDate.now().toString(), "hifz").getOrThrow()
                }
                rows = (listOf(session) + rows.filterNot { it.id == session.id }).sortedByDescending { it.date }
                students = withContext(Dispatchers.IO) { AppGraph.repo.students() }
                active = session
                message = null
            } catch (e: Exception) {
                message = e.message ?: "تعذر فتح جلسة اليوم"
            }
        }
    }

    fun openToday() {
        scope.launch {
            try {
                val session = withContext(Dispatchers.IO) {
                    val halaqaId = AppGraph.repo.firstHalaqaId()
                        ?: error("لا توجد حلقة مفعلة أو محفوظة محليًا لفتح جلسة اليوم")
                    AppGraph.repo.openOrCreateTodaySession(halaqaId, LocalDate.now().toString(), "hifz").getOrThrow()
                }
                rows = (listOf(session) + rows.filterNot { it.id == session.id }).sortedByDescending { it.date }
                active = session
                message = null
            } catch (e: Exception) {
                message = e.message ?: "تعذر فتح جلسة اليوم"
            }
        }
    }

    Column {
        AppTopBar(
            title = "الجلسات اليومية",
            onRefresh = {
                scope.launch { reload(force = true) }
                onRefresh()
            },
            pending = pending,
        )
        Row(
            Modifier.padding(12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Button(onClick = ::openToday) {
                Icon(Icons.Default.PlayArrow, contentDescription = null)
                Text(" ابدأ جلسة اليوم")
            }
            FilledIconButton(
                onClick = { add = true },
                modifier = Modifier.size(HalaqatiUiTokens.TouchTarget),
            ) {
                Icon(Icons.Default.Add, contentDescription = "جلسة مخصصة")
            }
            Surface(
                color = MaterialTheme.colorScheme.surfaceVariant,
                shape = MaterialTheme.shapes.small,
            ) {
                Text(
                    "تسميع · سرد · مراجعة · اختبار · نشاط",
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                )
            }
        }
        message?.let { StateNotice(it, kind = "error", modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)) }
        if (loading && rows.isEmpty()) LoadingSkeleton(rows = 3, modifier = Modifier.padding(12.dp))
        if (!loading && rows.isEmpty()) EmptyState("لا توجد جلسات حتى الآن")

        LazyColumn(
            contentPadding = PaddingValues(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            items(rows, key = { it.id }, contentType = { "session" }) { session ->
                GoldenSessionCard(session = session, onClick = { active = session })
            }
        }
    }

    if (add) {
        NewSessionDialog(
            close = { add = false },
            save = { date, type, title ->
                scope.launch {
                    try {
                        withContext(Dispatchers.IO) {
                            val halaqaId = AppGraph.repo.firstHalaqaId()
                                ?: error("لا توجد حلقة مفعلة لإنشاء الجلسة")
                            AppGraph.repo.createSession(halaqaId, date, type, title)
                        }
                        add = false
                        reload()
                    } catch (e: Exception) {
                        message = e.message ?: "تعذر إنشاء الجلسة"
                    }
                }
            },
        )
    }

    active?.let { session ->
        SessionRosterDialog(
            session = session,
            students = students.filter { it.halaqaId == null || it.halaqaId == session.halaqaId },
            pending = pending,
            close = { active = null },
            onChanged = { scope.launch { reload() } },
        )
    }
}

@Composable
private fun GoldenStudentCard(
    student: Student,
    halaqaName: String?,
    categoryName: String?,
    snapshot: PlanSnapshot?,
    monthStats: JSONObject?,
    onOpenProfile: () -> Unit,
    onRecitation: () -> Unit,
    onPlan: () -> Unit,
    onEdit: () -> Unit,
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(22.dp),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
    ) {
        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(verticalAlignment = Alignment.Top, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Surface(
                    modifier = Modifier.size(58.dp),
                    shape = RoundedCornerShape(18.dp),
                    color = MaterialTheme.colorScheme.primaryContainer,
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Text(student.fullName.trim().take(1).ifBlank { "ط" }, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    }
                }
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(student.fullName, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Text(
                        buildList {
                            add(if (student.track == "tathbit") "مسار التثبيت" else "مسار الحفظ العام")
                            if (!categoryName.isNullOrBlank()) add(categoryName)
                            if (!halaqaName.isNullOrBlank()) add(halaqaName)
                            studentAge(student.dateOfBirth)?.let { add("$it سنة") }
                        }.joinToString(" · "),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                Surface(
                    shape = RoundedCornerShape(999.dp),
                    color = if (student.status == "active") MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,
                ) {
                    Text(
                        studentStatusAr(student.status),
                        modifier = Modifier.padding(horizontal = 11.dp, vertical = 7.dp),
                        style = MaterialTheme.typography.labelMedium,
                        color = if (student.status == "active") MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                        fontWeight = FontWeight.Bold,
                    )
                }
            }
            monthStats?.let { stats ->
                val hifz = stats.optDouble("hifz_pages", 0.0)
                val tathbit = stats.optDouble("tathbit_pages", 0.0)
                val review = stats.optDouble("review_pages", 0.0)
                val absence = stats.optInt("absent", 0)
                Text(
                    buildList {
                        if (student.track == "tathbit") add("تثبيت ${plainNumber(tathbit)} ص") else add("حفظ ${plainNumber(hifz)} ص")
                        add("مراجعة ${plainNumber(review)} ص")
                        add("غياب $absence")
                    }.joinToString(" · "),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            snapshot?.progress?.let { progress ->
                Surface(
                    color = MaterialTheme.colorScheme.primaryContainer,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Text(
                        "الخطة ${plainNumber(progress.percentage)}% · ورد اليوم ${plainNumber(progress.dailyTarget)} ص · المنجز ${plainNumber(progress.completedToday)} ص",
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                    )
                }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                Button(
                    onClick = onRecitation,
                    modifier = Modifier.weight(1f).heightIn(min = 48.dp),
                    contentPadding = PaddingValues(horizontal = 8.dp),
                ) { Text("تسميع اليوم", maxLines = 1) }
                FilledTonalButton(
                    onClick = onOpenProfile,
                    modifier = Modifier.weight(1f).heightIn(min = 48.dp),
                    contentPadding = PaddingValues(horizontal = 8.dp),
                ) { Text("الملف الشخصي", maxLines = 1) }
                FilledTonalButton(
                    onClick = onPlan,
                    modifier = Modifier.weight(.72f).heightIn(min = 48.dp),
                    contentPadding = PaddingValues(horizontal = 7.dp),
                ) { Text("الخطة", maxLines = 1) }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                OutlinedButton(onClick = onEdit, modifier = Modifier.heightIn(min = 48.dp)) {
                    Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("تعديل البيانات")
                }
            }
        }
    }
}

private fun studentAge(dateOfBirth: String?): Int? {
    val dob = dateOfBirth?.let { runCatching { LocalDate.parse(it.take(10)) }.getOrNull() } ?: return null
    return Period.between(dob, LocalDate.now()).years.takeIf { it in 3..100 }
}

@Composable
private fun GoldenSessionCard(session: SessionRow, onClick: () -> Unit) {
    Card(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(22.dp),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
    ) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 17.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            com.mohammedsamir.halaqati.ui.components.GoldenNavIcon(
                key = "sessions",
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(34.dp),
            )
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(session.title.ifBlank { "جلسة اليوم — ${sessionTypeAr(session.type)}" }, style = MaterialTheme.typography.titleLarge)
                Text(
                    "${session.date} · ${sessionTypeAr(session.type)} · ${if (session.status == "open") "مفتوحة" else session.status}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            Icon(Icons.Default.ChevronLeft, contentDescription = "فتح الجلسة", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(28.dp))
        }
    }
}

fun sessionTypeAr(type: String) = when (type) {
    "tasmee" -> "تسميع"
    "sard" -> "سرد"
    "review" -> "مراجعة"
    "test" -> "اختبار"
    "tajweed" -> "تجويد"
    "lesson" -> "نشاط تربوي"
    "other" -> "أخرى"
    else -> type
}

@Composable
private fun NewSessionDialog(close: () -> Unit, save: (String, String, String) -> Unit) {
    var date by remember { mutableStateOf(LocalDate.now().toString()) }
    var type by remember { mutableStateOf("tasmee") }
    var title by remember { mutableStateOf("") }
    val types = SessionWorkflowRules.manualSessionTypes

    AlertDialog(
        onDismissRequest = close,
        title = { Text("جلسة جديدة") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = date,
                    onValueChange = { date = it },
                    label = { Text("التاريخ YYYY-MM-DD") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                )
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("العنوان (اختياري)") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                )
                SingleChoiceSegmentedButtonRow(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                ) {
                    types.forEachIndexed { index, value ->
                        SegmentedButton(
                            selected = type == value,
                            onClick = { type = value },
                            shape = SegmentedButtonDefaults.itemShape(index, types.size),
                        ) { Text(sessionTypeAr(value)) }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { save(date, type, title.trim()) },
                enabled = runCatching { LocalDate.parse(date) }.isSuccess,
            ) { Text("حفظ وفتح") }
        },
        dismissButton = { TextButton(onClick = close) { Text("إلغاء") } },
    )
}

private data class SessionRosterLoad(
    val attendance: Map<String, AttendanceRow>,
    val notes: Map<String, DailyNoteRow>,
    val recitations: Map<String, List<RecitationRow>>,
    val queue: List<OfflineQueue.SnapshotItem>,
)

@Composable
private fun SessionRosterDialog(
    session: SessionRow,
    students: List<Student>,
    pending: Int,
    close: () -> Unit,
    onChanged: () -> Unit,
) {
    val scope = rememberCoroutineScope()
    var selected by remember { mutableStateOf<Student?>(null) }
    var noteStudent by remember { mutableStateOf<Student?>(null) }
    var attendanceDetails by remember { mutableStateOf<Pair<Student, String>?>(null) }
    var attendance by remember { mutableStateOf<Map<String, AttendanceRow>>(emptyMap()) }
    var notes by remember { mutableStateOf<Map<String, DailyNoteRow>>(emptyMap()) }
    var recitations by remember { mutableStateOf<Map<String, List<RecitationRow>>>(emptyMap()) }
    var queuedStudents by remember { mutableStateOf<Set<String>>(emptySet()) }
    var blockedStudents by remember { mutableStateOf<Set<String>>(emptySet()) }
    var track by remember { mutableStateOf("all") }
    var loading by remember { mutableStateOf(true) }
    var message by remember { mutableStateOf<String?>(null) }

    suspend fun reloadRoster() {
        loading = true
        try {
            val result = withContext(Dispatchers.IO) {
                val q = AppGraph.repo.queueSnapshot(1000)
                val a = runCatching { AppGraph.repo.attendanceForSession(session.id) }.getOrDefault(emptyMap())
                val n = runCatching { AppGraph.repo.notesForSession(session.id) }.getOrDefault(emptyMap())
                val r = runCatching { AppGraph.repo.recitationsForSession(session.id) }.getOrDefault(emptyMap())
                SessionRosterLoad(a, n, r, q)
            }
            val attendanceOverlay = result.attendance.toMutableMap()
            val notesOverlay = result.notes.toMutableMap()
            val queued = mutableSetOf<String>()
            val blocked = mutableSetOf<String>()
            result.queue.forEach { item ->
                val d = item.dedupe.orEmpty()
                val studentId = when {
                    d.startsWith("attendance:${session.id}:") -> d.substringAfter("attendance:${session.id}:").substringBefore(':')
                    d.startsWith("note:${session.id}:") -> d.substringAfter("note:${session.id}:").substringBefore(':')
                    d.startsWith("recitation:${session.id}:") -> d.substringAfter("recitation:${session.id}:").substringBefore(':')
                    else -> ""
                }
                if (studentId.isNotBlank()) {
                    if (item.blocked) blocked += studentId else queued += studentId
                    val body = item.body?.let { runCatching { JSONObject(it) }.getOrNull() }
                    when {
                        d.startsWith("attendance:${session.id}:") && body != null -> {
                            attendanceOverlay[studentId] = AttendanceRow.from(body)
                        }
                        d.startsWith("note:${session.id}:") && body != null -> {
                            notesOverlay[studentId] = DailyNoteRow.from(body)
                        }
                    }
                }
            }
            attendance = attendanceOverlay
            notes = notesOverlay
            recitations = result.recitations
            queuedStudents = queued
            blockedStudents = blocked
            message = null
        } catch (e: Exception) {
            // Offline roster still remains usable; writes are queued by repository.
            message = e.message ?: "تعذر تحميل حالة الجلسة من الخادم"
        } finally {
            loading = false
        }
    }

    fun saveStatus(student: Student, status: String, reason: String = "", lateMinutes: Int = 0) {
        scope.launch {
            try {
                withContext(Dispatchers.IO) {
                    AppGraph.repo.saveAttendance(session.id, student.id, status, reason, lateMinutes)
                }
                attendance = attendance + (student.id to AttendanceRow(
                    id = "local:${session.id}:${student.id}",
                    sessionId = session.id,
                    studentId = student.id,
                    status = status,
                    excuseReason = reason,
                    arrivalMinutesLate = lateMinutes,
                ))
                if (!AppGraph.repo.online()) queuedStudents = queuedStudents + student.id
                message = null
                onChanged()
            } catch (e: Exception) {
                message = e.message ?: "تعذر حفظ الحضور"
            }
        }
    }

    LaunchedEffect(session.id) { reloadRoster() }

    val filtered = students.filter { track == "all" || it.track == track }
    val present = filtered.count { attendance[it.id]?.status == "present" }
    val absent = filtered.count { attendance[it.id]?.status == "absent" }
    val late = filtered.count { attendance[it.id]?.status == "late" }
    val recited = filtered.count { !recitations[it.id].isNullOrEmpty() }
    val done = filtered.count { attendance.containsKey(it.id) }

    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    ModalBottomSheet(
        onDismissRequest = close,
        sheetState = sheetState,
        modifier = Modifier.fillMaxHeight(0.96f),
    ) {
        Column(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp).padding(bottom = 12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Row(
                Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(Modifier.weight(1f)) {
                    Text(
                        session.title.ifBlank { sessionTypeAr(session.type) },
                        style = MaterialTheme.typography.titleLarge,
                    )
                    Text(
                        "${session.date} · ${sessionTypeAr(session.type)}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                IconButton(
                    onClick = close,
                    modifier = Modifier.size(HalaqatiUiTokens.TouchTarget),
                ) { Icon(Icons.Default.Close, contentDescription = "إغلاق") }
            }

            // Keep the session summary readable on narrow phones: 3 + 2 metrics instead of squeezing five.
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Box(Modifier.weight(1f)) { PlanMetric("تم الرصد", "$done/${filtered.size}") }
                Box(Modifier.weight(1f)) { PlanMetric("سمّع", recited.toString()) }
                Box(Modifier.weight(1f)) { PlanMetric("حاضر", present.toString()) }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Box(Modifier.weight(1f)) { PlanMetric("غائب", absent.toString()) }
                Box(Modifier.weight(1f)) { PlanMetric("متأخر", late.toString()) }
                Spacer(Modifier.weight(1f))
            }

            if (pending > 0 || queuedStudents.isNotEmpty() || blockedStudents.isNotEmpty()) {
                StateNotice(
                    text = if (blockedStudents.isNotEmpty()) {
                        "${blockedStudents.size} طالب لديهم عملية مزامنة تحتاج مراجعة"
                    } else {
                        "${queuedStudents.size.coerceAtLeast(pending)} عملية محفوظة محليًا بانتظار الرفع"
                    },
                    kind = if (blockedStudents.isNotEmpty()) "error" else "warning",
                )
            }

            Row(
                Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                ProFilterChip(track == "all", { track = "all" }, "الكل")
                ProFilterChip(track == "general_hifz", { track = "general_hifz" }, "الحفظ العام")
                ProFilterChip(track == "tathbit", { track = "tathbit" }, "التثبيت")
            }

            message?.let { StateNotice(it, kind = "error") }
            if (loading) {
                LoadingSkeleton(rows = 3, modifier = Modifier.fillMaxWidth())
            } else {
                LazyColumn(
                    modifier = Modifier.weight(1f, fill = false).heightIn(min = 260.dp, max = 620.dp),
                    verticalArrangement = Arrangement.spacedBy(2.dp),
                ) {
                    items(filtered, key = { it.id }, contentType = { "session_student" }) { student ->
                        val status = attendance[student.id]?.status
                        val syncLabel = when {
                            student.id in blockedStudents -> "خطأ مزامنة"
                            student.id in queuedStudents -> "بانتظار المزامنة"
                            else -> null
                        }
                        Column(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                            Row(
                                Modifier.fillMaxWidth().padding(horizontal = 4.dp),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Column(Modifier.weight(1f)) {
                                    Text(student.fullName, style = MaterialTheme.typography.titleLarge)
                                    Text(
                                        listOfNotNull(
                                            attendanceStatusAr(status),
                                            recitations[student.id]?.takeIf { it.isNotEmpty() }?.let { "تم التسميع (${it.size})" },
                                            syncLabel,
                                            if (notes.containsKey(student.id)) "ملاحظة محفوظة" else null,
                                        ).filter { it.isNotBlank() }.joinToString(" · "),
                                        style = MaterialTheme.typography.bodySmall,
                                        color = if (student.id in blockedStudents) {
                                            MaterialTheme.colorScheme.error
                                        } else {
                                            MaterialTheme.colorScheme.onSurfaceVariant
                                        },
                                    )
                                }
                                if (status != null) {
                                    Icon(
                                        imageVector = when (status) {
                                            "absent" -> Icons.Default.Cancel
                                            "late" -> Icons.Default.Schedule
                                            "excused" -> Icons.Default.Info
                                            else -> Icons.Default.CheckCircle
                                        },
                                        contentDescription = attendanceStatusAr(status),
                                        tint = if (status == "absent") MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary,
                                    )
                                }
                            }
                            recitations[student.id].orEmpty().forEach { rec ->
                                Surface(
                                    color = MaterialTheme.colorScheme.primaryContainer,
                                    shape = RoundedCornerShape(14.dp),
                                    modifier = Modifier.fillMaxWidth().padding(top = 7.dp),
                                ) {
                                    Column(Modifier.padding(horizontal = 12.dp, vertical = 9.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                        Text(
                                            "${recitationActivityAr(rec.activityType)} · ${recitationRangeText(rec)} · ${plainNumber(rec.pages)} ص",
                                            style = MaterialTheme.typography.labelLarge,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.primary,
                                        )
                                        Text(
                                            "${recitationEvaluationAr(rec.evaluation)} · أخطاء ${rec.mistakes} · تلقين ${rec.prompts}" +
                                                (rec.safetyPercentage?.let { " · سلامة ${plainNumber(it)}%" } ?: ""),
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurface,
                                        )
                                    }
                                }
                            }
                            Row(
                                modifier = Modifier.horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                            ) {
                                TextButton(
                                    onClick = { saveStatus(student, "present") },
                                    modifier = Modifier.heightIn(min = HalaqatiUiTokens.TouchTarget),
                                ) { Text("حاضر") }
                                TextButton(
                                    onClick = { saveStatus(student, "absent") },
                                    modifier = Modifier.heightIn(min = HalaqatiUiTokens.TouchTarget),
                                ) { Text("غائب") }
                                TextButton(
                                    onClick = { attendanceDetails = student to "late" },
                                    modifier = Modifier.heightIn(min = HalaqatiUiTokens.TouchTarget),
                                ) { Text("متأخر") }
                                TextButton(
                                    onClick = { attendanceDetails = student to "excused" },
                                    modifier = Modifier.heightIn(min = HalaqatiUiTokens.TouchTarget),
                                ) { Text("بعذر") }
                                FilledTonalButton(
                                    onClick = { selected = student },
                                    modifier = Modifier.heightIn(min = HalaqatiUiTokens.TouchTarget),
                                ) {
                                    Icon(Icons.Default.Mic, contentDescription = null)
                                    Spacer(Modifier.width(6.dp))
                                    Text("تسميع")
                                }
                                TextButton(
                                    onClick = { noteStudent = student },
                                    modifier = Modifier.heightIn(min = HalaqatiUiTokens.TouchTarget),
                                ) { Text("ملاحظة") }
                            }
                        }
                        HorizontalDivider()
                    }
                }
            }

            OutlinedButton(
                onClick = close,
                modifier = Modifier.fillMaxWidth().heightIn(min = HalaqatiUiTokens.TouchTarget),
            ) { Text("إغلاق الجلسة") }
        }
    }

    attendanceDetails?.let { (student, status) ->
        AttendanceDetailsDialog(
            student = student,
            status = status,
            close = { attendanceDetails = null },
            save = { reason, minutes ->
                saveStatus(student, status, reason, minutes)
                attendanceDetails = null
            },
        )
    }

    noteStudent?.let { student ->
        StudentNoteDialog(
            student = student,
            existing = notes[student.id],
            close = { noteStudent = null },
            save = { behavior, score, comment, homework, visible ->
                scope.launch {
                    try {
                        withContext(Dispatchers.IO) {
                            AppGraph.repo.saveDailyNote(
                                sessionId = session.id,
                                studentId = student.id,
                                behavior = behavior,
                                behaviorScore = score,
                                teacherComment = comment,
                                homework = homework,
                                parentVisible = visible,
                            )
                        }
                        notes = notes + (student.id to DailyNoteRow(
                            id = "local-note:${session.id}:${student.id}",
                            sessionId = session.id,
                            studentId = student.id,
                            behavior = behavior,
                            behaviorScore = score,
                            teacherComment = comment,
                            homework = homework,
                            parentVisible = visible,
                        ))
                        if (!AppGraph.repo.online()) queuedStudents = queuedStudents + student.id
                        noteStudent = null
                        onChanged()
                    } catch (e: Exception) {
                        message = e.message ?: "تعذر حفظ الملاحظة"
                    }
                }
            },
        )
    }

    selected?.let { student ->
        RecitationDialog(
            student = student,
            session = session,
            close = { selected = null },
            onSaved = {
                selected = null
                scope.launch { reloadRoster() }
                onChanged()
            },
        )
    }
}

@Composable
private fun AttendanceDetailsDialog(
    student: Student,
    status: String,
    close: () -> Unit,
    save: (String, Int) -> Unit,
) {
    var reason by remember { mutableStateOf("") }
    var minutes by remember { mutableStateOf("5") }
    AlertDialog(
        onDismissRequest = close,
        title = { Text(if (status == "late") "تأخر ${student.fullName}" else "غياب بعذر · ${student.fullName}") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (status == "late") {
                    OutlinedTextField(
                        value = minutes,
                        onValueChange = { minutes = it.filter(Char::isDigit) },
                        label = { Text("دقائق التأخر") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                    )
                } else {
                    OutlinedTextField(
                        value = reason,
                        onValueChange = { reason = it },
                        label = { Text("سبب العذر") },
                        minLines = 2,
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
            }
        },
        confirmButton = {
            Button(onClick = { save(reason.trim(), minutes.toIntOrNull() ?: 0) }) { Text("حفظ") }
        },
        dismissButton = { TextButton(onClick = close) { Text("إلغاء") } },
    )
}

@Composable
private fun StudentNoteDialog(
    student: Student,
    existing: DailyNoteRow?,
    close: () -> Unit,
    save: (String, Int?, String, String, Boolean) -> Unit,
) {
    var behavior by remember { mutableStateOf(existing?.behavior ?: "normal") }
    var score by remember { mutableStateOf(existing?.behaviorScore?.toString().orEmpty()) }
    var comment by remember { mutableStateOf(existing?.teacherComment.orEmpty()) }
    var homework by remember { mutableStateOf(existing?.homework.orEmpty()) }
    var visible by remember { mutableStateOf(existing?.parentVisible ?: true) }
    val behaviors = listOf(
        "excellent" to "ممتاز",
        "good" to "جيد",
        "normal" to "طبيعي",
        "needs_attention" to "يحتاج متابعة",
        "warning" to "تنبيه",
    )
    AlertDialog(
        onDismissRequest = close,
        title = { Text("ملاحظة ${student.fullName}") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    behaviors.forEach { (value, label) ->
                        ProFilterChip(behavior == value, { behavior = value }, label)
                    }
                }
                OutlinedTextField(
                    value = score,
                    onValueChange = { score = it.filter(Char::isDigit).take(1) },
                    label = { Text("درجة السلوك 1–5 (اختياري)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                OutlinedTextField(
                    value = comment,
                    onValueChange = { comment = it },
                    label = { Text("ملاحظة المحفظ") },
                    minLines = 2,
                    modifier = Modifier.fillMaxWidth(),
                )
                OutlinedTextField(
                    value = homework,
                    onValueChange = { homework = it },
                    label = { Text("الواجب") },
                    minLines = 2,
                    modifier = Modifier.fillMaxWidth(),
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Switch(checked = visible, onCheckedChange = { visible = it })
                    Spacer(Modifier.width(8.dp))
                    Text("تظهر الملاحظة لولي الأمر")
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { save(behavior, score.toIntOrNull()?.takeIf { it in 1..5 }, comment.trim(), homework.trim(), visible) },
            ) { Text("حفظ") }
        },
        dismissButton = { TextButton(onClick = close) { Text("إلغاء") } },
    )
}

private fun recitationActivityAr(type: String): String = when (type) {
    "new_hifz" -> "حفظ"
    "review_near" -> "مراجعة قريبة"
    "review_far" -> "تثبيت"
    "sard" -> "سرد"
    "tilawah" -> "تلاوة"
    "test" -> "اختبار"
    else -> type
}

private fun recitationEvaluationAr(value: String): String = when (value) {
    "excellent" -> "ممتاز"
    "very_good" -> "جيد جدًا"
    "good" -> "جيد"
    "repeat" -> "يحتاج إعادة"
    else -> "غير مقيّم"
}

private fun recitationRangeText(row: RecitationRow): String = when {
    row.startPage != null && row.endPage != null && row.startPage == row.endPage -> "ص ${row.startPage}"
    row.startPage != null && row.endPage != null -> "ص ${row.startPage}–${row.endPage}"
    row.startPage != null -> "من ص ${row.startPage}"
    row.endPage != null -> "إلى ص ${row.endPage}"
    else -> "نطاق محفوظ"
}

private fun attendanceStatusAr(status: String?): String = when (status) {
    "present" -> "حاضر"
    "absent" -> "غائب"
    "late" -> "متأخر"
    "excused" -> "بعذر"
    else -> "لم يُرصد بعد"
}

@Composable
private fun RecitationDialog(
    student: Student,
    session: SessionRow,
    close: () -> Unit,
    onSaved: () -> Unit,
    prefillStartPage: Int? = null,
    prefillEndPage: Int? = null,
    prefillPages: Double? = null,
    smartPlanId: String? = null,
    smartPlanType: String? = null,
    smartPlanDate: String? = null,
    qcfLineKeys: List<String> = emptyList(),
    activityTypeOverride: String? = null,
) {
    val scope = rememberCoroutineScope()
    var start by remember(prefillStartPage) { mutableStateOf(prefillStartPage?.toString().orEmpty()) }
    var end by remember(prefillEndPage) { mutableStateOf(prefillEndPage?.toString().orEmpty()) }
    var pages by remember(prefillPages) { mutableStateOf(prefillPages?.let(::plainNumber) ?: "1") }
    var mistakes by remember { mutableStateOf("0") }
    var prompts by remember { mutableStateOf("0") }
    var note by remember { mutableStateOf("") }
    var saving by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var showQuranPicker by remember { mutableStateOf(false) }
    var selectedQuranRange by remember(student.id, session.id) { mutableStateOf<QuranRangeResult?>(null) }
    var effectiveQcfLineKeys by remember(qcfLineKeys) { mutableStateOf(qcfLineKeys) }
    val resolvedActivityType = activityTypeOverride ?: when (session.type) {
        "sard" -> "sard"
        "review" -> "review_near"
        "test" -> "test"
        else -> "new_hifz"
    }

    val pageValue = if (effectiveQcfLineKeys.isNotEmpty()) {
        effectiveQcfLineKeys.distinct().size.toDouble() / 15.0
    } else pages.toDoubleOrNull()?.coerceAtLeast(0.0) ?: 0.0
    val mistakeValue = mistakes.toIntOrNull()?.coerceAtLeast(0) ?: 0
    val promptValue = prompts.toIntOrNull()?.coerceAtLeast(0) ?: 0
    val safety = SafetyScoring.calculate(pageValue, mistakeValue, promptValue)
    val evaluation = SafetyScoring.inferredEvaluation(safety, pageValue > 0.0)

    AlertDialog(
        onDismissRequest = { if (!saving) close() },
        title = { Text("تسميع ${student.fullName}") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                OutlinedButton(
                    onClick = { showQuranPicker = true },
                    modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp),
                ) {
                    Icon(Icons.Default.MenuBook, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("اختيار من المصحف: سورة / آية / صفحة / جزء / ربع")
                }
                selectedQuranRange?.let { selected ->
                    Surface(
                        color = MaterialTheme.colorScheme.secondaryContainer,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                            Text("📖 ${selected.displayLabel}", fontWeight = FontWeight.SemiBold)
                            Text("📄 ${plainNumber(selected.exactPages)} صفحة · 🔢 ${selected.ayahCount} آية")
                            Text("↕ ${selected.resolvedTraversal.name}", style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedTextField(
                        value = start,
                        onValueChange = {
                            start = it.filter(Char::isDigit)
                            selectedQuranRange = null
                            effectiveQcfLineKeys = emptyList()
                        },
                        label = { Text("من صفحة") },
                        modifier = Modifier.weight(1f),
                        singleLine = true,
                    )
                    OutlinedTextField(
                        value = end,
                        onValueChange = {
                            end = it.filter(Char::isDigit)
                            selectedQuranRange = null
                            effectiveQcfLineKeys = emptyList()
                        },
                        label = { Text("إلى صفحة") },
                        modifier = Modifier.weight(1f),
                        singleLine = true,
                    )
                }
                OutlinedTextField(
                    value = pages,
                    onValueChange = {
                        pages = it.filter { ch -> ch.isDigit() || ch == '.' }
                        selectedQuranRange = null
                        effectiveQcfLineKeys = emptyList()
                    },
                    label = { Text("عدد الصفحات") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                )
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedTextField(
                        value = mistakes,
                        onValueChange = { mistakes = it.filter(Char::isDigit) },
                        label = { Text("أخطاء") },
                        modifier = Modifier.weight(1f),
                        singleLine = true,
                    )
                    OutlinedTextField(
                        value = prompts,
                        onValueChange = { prompts = it.filter(Char::isDigit) },
                        label = { Text("تلقين") },
                        modifier = Modifier.weight(1f),
                        singleLine = true,
                    )
                }
                Surface(
                    color = if (evaluation == "repeat") MaterialTheme.colorScheme.errorContainer else MaterialTheme.colorScheme.primaryContainer,
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Row(
                        Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 11.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                    ) {
                        Column {
                            Text("تقييم V6 تلقائي", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(recitationEvaluationAr(evaluation), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        }
                        Text("سلامة ${plainNumber(safety)}%", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    }
                }
                OutlinedTextField(
                    value = note,
                    onValueChange = { note = it },
                    label = { Text("ملاحظة المحفظ") },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 2,
                )
            }
        },
        confirmButton = {
            Button(
                enabled = !saving && (pages.toDoubleOrNull() ?: 0.0) > 0,
                onClick = {
                    saving = true
                    error = null
                    scope.launch {
                        try {
                            val startPage = start.toIntOrNull()
                            val endPage = end.toIntOrNull()
                            if (startPage != null && startPage !in 1..604) error("صفحة البداية يجب أن تكون بين 1 و604")
                            if (endPage != null && endPage !in 1..604) error("صفحة النهاية يجب أن تكون بين 1 و604")
                            val authoritativeQuranRange = selectedQuranRange ?: runCatching {
                                if (startPage != null && endPage != null) {
                                    QuranCore.engine().calculate(
                                        QuranRangeRequest(
                                            track = student.track,
                                            activityType = resolvedActivityType,
                                            selection = QuranSelection.Pages(startPage, endPage),
                                        ),
                                    )
                                } else null
                            }.getOrElse { throw it }
                            val authoritativeQcfLineKeys = authoritativeQuranRange?.qcfLineKeys ?: effectiveQcfLineKeys
                            val authoritativePages = if (authoritativeQcfLineKeys.isNotEmpty()) {
                                authoritativeQcfLineKeys.distinct().size.toDouble() / 15.0
                            } else pageValue
                            withContext(Dispatchers.IO) {
                                AppGraph.repo.saveRecitation(
                                    RecitationDraft(
                                        studentId = student.id,
                                        sessionId = session.id,
                                        activityType = resolvedActivityType,
                                        startPage = authoritativeQuranRange?.startPage ?: startPage,
                                        endPage = authoritativeQuranRange?.endPage ?: endPage,
                                        pages = authoritativePages,
                                        mistakes = mistakeValue,
                                        prompts = promptValue,
                                        evaluation = evaluation,
                                        notes = note.trim(),
                                        smartPlanId = smartPlanId,
                                        smartPlanType = smartPlanType,
                                        smartPlanDate = smartPlanDate,
                                        qcfLineKeys = authoritativeQuranRange?.qcfLineKeys ?: effectiveQcfLineKeys,
                                        inputMethod = authoritativeQuranRange?.inputMethod ?: "pages",
                                        startSurah = authoritativeQuranRange?.start?.surah,
                                        startAyah = authoritativeQuranRange?.start?.ayah,
                                        endSurah = authoritativeQuranRange?.end?.surah,
                                        endAyah = authoritativeQuranRange?.end?.ayah,
                                        ayahsCount = authoritativeQuranRange?.ayahCount ?: 0,
                                        surahsCount = authoritativeQuranRange?.surahCount ?: 0,
                                        selectedSurahs = authoritativeQuranRange?.selectedSurahs.orEmpty(),
                                        selectedJuz = authoritativeQuranRange?.selectedJuz.orEmpty(),
                                        traversalDirection = authoritativeQuranRange?.resolvedTraversal?.name,
                                        quranSegments = authoritativeQuranRange?.orderedSegments?.map { it.compactKey() }.orEmpty(),
                                    ),
                                )
                            }
                            onSaved()
                        } catch (e: Exception) {
                            error = e.message ?: "تعذر حفظ التسميع"
                        } finally {
                            saving = false
                        }
                    }
                },
            ) { Text(if (saving) "جاري الحفظ…" else "حفظ") }
        },
        dismissButton = { TextButton(onClick = close, enabled = !saving) { Text("إلغاء") } },
    )

    if (showQuranPicker) {
        QuranRangePickerDialog(
            initialStartPage = start.toIntOrNull(),
            initialEndPage = end.toIntOrNull(),
            track = student.track,
            activityType = resolvedActivityType,
            onDismiss = { showQuranPicker = false },
            onConfirm = { selected ->
                selectedQuranRange = selected
                effectiveQcfLineKeys = selected.qcfLineKeys
                start = selected.startPage?.toString().orEmpty()
                end = selected.endPage?.toString().orEmpty()
                pages = plainNumber(selected.exactPages)
                showQuranPicker = false
            },
        )
    }
}

private data class QuickMemorizationEntry(val student: Student, val snapshot: PlanSnapshot?)
private data class QuickUndoToken(
    val sessionId: String,
    val studentId: String,
    val recitationId: String?,
    val studentIndex: Int,
    val studentName: String,
)

@Composable
fun QuickMemorizationScreen(pending: Int, onRefresh: () -> Unit) {
    val scope = rememberCoroutineScope()
    var entries by remember { mutableStateOf<List<QuickMemorizationEntry>>(emptyList()) }
    var index by remember { mutableIntStateOf(0) }
    var track by remember { mutableStateOf("general_hifz") }
    var attendance by remember { mutableStateOf("present") }
    var mistakes by remember { mutableIntStateOf(0) }
    var prompts by remember { mutableIntStateOf(0) }
    var loading by remember { mutableStateOf(true) }
    var saving by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }
    var undoToken by remember { mutableStateOf<QuickUndoToken?>(null) }
    var undoing by remember { mutableStateOf(false) }
    var fullRecitation by remember { mutableStateOf<Pair<QuickMemorizationEntry, SessionRow>?>(null) }

    suspend fun reload(force: Boolean = false) {
        loading = true
        try {
            val loaded = withContext(Dispatchers.IO) {
                val students = AppGraph.repo.students(forceRefresh = force).filter { it.status == "active" }
                val snapshots = AppGraph.repo.planSnapshots(LocalDate.now(), forceRefresh = force).groupBy { it.student.id }
                students.map { QuickMemorizationEntry(it, snapshots[it.id]?.firstOrNull()) }
            }
            entries = loaded
            index = index.coerceIn(0, (loaded.count { it.student.track == track } - 1).coerceAtLeast(0))
            message = null
        } catch (e: Exception) {
            message = e.message ?: "تعذر تجهيز التحفيظ السريع"
        } finally { loading = false }
    }

    LaunchedEffect(Unit) { reload() }
    val visible = entries.filter { it.student.track == track }
    val current = visible.getOrNull(index)
    val snapshot = current?.snapshot
    val assignment = snapshot?.progress?.assignment
    val duty = when {
        assignment?.milestone != null -> assignment.milestone.label
        assignment != null && assignment.pages > .001 -> "${assignmentKindAr(assignment.kind)} · ${pageRangeLabel(assignment.startPage, assignment.endPage)} · ${plainNumber(assignment.pages)} ص"
        snapshot?.nextDuty != null -> "المقرر القادم ${snapshot.nextDuty.date} · ${pageRangeLabel(snapshot.nextDuty.assignment.startPage, snapshot.nextDuty.assignment.endPage)}"
        else -> "لا يوجد مقرر ذكي قابل للتسجيل الآن"
    }

    fun resetAndMove(delta: Int) {
        mistakes = 0; prompts = 0; attendance = "present"
        index = (index + delta).coerceIn(0, (visible.size - 1).coerceAtLeast(0))
    }

    fun ensureSession(entry: QuickMemorizationEntry, done: (SessionRow) -> Unit) {
        scope.launch {
            try {
                val a = entry.snapshot?.progress?.assignment
                val h = entry.student.halaqaId ?: entry.snapshot?.plan?.halaqaId ?: error("الطالب غير مرتبط بحلقة")
                val session = withContext(Dispatchers.IO) {
                    AppGraph.repo.ensureTodaySession(h, LocalDate.now().toString(), a?.kind ?: "hifz")
                }
                done(session)
            } catch (e: Exception) { message = e.message ?: "تعذر فتح جلسة اليوم" }
        }
    }

    Column(Modifier.fillMaxSize()) {
        AppTopBar("التحفيظ السريع", onRefresh = { scope.launch { reload(true) }; onRefresh() }, pending = pending)
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ProFilterChip(track == "general_hifz", { track = "general_hifz"; index = 0 }, "الحفظ العام", Modifier.weight(1f))
            ProFilterChip(track == "tathbit", { track = "tathbit"; index = 0 }, "التثبيت", Modifier.weight(1f))
        }
        if (loading) {
            LoadingSkeleton(rows = 3, modifier = Modifier.padding(16.dp))
        } else if (current == null) {
            EmptyState("لا يوجد طلاب نشطون في هذا المسار")
        } else {
            Column(
                Modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Text("الطالب ${index + 1} من ${visible.size}", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
                ElevatedCard(Modifier.fillMaxWidth()) {
                    Column(Modifier.fillMaxWidth().padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        PlanHealthBadge(snapshot?.progress?.health ?: "green", snapshot?.progress?.healthLabel ?: "بدون خطة")
                        Text(current.student.fullName, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                        Surface(color = MaterialTheme.colorScheme.primaryContainer, shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                Text(if ((assignment?.pages ?: 0.0) > .001) "مقرر اليوم" else "الخطة الذكية", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(duty, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { attendance = "present" }, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = if (attendance == "present") MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant)) { Text("✓ حاضر") }
                    Button(onClick = { attendance = "absent" }, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = if (attendance == "absent") MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.surfaceVariant)) { Text("غائب") }
                    OutlinedButton(onClick = { attendance = "excused" }, modifier = Modifier.weight(1f)) { Text("بعذر") }
                }
                if (attendance == "present") {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        QuickCounter("الأخطاء", mistakes, { mistakes = (mistakes - 1).coerceAtLeast(0) }, { mistakes += 1 }, Modifier.weight(1f))
                        QuickCounter("التلقين", prompts, { prompts = (prompts - 1).coerceAtLeast(0) }, { prompts += 1 }, Modifier.weight(1f))
                    }
                } else {
                    StateNotice(if (attendance == "excused") "سيُسجل غياب بعذر وتعيد الخطة توزيع الورد." else "سيُسجل غياب بدون عذر وتعيد الخطة توزيع الورد.", "warning")
                }
                message?.let { StateNotice(it, if (it.startsWith("تم")) "success" else "error") }
                undoToken?.let { token ->
                    OutlinedButton(
                        onClick = {
                            if (!undoing) scope.launch {
                                undoing = true
                                try {
                                    val undone = withContext(Dispatchers.IO) {
                                        AppGraph.repo.undoPendingQuickSave(token.sessionId, token.studentId, token.recitationId)
                                    }
                                    if (undone) {
                                        index = token.studentIndex.coerceIn(0, (visible.size - 1).coerceAtLeast(0))
                                        mistakes = 0; prompts = 0; attendance = "present"
                                        message = "تم التراجع عن آخر حفظ للطالب ${token.studentName}"
                                        onRefresh()
                                    } else {
                                        message = "تعذر التراجع الفوري لأن المزامنة بدأت؛ استخدم نموذج الجلسة الكامل للتعديل"
                                    }
                                    undoToken = null
                                } finally { undoing = false }
                            }
                        },
                        enabled = !saving && !undoing,
                        modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp),
                    ) { Text(if (undoing) "جارٍ التراجع…" else "↶ تراجع عن آخر حفظ") }
                }
                Spacer(Modifier.weight(1f))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { resetAndMove(-1) }, enabled = index > 0 && !saving, modifier = Modifier.weight(.8f).heightIn(min = 52.dp)) { Text("السابق") }
                    Button(
                        onClick = {
                            val entry = current
                            saving = true
                            ensureSession(entry) { session ->
                                scope.launch {
                                    try {
                                        val savedIndex = index
                                        val savedAttendance = attendance
                                        val recitationId = withContext(Dispatchers.IO) {
                                            AppGraph.repo.saveAttendance(session.id, entry.student.id, savedAttendance, if (savedAttendance == "excused") "غياب بعذر" else "", 0)
                                            if (savedAttendance == "present") {
                                                val snap = entry.snapshot ?: error("لا توجد خطة ذكية للطالب")
                                                val a = snap.progress.assignment
                                                require(a.pages > .001) { "لا يوجد مقرر ذكي قابل للتسجيل الآن" }
                                                val safety = SafetyScoring.calculate(a.pages, mistakes, prompts)
                                                AppGraph.repo.saveRecitation(RecitationDraft(
                                                    studentId = entry.student.id,
                                                    sessionId = session.id,
                                                    activityType = when (a.kind) { "sard" -> "sard"; "review" -> "review_near"; "tathbit" -> "review_far"; "test" -> "test"; else -> "new_hifz" },
                                                    startPage = a.startPage,
                                                    endPage = a.endPage,
                                                    pages = a.pages,
                                                    mistakes = mistakes,
                                                    prompts = prompts,
                                                    evaluation = SafetyScoring.inferredEvaluation(safety, true),
                                                    smartPlanId = snap.plan.id,
                                                    smartPlanType = snap.plan.type,
                                                    smartPlanDate = snap.nextDuty?.date?.takeIf { (assignment?.pages ?: 0.0) <= .001 }?.toString() ?: LocalDate.now().toString(),
                                                    qcfLineKeys = a.lineKeys,
                                                ))
                                            } else null
                                        }
                                        undoToken = QuickUndoToken(session.id, entry.student.id, recitationId, savedIndex, entry.student.fullName)
                                        message = if (savedAttendance == "present") "تم حفظ التسميع محليًا" else "تم حفظ الغياب محليًا"
                                        resetAndMove(1)
                                        onRefresh()
                                    } catch (e: Exception) { message = e.message ?: "تعذر الحفظ" }
                                    finally { saving = false }
                                }
                            }
                        },
                        enabled = !saving && (attendance != "present" || (assignment?.pages ?: 0.0) > .001),
                        modifier = Modifier.weight(1.5f).heightIn(min = 52.dp),
                    ) { Text(if (saving) "جارٍ الحفظ…" else if (attendance == "present") "✓ تمّ التسميع وحفظ" else "حفظ الغياب والتالي") }
                    OutlinedButton(onClick = { resetAndMove(1) }, enabled = index < visible.lastIndex && !saving, modifier = Modifier.weight(.8f).heightIn(min = 52.dp)) { Text("التالي") }
                }
                OutlinedButton(
                    onClick = { ensureSession(current) { fullRecitation = current to it } },
                    modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp),
                ) { Text("نموذج التسميع الكامل") }
            }
        }
    }

    fullRecitation?.let { (entry, session) ->
        val a = entry.snapshot?.progress?.assignment
        RecitationDialog(
            student = entry.student,
            session = session,
            close = { fullRecitation = null },
            onSaved = { fullRecitation = null; scope.launch { reload(true) }; onRefresh() },
            prefillStartPage = a?.startPage,
            prefillEndPage = a?.endPage,
            prefillPages = a?.pages?.takeIf { it > 0.0 },
            smartPlanId = entry.snapshot?.plan?.id,
            smartPlanType = entry.snapshot?.plan?.type,
            smartPlanDate = LocalDate.now().toString(),
            qcfLineKeys = a?.lineKeys.orEmpty(),
        )
    }
}

@Composable
private fun QuickCounter(label: String, value: Int, minus: () -> Unit, plus: () -> Unit, modifier: Modifier = Modifier) {
    Surface(modifier = modifier, color = MaterialTheme.colorScheme.surface, border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline), shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(label, style = MaterialTheme.typography.labelLarge)
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                IconButton(onClick = minus, modifier = Modifier.size(HalaqatiUiTokens.TouchTarget)) { Icon(Icons.Default.Remove, contentDescription = "إنقاص $label") }
                Text(value.toString(), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                IconButton(onClick = plus, modifier = Modifier.size(HalaqatiUiTokens.TouchTarget)) { Icon(Icons.Default.Add, contentDescription = "زيادة $label") }
            }
        }
    }
}

@Composable
fun PlansScreen(profile: Profile, pending: Int, onRefresh: () -> Unit) {
    val scope = rememberCoroutineScope()
    val canManage = profile.role !in setOf(UserRole.GUARDIAN, UserRole.STUDENT)
    var rows by remember { mutableStateOf<List<PlanSnapshot>>(emptyList()) }
    var allPlans by remember { mutableStateOf<List<PlanRow>>(emptyList()) }
    var students by remember { mutableStateOf<List<Student>>(emptyList()) }
    var halaqas by remember { mutableStateOf<List<JSONObject>>(emptyList()) }
    var categories by remember { mutableStateOf<List<JSONObject>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var online by remember { mutableStateOf(true) }
    var message by remember { mutableStateOf<String?>(null) }
    var query by remember { mutableStateOf("") }
    var track by remember { mutableStateOf("all") }
    var guardianStudentId by remember { mutableStateOf<String?>(null) }
    var details by remember { mutableStateOf<PlanSnapshot?>(null) }
    var planRecitation by remember { mutableStateOf<Pair<PlanSnapshot, SessionRow>?>(null) }
    var preparing by remember { mutableStateOf<String?>(null) }
    var approvingMilestone by remember { mutableStateOf<String?>(null) }
    var showManager by remember { mutableStateOf(false) }
    var showEditor by remember { mutableStateOf(false) }
    var editPlan by remember { mutableStateOf<PlanRow?>(null) }
    var overrideParent by remember { mutableStateOf<PlanRow?>(null) }

    suspend fun reload(force: Boolean = false) {
        loading = true
        try {
            online = withContext(Dispatchers.IO) { AppGraph.repo.online() }
            rows = withContext(Dispatchers.IO) { AppGraph.repo.planSnapshots(forceRefresh = force) }
            if (canManage) {
                allPlans = withContext(Dispatchers.IO) { AppGraph.repo.plans(forceRefresh = force) }
                students = withContext(Dispatchers.IO) { AppGraph.repo.students(forceRefresh = force) }
                halaqas = withContext(Dispatchers.IO) {
                    val arr = AppGraph.repo.table("halaqas", "select=id,name,active&order=name.asc&limit=200")
                    (0 until arr.length()).mapNotNull { arr.optJSONObject(it) }
                }
                categories = withContext(Dispatchers.IO) {
                    val arr = AppGraph.repo.table("student_categories", "select=id,halaqa_id,name,active&order=name.asc&limit=500")
                    (0 until arr.length()).mapNotNull { arr.optJSONObject(it) }
                }
            }
            message = null
        } catch (e: Exception) {
            message = e.message ?: "تعذر تحميل تقدم الخطط"
        } finally {
            loading = false
        }
    }

    LaunchedEffect(Unit) { reload() }

    val guardianChildren = rows.map { it.student }.distinctBy { it.id }
    LaunchedEffect(profile.role, guardianChildren.map { it.id }) {
        if (profile.role == UserRole.GUARDIAN && guardianStudentId !in guardianChildren.map { it.id }) {
            guardianStudentId = guardianChildren.firstOrNull()?.id
        }
    }
    val filtered = rows.filter { snapshot ->
        (profile.role != UserRole.GUARDIAN || guardianStudentId == null || snapshot.student.id == guardianStudentId) &&
            (track == "all" || snapshot.student.track == track) &&
            (query.isBlank() || snapshot.student.fullName.contains(query, ignoreCase = true) ||
                snapshot.plan.title.contains(query, ignoreCase = true))
    }

    Column {
        AppTopBar(
            title = if (profile.role == UserRole.GUARDIAN) "خطط الأبناء" else "الخطط الذكية",
            onRefresh = {
                scope.launch { reload(force = true) }
                onRefresh()
            },
            pending = pending,
        )

        Column(
            Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            if (profile.role == UserRole.GUARDIAN) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary),
                    shape = RoundedCornerShape(22.dp),
                ) {
                    Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("خطط أبنائي الذكية", color = MaterialTheme.colorScheme.onPrimary, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                        Text("اختيار الابن يعرض خطته الفعالة ومقرر اليوم والتقدم والتعويض دون خلط بين الأبناء.", color = MaterialTheme.colorScheme.onPrimary.copy(alpha = .82f), style = MaterialTheme.typography.bodyMedium)
                    }
                }
                Text("اختيار الابن", style = MaterialTheme.typography.labelLarge)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    guardianChildren.forEach { child ->
                        ProFilterChip(
                            selected = guardianStudentId == child.id,
                            onClick = { guardianStudentId = child.id },
                            label = child.fullName,
                        )
                    }
                }
                filtered.firstOrNull()?.let { snap ->
                    val a = snap.progress.assignment
                    val required = snap.progress.dailyTarget
                    val completed = snap.progress.completedToday
                    val remaining = (required - completed).coerceAtLeast(0.0)
                    Surface(
                        color = MaterialTheme.colorScheme.surface,
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                            Text("مقرر اليوم", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
                            Text(
                                when {
                                    a.milestone != null -> a.milestone.label
                                    a.startPage != null && a.endPage != null -> "${assignmentKindAr(a.kind)} · صفحات ${a.startPage}–${a.endPage} · ${plainNumber(a.pages)} ص"
                                    a.pages > 0 -> "${assignmentKindAr(a.kind)} · ${plainNumber(a.pages)} ص"
                                    else -> "لا يوجد مقرر اليوم"
                                },
                                style = MaterialTheme.typography.bodyMedium,
                            )
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                PlanStatTile("المطلوب", "${plainNumber(required)} ص", Modifier.weight(1f))
                                PlanStatTile("المنجز", "${plainNumber(completed)} ص", Modifier.weight(1f))
                                PlanStatTile("المتبقي", "${plainNumber(remaining)} ص", Modifier.weight(1f))
                            }
                            snap.lastRecitation?.let { last ->
                                Text("آخر تسميع: ${last.date} · ${pageRangeLabel(last.startPage, last.endPage)} · ${last.evaluation?.let(::recitationEvaluationAr) ?: "غير مقيّم"}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            snap.nextDuty?.let { next ->
                                Text("المقرر القادم: ${next.date} · ${pageRangeLabel(next.assignment.startPage, next.assignment.endPage)}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
            }
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("بحث باسم الطالب أو الخطة") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                singleLine = true,
            )
            Row(
                Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                ProFilterChip(track == "all", { track = "all" }, "الكل")
                ProFilterChip(track == "general_hifz", { track = "general_hifz" }, "الحفظ العام")
                ProFilterChip(track == "tathbit", { track = "tathbit" }, "التثبيت")
            }
            if (canManage) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = { editPlan = null; showEditor = true },
                        modifier = Modifier.weight(1f).heightIn(min = 48.dp),
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text("خطة جديدة")
                    }
                    OutlinedButton(
                        onClick = { showManager = true },
                        modifier = Modifier.weight(1f).heightIn(min = 48.dp),
                    ) {
                        Icon(Icons.Default.Inventory2, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text("إدارة الخطط")
                    }
                }
            }
            Surface(
                color = if (online) MaterialTheme.colorScheme.secondaryContainer else MaterialTheme.colorScheme.tertiaryContainer,
                shape = MaterialTheme.shapes.small,
            ) {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 9.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Icon(
                        if (online) Icons.Default.CloudDone else Icons.Default.CloudOff,
                        contentDescription = null,
                        tint = if (online) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.onTertiaryContainer,
                    )
                    Text(
                        when {
                            !online && pending > 0 -> "بدون اتصال · تم حفظ $pending تغييرات محليًا"
                            !online -> "بدون اتصال · سيُحفظ أي تغيير محليًا"
                            pending > 0 -> "متصل · $pending عملية بانتظار المزامنة"
                            else -> "متصل · البيانات متزامنة"
                        },
                        style = MaterialTheme.typography.bodySmall,
                        color = if (online) MaterialTheme.colorScheme.onSecondaryContainer else MaterialTheme.colorScheme.onTertiaryContainer,
                    )
                }
            }
        }

        message?.let { StateNotice(it, kind = "error", modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)) }
        if (loading && rows.isEmpty()) LoadingSkeleton(rows = 3, modifier = Modifier.padding(12.dp))
        if (!loading && filtered.isEmpty()) EmptyState("لا توجد خطط فعالة مطابقة")

        LazyColumn(
            contentPadding = PaddingValues(12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            items(filtered, key = { "${it.student.id}:${it.plan.id}" }, contentType = { "smart_plan" }) { snapshot ->
                val progress = snapshot.progress
                ElevatedCard(
                    onClick = { details = snapshot },
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Column(
                        Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(9.dp),
                    ) {
                        Row(
                            Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                        ) {
                            Column(Modifier.weight(1f)) {
                                Text(snapshot.student.fullName, style = MaterialTheme.typography.titleMedium)
                                Text(
                                    snapshot.plan.title.ifBlank { planTypeAr(snapshot.plan.type) },
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            }
                            PlanHealthBadge(progress.health, progress.healthLabel)
                        }

                        LinearProgressIndicator(
                            progress = { (progress.percentage / 100.0).toFloat().coerceIn(0f, 1f) },
                            modifier = Modifier.fillMaxWidth().height(8.dp).graphicsLayer(scaleX = -1f),
                        )

                        val requiredToday = progress.dailyTarget.coerceAtLeast(0.0)
                        val completedToday = progress.completedToday.coerceAtLeast(0.0)
                        val remainingToday = (requiredToday - completedToday).coerceAtLeast(0.0)
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            PlanStatTile("مطلوب اليوم", "${plainNumber(requiredToday)} ص", Modifier.weight(1f))
                            PlanStatTile("المنجز اليوم", "${plainNumber(completedToday)} ص", Modifier.weight(1f))
                            PlanStatTile("المتبقي اليوم", "${plainNumber(remainingToday)} ص", Modifier.weight(1f))
                        }
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            PlanStatTile("التقدم", "${plainNumber(progress.percentage)}%", Modifier.weight(1f))
                            PlanStatTile("المكتمل", "${plainNumber(progress.completed)} ص", Modifier.weight(1f))
                            PlanStatTile("باقي الخطة", "${plainNumber(progress.remaining)} ص", Modifier.weight(1f))
                        }

                        snapshot.weekRequirement?.let { week ->
                            PlanInfoBlock(
                                title = "هذا الأسبوع",
                                value = buildString {
                                    append("${plainNumber(week.amount)} ص")
                                    if (week.startPage != null || week.endPage != null) append(" · ${pageRangeLabel(week.startPage, week.endPage)}")
                                },
                                icon = Icons.Default.DateRange,
                            )
                        }
                        snapshot.lastRecitation?.let { last ->
                            PlanInfoBlock(
                                title = "آخر تسميع · ${last.date}",
                                value = buildString {
                                    append("${assignmentKindAr(last.activityType)} · ${pageRangeLabel(last.startPage, last.endPage)} · ${plainNumber(last.pagesCount)} ص")
                                    last.evaluation?.let { append(" · ${recitationEvaluationAr(it)}") }
                                    append(" · ${last.mistakes} خطأ · ${last.prompts} تلقين")
                                },
                                icon = Icons.Default.History,
                            )
                        } ?: PlanInfoBlock("آخر تسميع", "لا يوجد تسميع مرتبط بالخطة بعد", Icons.Default.History)

                        val assignment = progress.assignment
                        val assignmentText = when {
                            assignment.milestone != null -> assignment.milestone.label
                            assignment.blockedByRetry -> "إعادة تثبيت ${pageRangeLabel(assignment.startPage, assignment.endPage)}"
                            assignment.pages <= 0.0 -> if (progress.remaining <= 0.0) "تم إكمال الخطة" else "لا يوجد مقرر اليوم"
                            else -> "${assignmentKindAr(assignment.kind)} · ${pageRangeLabel(assignment.startPage, assignment.endPage)}"
                        }
                        Surface(
                            color = MaterialTheme.colorScheme.primaryContainer,
                            shape = MaterialTheme.shapes.small,
                        ) {
                            Row(
                                Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 9.dp),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Icon(Icons.Default.MenuBook, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                Spacer(Modifier.width(8.dp))
                                Text(assignmentText, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
                            }
                        }

                        snapshot.nextDuty?.let { next ->
                            val nextAssignment = next.assignment
                            PlanInfoBlock(
                                title = "المقرر القادم · ${next.date}",
                                value = when {
                                    nextAssignment.milestone != null -> nextAssignment.milestone.label
                                    nextAssignment.pages > 0.0 -> "${assignmentKindAr(nextAssignment.kind)} · ${pageRangeLabel(nextAssignment.startPage, nextAssignment.endPage)} · ${plainNumber(nextAssignment.pages)} ص"
                                    else -> "لا يوجد مقرر"
                                },
                                icon = Icons.Default.ArrowBack,
                            )
                        }
                        PlanInfoBlock(
                            title = "لماذا هذا المقرر؟",
                            value = planWhyText(progress),
                            icon = Icons.Default.Info,
                        )

                        if (progress.behindBy > 0.0) {
                            Text(
                                "متأخر ${plainNumber(progress.behindBy)} صفحة · التعويض اليوم ${plainNumber(progress.recoveryShare)} صفحة",
                                style = MaterialTheme.typography.labelLarge,
                                color = MaterialTheme.colorScheme.error,
                            )
                        } else if (progress.aheadBy > 0.0) {
                            Text(
                                "متقدم ${plainNumber(progress.aheadBy)} صفحة",
                                style = MaterialTheme.typography.labelLarge,
                                color = MaterialTheme.colorScheme.primary,
                            )
                        }

                        if (canManage) {
                            Button(
                                onClick = {
                                    preparing = snapshot.plan.id
                                    scope.launch {
                                        try {
                                            val session = withContext(Dispatchers.IO) {
                                                AppGraph.repo.ensureTodaySession(
                                                    halaqaId = snapshot.student.halaqaId ?: snapshot.plan.halaqaId,
                                                    date = LocalDate.now().toString(),
                                                    assignmentKind = assignment.kind,
                                                )
                                            }
                                            planRecitation = snapshot to session
                                            message = null
                                        } catch (e: Exception) {
                                            message = e.message ?: "تعذر تجهيز جلسة التسميع"
                                        } finally {
                                            preparing = null
                                        }
                                    }
                                },
                                enabled = preparing == null && approvingMilestone == null &&
                                    (assignment.pages > 0.0 || assignment.milestone != null),
                                modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp),
                            ) {
                                Icon(Icons.Default.RecordVoiceOver, contentDescription = null)
                                Spacer(Modifier.width(8.dp))
                                Text(if (preparing == snapshot.plan.id) "جاري التجهيز…" else "تسميع المقرر")
                            }
                            assignment.milestone?.let { milestone ->
                                OutlinedButton(
                                    onClick = {
                                        approvingMilestone = snapshot.plan.id
                                        scope.launch {
                                            try {
                                                withContext(Dispatchers.IO) {
                                                    AppGraph.repo.recordPlanEvent(
                                                        planId = snapshot.plan.id,
                                                        studentId = snapshot.student.id,
                                                        eventType = "milestone_approved",
                                                        payload = JSONObject()
                                                            .put("milestone_key", milestone.key)
                                                            .put("approved_at", java.time.Instant.now().toString()),
                                                    )
                                                }
                                                reload()
                                                message = "تم اعتماد ${milestone.label} وفتح المقرر التالي"
                                                onRefresh()
                                            } catch (e: Exception) {
                                                message = e.message ?: "تعذر اعتماد الاختبار"
                                            } finally {
                                                approvingMilestone = null
                                            }
                                        }
                                    },
                                    enabled = approvingMilestone == null && preparing == null,
                                    modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp),
                                ) {
                                    Icon(Icons.Default.Verified, contentDescription = null)
                                    Spacer(Modifier.width(8.dp))
                                    Text(if (approvingMilestone == snapshot.plan.id) "جاري الاعتماد…" else "اعتماد ${milestone.label}")
                                }
                            }
                        }
                    }
                }
            }
            item { Spacer(Modifier.height(120.dp)) }
        }
    }

    details?.let { snapshot ->
        PlanDetailDialog(snapshot = snapshot, close = { details = null })
    }

    planRecitation?.let { (snapshot, session) ->
        val assignment = snapshot.progress.assignment
        RecitationDialog(
            student = snapshot.student,
            session = session,
            close = { planRecitation = null },
            onSaved = {
                planRecitation = null
                scope.launch { reload(force = true) }
                onRefresh()
            },
            prefillStartPage = assignment.startPage,
            prefillEndPage = assignment.endPage,
            prefillPages = assignment.pages.takeIf { it > 0.0 },
            smartPlanId = snapshot.plan.id,
            smartPlanType = snapshot.plan.type,
            smartPlanDate = LocalDate.now().toString(),
            qcfLineKeys = assignment.lineKeys,
            activityTypeOverride = when (assignment.kind) {
                "sard" -> "sard"
                "review" -> "review_near"
                "tathbit" -> "review_far"
                "test" -> "test"
                else -> "new_hifz"
            },
        )
    }

    if (showManager) {
        PlansManagerSheet(
            plans = allPlans,
            students = students,
            halaqas = halaqas,
            categories = categories,
            onDismiss = { showManager = false },
            onAdd = { showManager = false; editPlan = null; showEditor = true },
            onEdit = { plan -> showManager = false; overrideParent = null; editPlan = plan; showEditor = true },
            onOverride = { plan -> showManager = false; editPlan = null; overrideParent = plan; showEditor = true },
            onStatus = { plan, status ->
                scope.launch {
                    try {
                        withContext(Dispatchers.IO) { AppGraph.repo.setPlanStatus(plan.id, status) }
                        reload()
                        message = when (status) {
                            "archived" -> "تمت أرشفة الخطة"
                            "paused" -> "تم إيقاف الخطة مؤقتاً"
                            "active" -> "تم تفعيل الخطة"
                            else -> "تم تحديث حالة الخطة"
                        }
                        onRefresh()
                    } catch (e: Exception) {
                        message = e.message ?: "تعذر تحديث الخطة"
                    }
                }
            },
        )
    }

    if (showEditor) {
        SmartPlanEditorDialog(
            current = editPlan,
            template = overrideParent,
            students = students,
            halaqas = halaqas,
            categories = categories,
            onDismiss = { showEditor = false; editPlan = null; overrideParent = null },
            onSave = { draft ->
                scope.launch {
                    try {
                        withContext(Dispatchers.IO) { AppGraph.repo.saveSmartPlan(draft) }
                        showEditor = false
                        editPlan = null
                        overrideParent = null
                        reload()
                        message = "تم حفظ الخطة الذكية"
                        onRefresh()
                    } catch (e: Exception) {
                        message = e.message ?: "تعذر حفظ الخطة"
                    }
                }
            },
        )
    }
}

@Composable
private fun PlansManagerSheet(
    plans: List<PlanRow>,
    students: List<Student>,
    halaqas: List<JSONObject>,
    categories: List<JSONObject>,
    onDismiss: () -> Unit,
    onAdd: () -> Unit,
    onEdit: (PlanRow) -> Unit,
    onOverride: (PlanRow) -> Unit,
    onStatus: (PlanRow, String) -> Unit,
) {
    var status by remember { mutableStateOf("all") }
    val filtered = plans.filter { status == "all" || it.status == status }
    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("إدارة الخطط", style = MaterialTheme.typography.titleLarge)
                    Text("إنشاء وتعديل وإيقاف وأرشفة واستعادة الخطط", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                FilledIconButton(onClick = onAdd, modifier = Modifier.size(48.dp)) {
                    Icon(Icons.Default.Add, contentDescription = "خطة جديدة")
                }
            }
            Spacer(Modifier.height(8.dp))
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("all" to "الكل", "active" to "فعالة", "paused" to "موقفة", "completed" to "مكتملة", "archived" to "الأرشيف").forEach { (key, label) ->
                    ProFilterChip(status == key, { status = key }, label)
                }
            }
            Spacer(Modifier.height(8.dp))
            if (filtered.isEmpty()) {
                EmptyState("لا توجد خطط في هذه الحالة")
            } else {
                LazyColumn(
                    modifier = Modifier.heightIn(max = 610.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    contentPadding = PaddingValues(bottom = 28.dp),
                ) {
                    items(filtered, key = { it.id }) { plan ->
                        ElevatedCard(Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Column(Modifier.weight(1f)) {
                                        Text(plan.title.ifBlank { planTypeAr(plan.type) }, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold)
                                        Text(
                                            planScopeLabel(plan, students, halaqas, categories),
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        )
                                    }
                                    Surface(
                                        color = MaterialTheme.colorScheme.secondaryContainer,
                                        contentColor = MaterialTheme.colorScheme.onSecondaryContainer,
                                        shape = MaterialTheme.shapes.extraLarge,
                                    ) {
                                        Text(
                                            planStatusAr(plan.status),
                                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp),
                                            style = MaterialTheme.typography.labelLarge,
                                        )
                                    }
                                }
                                Text("${planTypeAr(plan.type)} · ${plainNumber(plan.target)} صفحة · ${plan.startDate} ← ${plan.endDate}", style = MaterialTheme.typography.bodySmall)
                                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    OutlinedButton(onClick = { onEdit(plan) }, modifier = Modifier.heightIn(min = 48.dp)) {
                                        Icon(Icons.Default.Edit, contentDescription = null)
                                        Spacer(Modifier.width(6.dp)); Text("تعديل")
                                    }
                                    if (plan.scopeType != "student" && plan.status != "archived") {
                                        OutlinedButton(onClick = { onOverride(plan) }, modifier = Modifier.heightIn(min = 48.dp)) {
                                            Icon(Icons.Default.PersonAddAlt, contentDescription = null)
                                            Spacer(Modifier.width(6.dp)); Text("تجاوز خاص بالطالب")
                                        }
                                    }
                                    when (plan.status) {
                                        "active" -> OutlinedButton(onClick = { onStatus(plan, "paused") }, modifier = Modifier.heightIn(min = 48.dp)) { Text("إيقاف مؤقت") }
                                        "paused", "archived", "draft" -> Button(onClick = { onStatus(plan, "active") }, modifier = Modifier.heightIn(min = 48.dp)) { Text(if (plan.status == "archived") "استعادة" else "تفعيل") }
                                    }
                                    if (plan.status != "archived") {
                                        TextButton(onClick = { onStatus(plan, "archived") }, modifier = Modifier.heightIn(min = 48.dp)) { Text("أرشفة") }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

private fun planStatusAr(value: String) = when (value) {
    "draft" -> "مسودة"
    "active" -> "فعالة"
    "paused" -> "موقفة"
    "completed" -> "مكتملة"
    "archived" -> "مؤرشفة"
    else -> value
}

private fun planScopeLabel(
    plan: PlanRow,
    students: List<Student>,
    halaqas: List<JSONObject>,
    categories: List<JSONObject>,
): String = when (plan.scopeType) {
    "student" -> students.firstOrNull { it.id == plan.studentId }?.fullName ?: "طالب محدد"
    "category" -> categories.firstOrNull { it.optString("id") == plan.categoryId }?.optString("name") ?: "فئة محددة"
    else -> halaqas.firstOrNull { it.optString("id") == plan.halaqaId }?.optString("name") ?: "الحلقة كلها"
}

@Composable
private fun SmartPlanEditorDialog(
    current: PlanRow?,
    template: PlanRow? = null,
    students: List<Student>,
    halaqas: List<JSONObject>,
    categories: List<JSONObject>,
    onDismiss: () -> Unit,
    onSave: (SmartPlanDraft) -> Unit,
) {
    val today = LocalDate.now()
    val source = current ?: template
    val isStudentOverride = current == null && template != null
    val planKey = current?.id ?: template?.id?.let { "student_override:$it" }
    var scopeType by remember(planKey) { mutableStateOf(if (isStudentOverride) "student" else (source?.scopeType ?: "student")) }
    var halaqaId by remember(planKey) { initialPlanHalaqaId(source, halaqas) }
    var studentId by remember(planKey) { initialPlanStudentId(source, students, halaqaId) }
    var categoryId by remember(planKey) { initialPlanCategoryId(source, categories, halaqaId) }
    var type by remember(planKey) { initialPlanType(source) }
    var title by remember(planKey) { mutableStateOf(if (isStudentOverride) "${source?.title.orEmpty()} · تخصيص" else initialPlanTitle(source).value) }
    var target by remember(planKey) { initialPlanTarget(source) }
    var startDate by remember(planKey) { initialPlanStartDate(source, today) }
    var endDate by remember(planKey) { initialPlanEndDate(source, today) }
    var weekdays by remember(planKey) { initialPlanWeekdays(source) }
    var catchUp by remember(planKey) { initialPlanCatchUp(source) }
    var rangeStartPage by remember(planKey) { initialPlanRangeStartPage(source) }
    var rangeEndPage by remember(planKey) { initialPlanRangeEndPage(source) }
    var rangeStartSurah by remember(planKey) { initialPlanRangeStartSurah(source) }
    var rangeStartAyah by remember(planKey) { initialPlanRangeStartAyah(source) }
    var rangeEndSurah by remember(planKey) { initialPlanRangeEndSurah(source) }
    var rangeEndAyah by remember(planKey) { initialPlanRangeEndAyah(source) }
    var reviewTier by remember(planKey) { initialPlanReviewTier(source) }
    var nearPages by remember(planKey) { initialPlanNearPages(source) }
    var farPages by remember(planKey) { initialPlanFarPages(source) }
    var minEvaluation by remember(planKey) { initialPlanMinEvaluation(source) }
    var dailyCap by remember(planKey) { initialPlanDailyCap(source) }
    var milestone by remember(planKey) { initialPlanMilestone(source) }
    var delayDays by remember(planKey) { initialPlanDelayDays(source) }
    var qualityGate by remember(planKey) { initialPlanQualityGate(source) }
    var autoExtend by remember(planKey) { initialPlanAutoExtend(source) }
    var milestoneApproval by remember(planKey) { initialPlanMilestoneApproval(source) }
    var homePrepPush by remember(planKey) { initialPlanHomePrepPush(source) }
    var note by remember(planKey) { initialPlanNote(source) }
    var routeDirection by remember(planKey) { initialPlanRouteDirection(source) }
    var showRangePicker by remember { mutableStateOf(false) }
    var showAdvanced by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    val scopedStudents = students.filter { st ->
        st.halaqaId == halaqaId && st.status == "active" &&
            (!isStudentOverride || template?.scopeType != "category" || st.categoryId == template.categoryId)
    }
    val scopedCategories = categories.filter { it.optString("halaqa_id") == halaqaId && it.optBoolean("active", true) }
    val weekdayLabels = listOf("الأحد", "الاثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة", "السبت")

    fun buildDraft(): SmartPlanDraft {
        val parsedTarget = target.toDoubleOrNull() ?: error("أدخل هدفاً صحيحاً بالصفحات")
        val parsedDailyCap = dailyCap.toDoubleOrNull() ?: error("أقصى زيادة يومية غير صالحة")
        val parsedDelay = delayDays.toIntOrNull() ?: error("أيام تنبيه التأخر غير صالحة")
        val parsedNear = nearPages.toDoubleOrNull() ?: 0.0
        val parsedFar = farPages.toDoubleOrNull() ?: 0.0
        val settings = editorPlanSettings(source)
        return SmartPlanDraft(
            id = current?.id,
            scopeType = if (isStudentOverride) "student" else scopeType,
            halaqaId = halaqaId,
            studentId = studentId,
            categoryId = categoryId,
            parentPlanId = if (isStudentOverride) template?.id else current?.parentPlanId,
            type = type,
            reviewTier = if (type == "review") reviewTier else "none",
            title = title,
            targetPages = parsedTarget,
            startDate = startDate,
            endDate = endDate,
            scheduleWeekdays = weekdays.sorted(),
            catchUpWeekday = catchUp,
            maxDailyMultiplier = parsedDailyCap,
            autoExtend = autoExtend,
            qualityGateEnabled = qualityGate,
            minimumEvaluation = minEvaluation,
            rangeStartPage = rangeStartPage,
            rangeEndPage = rangeEndPage,
            rangeStartSurah = rangeStartSurah,
            rangeStartAyah = rangeStartAyah,
            rangeEndSurah = rangeEndSurah,
            rangeEndAyah = rangeEndAyah,
            nearRevisionPages = parsedNear,
            farRevisionPages = parsedFar,
            milestoneMode = milestone,
            milestoneRequiresApproval = milestoneApproval,
            delayAlertDays = parsedDelay,
            homePrepPush = homePrepPush,
            status = current?.status?.takeUnless { it == "archived" } ?: "active",
            note = note,
            minimumDailyMode = settings.minimumDailyMode,
            minimumDailyPages = settings.minimumDailyPages,
            intensiveWeekFrom = settings.intensiveWeekFrom,
            intensiveWeekTo = settings.intensiveWeekTo,
            intensiveWeekdays = settings.intensiveWeekdays,
            memorizationLineKeys = settings.memorizationLineKeys,
            routeDirection = if (type in setOf("sard", "tathbit")) routeDirection else settings.routeDirection,
        )
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(when { isStudentOverride -> "تجاوز خاص بالطالب"; current == null -> "خطة ذكية جديدة"; else -> "تعديل الخطة الذكية" }) },
        text = {
            LazyColumn(
                modifier = Modifier.heightIn(max = 620.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                item {
                    Text("نطاق التطبيق", style = MaterialTheme.typography.titleSmall)
                    if (isStudentOverride) {
                        StateNotice("هذه خطة ابن مرتبطة بالخطة الأصلية ${template?.title.orEmpty()}. يرث الطالب الإعدادات ويمكن تخصيص هدفه أو نطاقه دون تغيير الخطة الجماعية.", "info")
                    } else {
                        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf("student" to "طالب", "category" to "فئة", "halaqa" to "الحلقة").forEach { (key, label) ->
                                ProFilterChip(scopeType == key, { scopeType = key }, label)
                            }
                        }
                    }
                }
                item {
                    Text("الحلقة", style = MaterialTheme.typography.labelLarge)
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        halaqas.filter { it.optBoolean("active", true) || it.optString("id") == halaqaId }.forEach { h ->
                            val id = h.optString("id")
                            ProFilterChip(
                                selected = halaqaId == id,
                                onClick = {
                                    halaqaId = id
                                    studentId = students.firstOrNull { it.halaqaId == id && it.status == "active" }?.id
                                    categoryId = categories.firstOrNull { it.optString("halaqa_id") == id && it.optBoolean("active", true) }?.optString("id")
                                },
                                label = h.optString("name", "حلقة"),
                            )
                        }
                    }
                }
                if (scopeType == "student") item {
                    Text("الطالب", style = MaterialTheme.typography.labelLarge)
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        scopedStudents.forEach { st -> ProFilterChip(studentId == st.id, { studentId = st.id }, st.fullName) }
                    }
                    if (scopedStudents.isEmpty()) Text("لا يوجد طلاب فعالون في الحلقة", color = MaterialTheme.colorScheme.error)
                }
                if (scopeType == "category") item {
                    Text("الفئة", style = MaterialTheme.typography.labelLarge)
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        scopedCategories.forEach { c ->
                            val id = c.optString("id")
                            ProFilterChip(categoryId == id, { categoryId = id }, c.optString("name"))
                        }
                    }
                    if (scopedCategories.isEmpty()) Text("لا توجد فئات فعالة في الحلقة", color = MaterialTheme.colorScheme.error)
                }
                item {
                    Text("نوع الخطة", style = MaterialTheme.typography.labelLarge)
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("hifz" to "حفظ", "review" to "مراجعة", "sard" to "سرد", "tathbit" to "تثبيت").forEach { (key, label) ->
                            ProFilterChip(type == key, { type = key }, label)
                        }
                    }
                }
                item {
                    OutlinedTextField(title, { title = it }, label = { Text("عنوان الخطة") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                }
                item {
                    OutlinedTextField(target, { target = it.filter { ch -> ch.isDigit() || ch == '.' } }, label = { Text("المطلوب خلال الخطة بالصفحات") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                }
                item {
                    OutlinedButton(onClick = { showRangePicker = true }, modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp)) {
                        Icon(Icons.Default.MenuBook, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text("نطاق القرآن: ${pageRangeLabel(rangeStartPage, rangeEndPage)}")
                    }
                }
                if (type in setOf("sard", "tathbit")) item {
                    Text("اتجاه المسار", style = MaterialTheme.typography.labelLarge)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        ProFilterChip(routeDirection == "reverse_surahs_forward_ayahs", { routeDirection = "reverse_surahs_forward_ayahs" }, "الناس ← البقرة")
                        ProFilterChip(routeDirection == "forward_surahs_forward_ayahs", { routeDirection = "forward_surahs_forward_ayahs" }, "البقرة → الناس")
                    }
                }
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(startDate, { startDate = it }, label = { Text("تاريخ البدء") }, modifier = Modifier.weight(1f), singleLine = true)
                        OutlinedTextField(endDate, { endDate = it }, label = { Text("تاريخ الانتهاء") }, modifier = Modifier.weight(1f), singleLine = true)
                    }
                }
                item {
                    Text("أيام الدوام", style = MaterialTheme.typography.labelLarge)
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        weekdayLabels.forEachIndexed { index, label ->
                            ProFilterChip(
                                selected = index in weekdays,
                                onClick = { weekdays = if (index in weekdays) weekdays - index else weekdays + index },
                                label = label,
                            )
                        }
                    }
                }
                item {
                    Text("يوم الاستدراك", style = MaterialTheme.typography.labelLarge)
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        ProFilterChip(catchUp == null, { catchUp = null }, "بدون")
                        weekdayLabels.forEachIndexed { index, label -> ProFilterChip(catchUp == index, { catchUp = index }, label) }
                    }
                }
                if (type == "review") item {
                    Text("مسار المراجعة", style = MaterialTheme.typography.labelLarge)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("near" to "قريبة", "far" to "بعيدة", "both" to "قريبة + بعيدة").forEach { (key, label) ->
                            ProFilterChip(reviewTier == key, { reviewTier = key }, label)
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(nearPages, { nearPages = it.filter { ch -> ch.isDigit() || ch == '.' } }, label = { Text("قريبة يومياً") }, modifier = Modifier.weight(1f), singleLine = true)
                        OutlinedTextField(farPages, { farPages = it.filter { ch -> ch.isDigit() || ch == '.' } }, label = { Text("دورة بعيدة") }, modifier = Modifier.weight(1f), singleLine = true)
                    }
                }
                item {
                    TextButton(onClick = { showAdvanced = !showAdvanced }, modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp)) {
                        Text(if (showAdvanced) "إخفاء قواعد الخطة" else "قواعد الخطة الذكية")
                        Spacer(Modifier.width(6.dp))
                        Icon(if (showAdvanced) Icons.Default.ExpandLess else Icons.Default.ExpandMore, contentDescription = null)
                    }
                }
                if (showAdvanced) {
                    item {
                        Text("أقل تقييم للاجتياز", style = MaterialTheme.typography.labelLarge)
                        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf("excellent" to "ممتاز", "very_good" to "جيد جداً", "good" to "جيد").forEach { (key, label) ->
                                ProFilterChip(minEvaluation == key, { minEvaluation = key }, label)
                            }
                        }
                    }
                    item {
                        Text("أقصى زيادة يومية", style = MaterialTheme.typography.labelLarge)
                        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf("1.25", "1.5", "1.75", "2.0").forEach { value ->
                                ProFilterChip(dailyCap == value || dailyCap == value.removeSuffix(".0"), { dailyCap = value }, "${(value.toDouble() * 100).toInt()}%")
                            }
                        }
                    }
                    item {
                        Text("الاختبار المرحلي", style = MaterialTheme.typography.labelLarge)
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf("none" to "بدون", "hizb" to "حزب", "juz" to "جزء").forEach { (key, label) ->
                                ProFilterChip(milestone == key, { milestone = key }, label)
                            }
                        }
                    }
                    item { OutlinedTextField(delayDays, { delayDays = it.filter(Char::isDigit) }, label = { Text("تنبيه التأخر بعد أيام دوام") }, modifier = Modifier.fillMaxWidth(), singleLine = true) }
                    item { SwitchRow("لا يتقدم قبل اجتياز التقييم", qualityGate) { qualityGate = it } }
                    item { SwitchRow("تمديد نهاية الخطة تلقائياً", autoExtend) { autoExtend = it } }
                    item { SwitchRow("الاختبار المرحلي يحتاج اعتماد المحفّظ", milestoneApproval) { milestoneApproval = it } }
                    item { SwitchRow("تنبيه التحضير المنزلي لولي الأمر", homePrepPush) { homePrepPush = it } }
                }
                item { OutlinedTextField(note, { note = it }, label = { Text("ملاحظة للمحفّظ وولي الأمر") }, modifier = Modifier.fillMaxWidth(), minLines = 2) }
                error?.let { item { Text(it, color = MaterialTheme.colorScheme.error) } }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    try {
                        error = null
                        onSave(buildDraft())
                    } catch (e: Exception) {
                        error = e.message ?: "تحقق من بيانات الخطة"
                    }
                },
            ) { Text("حفظ الخطة") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } },
    )

    if (showRangePicker) {
        QuranRangePickerDialog(
            initialStartPage = rangeStartPage,
            initialEndPage = rangeEndPage,
            track = track,
            activityType = if (track == "general_hifz") "new_hifz" else "review_near",
            onDismiss = { showRangePicker = false },
            onConfirm = { selected ->
                rangeStartPage = selected.startPage
                rangeEndPage = selected.endPage
                rangeStartSurah = selected.start?.surah
                rangeStartAyah = selected.start?.ayah
                rangeEndSurah = selected.end?.surah
                rangeEndAyah = selected.end?.ayah
                showRangePicker = false
            },
        )
    }
}

@Composable
private fun SwitchRow(label: String, checked: Boolean, onChecked: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().heightIn(min = 48.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
        Switch(checked = checked, onCheckedChange = onChecked)
    }
}

@Composable
private fun PlanHealthBadge(health: String, label: String) {
    val colors = when (health) {
        "red" -> MaterialTheme.colorScheme.errorContainer to MaterialTheme.colorScheme.onErrorContainer
        "yellow" -> MaterialTheme.colorScheme.tertiaryContainer to MaterialTheme.colorScheme.onTertiaryContainer
        else -> MaterialTheme.colorScheme.primaryContainer to MaterialTheme.colorScheme.onPrimaryContainer
    }
    Surface(color = colors.first, contentColor = colors.second, shape = MaterialTheme.shapes.extraLarge) {
        Text(label, Modifier.padding(horizontal = 10.dp, vertical = 6.dp), style = MaterialTheme.typography.labelLarge)
    }
}

@Composable
private fun PlanStatTile(label: String, value: String, modifier: Modifier = Modifier) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(14.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
    ) {
        Column(Modifier.padding(horizontal = 8.dp, vertical = 10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(value, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
            Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
        }
    }
}

@Composable
private fun PlanInfoBlock(title: String, value: String, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
    ) {
        Row(Modifier.fillMaxWidth().padding(11.dp), verticalAlignment = Alignment.Top, horizontalArrangement = Arrangement.spacedBy(9.dp)) {
            Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(title, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                Text(value, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

private fun planWhyText(progress: com.mohammedsamir.halaqati.plans.SmartPlanEngine.Progress): String = when {
    progress.assignment.blockedByRetry -> "يوجد مقرر سابق يحتاج إعادة؛ بوابة الجودة تمنع التقدم حتى تثبيته."
    progress.behindBy > 0.01 -> "أنت متأخر ${plainNumber(progress.behindBy)} ص عن المسار؛ أضيف ${plainNumber(progress.recoveryShare)} ص تعويضًا إلى ورد اليوم."
    progress.assignment.isCatchUp -> "هذا يوم تعويض مخصص لاستعادة المتأخر من الأيام السابقة."
    progress.aheadBy > 0.01 -> "الطالب متقدم ${plainNumber(progress.aheadBy)} ص؛ المقرر يحافظ على تسلسل الخطة دون مضاعفة غير لازمة."
    progress.assignment.pages <= 0.001 && progress.remaining <= 0.001 -> "اكتملت الخطة الحالية."
    progress.assignment.pages <= 0.001 -> "اليوم ليس يوم دوام للخطة؛ سيظهر المقرر في يوم الخطة التالي."
    else -> "المطلوب حتى اليوم ${plainNumber(progress.plannedByToday)} ص، والمنجز ${plainNumber(progress.completed)} ص؛ ورد اليوم محسوب وفق أيام الدوام والحد اليومي والتقدم الفعلي."
}

@Composable
private fun PlanMetric(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, style = MaterialTheme.typography.titleMedium)
        Text(label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun PlanDetailDialog(snapshot: PlanSnapshot, close: () -> Unit) {
    val p = snapshot.progress
    AlertDialog(
        onDismissRequest = close,
        title = { Text("${snapshot.student.fullName} · ${planTypeAr(snapshot.plan.type)}") },
        text = {
            LazyColumn(
                modifier = Modifier.heightIn(max = 560.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                item {
                    Text(snapshot.plan.title.ifBlank { planTypeAr(snapshot.plan.type) }, style = MaterialTheme.typography.titleMedium)
                    Text(
                        "${snapshot.plan.startDate} ← ${snapshot.plan.endDate}",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                item {
                    LinearProgressIndicator(
                        progress = { (p.percentage / 100.0).toFloat().coerceIn(0f, 1f) },
                        modifier = Modifier.fillMaxWidth().height(9.dp).graphicsLayer(scaleX = -1f),
                    )
                }
                item {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        PlanMetric("المكتمل", "${plainNumber(p.completed)} ص")
                        PlanMetric("المتبقي", "${plainNumber(p.remaining)} ص")
                        PlanMetric("النسبة", "${plainNumber(p.percentage)}%")
                    }
                }
                item { HorizontalDivider() }
                item { PlanDetailLine("الحالة", "${p.healthLabel} · ${p.paceLabel}") }
                item { PlanDetailLine("المقرر اليوم", "${plainNumber(p.assignment.pages)} صفحة") }
                item { PlanDetailLine("الحد اليومي", "${plainNumber(p.dailyCap)} صفحة") }
                item { PlanDetailLine("الحد الأدنى", "${plainNumber(p.minimumDaily)} صفحة") }
                item { PlanDetailLine("المخطط حتى اليوم", "${plainNumber(p.plannedByToday)} صفحة") }
                item { PlanDetailLine("العجز", "${plainNumber(p.deficit)} صفحة") }
                item { PlanDetailLine("أيام التأخر المتتالية", p.consecutiveMissed.toString()) }
                if (p.extensionNeeded) {
                    item { PlanDetailLine("التمديد المقترح", p.suggestedEndDate.toString()) }
                }
                item {
                    PlanDetailLine(
                        "النطاق",
                        pageRangeLabel(snapshot.plan.rangeStartPage, snapshot.plan.rangeEndPage),
                    )
                }
                if (p.retryPages.isNotEmpty()) {
                    item { PlanDetailLine("صفحات تحتاج إعادة", p.retryPages.joinToString(", ")) }
                }
                p.assignment.milestone?.let { milestone ->
                    item { PlanDetailLine("الاختبار المطلوب", milestone.label) }
                }
                snapshot.plan.note.takeIf { it.isNotBlank() }?.let { note ->
                    item { PlanDetailLine("ملاحظة الخطة", note) }
                }
            }
        },
        confirmButton = { Button(onClick = close) { Text("إغلاق") } },
    )
}

@Composable
private fun PlanDetailLine(label: String, value: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, style = MaterialTheme.typography.bodyMedium)
    }
}

private fun assignmentKindAr(value: String) = when (value) {
    "hifz", "new_hifz" -> "حفظ جديد"
    "review", "review_near" -> "مراجعة قريبة"
    "review_far", "tathbit" -> "تثبيت"
    "sard" -> "سرد"
    "tilawah" -> "تلاوة"
    "test" -> "اختبار"
    else -> value
}

private fun pageRangeLabel(start: Int?, end: Int?): String = when {
    start == null && end == null -> "يُحدد حسب الخطة"
    start != null && end != null && start == end -> "صفحة $start"
    start != null && end != null -> "من صفحة $start إلى $end"
    start != null -> "من صفحة $start"
    else -> "حتى صفحة $end"
}

internal fun plainNumber(value: Double): String {
    val rounded = kotlin.math.round(value * 100.0) / 100.0
    return if (kotlin.math.abs(rounded - rounded.toInt()) < 0.000001) rounded.toInt().toString()
    else rounded.toString().trimEnd('0').trimEnd('.')
}

fun planTypeAr(value: String) = when (value) {
    "hifz" -> "حفظ"
    "review" -> "مراجعة"
    "sard" -> "سرد"
    "tathbit" -> "تثبيت"
    else -> value
}


@Composable
fun UsersScreen(pending: Int, onRefresh: () -> Unit) {
    val scope = rememberCoroutineScope()
    var rows by remember { mutableStateOf<List<JSONObject>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var status by remember { mutableStateOf("pending") }
    var query by remember { mutableStateOf("") }
    var message by remember { mutableStateOf<String?>(null) }
    var rejectUser by remember { mutableStateOf<JSONObject?>(null) }
    var roleUser by remember { mutableStateOf<JSONObject?>(null) }
    var deleteUser by remember { mutableStateOf<JSONObject?>(null) }
    var linkGuardian by remember { mutableStateOf(false) }
    var busyId by remember { mutableStateOf<String?>(null) }

    suspend fun reload() {
        loading = true
        try {
            val arr = withContext(Dispatchers.IO) { AppGraph.repo.accountProfiles() }
            rows = (0 until arr.length()).mapNotNull { arr.optJSONObject(it) }
            message = null
        } catch (e: Exception) {
            message = e.message ?: "تعذر تحميل الحسابات"
        } finally {
            loading = false
        }
    }

    fun runAccountAction(userId: String, action: () -> Unit, success: String) {
        busyId = userId
        scope.launch {
            try {
                withContext(Dispatchers.IO) { action() }
                message = success
                reload()
                onRefresh()
            } catch (e: Exception) {
                message = e.message ?: "تعذر تنفيذ العملية"
            } finally {
                busyId = null
            }
        }
    }

    LaunchedEffect(Unit) { reload() }
    val filtered = rows.filter { row ->
        (status == "all" || row.optString("approval_status") == status) &&
            (query.isBlank() || row.optString("full_name").contains(query, true) || row.optString("email").contains(query, true))
    }

    Column {
        AppTopBar(
            title = "الحسابات والصلاحيات",
            onRefresh = { scope.launch { reload() }; onRefresh() },
            pending = pending,
        )
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("بحث بالاسم أو البريد") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                singleLine = true,
            )
            Row(
                Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                listOf("pending" to "بانتظار الاعتماد", "approved" to "معتمدة", "rejected" to "مرفوضة", "all" to "الكل")
                    .forEach { (value, label) ->
                        ProFilterChip(status == value, { status = value }, label)
                    }
            }
            OutlinedButton(
                onClick = { linkGuardian = true },
                modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp),
            ) {
                Icon(Icons.Default.FamilyRestroom, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("ربط ولي الأمر بالطالب")
            }
        }
        message?.let {
            StateNotice(
                it,
                kind = if (it.startsWith("تعذر") || it.contains("غير صالح")) "error" else "success",
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp),
            )
        }
        if (loading && rows.isEmpty()) LoadingSkeleton(rows = 4, modifier = Modifier.padding(12.dp))
        if (!loading && filtered.isEmpty()) EmptyState("لا توجد حسابات في هذا التصنيف")
        LazyColumn(
            contentPadding = PaddingValues(start = 12.dp, end = 12.dp, top = 12.dp, bottom = 96.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            items(filtered, key = { it.optString("id") }) { row ->
                val id = row.optString("id")
                val isAdmin = row.optString("role") == "admin"
                val approval = row.optString("approval_status")
                val active = row.optBoolean("active", true)
                val requested = row.optString("requested_role").ifBlank { row.optString("role", "guardian") }
                ElevatedCard(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.AccountCircle, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            Spacer(Modifier.width(8.dp))
                            Column(Modifier.weight(1f)) {
                                Text(row.optString("full_name").ifBlank { "مستخدم" }, style = MaterialTheme.typography.titleMedium)
                                Text(row.optString("email").ifBlank { "—" }, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            AccountStatusBadge(approval, active, isAdmin)
                        }
                        Text(
                            if (isAdmin) "مسؤول النظام" else "الصلاحية: ${roleAr(row.optString("role"))} · الطلب: ${roleAr(requested)}",
                            style = MaterialTheme.typography.labelLarge,
                        )
                        row.optString("rejection_reason").takeIf { it.isNotBlank() }?.let { reason ->
                            Text("سبب الرفض: $reason", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                        }
                        if (!isAdmin) {
                            Row(
                                Modifier.horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                            ) {
                                when (approval) {
                                    "pending" -> {
                                        Button(
                                            onClick = {
                                                runAccountAction(id, { AppGraph.repo.approveAccount(id, requested) }, "تم اعتماد الحساب")
                                            },
                                            enabled = busyId == null,
                                            modifier = Modifier.heightIn(min = 48.dp),
                                        ) { Text(if (busyId == id) "جاري…" else "اعتماد") }
                                        OutlinedButton(onClick = { rejectUser = row }, enabled = busyId == null, modifier = Modifier.heightIn(min = 48.dp)) { Text("رفض") }
                                    }
                                    "rejected" -> Button(
                                        onClick = { runAccountAction(id, { AppGraph.repo.approveAccount(id, requested) }, "تم اعتماد الحساب من جديد") },
                                        enabled = busyId == null,
                                        modifier = Modifier.heightIn(min = 48.dp),
                                    ) { Text("اعتماد من جديد") }
                                    else -> {
                                        FilledTonalButton(
                                            onClick = { runAccountAction(id, { AppGraph.repo.setAccountActive(id, !active) }, if (active) "تم إيقاف الحساب" else "تم تفعيل الحساب") },
                                            enabled = busyId == null,
                                            modifier = Modifier.heightIn(min = 48.dp),
                                        ) { Text(if (active) "إيقاف" else "تفعيل") }
                                        OutlinedButton(onClick = { roleUser = row }, enabled = busyId == null, modifier = Modifier.heightIn(min = 48.dp)) { Text("تغيير الصلاحية") }
                                    }
                                }
                                TextButton(onClick = { deleteUser = row }, enabled = busyId == null, modifier = Modifier.heightIn(min = 48.dp)) {
                                    Icon(Icons.Default.DeleteForever, contentDescription = null)
                                    Text(" حذف نهائي")
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    rejectUser?.let { row ->
        RejectAccountDialog(
            name = row.optString("full_name"),
            close = { rejectUser = null },
            save = { reason ->
                val id = row.optString("id")
                rejectUser = null
                runAccountAction(id, { AppGraph.repo.rejectAccount(id, reason) }, "تم رفض طلب الحساب")
            },
        )
    }
    roleUser?.let { row ->
        RoleAccountDialog(
            name = row.optString("full_name"),
            current = row.optString("role", "guardian"),
            close = { roleUser = null },
            save = { role ->
                val id = row.optString("id")
                roleUser = null
                runAccountAction(id, { AppGraph.repo.changeAccountRole(id, role) }, "تم تغيير الصلاحية")
            },
        )
    }
    deleteUser?.let { row ->
        DeleteAccountDialog(
            name = row.optString("full_name"),
            close = { deleteUser = null },
            confirm = {
                val id = row.optString("id")
                deleteUser = null
                runAccountAction(id, { AppGraph.repo.deleteAccountPermanently(id) }, "تم حذف الحساب نهائيًا")
            },
        )
    }
    if (linkGuardian) {
        GuardianLinkDialog(
            close = { linkGuardian = false },
            onSaved = {
                linkGuardian = false
                message = "تم تحديث ربط ولي الأمر"
                onRefresh()
            },
        )
    }
}

@Composable
private fun AccountStatusBadge(approval: String, active: Boolean, admin: Boolean) {
    val (label, container, content) = when {
        admin -> Triple("مسؤول", MaterialTheme.colorScheme.secondaryContainer, MaterialTheme.colorScheme.onSecondaryContainer)
        approval == "pending" -> Triple("بانتظار الاعتماد", MaterialTheme.colorScheme.tertiaryContainer, MaterialTheme.colorScheme.onTertiaryContainer)
        approval == "rejected" -> Triple("مرفوض", MaterialTheme.colorScheme.errorContainer, MaterialTheme.colorScheme.onErrorContainer)
        !active -> Triple("موقوف", MaterialTheme.colorScheme.errorContainer, MaterialTheme.colorScheme.onErrorContainer)
        else -> Triple("نشط", MaterialTheme.colorScheme.primaryContainer, MaterialTheme.colorScheme.onPrimaryContainer)
    }
    Surface(color = container, contentColor = content, shape = MaterialTheme.shapes.extraLarge) {
        Text(label, Modifier.padding(horizontal = 9.dp, vertical = 5.dp), style = MaterialTheme.typography.labelMedium)
    }
}

private fun roleAr(value: String) = when (value) {
    "admin" -> "مسؤول النظام"
    "supervisor" -> "مشرف الحلقات"
    "teacher" -> "محفّظ الحلقة"
    "guardian" -> "ولي أمر"
    "student" -> "طالب"
    else -> "غير محدد"
}

@Composable
private fun RejectAccountDialog(name: String, close: () -> Unit, save: (String) -> Unit) {
    var reason by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = close,
        title = { Text("رفض حساب $name") },
        text = { OutlinedTextField(value = reason, onValueChange = { reason = it }, label = { Text("سبب الرفض (اختياري)") }, minLines = 2, modifier = Modifier.fillMaxWidth()) },
        confirmButton = { Button(onClick = { save(reason.trim()) }, modifier = Modifier.heightIn(min = HalaqatiUiTokens.TouchTarget)) { Text("رفض الحساب") } },
        dismissButton = { TextButton(onClick = close, modifier = Modifier.heightIn(min = HalaqatiUiTokens.TouchTarget)) { Text("إلغاء") } },
    )
}

@Composable
private fun RoleAccountDialog(name: String, current: String, close: () -> Unit, save: (String) -> Unit) {
    var role by remember { mutableStateOf(current.takeIf { it in setOf("guardian", "teacher", "supervisor") } ?: "guardian") }
    val roles = listOf("guardian", "teacher", "supervisor")
    AlertDialog(
        onDismissRequest = close,
        title = { Text("صلاحية $name") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                roles.forEach { value ->
                    ProFilterChip(role == value, { role = value }, roleAr(value), modifier = Modifier.fillMaxWidth())
                }
            }
        },
        confirmButton = { Button(onClick = { save(role) }, modifier = Modifier.heightIn(min = HalaqatiUiTokens.TouchTarget)) { Text("حفظ") } },
        dismissButton = { TextButton(onClick = close, modifier = Modifier.heightIn(min = HalaqatiUiTokens.TouchTarget)) { Text("إلغاء") } },
    )
}

@Composable
private fun DeleteAccountDialog(name: String, close: () -> Unit, confirm: () -> Unit) {
    var typed by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = close,
        title = { Text("حذف الحساب نهائيًا") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("سيتم حذف حساب «$name» نهائيًا. اكتب حذف للتأكيد.", color = MaterialTheme.colorScheme.error)
                OutlinedTextField(value = typed, onValueChange = { typed = it }, label = { Text("اكتب: حذف") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            }
        },
        confirmButton = { Button(onClick = confirm, enabled = typed.trim() == "حذف", modifier = Modifier.heightIn(min = HalaqatiUiTokens.TouchTarget)) { Text("حذف نهائي") } },
        dismissButton = { TextButton(onClick = close, modifier = Modifier.heightIn(min = HalaqatiUiTokens.TouchTarget)) { Text("إلغاء") } },
    )
}

@Composable
private fun GuardianLinkDialog(close: () -> Unit, onSaved: () -> Unit, initialStudentId: String? = null) {
    val scope = rememberCoroutineScope()
    var students by remember { mutableStateOf<List<Student>>(emptyList()) }
    var guardians by remember { mutableStateOf<List<JSONObject>>(emptyList()) }
    var studentId by remember { mutableStateOf<String?>(null) }
    var guardianId by remember { mutableStateOf<String?>(null) }
    var loading by remember { mutableStateOf(true) }
    var saving by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(Unit) {
        try {
            val result = withContext(Dispatchers.IO) {
                val st = AppGraph.repo.students()
                val ga = AppGraph.repo.guardianAccounts()
                st to (0 until ga.length()).mapNotNull { ga.optJSONObject(it) }
            }
            students = result.first
            guardians = result.second
            studentId = initialStudentId?.takeIf { wanted -> students.any { it.id == wanted } } ?: students.firstOrNull()?.id
            guardianId = guardians.firstOrNull()?.optString("id")
        } catch (e: Exception) {
            error = e.message ?: "تعذر تحميل بيانات الربط"
        } finally {
            loading = false
        }
    }

    AlertDialog(
        onDismissRequest = { if (!saving) close() },
        title = { Text("ربط ولي الأمر بالطالب") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (loading) LoadingSkeleton(rows = 2)
                error?.let { StateNotice(it, "error") }
                Text("الطالب", style = MaterialTheme.typography.labelLarge)
                LazyColumn(Modifier.heightIn(max = 160.dp)) {
                    items(students, key = { it.id }) { student ->
                        ProFilterChip(
                            selected = studentId == student.id,
                            onClick = { studentId = student.id },
                            label = student.fullName,
                            modifier = Modifier.fillMaxWidth(),
                        )
                    }
                }
                if (!loading && students.isEmpty()) EmptyState("لا يوجد طلاب متاحون للربط")
                Text("ولي الأمر", style = MaterialTheme.typography.labelLarge)
                LazyColumn(Modifier.heightIn(max = 160.dp)) {
                    items(guardians, key = { it.optString("id") }) { guardian ->
                        ProFilterChip(
                            selected = guardianId == guardian.optString("id"),
                            onClick = { guardianId = guardian.optString("id") },
                            label = guardian.optString("full_name").ifBlank { guardian.optString("email", "ولي أمر") },
                            modifier = Modifier.fillMaxWidth(),
                        )
                    }
                }
                if (!loading && guardians.isEmpty()) EmptyState("لا توجد حسابات أولياء أمور معتمدة")
            }
        },
        confirmButton = {
            Button(
                enabled = !loading && !saving && !studentId.isNullOrBlank() && !guardianId.isNullOrBlank(),
                onClick = {
                    val st = studentId ?: return@Button
                    saving = true
                    scope.launch {
                        try {
                            withContext(Dispatchers.IO) { AppGraph.repo.linkPrimaryGuardian(st, guardianId) }
                            onSaved()
                        } catch (e: Exception) {
                            error = e.message ?: "تعذر ربط ولي الأمر"
                        } finally {
                            saving = false
                        }
                    }
                },
                modifier = Modifier.heightIn(min = HalaqatiUiTokens.TouchTarget),
            ) { Text(if (saving) "جاري الحفظ…" else "حفظ الربط") }
        },
        dismissButton = { TextButton(onClick = close, enabled = !saving, modifier = Modifier.heightIn(min = HalaqatiUiTokens.TouchTarget)) { Text("إلغاء") } },
    )
}

// Keep nullable field initialization in separate FIR control-flow graphs.
private fun initialPlanScopeType(current: PlanRow?): MutableState<String> =
    mutableStateOf(current?.scopeType ?: "student")

private fun initialPlanHalaqaId(current: PlanRow?, halaqas: List<JSONObject>): MutableState<String> =
    mutableStateOf(current?.halaqaId ?: halaqas.firstOrNull()?.optString("id").orEmpty())

private fun initialPlanStudentId(current: PlanRow?, students: List<Student>, halaqaId: String): MutableState<String?> =
    mutableStateOf(current?.studentId ?: students.firstOrNull { it.halaqaId == halaqaId }?.id)

private fun initialPlanCategoryId(current: PlanRow?, categories: List<JSONObject>, halaqaId: String): MutableState<String?> =
    mutableStateOf(current?.categoryId ?: categories.firstOrNull { it.optString("halaqa_id") == halaqaId }?.optString("id"))

private fun initialPlanType(current: PlanRow?): MutableState<String> =
    mutableStateOf(current?.type ?: "hifz")

private fun initialPlanTitle(current: PlanRow?): MutableState<String> =
    mutableStateOf(current?.title.orEmpty())

private fun initialPlanTarget(current: PlanRow?): MutableState<String> =
    mutableStateOf((current?.target ?: 20.0).toString())

private fun initialPlanStartDate(current: PlanRow?, today: LocalDate): MutableState<String> =
    mutableStateOf(current?.startDate ?: today.toString())

private fun initialPlanEndDate(current: PlanRow?, today: LocalDate): MutableState<String> =
    mutableStateOf(current?.endDate ?: today.plusMonths(1).toString())

private fun initialPlanWeekdays(current: PlanRow?): MutableState<Set<Int>> =
    mutableStateOf((current?.scheduleWeekdays?.toSet()?.takeIf { it.isNotEmpty() } ?: setOf(0, 1, 2, 3, 4)))

private fun initialPlanCatchUp(current: PlanRow?): MutableState<Int?> =
    mutableStateOf(current?.catchUpWeekday)

private fun initialPlanRangeStartPage(current: PlanRow?): MutableState<Int?> =
    mutableStateOf(current?.rangeStartPage)

private fun initialPlanRangeEndPage(current: PlanRow?): MutableState<Int?> =
    mutableStateOf(current?.rangeEndPage)

private fun initialPlanRangeStartSurah(current: PlanRow?): MutableState<Int?> =
    mutableStateOf(current?.rangeStartSurah)

private fun initialPlanRangeStartAyah(current: PlanRow?): MutableState<Int?> =
    mutableStateOf(current?.rangeStartAyah)

private fun initialPlanRangeEndSurah(current: PlanRow?): MutableState<Int?> =
    mutableStateOf(current?.rangeEndSurah)

private fun initialPlanRangeEndAyah(current: PlanRow?): MutableState<Int?> =
    mutableStateOf(current?.rangeEndAyah)

private fun initialPlanReviewTier(current: PlanRow?): MutableState<String> =
    mutableStateOf(current?.reviewTier ?: "none")

private fun initialPlanNearPages(current: PlanRow?): MutableState<String> =
    mutableStateOf((current?.nearRevisionPages ?: 7.0).toString())

private fun initialPlanFarPages(current: PlanRow?): MutableState<String> =
    mutableStateOf((current?.farRevisionPages ?: 20.0).toString())

private fun initialPlanMinEvaluation(current: PlanRow?): MutableState<String> =
    mutableStateOf(current?.minimumEvaluation ?: "good")

private fun initialPlanDailyCap(current: PlanRow?): MutableState<String> =
    mutableStateOf((current?.maxDailyMultiplier ?: 1.5).toString())

private fun initialPlanMilestone(current: PlanRow?): MutableState<String> =
    mutableStateOf(current?.milestoneMode ?: "juz")

private fun initialPlanDelayDays(current: PlanRow?): MutableState<String> =
    mutableStateOf((current?.delayAlertDays ?: 3).toString())

private fun initialPlanQualityGate(current: PlanRow?): MutableState<Boolean> =
    mutableStateOf(current?.qualityGateEnabled ?: true)

private fun initialPlanAutoExtend(current: PlanRow?): MutableState<Boolean> =
    mutableStateOf(current?.autoExtend ?: true)

private fun initialPlanMilestoneApproval(current: PlanRow?): MutableState<Boolean> =
    mutableStateOf(current?.milestoneRequiresApproval ?: true)

private fun initialPlanHomePrepPush(current: PlanRow?): MutableState<Boolean> =
    mutableStateOf(current?.homePrepPush ?: true)

private fun initialPlanNote(current: PlanRow?): MutableState<String> =
    mutableStateOf(current?.note.orEmpty())

private fun initialPlanRouteDirection(current: PlanRow?): MutableState<String> =
    mutableStateOf(current?.settings?.routeDirection ?: "reverse_surahs_forward_ayahs")

private fun editorPlanSettings(current: PlanRow?): PlanSettingsRow =
    current?.settings ?: PlanSettingsRow()
