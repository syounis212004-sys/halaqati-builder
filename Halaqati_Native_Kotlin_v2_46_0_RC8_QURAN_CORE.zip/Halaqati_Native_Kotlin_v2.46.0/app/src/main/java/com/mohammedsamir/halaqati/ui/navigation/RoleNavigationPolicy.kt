package com.mohammedsamir.halaqati.ui.navigation

import com.mohammedsamir.halaqati.model.UserRole

data class MoreSection(val title: String, val items: List<AppDestination>)
data class DrawerNavItem(val destination: AppDestination, val label: String)

object RoleNavigationPolicy {
    private val admin = listOf(
        AppDestination.Home, AppDestination.Notifications, AppDestination.Halaqas,
        AppDestination.Community, AppDestination.Sessions, AppDestination.SessionToday, AppDestination.QuickMemorization,
        AppDestination.Students, AppDestination.Plans, AppDestination.Certificates,
        AppDestination.Reports, AppDestination.Quran, AppDestination.Rankings,
        AppDestination.ImportExport, AppDestination.SyncCenter, AppDestination.Supervision,
        AppDestination.Users, AppDestination.Settings,
    )
    private val supervisor = admin.filterNot { it == AppDestination.Users }
    private val teacher = supervisor.filterNot { it == AppDestination.Supervision }
    private val guardian = listOf(
        AppDestination.Home, AppDestination.Notifications, AppDestination.Community,
        AppDestination.Plans, AppDestination.Reports, AppDestination.GuardianCompetition,
        AppDestination.GuardianAchievements, AppDestination.GuardianProfile,
        AppDestination.SyncCenter, AppDestination.Settings,
    )
    private val limited = listOf(AppDestination.Home, AppDestination.GuardianProfile, AppDestination.Settings)

    fun destinations(role: UserRole) = when (role) {
        UserRole.ADMIN -> admin
        UserRole.SUPERVISOR -> supervisor
        UserRole.TEACHER -> teacher
        UserRole.GUARDIAN -> guardian
        else -> limited
    }

    fun bottom(role: UserRole) = if (role == UserRole.GUARDIAN) {
        listOf(AppDestination.Home, AppDestination.Reports, AppDestination.Plans, AppDestination.GuardianProfile, AppDestination.More)
    } else {
        listOf(AppDestination.Home, AppDestination.Sessions, AppDestination.Students, AppDestination.Plans, AppDestination.More)
    }

    /**
     * Golden-master drawer order and role-specific labels copied from Halaqati v2.44.
     * SyncCenter stays accessible from the compact sync badge instead of adding a new row
     * that did not exist in the 2.44 drawer.
     */
    fun drawerItems(role: UserRole): List<DrawerNavItem> = when (role) {
        UserRole.ADMIN -> listOf(
            item(AppDestination.Home, "الرئيسية"),
            item(AppDestination.Notifications, "الإشعارات"),
            item(AppDestination.Halaqas, "إدارة الحلقات والفئات"),
            item(AppDestination.Community, "الإعلانات ومنتدى الحلقة"),
            item(AppDestination.Sessions, "الجلسات اليومية"),
            item(AppDestination.Students, "الطلاب"),
            item(AppDestination.Plans, "الخطط الذكية"),
            item(AppDestination.Certificates, "الشهادات"),
            item(AppDestination.Reports, "التقارير"),
            item(AppDestination.Quran, "حاسبة القرآن"),
            item(AppDestination.Rankings, "الترتيب والإحصائيات"),
            item(AppDestination.ImportExport, "الاستيراد والتصدير"),
            item(AppDestination.Supervision, "متابعة المحفّظ"),
            item(AppDestination.Users, "الحسابات والصلاحيات"),
            item(AppDestination.Settings, "الإعدادات"),
        )
        UserRole.SUPERVISOR -> listOf(
            item(AppDestination.Home, "الرئيسية"),
            item(AppDestination.Notifications, "الإشعارات"),
            item(AppDestination.Community, "الإعلانات ومنتدى الحلقة"),
            item(AppDestination.Halaqas, "الحلقات والفئات"),
            item(AppDestination.Sessions, "الجلسات اليومية"),
            item(AppDestination.Students, "الطلاب"),
            item(AppDestination.Plans, "الخطط الذكية"),
            item(AppDestination.Certificates, "الشهادات"),
            item(AppDestination.Reports, "التقارير"),
            item(AppDestination.Quran, "حاسبة القرآن"),
            item(AppDestination.Rankings, "الترتيب والإحصائيات"),
            item(AppDestination.ImportExport, "الاستيراد والتصدير"),
            item(AppDestination.Supervision, "متابعة المحفّظ"),
            item(AppDestination.Settings, "الإعدادات"),
        )
        UserRole.TEACHER -> listOf(
            item(AppDestination.Home, "الرئيسية"),
            item(AppDestination.Notifications, "الإشعارات"),
            item(AppDestination.Community, "الإعلانات ومنتدى الحلقة"),
            item(AppDestination.Halaqas, "حلقتي والفئات"),
            item(AppDestination.Sessions, "الجلسات اليومية"),
            item(AppDestination.Students, "طلابي"),
            item(AppDestination.Plans, "الخطط الذكية"),
            item(AppDestination.Certificates, "الشهادات"),
            item(AppDestination.Reports, "التقارير"),
            item(AppDestination.Quran, "حاسبة القرآن"),
            item(AppDestination.Rankings, "الترتيب والإحصائيات"),
            item(AppDestination.ImportExport, "تصدير البيانات"),
            item(AppDestination.Settings, "الإعدادات"),
        )
        UserRole.GUARDIAN -> listOf(
            item(AppDestination.Home, "الرئيسية"),
            item(AppDestination.Notifications, "الإشعارات"),
            item(AppDestination.Community, "الإعلانات ومنتدى الحلقة"),
            item(AppDestination.Plans, "خطط أبنائي الذكية"),
            item(AppDestination.Reports, "تقارير أبنائي"),
            item(AppDestination.GuardianCompetition, "إحصائيات ومنافسة"),
            item(AppDestination.GuardianAchievements, "الإنجازات"),
            item(AppDestination.GuardianProfile, "ملف الطالب"),
            item(AppDestination.Settings, "الإعدادات"),
        )
        else -> listOf(
            item(AppDestination.Home, "الرئيسية"),
            item(AppDestination.GuardianProfile, "ملف الطالب"),
            item(AppDestination.Settings, "الإعدادات"),
        )
    }

    fun moreSections(role: UserRole): List<MoreSection> {
        val allowed = destinations(role).toSet()
        fun sec(title: String, vararg c: AppDestination): MoreSection? {
            val v = c.filter { it in allowed && it !in bottom(role) }
            return v.takeIf { it.isNotEmpty() }?.let { MoreSection(title, it) }
        }
        return listOfNotNull(
            sec("إدارة الحلقة", AppDestination.Halaqas),
            sec("المتابعة والإنجاز", AppDestination.GuardianCompetition, AppDestination.GuardianAchievements, AppDestination.Rankings, AppDestination.Supervision, AppDestination.Certificates),
            sec("التقارير والأدوات", AppDestination.Reports, AppDestination.Quran, AppDestination.ImportExport),
            sec("التواصل", AppDestination.Notifications, AppDestination.Community),
            sec("الإدارة والصلاحيات", AppDestination.Users),
            sec("النظام", AppDestination.SyncCenter, AppDestination.Settings),
        )
    }

    fun canOpen(role: UserRole, destination: AppDestination) = destination in destinations(role)

    private fun item(destination: AppDestination, label: String) = DrawerNavItem(destination, label)
}
