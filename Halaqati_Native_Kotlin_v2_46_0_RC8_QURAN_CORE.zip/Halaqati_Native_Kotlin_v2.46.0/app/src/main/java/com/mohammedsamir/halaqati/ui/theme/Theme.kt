package com.mohammedsamir.halaqati.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.mohammedsamir.halaqati.data.ThemeMode
import com.mohammedsamir.halaqati.data.UiDensity
import com.mohammedsamir.halaqati.data.UiPreferences

object HalaqatiUiTokens {
    val TouchTarget = 48.dp
    val RadiusSmall = 12.dp
    val RadiusMedium = 16.dp
    val RadiusLarge = 22.dp
    val SpaceXs = 4.dp
    val SpaceSm = 8.dp
    val SpaceMd = 12.dp
    val SpaceLg = 16.dp
    val SpaceXl = 24.dp
}

data class HalaqatiSpacing(val xs: Dp, val sm: Dp, val md: Dp, val lg: Dp, val xl: Dp)
val LocalHalaqatiSpacing = staticCompositionLocalOf { HalaqatiSpacing(4.dp, 8.dp, 12.dp, 16.dp, 24.dp) }

private fun spacing(density: UiDensity) = when (density) {
    UiDensity.COMFORTABLE -> HalaqatiSpacing(6.dp, 10.dp, 14.dp, 18.dp, 28.dp)
    UiDensity.BALANCED -> HalaqatiSpacing(4.dp, 8.dp, 12.dp, 16.dp, 24.dp)
    UiDensity.COMPACT -> HalaqatiSpacing(3.dp, 6.dp, 9.dp, 12.dp, 18.dp)
}

private val HalaqatiLight = lightColorScheme(
    primary = Color(0xFF0D3B2F), onPrimary = Color.White,
    primaryContainer = Color(0xFFE1EEE8), onPrimaryContainer = Color(0xFF0D3B2F),
    secondary = Color(0xFF2F8B69), onSecondary = Color.White,
    secondaryContainer = Color(0xFFEAF3EE), onSecondaryContainer = Color(0xFF16634F),
    tertiary = Color(0xFFC89D4A), onTertiary = Color(0xFF1B1B1B),
    tertiaryContainer = Color(0xFFF4E7C6), onTertiaryContainer = Color(0xFF493715),
    background = Color(0xFFF7F8F4), onBackground = Color(0xFF18231F),
    surface = Color(0xFFFFFFFF), onSurface = Color(0xFF18231F),
    surfaceVariant = Color(0xFFEEF2EF), onSurfaceVariant = Color(0xFF52645D),
    outline = Color(0xFFCDD8D2), error = Color(0xFFD84B4B),
)
private val HalaqatiDark = darkColorScheme(
    primary = Color(0xFF63B190), onPrimary = Color(0xFF071F17),
    primaryContainer = Color(0xFF1D3028), onPrimaryContainer = Color(0xFFEDF5F1),
    secondary = Color(0xFF78C1A3), onSecondary = Color(0xFF071F17),
    secondaryContainer = Color(0xFF14221C), onSecondaryContainer = Color(0xFFEDF5F1),
    tertiary = Color(0xFFD8BA73), onTertiary = Color(0xFF3D2F10),
    tertiaryContainer = Color(0xFF5A4720), onTertiaryContainer = Color(0xFFF4E7C6),
    background = Color(0xFF101714), onBackground = Color(0xFFEDF5F1),
    surface = Color(0xFF17211D), onSurface = Color(0xFFEDF5F1),
    surfaceVariant = Color(0xFF1D3028), onSurfaceVariant = Color(0xFFA2B1AA),
    outline = Color(0xFF2D3934), error = Color(0xFFFFB4AB),
)
private val HalaqatiShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp), small = RoundedCornerShape(HalaqatiUiTokens.RadiusSmall),
    medium = RoundedCornerShape(HalaqatiUiTokens.RadiusMedium), large = RoundedCornerShape(HalaqatiUiTokens.RadiusLarge),
    extraLarge = RoundedCornerShape(24.dp),
)
private fun readableOn(color: Color) = if (color.luminance() > .45f) Color(0xFF10201F) else Color.White

@Composable
fun HalaqatiTheme(preferences: UiPreferences = UiPreferences.defaults(), content: @Composable () -> Unit) {
    val dark = when (preferences.themeMode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.DARK -> true
        ThemeMode.LIGHT -> false
    }
    val primary = Color(preferences.primaryArgb)
    val accent = Color(preferences.accentArgb)
    val base = if (dark) HalaqatiDark else HalaqatiLight
    val scheme = base.copy(primary = primary, onPrimary = readableOn(primary), secondary = accent, onSecondary = readableOn(accent))
    CompositionLocalProvider(
        LocalLayoutDirection provides LayoutDirection.Rtl,
        LocalHalaqatiSpacing provides spacing(preferences.density),
    ) {
        MaterialTheme(colorScheme = scheme, typography = cairoTypography(), shapes = HalaqatiShapes, content = content)
    }
}
