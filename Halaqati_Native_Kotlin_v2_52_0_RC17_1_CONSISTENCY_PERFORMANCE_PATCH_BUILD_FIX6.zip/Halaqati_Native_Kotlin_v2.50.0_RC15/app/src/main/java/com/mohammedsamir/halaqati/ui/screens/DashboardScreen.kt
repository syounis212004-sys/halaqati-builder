@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.mohammedsamir.halaqati.ui.screens

import androidx.lifecycle.compose.collectAsStateWithLifecycle

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.PersonSearch
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.mohammedsamir.halaqati.model.Profile
import com.mohammedsamir.halaqati.model.SyncState
import com.mohammedsamir.halaqati.ui.components.AppTopBar
import com.mohammedsamir.halaqati.ui.components.EmptyState
import com.mohammedsamir.halaqati.ui.components.LoadingSkeleton
import com.mohammedsamir.halaqati.ui.components.GoldenFeatureHero
import com.mohammedsamir.halaqati.ui.components.MetricCard
import com.mohammedsamir.halaqati.ui.components.StateNotice
import com.mohammedsamir.halaqati.ui.dashboard.DashboardRules
import com.mohammedsamir.halaqati.ui.dashboard.DailyOperationStateEngine
import com.mohammedsamir.halaqati.ui.dashboard.DashboardViewModel
import com.mohammedsamir.halaqati.ui.dashboard.FollowUpRules
import com.mohammedsamir.halaqati.ui.theme.HalaqatiUiTokens

@Composable
fun DashboardScreen(
    p: Profile,
    sync: SyncState,
    navigate: (String) -> Unit,
    onSync: () -> Unit,
    vm: DashboardViewModel = viewModel(),
) {
    val state by vm.state.collectAsStateWithLifecycle()
    val uiPrefs by com.mohammedsamir.halaqati.data.AppGraph.uiPreferences.state.collectAsStateWithLifecycle()
    val compactHome = uiPrefs.homeStyle == com.mohammedsamir.halaqati.data.HomeStyle.COMPACT
    LaunchedEffect(p.id, sync) { vm.bind(p, sync) }

    var selectedDailyBucket by remember { mutableStateOf<DailyBoardBucket?>(null) }
    val dailyBuckets = remember(state.notHeard, state.absentLate) { listOf(
        DailyBoardBucket("لم يسمّع اليوم", state.notHeard, "danger"),
        DailyBoardBucket("غائب اليوم", state.absentLate, "warning"),
    ) }
    val planBuckets = remember(state.attention, state.attendance, state.overTarget) { listOf(
        DailyBoardBucket("متأخر عن الخطة", state.attention, "warning"),
        DailyBoardBucket("يحتاج مراجعة", state.attendance, "info"),
        DailyBoardBucket("تجاوز هدفه", state.overTarget, "success"),
    ) }
    val followUpGroups = remember(state.attention, state.attendance, state.absentLate, state.notHeard) {
        FollowUpRules.group(
            delayed = state.attention,
            quality = state.attendance,
            absence = state.absentLate,
            notHeard = state.notHeard,
        )
    }
    val allFollowUp = remember(followUpGroups) { followUpGroups.flatMap { it.items }.distinctBy { it.studentId } }
    val isOffDay = state.dailyOperation.mode == DailyOperationStateEngine.Mode.OFF_DAY
    val waitingForSession = state.dailyOperation.mode == DailyOperationStateEngine.Mode.NO_SESSION_YET

    val expectedToday = state.dailyOperation.expectedStudentIds.size
    val todayPresent = if (state.dailyOperation.countDailyMetrics) (expectedToday - state.absentLate.size).coerceAtLeast(0) else 0
    val waitingCount = if (state.dailyOperation.countDailyMetrics) (todayPresent - state.progress.heardStudents).coerceAtLeast(0) else 0
    val firstName = p.fullName.trim().substringBefore(' ').ifBlank { "بك" }

    Column(Modifier.fillMaxSize()) {
        AppTopBar(
            title = "أهلًا، $firstName",
            onRefresh = { vm.refresh(force = true) },
            pending = sync.pending,
            kicker = if (state.today.isBlank()) "لوحة اليوم · متابعة الحلقة" else "لوحة اليوم · ${state.today} · متابعة الحلقة",
        )
        LazyColumn(
            Modifier.weight(1f).fillMaxWidth(),
            contentPadding = PaddingValues(
                start = HalaqatiUiTokens.ScreenHorizontal,
                end = HalaqatiUiTokens.ScreenHorizontal,
                top = 4.dp,
                bottom = HalaqatiUiTokens.SpaceXl,
            ),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            item {
                GoldenFeatureHero(
                    title = "كل يوم، أثرٌ يبقى",
                    subtitle = when {
                        !state.loaded -> "نجهّز صورة اليوم من آخر بيانات متاحة."
                        isOffDay -> "اليوم إجازة، والبيانات السابقة متاحة للمتابعة."
                        waitingForSession -> "متابعة واضحة، ووقت أكثر لطلابك."
                        else -> state.dailyOperation.subtitle
                    },
                    badge = if (sync.online) null else "دون اتصال",
                )
            }
            item {
                Button(
                    onClick = { navigate("session_today") },
                    enabled = state.loaded && !isOffDay,
                    modifier = Modifier.fillMaxWidth().heightIn(min = HalaqatiUiTokens.ActionHeight),
                    shape = RoundedCornerShape(16.dp),
                ) {
                    Icon(Icons.Default.PlayArrow, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text(
                        when {
                            isOffDay -> "اليوم إجازة"
                            waitingForSession -> "ابدأ جلسة اليوم"
                            else -> "فتح جلسة اليوم"
                        },
                        fontWeight = FontWeight.Bold,
                    )
                }
            }
            item {
                FilledTonalButton(
                    onClick = { navigate("quick_memorization") },
                    modifier = Modifier.fillMaxWidth().heightIn(min = HalaqatiUiTokens.TouchTarget),
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.filledTonalButtonColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                ) {
                    Text("التحفيظ السريع", fontWeight = FontWeight.SemiBold)
                }
            }

            if (!sync.online) {
                item {
                    StateNotice(
                        "البيانات المحفوظة متاحة الآن. أي تسجيل جديد يُحفظ محليًا ويُزامن عند عودة الاتصال.",
                        kind = "warning",
                    )
                }
            } else if (sync.blocked > 0) {
                item { StateNotice("هناك ${sync.blocked} عمليات مزامنة تحتاج مراجعة.", "error") }
            }

            state.errors.values.firstOrNull()?.let { message ->
                item { StateNotice("بقيت البيانات السابقة ظاهرة. $message", kind = "warning") }
            }

            if (!state.loaded) {
                item { LoadingSkeleton(rows = 2) }
            } else {
                item {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Box(Modifier.weight(1f)) { MetricCard("حاضر اليوم", todayPresent.toString(), onClick = { navigate("session_today") }) }
                        Box(Modifier.weight(1f)) { MetricCard("أتمّ التسميع", state.progress.heardStudents.toString(), onClick = { navigate("reports") }) }
                        Box(Modifier.weight(1f)) { MetricCard("بانتظارك", waitingCount.toString(), onClick = { navigate("follow_up") }) }
                    }
                }
            }

        item {
            Text("المتابعة اليومية", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        }
        item {
            if (!state.loaded) {
                LoadingSkeleton(rows = 1)
            } else if (isOffDay || waitingForSession) {
                DailyOperationBanner(
                    title = state.dailyOperation.title,
                    subtitle = state.dailyOperation.subtitle,
                    offDay = isOffDay,
                )
            } else {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    dailyBuckets.forEach { bucket ->
                        DailyStatusCard(
                            bucket = bucket,
                            modifier = Modifier.weight(1f),
                            onOpen = { selectedDailyBucket = bucket },
                        )
                    }
                }
            }
        }
        item {
            Text("متابعة الخطة", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                planBuckets.chunked(2).forEach { pair ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        pair.forEach { bucket ->
                            DailyStatusCard(
                                bucket = bucket,
                                modifier = Modifier.weight(1f),
                                onOpen = { selectedDailyBucket = bucket },
                            )
                        }
                        if (pair.size == 1) Spacer(Modifier.weight(1f))
                    }
                }
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("طلاب يحتاجون متابعة", style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f), fontWeight = FontWeight.Bold)
                if (allFollowUp.isNotEmpty()) {
                    TextButton(onClick = { navigate("follow_up") }) { Text("فتح المتابعة") }
                }
            }
        }
        followUpGroups.forEach { group ->
            val title = group.title
            val itemsInGroup = group.items
            item { Text(title, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold) }
            items(itemsInGroup.take(if (compactHome) 2 else 4), key = { "follow:$title:${it.studentId}" }) { followItem ->
                ElevatedCard(onClick = { navigate("student:${followItem.studentId}") }, modifier = Modifier.fillMaxWidth()) {
                    Row(
                        Modifier.fillMaxWidth().padding(horizontal = 13.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(9.dp),
                    ) {
                        Icon(Icons.Default.PersonSearch, contentDescription = null, modifier = Modifier.size(19.dp), tint = MaterialTheme.colorScheme.primary)
                        Column(Modifier.weight(1f)) {
                            Text(followItem.studentName, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold, maxLines = 2)
                            Text(followItem.reason, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Icon(Icons.Default.ChevronLeft, contentDescription = "فتح الطالب", modifier = Modifier.size(20.dp))
                    }
                }
            }
        }
        if (allFollowUp.isEmpty() && state.loaded) {
            item { EmptyState("لا توجد تنبيهات متابعة حاليًا") }
        }

        item {
            OutlinedButton(
                onClick = { navigate("rankings") },
                modifier = Modifier.fillMaxWidth().heightIn(min = HalaqatiUiTokens.TouchTarget),
            ) { Text("الإحصائيات والترتيب") }
        }
        if (sync.pending > 0) {
            item {
                OutlinedButton(
                    onClick = onSync,
                    modifier = Modifier.fillMaxWidth().heightIn(min = HalaqatiUiTokens.TouchTarget),
                ) { Text("مزامنة ${sync.pending} عملية معلقة") }
            }
        }
        item { Spacer(Modifier.height(8.dp)) }
    }

        selectedDailyBucket?.let { bucket ->
            ModalBottomSheet(onDismissRequest = { selectedDailyBucket = null }) {
                Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp)) {
                    Text(bucket.title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    if (bucket.items.isEmpty()) {
                        EmptyState("لا توجد عناصر في هذه القائمة")
                    } else {
                        LazyColumn(
                            modifier = Modifier.fillMaxWidth().heightIn(max = 520.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp),
                        ) {
                            items(bucket.items, key = { "daily:${bucket.title}:${it.studentId}" }) { item ->
                                ListItem(
                                    headlineContent = { Text(item.studentName, fontWeight = FontWeight.SemiBold) },
                                    supportingContent = { Text(item.reason) },
                                    trailingContent = { Icon(Icons.Default.ChevronLeft, contentDescription = "فتح الطالب") },
                                    modifier = Modifier.clickable {
                                        selectedDailyBucket = null
                                        navigate("student:${item.studentId}")
                                    },
                                )
                            }
                        }
                    }
                    Spacer(Modifier.height(24.dp))
                }
            }
        }
    }
}


@Composable
private fun DailyOperationBanner(
    title: String,
    subtitle: String,
    offDay: Boolean,
) {
    ElevatedCard(Modifier.fillMaxWidth()) {
        Column(
            Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 18.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text(
                subtitle,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            if (offDay) {
                Text(
                    "لم يسمّع اليوم: 0 · غائب اليوم: 0",
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.SemiBold,
                )
            } else {
                Text(
                    "لن يُحسب أي طالب كـ«لم يسمّع» أو «غائب» قبل بدء الجلسة.",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.primary,
                )
            }
        }
    }
}


private data class DailyBoardBucket(
    val title: String,
    val items: List<com.mohammedsamir.halaqati.ui.dashboard.DashboardAttentionItem>,
    val kind: String,
)

@Composable
private fun DailyStatusCard(
    bucket: DailyBoardBucket,
    modifier: Modifier = Modifier,
    onOpen: () -> Unit,
) {
    ElevatedCard(modifier = modifier.heightIn(min = 188.dp)) {
        Column(
            Modifier.fillMaxSize().padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Text(bucket.items.size.toString(), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            Text(bucket.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            bucket.items.take(2).forEach { item ->
                Text(
                    item.studentName,
                    style = MaterialTheme.typography.bodySmall,
                    maxLines = 1,
                )
            }
            if (bucket.items.isEmpty()) {
                Text("لا يوجد", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Spacer(Modifier.weight(1f))
            TextButton(onClick = onOpen, modifier = Modifier.fillMaxWidth()) {
                Text("عرض القائمة كاملة (${bucket.items.size})", fontWeight = FontWeight.Bold)
            }
        }
    }
}
