package com.mohammedsamir.halaqati.ui.update

import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.Settings
import com.mohammedsamir.halaqati.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object NativeAppUpdater {
    const val UPDATE_MANIFEST_URL = "https://syounis212004-sys.github.io/halaqati-web/version.json"

    data class UpdateInfo(val versionCode: Int, val versionName: String, val apkUrl: String, val notes: List<String>) {
        val available: Boolean get() = versionCode > BuildConfig.VERSION_CODE
    }

    data class DownloadState(
        val status: Int,
        val progress: Int,
        val downloadedBytes: Long,
        val totalBytes: Long,
        val localUri: String? = null,
        val reason: Int = 0,
    ) {
        val running: Boolean get() = status == DownloadManager.STATUS_RUNNING || status == DownloadManager.STATUS_PENDING || status == DownloadManager.STATUS_PAUSED
        val complete: Boolean get() = status == DownloadManager.STATUS_SUCCESSFUL
        val failed: Boolean get() = status == DownloadManager.STATUS_FAILED
    }

    suspend fun check(): UpdateInfo = withContext(Dispatchers.IO) {
        val conn = URL("$UPDATE_MANIFEST_URL?t=${System.currentTimeMillis()}").openConnection() as HttpURLConnection
        conn.connectTimeout = 12_000
        conn.readTimeout = 12_000
        conn.setRequestProperty("Cache-Control", "no-cache")
        try {
            if (conn.responseCode !in 200..299) error("تعذر الوصول إلى ملف التحديث (${conn.responseCode})")
            val json = JSONObject(conn.inputStream.bufferedReader().use { it.readText() })
            val code = json.optInt("versionCode", 0)
            val url = json.optString("apkUrl")
            require(code > 0 && url.startsWith("http")) { "ملف التحديث غير مكتمل" }
            val rawNotes = json.opt("notes")
            val notes = when (rawNotes) {
                is org.json.JSONArray -> (0 until rawNotes.length()).mapNotNull { rawNotes.optString(it).takeIf(String::isNotBlank) }
                is String -> rawNotes.lines().map(String::trim).filter(String::isNotBlank)
                else -> emptyList()
            }
            UpdateInfo(code, json.optString("versionName", code.toString()), url, notes)
        } finally { conn.disconnect() }
    }

    fun downloadAndInstall(context: Context, info: UpdateInfo): Long {
        val request = DownloadManager.Request(Uri.parse(info.apkUrl))
            .setTitle("تحديث حلقتي ${info.versionName}")
            .setDescription("تنزيل إصدار حلقتي الجديد")
            .setMimeType("application/vnd.android.package-archive")
            .setAllowedOverMetered(true)
            .setAllowedOverRoaming(false)
            .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "Halaqati-${info.versionName}.apk")
        return context.getSystemService(DownloadManager::class.java).enqueue(request)
    }

    fun queryDownload(context: Context, downloadId: Long): DownloadState {
        val manager = context.getSystemService(DownloadManager::class.java)
        manager.query(DownloadManager.Query().setFilterById(downloadId)).use { cursor ->
            if (!cursor.moveToFirst()) return DownloadState(DownloadManager.STATUS_FAILED, 0, 0, 0, reason = -1)
            val status = cursor.getInt(cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS))
            val downloaded = cursor.getLong(cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR)).coerceAtLeast(0)
            val total = cursor.getLong(cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES)).coerceAtLeast(0)
            val reason = cursor.getInt(cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_REASON))
            val uri = cursor.getString(cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_LOCAL_URI))
            val progress = if (total > 0) ((downloaded * 100L) / total).toInt().coerceIn(0, 100) else if (status == DownloadManager.STATUS_SUCCESSFUL) 100 else 0
            return DownloadState(status, progress, downloaded, total, uri, reason)
        }
    }

    fun canRequestPackageInstalls(context: Context): Boolean =
        Build.VERSION.SDK_INT < Build.VERSION_CODES.O || context.packageManager.canRequestPackageInstalls()

    fun openInstallPermission(context: Context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        context.startActivity(
            Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:${context.packageName}"))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
        )
    }

    fun installDownloaded(context: Context, downloadId: Long) {
        if (!canRequestPackageInstalls(context)) {
            openInstallPermission(context)
            return
        }
        val manager = context.getSystemService(DownloadManager::class.java)
        val uri = manager.getUriForDownloadedFile(downloadId) ?: error("ملف التحديث غير متاح للتثبيت")
        context.startActivity(
            Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, "application/vnd.android.package-archive")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
            },
        )
    }

    fun openDownloads(context: Context) {
        context.startActivity(Intent(DownloadManager.ACTION_VIEW_DOWNLOADS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
}
