package com.mohammedsamir.halaqati.ui.theme

import androidx.compose.material3.Typography
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import com.mohammedsamir.halaqati.R

/** Cairo is the single application typeface. The variable font is embedded by CI before resource processing. */
val CairoFamily = FontFamily(
    Font(R.font.cairo, FontWeight.Light),
    Font(R.font.cairo, FontWeight.Normal),
    Font(R.font.cairo, FontWeight.Medium),
    Font(R.font.cairo, FontWeight.SemiBold),
    Font(R.font.cairo, FontWeight.Bold),
)

/** RC17.1 hierarchy: names/titles are strong, supporting copy is intentionally lighter. */
fun cairoTypography() = Typography(
    displayLarge = TextStyle(fontFamily = CairoFamily, fontWeight = FontWeight.Bold, fontSize = 44.sp, lineHeight = 58.sp),
    displayMedium = TextStyle(fontFamily = CairoFamily, fontWeight = FontWeight.Bold, fontSize = 38.sp, lineHeight = 50.sp),
    displaySmall = TextStyle(fontFamily = CairoFamily, fontWeight = FontWeight.Bold, fontSize = 32.sp, lineHeight = 44.sp),
    headlineLarge = TextStyle(fontFamily = CairoFamily, fontWeight = FontWeight.Bold, fontSize = 28.sp, lineHeight = 40.sp),
    headlineMedium = TextStyle(fontFamily = CairoFamily, fontWeight = FontWeight.SemiBold, fontSize = 25.sp, lineHeight = 36.sp),
    headlineSmall = TextStyle(fontFamily = CairoFamily, fontWeight = FontWeight.SemiBold, fontSize = 22.sp, lineHeight = 32.sp),
    titleLarge = TextStyle(fontFamily = CairoFamily, fontWeight = FontWeight.Bold, fontSize = 20.sp, lineHeight = 30.sp),
    titleMedium = TextStyle(fontFamily = CairoFamily, fontWeight = FontWeight.SemiBold, fontSize = 17.sp, lineHeight = 27.sp),
    titleSmall = TextStyle(fontFamily = CairoFamily, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, lineHeight = 23.sp),
    bodyLarge = TextStyle(fontFamily = CairoFamily, fontWeight = FontWeight.Medium, fontSize = 16.sp, lineHeight = 27.sp),
    bodyMedium = TextStyle(fontFamily = CairoFamily, fontWeight = FontWeight.Medium, fontSize = 14.sp, lineHeight = 24.sp),
    bodySmall = TextStyle(fontFamily = CairoFamily, fontWeight = FontWeight.Light, fontSize = 12.sp, lineHeight = 20.sp),
    labelLarge = TextStyle(fontFamily = CairoFamily, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, lineHeight = 22.sp),
    labelMedium = TextStyle(fontFamily = CairoFamily, fontWeight = FontWeight.Medium, fontSize = 12.sp, lineHeight = 20.sp),
    labelSmall = TextStyle(fontFamily = CairoFamily, fontWeight = FontWeight.Normal, fontSize = 12.sp, lineHeight = 18.sp),
)
