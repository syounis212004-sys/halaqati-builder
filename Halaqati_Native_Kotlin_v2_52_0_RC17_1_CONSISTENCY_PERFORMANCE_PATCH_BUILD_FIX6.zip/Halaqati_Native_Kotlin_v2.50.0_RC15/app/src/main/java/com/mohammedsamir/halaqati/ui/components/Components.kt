@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.mohammedsamir.halaqati.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.mohammedsamir.halaqati.ui.theme.HalaqatiUiTokens

/**
 * Shared chrome for the RC17 redesign. Existing screen contracts remain unchanged;
 * the optional kicker lets role-specific screens reproduce the supplied prototype.
 */
@Composable
fun AppTopBar(
    title: String,
    onBack: (() -> Unit)? = null,
    onRefresh: (() -> Unit)? = null,
    pending: Int = 0,
    kicker: String? = null,
) {
    val shell = LocalGoldenShellActions.current
    Surface(
        color = MaterialTheme.colorScheme.background,
        shadowElevation = 0.dp,
        modifier = Modifier.fillMaxWidth(),
    ) {
        // RC17.1 RTL contract: the textual hierarchy owns START (right in Arabic), while
        // navigation/utility actions live at END (left). Never hard-code left/right here.
        Row(
            Modifier
                .fillMaxWidth()
                .heightIn(min = 82.dp)
                .padding(horizontal = HalaqatiUiTokens.ScreenHorizontal, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Column(
                Modifier.weight(1f),
                horizontalAlignment = Alignment.Start,
            ) {
                Text(
                    kicker ?: shell?.let { "${it.roleLabel} · ${if (it.online) "متصل" else "دون اتصال"}" }.orEmpty(),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Spacer(Modifier.height(2.dp))
                Text(
                    title,
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }

            if (onRefresh != null) {
                IconButton(
                    onClick = onRefresh,
                    modifier = Modifier
                        .size(48.dp)
                        .background(MaterialTheme.colorScheme.surface, RoundedCornerShape(16.dp)),
                ) {
                    Icon(Icons.Default.Refresh, contentDescription = "تحديث", tint = MaterialTheme.colorScheme.primary)
                }
            }
            shell?.let { chrome ->
                IconButton(
                    onClick = chrome.openNotifications,
                    modifier = Modifier
                        .size(48.dp)
                        .background(MaterialTheme.colorScheme.surface, RoundedCornerShape(16.dp)),
                ) {
                    BadgedBox(
                        badge = {
                            if (pending > 0 || chrome.pending > 0) {
                                Badge(containerColor = MaterialTheme.colorScheme.tertiary) {
                                    Text((maxOf(pending, chrome.pending)).coerceAtMost(99).toString())
                                }
                            }
                        },
                    ) {
                        GoldenNavIcon(
                            key = "notifications",
                            contentDescription = "الإشعارات",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(24.dp),
                        )
                    }
                }
                if (!chrome.online || chrome.pending > 0) Surface(
                    onClick = chrome.openSyncCenter,
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    contentColor = MaterialTheme.colorScheme.primary,
                ) {
                    Text(
                        if (chrome.pending > 0) "${chrome.pending}" else "!",
                        modifier = Modifier.padding(horizontal = 9.dp, vertical = 8.dp),
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                    )
                }
            }

            IconButton(
                onClick = onBack ?: shell?.openDrawer ?: {},
                enabled = onBack != null || shell != null,
                modifier = Modifier
                    .size(48.dp)
                    .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(16.dp))
                    .background(MaterialTheme.colorScheme.surface, RoundedCornerShape(16.dp)),
            ) {
                Icon(
                    if (onBack != null) Icons.AutoMirrored.Filled.ArrowBack else Icons.Default.Menu,
                    contentDescription = if (onBack != null) "رجوع" else "القائمة",
                    tint = MaterialTheme.colorScheme.onSurface,
                )
            }
        }
    }
}

@Composable
fun GoldenFeatureHero(
    title: String,
    subtitle: String,
    badge: String? = null,
    modifier: Modifier = Modifier,
    actions: @Composable RowScope.() -> Unit = {},
) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(HalaqatiUiTokens.RadiusHero),
        color = MaterialTheme.colorScheme.primary,
        contentColor = MaterialTheme.colorScheme.onPrimary,
    ) {
        Box(Modifier.fillMaxWidth()) {
            // Quiet ring motif from the design package, intentionally decorative only.
            Box(
                Modifier
                    .align(Alignment.TopStart)
                    .offset(x = (-42).dp, y = (-56).dp)
                    .size(164.dp)
                    .border(1.dp, MaterialTheme.colorScheme.onPrimary.copy(alpha = .08f), CircleShape),
            )
            Column(
                Modifier.fillMaxWidth().padding(horizontal = 22.dp, vertical = 20.dp),
                verticalArrangement = Arrangement.spacedBy(9.dp),
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f), horizontalAlignment = Alignment.Start) {
                        Text(
                            title,
                            color = MaterialTheme.colorScheme.onPrimary,
                            style = MaterialTheme.typography.headlineMedium,
                            fontWeight = FontWeight.Bold,
                        )
                        Text(
                            subtitle,
                            color = MaterialTheme.colorScheme.onPrimary.copy(alpha = .82f),
                            style = MaterialTheme.typography.bodyMedium,
                        )
                    }
                    badge?.takeIf { it.isNotBlank() }?.let {
                        Spacer(Modifier.width(10.dp))
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = MaterialTheme.colorScheme.onPrimary.copy(alpha = .10f),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.onPrimary.copy(alpha = .14f)),
                        ) {
                            Text(
                                it,
                                color = MaterialTheme.colorScheme.onPrimary,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp),
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                            )
                        }
                    }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp), content = actions)
            }
        }
    }
}

@Composable
fun MetricCard(
    title: String,
    value: String,
    subtitle: String = "",
    onClick: (() -> Unit)? = null,
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .then(if (onClick != null) Modifier.clickable { onClick() } else Modifier),
        shape = RoundedCornerShape(HalaqatiUiTokens.RadiusMetric),
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 0.dp,
    ) {
        Column(
            Modifier.padding(horizontal = 12.dp, vertical = 14.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(2.dp),
        ) {
            Text(value, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, maxLines = 1)
            Text(
                title,
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            if (subtitle.isNotBlank()) {
                Text(
                    subtitle,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                )
            }
        }
    }
}

@Composable
fun SyncBanner(
    online: Boolean,
    pending: Int,
    blocked: Int = 0,
    error: String? = null,
    onSync: () -> Unit,
    onDetails: (() -> Unit)? = null,
) {
    AnimatedVisibility(
        visible = !online || pending > 0 || blocked > 0 || error != null,
        enter = fadeIn() + expandVertically(),
        exit = fadeOut() + shrinkVertically(),
    ) {
        Box(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp)) {
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = when {
                    error != null -> MaterialTheme.colorScheme.errorContainer
                    !online -> MaterialTheme.colorScheme.tertiaryContainer
                    else -> MaterialTheme.colorScheme.secondaryContainer
                },
            ) {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 9.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(
                        when {
                            error != null -> Icons.Default.ErrorOutline
                            online -> Icons.Default.Sync
                            else -> Icons.Default.CloudOff
                        },
                        contentDescription = null,
                        modifier = Modifier.size(20.dp),
                    )
                    Spacer(Modifier.width(8.dp))
                    Text(
                        when {
                            error != null && (error.contains("resolve host", true) || error.contains("hostname", true)) -> "وضع دون اتصال — تُعرض آخر بيانات محفوظة وستتم المزامنة تلقائيًا"
                            error != null -> error
                            blocked > 0 -> "هناك $blocked عمليات تحتاج مراجعة، و$pending بانتظار الرفع"
                            !online && pending > 0 -> "عدم اتصال — حُفظت $pending تغييرات محليًا وستُزامن تلقائيًا"
                            !online -> "عدم اتصال — سيُحفظ أي تغيير محليًا ثم يُزامن عند عودة الإنترنت"
                            else -> "لديك $pending تغييرات بانتظار المزامنة"
                        },
                        Modifier.weight(1f),
                        style = MaterialTheme.typography.bodySmall,
                    )
                    if (onDetails != null && blocked > 0) TextButton(onClick = onDetails) { Text("التفاصيل") }
                    if (online && pending > 0) TextButton(onClick = onSync) { Text("مزامنة") }
                }
            }
        }
    }
}

@Composable
fun EmptyState(
    text: String,
    actionLabel: String? = null,
    onAction: (() -> Unit)? = null,
    modifier: Modifier = Modifier,
) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(HalaqatiUiTokens.RadiusLarge),
        color = MaterialTheme.colorScheme.surface,
    ) {
        Column(
            Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 26.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Surface(shape = RoundedCornerShape(16.dp), color = MaterialTheme.colorScheme.surfaceVariant) {
                Icon(
                    Icons.Default.SearchOff,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(12.dp).size(28.dp),
                )
            }
            Text(text, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodyMedium)
            if (actionLabel != null && onAction != null) {
                OutlinedButton(onClick = onAction, modifier = Modifier.heightIn(min = HalaqatiUiTokens.TouchTarget)) { Text(actionLabel) }
            }
        }
    }
}

@Composable
fun ProFilterChip(
    selected: Boolean,
    onClick: () -> Unit,
    label: String,
    modifier: Modifier = Modifier,
    leadingIcon: (@Composable (() -> Unit))? = null,
    showCheckIcon: Boolean = true,
) {
    FilterChip(
        selected = selected,
        onClick = onClick,
        label = { Text(label, style = MaterialTheme.typography.labelLarge, maxLines = 1, overflow = TextOverflow.Ellipsis) },
        leadingIcon = leadingIcon ?: if (selected && showCheckIcon) {
            { Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(17.dp)) }
        } else null,
        modifier = modifier.heightIn(min = 44.dp),
        shape = RoundedCornerShape(12.dp),
        border = null,
        colors = FilterChipDefaults.filterChipColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant,
            labelColor = MaterialTheme.colorScheme.onSurfaceVariant,
            selectedContainerColor = MaterialTheme.colorScheme.surface,
            selectedLabelColor = MaterialTheme.colorScheme.primary,
            selectedLeadingIconColor = MaterialTheme.colorScheme.primary,
        ),
    )
}

@Composable
fun StatusPill(text: String, kind: String = "info", modifier: Modifier = Modifier) {
    val colors = when (kind) {
        "error" -> MaterialTheme.colorScheme.errorContainer to MaterialTheme.colorScheme.onErrorContainer
        "success" -> MaterialTheme.colorScheme.primaryContainer to MaterialTheme.colorScheme.onPrimaryContainer
        "warning" -> MaterialTheme.colorScheme.tertiaryContainer to MaterialTheme.colorScheme.onTertiaryContainer
        else -> MaterialTheme.colorScheme.secondaryContainer to MaterialTheme.colorScheme.onSecondaryContainer
    }
    Surface(modifier = modifier, color = colors.first, contentColor = colors.second, shape = RoundedCornerShape(10.dp)) {
        Text(text, modifier = Modifier.padding(horizontal = 9.dp, vertical = 5.dp), style = MaterialTheme.typography.labelMedium)
    }
}

@Composable
fun LoadingSkeleton(rows: Int = 3, modifier: Modifier = Modifier) {
    Column(modifier, verticalArrangement = Arrangement.spacedBy(10.dp)) {
        repeat(rows) { index ->
            Surface(
                Modifier.fillMaxWidth().heightIn(min = 104.dp),
                shape = RoundedCornerShape(HalaqatiUiTokens.RadiusLarge),
                color = MaterialTheme.colorScheme.surfaceVariant,
            ) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Box(Modifier.fillMaxWidth(if (index % 2 == 0) .58f else .72f).height(15.dp).background(MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(8.dp)))
                    Box(Modifier.fillMaxWidth(.9f).height(11.dp).background(MaterialTheme.colorScheme.outlineVariant.copy(alpha = .8f), RoundedCornerShape(8.dp)))
                    Box(Modifier.fillMaxWidth(.68f).height(11.dp).background(MaterialTheme.colorScheme.outlineVariant.copy(alpha = .65f), RoundedCornerShape(8.dp)))
                }
            }
        }
    }
}

@Composable
fun StateNotice(text: String, kind: String = "info", modifier: Modifier = Modifier) {
    val colors = when (kind) {
        "error" -> MaterialTheme.colorScheme.errorContainer to MaterialTheme.colorScheme.onErrorContainer
        "success" -> MaterialTheme.colorScheme.primaryContainer to MaterialTheme.colorScheme.onPrimaryContainer
        "warning" -> MaterialTheme.colorScheme.tertiaryContainer to MaterialTheme.colorScheme.onTertiaryContainer
        else -> MaterialTheme.colorScheme.secondaryContainer to MaterialTheme.colorScheme.onSecondaryContainer
    }
    Surface(modifier = modifier.fillMaxWidth(), color = colors.first, shape = RoundedCornerShape(14.dp)) {
        Text(text, Modifier.padding(horizontal = 14.dp, vertical = 11.dp), style = MaterialTheme.typography.bodyMedium, color = colors.second)
    }
}
