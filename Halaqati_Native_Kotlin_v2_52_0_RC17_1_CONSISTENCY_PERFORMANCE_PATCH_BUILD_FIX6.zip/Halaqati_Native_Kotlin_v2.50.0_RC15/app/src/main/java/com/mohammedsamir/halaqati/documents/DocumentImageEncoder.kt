package com.mohammedsamir.halaqati.documents

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.util.Base64
import java.io.ByteArrayOutputStream

/** Keeps document assets small before Chromium embeds them into PDF. */
object DocumentImageEncoder {
    fun resourceJpeg(context: Context, resId: Int, maxDimension: Int = 520, quality: Int = 84): String? {
        val bitmap = BitmapFactory.decodeResource(context.resources, resId) ?: return null
        return try { encode(bitmap, maxDimension, transparent = false, jpegQuality = quality) } finally { bitmap.recycle() }
    }

    fun dataUrl(value: String?, maxDimension: Int, transparent: Boolean): String? {
        if (value.isNullOrBlank() || !value.startsWith("data:image/")) return null
        val raw = runCatching { Base64.decode(value.substringAfter(','), Base64.DEFAULT) }.getOrNull() ?: return null
        val bitmap = BitmapFactory.decodeByteArray(raw, 0, raw.size) ?: return null
        return try { encode(bitmap, maxDimension, transparent = transparent, jpegQuality = 84) } finally { bitmap.recycle() }
    }

    private fun encode(source: Bitmap, maxDimension: Int, transparent: Boolean, jpegQuality: Int): String {
        val max = maxOf(source.width, source.height).coerceAtLeast(1)
        val scale = minOf(1f, maxDimension.toFloat() / max.toFloat())
        val targetW = (source.width * scale).toInt().coerceAtLeast(1)
        val targetH = (source.height * scale).toInt().coerceAtLeast(1)
        val scaled = if (targetW == source.width && targetH == source.height) source
        else Bitmap.createScaledBitmap(source, targetW, targetH, true)
        val flattened = if (transparent) scaled else Bitmap.createBitmap(targetW, targetH, Bitmap.Config.ARGB_8888).also { out ->
            Canvas(out).apply {
                drawColor(Color.WHITE)
                drawBitmap(scaled, 0f, 0f, null)
            }
        }
        return try {
            val bytes = ByteArrayOutputStream().use { out ->
                if (transparent) flattened.compress(Bitmap.CompressFormat.PNG, 100, out)
                else flattened.compress(Bitmap.CompressFormat.JPEG, jpegQuality.coerceIn(60, 95), out)
                out.toByteArray()
            }
            val mime = if (transparent) "image/png" else "image/jpeg"
            "data:$mime;base64," + Base64.encodeToString(bytes, Base64.NO_WRAP)
        } finally {
            if (flattened !== scaled) flattened.recycle()
            if (scaled !== source) scaled.recycle()
        }
    }
}
