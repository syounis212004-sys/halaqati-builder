package com.mohammedsamir.halaqati.data

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

enum class ThemeMode { SYSTEM, LIGHT, DARK }
enum class UiDensity { COMFORTABLE, BALANCED, COMPACT }
enum class HomeStyle { MODERN, COMPACT }
enum class MotionLevel { NORMAL, REDUCED }

data class UiPreferences(
    val themeMode: ThemeMode,
    val primaryArgb: Int,
    val accentArgb: Int,
    val density: UiDensity,
    val homeStyle: HomeStyle = HomeStyle.MODERN,
    val motion: MotionLevel = MotionLevel.NORMAL,
) {
    companion object {
        fun defaults() = UiPreferences(
            themeMode = ThemeMode.SYSTEM,
            primaryArgb = 0xFF155643.toInt(),
            accentArgb = 0xFF2F8B69.toInt(),
            density = UiDensity.BALANCED,
        )
    }
}

class UiPreferencesStore(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences("halaqati_ui_v1", Context.MODE_PRIVATE)
    private val _state = MutableStateFlow(read())
    val state: StateFlow<UiPreferences> = _state.asStateFlow()

    fun update(transform: (UiPreferences) -> UiPreferences) {
        val next = transform(_state.value)
        prefs.edit()
            .putString("theme_mode", next.themeMode.name)
            .putInt("primary_argb", next.primaryArgb)
            .putInt("accent_argb", next.accentArgb)
            .putString("density", next.density.name)
            .putString("home_style", next.homeStyle.name)
            .putString("motion", next.motion.name)
            .apply()
        _state.value = next
    }

    fun reset() = update { UiPreferences.defaults() }

    private fun read(): UiPreferences {
        val d = UiPreferences.defaults()
        val storedPrimary = prefs.getInt("primary_argb", d.primaryArgb)
        val storedAccent = prefs.getInt("accent_argb", d.accentArgb)
        // T6 used a temporary teal default. Migrate only that exact pair so genuine
        // user-selected custom colors are preserved while existing installs regain 2.44's palette.
        val legacyDefaults =
            (storedPrimary == 0xFF147A78.toInt() && storedAccent == 0xFF0B4F4B.toInt()) ||
            (storedPrimary == 0xFF0D3B2F.toInt() && storedAccent == 0xFF2F8B69.toInt())
        return UiPreferences(
            themeMode = enumValueOrDefault(prefs.getString("theme_mode", null), d.themeMode),
            primaryArgb = if (legacyDefaults) d.primaryArgb else storedPrimary,
            accentArgb = if (legacyDefaults) d.accentArgb else storedAccent,
            density = enumValueOrDefault(prefs.getString("density", null), d.density),
            homeStyle = enumValueOrDefault(prefs.getString("home_style", null), d.homeStyle),
            motion = enumValueOrDefault(prefs.getString("motion", null), d.motion),
        )
    }

    private inline fun <reified T : Enum<T>> enumValueOrDefault(raw: String?, fallback: T): T =
        enumValues<T>().firstOrNull { it.name == raw } ?: fallback
}
