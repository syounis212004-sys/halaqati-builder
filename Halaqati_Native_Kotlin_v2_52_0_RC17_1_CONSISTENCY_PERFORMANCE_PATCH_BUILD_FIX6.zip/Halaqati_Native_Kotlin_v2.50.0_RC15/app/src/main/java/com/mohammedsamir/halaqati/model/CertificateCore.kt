package com.mohammedsamir.halaqati.model

import org.json.JSONObject

/** RC13 server-backed certificate core. Supabase stores lightweight certificate metadata and official numbers only; rendered PDF/assets remain local. */
data class CertificateTemplateRow(
    val id: String,
    val halaqaId: String?,
    val name: String,
    val certificateType: String?,
    val config: JSONObject = JSONObject(),
    val active: Boolean = true,
    val updatedAt: String = "",
) {
    companion object {
        fun from(j: JSONObject) = CertificateTemplateRow(
            id = j.optString("id"),
            halaqaId = j.optNullableString("halaqa_id"),
            name = j.optString("name"),
            certificateType = j.optNullableString("certificate_type"),
            config = j.optJSONObject("config") ?: JSONObject(),
            active = j.optBoolean("active", true),
            updatedAt = j.optString("updated_at"),
        )
    }
}

data class CertificateRecord(
    val id: String,
    val number: String?,
    val studentId: String,
    val halaqaId: String?,
    val certificateType: String,
    val title: String,
    val issueDate: String?,
    val status: String,
    val sourcePlanId: String?,
    val sourcePhaseId: String?,
    val templateId: String?,
    val startSurah: Int?,
    val startAyah: Int?,
    val endSurah: Int?,
    val endAyah: Int?,
    val startPage: Double?,
    val endPage: Double?,
    val pagesCount: Double?,
    val juzCount: Double?,
    val snapshot: JSONObject = JSONObject(),
    val createdAt: String = "",
    val issuedAt: String? = null,
    val updatedAt: String = "",
) {
    companion object {
        fun from(j: JSONObject): CertificateRecord {
            fun intOrNull(name: String): Int? = if (!j.has(name) || j.isNull(name)) null else j.optInt(name)
            fun doubleOrNull(name: String): Double? = if (!j.has(name) || j.isNull(name)) null else j.optDouble(name)
            return CertificateRecord(
                id = j.optString("id"),
                number = j.optNullableString("certificate_number"),
                studentId = j.optString("student_id"),
                halaqaId = j.optNullableString("halaqa_id"),
                certificateType = j.optString("certificate_type"),
                title = j.optString("title"),
                issueDate = j.optNullableString("issue_date"),
                status = j.optString("status", "draft"),
                sourcePlanId = j.optNullableString("source_plan_id"),
                sourcePhaseId = j.optNullableString("source_phase_id"),
                templateId = j.optNullableString("template_id"),
                startSurah = intOrNull("start_surah"),
                startAyah = intOrNull("start_ayah"),
                endSurah = intOrNull("end_surah"),
                endAyah = intOrNull("end_ayah"),
                startPage = doubleOrNull("start_page"),
                endPage = doubleOrNull("end_page"),
                pagesCount = doubleOrNull("pages_count"),
                juzCount = doubleOrNull("juz_count"),
                snapshot = j.optJSONObject("snapshot") ?: JSONObject(),
                createdAt = j.optString("created_at"),
                issuedAt = j.optNullableString("issued_at"),
                updatedAt = j.optString("updated_at"),
            )
        }
    }
}

data class CertificateCoreDraft(
    val id: String? = null,
    val studentId: String,
    val halaqaId: String?,
    val certificateType: String,
    val title: String,
    val issueDate: String? = null,
    val sourcePlanId: String? = null,
    val sourcePhaseId: String? = null,
    val templateId: String? = null,
    val startSurah: Int? = null,
    val startAyah: Int? = null,
    val endSurah: Int? = null,
    val endAyah: Int? = null,
    val startPage: Double? = null,
    val endPage: Double? = null,
    val pagesCount: Double? = null,
    val juzCount: Double? = null,
    val snapshot: JSONObject = JSONObject(),
)
