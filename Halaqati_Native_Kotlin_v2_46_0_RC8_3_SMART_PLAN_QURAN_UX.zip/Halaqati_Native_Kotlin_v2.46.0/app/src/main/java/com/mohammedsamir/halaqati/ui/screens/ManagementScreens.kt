@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.mohammedsamir.halaqati.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.mohammedsamir.halaqati.data.AppGraph
import com.mohammedsamir.halaqati.data.PlanSnapshot
import com.mohammedsamir.halaqati.model.Profile
import com.mohammedsamir.halaqati.model.Student
import com.mohammedsamir.halaqati.model.UserRole
import com.mohammedsamir.halaqati.quran.RecitationParityRules
import com.mohammedsamir.halaqati.ui.components.*
import com.mohammedsamir.halaqati.ui.theme.HalaqatiUiTokens
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter

private fun JSONArray.rows(): List<JSONObject> = (0 until length()).mapNotNull { optJSONObject(it) }
private fun roleCanManage(role: UserRole) = role in setOf(UserRole.ADMIN, UserRole.SUPERVISOR, UserRole.TEACHER)
private fun roleCanAdmin(role: UserRole) = role in setOf(UserRole.ADMIN, UserRole.SUPERVISOR)

@Composable
fun HalaqasManagementScreen(profile: Profile, pending: Int, onRefresh: () -> Unit) {
    val scope = rememberCoroutineScope()
    var halaqas by remember { mutableStateOf<List<JSONObject>>(emptyList()) }
    var categories by remember { mutableStateOf<List<JSONObject>>(emptyList()) }
    var students by remember { mutableStateOf<List<Student>>(emptyList()) }
    var teachers by remember { mutableStateOf<List<JSONObject>>(emptyList()) }
    var supervisors by remember { mutableStateOf<List<JSONObject>>(emptyList()) }
    var teacherLinks by remember { mutableStateOf<List<JSONObject>>(emptyList()) }
    var supervisorLinks by remember { mutableStateOf<List<JSONObject>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var message by remember { mutableStateOf<String?>(null) }
    var editHalaqa by remember { mutableStateOf<JSONObject?>(null) }
    var addHalaqa by remember { mutableStateOf(false) }
    var categoryHalaqa by remember { mutableStateOf<JSONObject?>(null) }
    var staffHalaqa by remember { mutableStateOf<JSONObject?>(null) }
    var deleteHalaqa by remember { mutableStateOf<JSONObject?>(null) }

    suspend fun reload() {
        loading = true
        try {
            val result = withContext(Dispatchers.IO) {
                val h = AppGraph.repo.table("halaqas", "select=*&order=created_at.asc&limit=200").rows()
                val c = AppGraph.repo.table("student_categories", "select=*&order=name.asc&limit=500").rows()
                val s = AppGraph.repo.students()
                val p = if (profile.role in setOf(UserRole.ADMIN, UserRole.SUPERVISOR)) {
                    AppGraph.repo.table("profiles", "select=id,full_name,email,role,approval_status,active&approval_status=eq.approved&active=eq.true&limit=500").rows()
                } else emptyList()
                val tl = AppGraph.repo.table("halaqa_teachers", "select=*&limit=1000").rows()
                val sl = AppGraph.repo.table("halaqa_supervisors", "select=*&limit=1000").rows()
                listOf(h, c, p, tl, sl) to s
            }
            halaqas = result.first[0]
            categories = result.first[1]
            val profiles = result.first[2]
            teachers = profiles.filter { it.optString("role") == "teacher" }
            supervisors = profiles.filter { it.optString("role") == "supervisor" }
            teacherLinks = result.first[3]
            supervisorLinks = result.first[4]
            students = result.second
            message = null
        } catch (e: Exception) {
            message = e.message ?: "تعذر تحميل بيانات الحلقات"
        } finally {
            loading = false
        }
    }

    LaunchedEffect(Unit) { reload() }

    Column {
        AppTopBar(
            title = if (profile.role == UserRole.ADMIN) "إدارة الحلقات والفئات" else "الحلقات والفئات",
            onRefresh = { scope.launch { reload() }; onRefresh() },
            pending = pending,
        )
        message?.let { StateNotice(it, kind = "error", modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)) }
        if (loading && halaqas.isEmpty()) LoadingSkeleton(rows = 3, modifier = Modifier.padding(12.dp))

        if (profile.role == UserRole.ADMIN) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), horizontalArrangement = Arrangement.End) {
                Button(
                    onClick = { addHalaqa = true },
                    modifier = Modifier.heightIn(min = HalaqatiUiTokens.TouchTarget),
                ) {
                    Icon(Icons.Default.Add, contentDescription = null)
                    Spacer(Modifier.width(6.dp))
                    Text("إضافة حلقة")
                }
            }
        }

        if (!loading && halaqas.isEmpty()) EmptyState("لا توجد حلقات بعد")
        LazyColumn(
            contentPadding = PaddingValues(12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            items(halaqas, key = { it.optString("id") }) { h ->
                val hid = h.optString("id")
                val hStudents = students.filter { it.halaqaId == hid && it.status != "withdrawn" }
                val hCats = categories.filter { it.optString("halaqa_id") == hid && it.optBoolean("active", true) }
                val tIds = teacherLinks.filter { it.optString("halaqa_id") == hid }.map { it.optString("teacher_id") }.toSet()
                val sIds = supervisorLinks.filter { it.optString("halaqa_id") == hid }.map { it.optString("supervisor_id") }.toSet()
                val tNames = teachers.filter { it.optString("id") in tIds }.joinToString("، ") { it.optString("full_name", "محفّظ") }
                val sNames = supervisors.filter { it.optString("id") in sIds }.joinToString("، ") { it.optString("full_name", "مشرف") }
                ElevatedCard(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Surface(
                                shape = MaterialTheme.shapes.large,
                                color = MaterialTheme.colorScheme.primaryContainer,
                            ) {
                                Icon(Icons.Default.Groups, contentDescription = null, modifier = Modifier.padding(12.dp), tint = MaterialTheme.colorScheme.primary)
                            }
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) {
                                Text(h.optString("name", "حلقة"), fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                                Text(
                                    listOf(h.optString("location"), h.optString("schedule_text")).filter { it.isNotBlank() }.joinToString(" · ").ifBlank { "المكان والبرنامج غير محددين" },
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            }
                            Surface(
                                color = if (h.optBoolean("active", true)) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,
                                contentColor = if (h.optBoolean("active", true)) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurfaceVariant,
                                shape = MaterialTheme.shapes.extraLarge,
                            ) {
                                Text(
                                    if (h.optBoolean("active", true)) "نشطة" else "موقوفة",
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp),
                                    style = MaterialTheme.typography.labelLarge,
                                )
                            }
                        }
                        Text("المشرفون: ${sNames.ifBlank { "غير معيّنين" }}", style = MaterialTheme.typography.bodySmall)
                        Text("المحفّظون: ${tNames.ifBlank { if (profile.role == UserRole.TEACHER) "حسب الربط" else "غير معيّنين" }}", style = MaterialTheme.typography.bodySmall)
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            SmallStat("الطلاب", hStudents.size.toString(), Modifier.weight(1f))
                            SmallStat("الفئات", hCats.size.toString(), Modifier.weight(1f))
                            SmallStat("المشرفون", sIds.size.toString(), Modifier.weight(1f))
                        }
                        Text(
                            "المسارات: حفظ عام ${hStudents.count { it.track != "tathbit" }} · تثبيت ${hStudents.count { it.track == "tathbit" }}",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = { categoryHalaqa = h }) { Text("الفئات") }
                            if (profile.role == UserRole.ADMIN) {
                                OutlinedButton(onClick = { staffHalaqa = h }, modifier = Modifier.heightIn(min = 48.dp)) {
                                    Icon(Icons.Default.GroupAdd, contentDescription = null)
                                    Spacer(Modifier.width(6.dp))
                                    Text("تعيين الطاقم")
                                }
                                OutlinedButton(onClick = { editHalaqa = h }, modifier = Modifier.heightIn(min = 48.dp)) { Text("تعديل") }
                                TextButton(
                                    onClick = {
                                        scope.launch {
                                            try {
                                                withContext(Dispatchers.IO) {
                                                    AppGraph.repo.patch(
                                                        "halaqas",
                                                        "id=eq.$hid",
                                                        JSONObject().put("active", !h.optBoolean("active", true)).put("updated_at", Instant.now().toString()),
                                                        dedupe = "halaqa-active:$hid",
                                                    )
                                                }
                                                reload(); onRefresh()
                                            } catch (e: Exception) { message = e.message }
                                        }
                                    },
                                    modifier = Modifier.heightIn(min = 48.dp),
                                ) { Text(if (h.optBoolean("active", true)) "إيقاف" else "تفعيل") }
                                TextButton(
                                    onClick = { deleteHalaqa = h },
                                    colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.error),
                                    modifier = Modifier.heightIn(min = 48.dp),
                                ) { Text("حذف") }
                            }
                        }
                    }
                }
            }
        }
    }

    if (addHalaqa || editHalaqa != null) {
        HalaqaDialog(
            current = editHalaqa,
            close = { addHalaqa = false; editHalaqa = null },
            save = { name, location, schedule, description ->
                scope.launch {
                    try {
                        withContext(Dispatchers.IO) {
                            val obj = JSONObject()
                                .put("name", name)
                                .put("location", location.takeIf { it.isNotBlank() } ?: JSONObject.NULL)
                                .put("schedule_text", schedule.takeIf { it.isNotBlank() } ?: JSONObject.NULL)
                                .put("description", description.takeIf { it.isNotBlank() } ?: JSONObject.NULL)
                                .put("active", true)
                            val id = editHalaqa?.optString("id")
                            if (id.isNullOrBlank()) AppGraph.repo.write("halaqas", obj, dedupe = "halaqa-create:${name.lowercase()}")
                            else AppGraph.repo.patch("halaqas", "id=eq.$id", obj.put("updated_at", Instant.now().toString()), dedupe = "halaqa:$id")
                        }
                        addHalaqa = false; editHalaqa = null
                        reload(); onRefresh()
                    } catch (e: Exception) { message = e.message ?: "تعذر حفظ الحلقة" }
                }
            },
        )
    }
    categoryHalaqa?.let { h ->
        CategoriesDialog(
            halaqa = h,
            categories = categories.filter { it.optString("halaqa_id") == h.optString("id") },
            students = students,
            canEdit = roleCanManage(profile.role),
            close = { categoryHalaqa = null },
            changed = { scope.launch { reload() }; onRefresh() },
        )
    }

    staffHalaqa?.let { h ->
        HalaqaStaffDialog(
            halaqa = h,
            teachers = teachers,
            supervisors = supervisors,
            currentTeacherIds = teacherLinks.filter { it.optString("halaqa_id") == h.optString("id") }.map { it.optString("teacher_id") }.toSet(),
            currentSupervisorIds = supervisorLinks.filter { it.optString("halaqa_id") == h.optString("id") }.map { it.optString("supervisor_id") }.toSet(),
            close = { staffHalaqa = null },
            save = { wantedTeachers, wantedSupervisors ->
                scope.launch {
                    try {
                        val hid = h.optString("id")
                        withContext(Dispatchers.IO) {
                            val oldTeachers = teacherLinks.filter { it.optString("halaqa_id") == hid }.map { it.optString("teacher_id") }.toSet()
                            val oldSupervisors = supervisorLinks.filter { it.optString("halaqa_id") == hid }.map { it.optString("supervisor_id") }.toSet()
                            oldTeachers.filter { it !in wantedTeachers }.forEach { teacherId ->
                                AppGraph.repo.delete("halaqa_teachers", "halaqa_id=eq.$hid&teacher_id=eq.$teacherId", "halaqa-teacher-delete:$hid:$teacherId")
                            }
                            wantedTeachers.filter { it !in oldTeachers }.forEachIndexed { index, teacherId ->
                                AppGraph.repo.write(
                                    "halaqa_teachers",
                                    JSONObject().put("halaqa_id", hid).put("teacher_id", teacherId).put("is_primary", index == 0 && oldTeachers.isEmpty()),
                                    onConflict = "halaqa_id,teacher_id",
                                    dedupe = "halaqa-teacher:$hid:$teacherId",
                                )
                            }
                            oldSupervisors.filter { it !in wantedSupervisors }.forEach { supervisorId ->
                                AppGraph.repo.delete("halaqa_supervisors", "halaqa_id=eq.$hid&supervisor_id=eq.$supervisorId", "halaqa-supervisor-delete:$hid:$supervisorId")
                            }
                            wantedSupervisors.filter { it !in oldSupervisors }.forEach { supervisorId ->
                                val obj = JSONObject().put("halaqa_id", hid).put("supervisor_id", supervisorId)
                                AppGraph.repo.store.load()?.userId?.let { obj.put("created_by", it) }
                                AppGraph.repo.write(
                                    "halaqa_supervisors",
                                    obj,
                                    onConflict = "halaqa_id,supervisor_id",
                                    dedupe = "halaqa-supervisor:$hid:$supervisorId",
                                )
                            }
                            AppGraph.repo.patch(
                                "halaqas",
                                "id=eq.$hid",
                                JSONObject().put("supervisor_id", wantedSupervisors.firstOrNull() ?: JSONObject.NULL).put("updated_at", Instant.now().toString()),
                                dedupe = "halaqa-primary-supervisor:$hid",
                            )
                        }
                        staffHalaqa = null
                        reload(); onRefresh()
                    } catch (e: Exception) { message = e.message ?: "تعذر تحديث طاقم الحلقة" }
                }
            },
        )
    }

    deleteHalaqa?.let { h ->
        DeleteHalaqaDialog(
            halaqa = h,
            close = { deleteHalaqa = null },
            confirm = {
                scope.launch {
                    try {
                        val hid = h.optString("id")
                        withContext(Dispatchers.IO) {
                            AppGraph.repo.rpcWrite(
                                "delete_halaqa_cascade",
                                JSONObject().put("p_halaqa_id", hid),
                                dedupe = "halaqa-cascade-delete:$hid",
                            )
                        }
                        // Hide immediately even when the safe cascade RPC is queued offline.
                        halaqas = halaqas.filterNot { it.optString("id") == hid }
                        deleteHalaqa = null
                        if (AppGraph.repo.online()) reload()
                        onRefresh()
                    } catch (e: Exception) { message = e.message ?: "تعذر حذف الحلقة" }
                }
            },
        )
    }
}

@Composable
private fun HalaqaStaffDialog(
    halaqa: JSONObject,
    teachers: List<JSONObject>,
    supervisors: List<JSONObject>,
    currentTeacherIds: Set<String>,
    currentSupervisorIds: Set<String>,
    close: () -> Unit,
    save: (Set<String>, Set<String>) -> Unit,
) {
    var wantedTeachers by remember(halaqa.optString("id")) { mutableStateOf(currentTeacherIds) }
    var wantedSupervisors by remember(halaqa.optString("id")) { mutableStateOf(currentSupervisorIds) }
    AlertDialog(
        onDismissRequest = close,
        title = { Text("طاقم ${halaqa.optString("name", "الحلقة")}") },
        text = {
            LazyColumn(
                modifier = Modifier.heightIn(max = 520.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp),
            ) {
                item { Text("المحفّظون", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold) }
                if (teachers.isEmpty()) item { Text("لا توجد حسابات محفّظين معتمدة.", style = MaterialTheme.typography.bodyMedium) }
                items(teachers, key = { "t:${it.optString("id")}" }) { person ->
                    val id = person.optString("id")
                    ListItem(
                        headlineContent = { Text(person.optString("full_name", "محفّظ")) },
                        supportingContent = { Text(person.optString("email"), style = MaterialTheme.typography.bodySmall) },
                        leadingContent = {
                            Checkbox(
                                checked = id in wantedTeachers,
                                onCheckedChange = { checked -> wantedTeachers = if (checked) wantedTeachers + id else wantedTeachers - id },
                            )
                        },
                        modifier = Modifier.heightIn(min = 56.dp),
                    )
                }
                item { HorizontalDivider(); Spacer(Modifier.height(6.dp)); Text("المشرفون", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold) }
                if (supervisors.isEmpty()) item { Text("لا توجد حسابات مشرفين معتمدة.", style = MaterialTheme.typography.bodyMedium) }
                items(supervisors, key = { "s:${it.optString("id")}" }) { person ->
                    val id = person.optString("id")
                    ListItem(
                        headlineContent = { Text(person.optString("full_name", "مشرف")) },
                        supportingContent = { Text(person.optString("email"), style = MaterialTheme.typography.bodySmall) },
                        leadingContent = {
                            Checkbox(
                                checked = id in wantedSupervisors,
                                onCheckedChange = { checked -> wantedSupervisors = if (checked) wantedSupervisors + id else wantedSupervisors - id },
                            )
                        },
                        modifier = Modifier.heightIn(min = 56.dp),
                    )
                }
                item {
                    Text(
                        "أول مشرف محدد يُحفظ أيضًا كمشرف رئيسي للحلقة للتوافق مع البيانات القديمة.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        },
        confirmButton = { Button(onClick = { save(wantedTeachers, wantedSupervisors) }, modifier = Modifier.heightIn(min = 48.dp)) { Text("حفظ التعيينات") } },
        dismissButton = { TextButton(onClick = close, modifier = Modifier.heightIn(min = 48.dp)) { Text("إلغاء") } },
    )
}

@Composable
private fun DeleteHalaqaDialog(halaqa: JSONObject, close: () -> Unit, confirm: () -> Unit) {
    val expected = halaqa.optString("name")
    var typed by remember(expected) { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = close,
        icon = { Icon(Icons.Default.WarningAmber, contentDescription = null, tint = MaterialTheme.colorScheme.error) },
        title = { Text("حذف الحلقة نهائيًا") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("هذا الإجراء يستخدم الحذف المتسلسل الآمن الموجود في قاعدة حلقاتي، وقد يحذف البيانات المرتبطة بهذه الحلقة.")
                Text("اكتب اسم الحلقة للتأكيد: $expected", fontWeight = FontWeight.Bold)
                OutlinedTextField(typed, { typed = it }, label = { Text("اسم الحلقة") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                if (!AppGraph.repo.online()) {
                    Text(
                        "أنت دون اتصال: سيُحفظ طلب الحذف محليًا ويُرسل إلى الخادم عند عودة الاتصال.",
                        color = MaterialTheme.colorScheme.tertiary,
                        style = MaterialTheme.typography.bodySmall,
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = confirm,
                enabled = typed.trim() == expected.trim() && expected.isNotBlank(),
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                modifier = Modifier.heightIn(min = 48.dp),
            ) { Text("حذف نهائي") }
        },
        dismissButton = { TextButton(onClick = close, modifier = Modifier.heightIn(min = 48.dp)) { Text("إلغاء") } },
    )
}

@Composable
private fun SmallStat(label: String, value: String, modifier: Modifier = Modifier) {
    Surface(modifier, color = MaterialTheme.colorScheme.surfaceVariant, shape = MaterialTheme.shapes.medium) {
        Column(Modifier.padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(value, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
            Text(label, style = MaterialTheme.typography.labelSmall)
        }
    }
}

@Composable
private fun HalaqaDialog(current: JSONObject?, close: () -> Unit, save: (String, String, String, String) -> Unit) {
    var name by remember(current) { mutableStateOf(current?.optString("name").orEmpty()) }
    var location by remember(current) { mutableStateOf(current?.optString("location").orEmpty()) }
    var schedule by remember(current) { mutableStateOf(current?.optString("schedule_text").orEmpty()) }
    var description by remember(current) { mutableStateOf(current?.optString("description").orEmpty()) }
    AlertDialog(
        onDismissRequest = close,
        title = { Text(if (current == null) "إضافة حلقة" else "تعديل الحلقة") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text("اسم الحلقة") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(location, { location = it }, label = { Text("المكان") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(schedule, { schedule = it }, label = { Text("البرنامج") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(description, { description = it }, label = { Text("الوصف") }, minLines = 2, modifier = Modifier.fillMaxWidth())
            }
        },
        confirmButton = { Button(onClick = { save(name.trim(), location.trim(), schedule.trim(), description.trim()) }, enabled = name.trim().length >= 2) { Text("حفظ") } },
        dismissButton = { TextButton(onClick = close) { Text("إلغاء") } },
    )
}

@Composable
private fun CategoriesDialog(
    halaqa: JSONObject,
    categories: List<JSONObject>,
    students: List<Student>,
    canEdit: Boolean,
    close: () -> Unit,
    changed: () -> Unit,
) {
    val scope = rememberCoroutineScope()
    var name by remember { mutableStateOf("") }
    var minAge by remember { mutableStateOf("") }
    var maxAge by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    AlertDialog(
        onDismissRequest = close,
        title = { Text("فئات ${halaqa.optString("name", "الحلقة")}") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                categories.filter { it.optBoolean("active", true) }.forEach { c ->
                    val count = students.count { it.categoryId == c.optString("id") && it.status != "withdrawn" }
                    ElevatedCard(Modifier.fillMaxWidth()) {
                        ListItem(
                            headlineContent = { Text(c.optString("name", "فئة"), fontWeight = FontWeight.Bold) },
                            supportingContent = {
                                val ages = listOf(c.optString("min_age"), c.optString("max_age")).filter { it.isNotBlank() && it != "null" }.joinToString("–")
                                Text(listOf(if (ages.isBlank()) "" else "العمر $ages سنة", "$count طالب").filter { it.isNotBlank() }.joinToString(" · "))
                            },
                            trailingContent = {
                                if (canEdit) IconButton(
                                    onClick = {
                                    val id = c.optString("id")
                                    scope.launch {
                                        try {
                                            withContext(Dispatchers.IO) {
                                                students.filter { it.categoryId == id }.forEach { st ->
                                                    AppGraph.repo.patch("students", "id=eq.${st.id}", JSONObject().put("category_id", JSONObject.NULL), dedupe = "student-category:${st.id}")
                                                }
                                                AppGraph.repo.delete("student_categories", "id=eq.$id", dedupe = "category-delete:$id")
                                            }
                                            changed()
                                        } catch (e: Exception) { error = e.message }
                                    }
                                    },
                                    modifier = Modifier.size(HalaqatiUiTokens.TouchTarget),
                                ) { Icon(Icons.Default.DeleteOutline, contentDescription = "إزالة") }
                            },
                        )
                    }
                }
                if (canEdit) {
                    HorizontalDivider()
                    Text("إضافة فئة", fontWeight = FontWeight.Bold)
                    OutlinedTextField(name, { name = it }, label = { Text("اسم الفئة") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(minAge, { minAge = it.filter(Char::isDigit).take(3) }, label = { Text("من عمر") }, singleLine = true, modifier = Modifier.weight(1f))
                        OutlinedTextField(maxAge, { maxAge = it.filter(Char::isDigit).take(3) }, label = { Text("إلى عمر") }, singleLine = true, modifier = Modifier.weight(1f))
                    }
                    error?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
                }
            }
        },
        confirmButton = {
            if (canEdit) Button(
                enabled = name.trim().length >= 2,
                onClick = {
                    scope.launch {
                        try {
                            withContext(Dispatchers.IO) {
                                val obj = JSONObject()
                                    .put("halaqa_id", halaqa.optString("id"))
                                    .put("name", name.trim())
                                    .put("active", true)
                                minAge.toIntOrNull()?.let { obj.put("min_age", it.coerceIn(0, 100)) }
                                maxAge.toIntOrNull()?.let { obj.put("max_age", it.coerceIn(0, 100)) }
                                AppGraph.repo.store.load()?.userId?.let { obj.put("created_by", it) }
                                AppGraph.repo.write("student_categories", obj, dedupe = "category:${halaqa.optString("id")}:${name.trim().lowercase()}")
                            }
                            name = ""; minAge = ""; maxAge = ""; error = null
                            changed()
                        } catch (e: Exception) { error = e.message ?: "تعذر إضافة الفئة" }
                    }
                },
            ) { Text("إضافة") }
        },
        dismissButton = { TextButton(onClick = close) { Text("إغلاق") } },
    )
}

@Composable
fun CommunityNativeScreen(profile: Profile, pending: Int, onRefresh: () -> Unit) {
    val scope = rememberCoroutineScope()
    var tab by remember { mutableStateOf("announcements") }
    var announcements by remember { mutableStateOf<List<JSONObject>>(emptyList()) }
    var posts by remember { mutableStateOf<List<JSONObject>>(emptyList()) }
    var comments by remember { mutableStateOf<List<JSONObject>>(emptyList()) }
    var halaqas by remember { mutableStateOf<List<JSONObject>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var message by remember { mutableStateOf<String?>(null) }
    var addAnnouncement by remember { mutableStateOf(false) }
    var editAnnouncement by remember { mutableStateOf<JSONObject?>(null) }
    var deleteAnnouncement by remember { mutableStateOf<JSONObject?>(null) }
    var addPost by remember { mutableStateOf(false) }
    var editPost by remember { mutableStateOf<JSONObject?>(null) }
    var deletePost by remember { mutableStateOf<JSONObject?>(null) }
    var commentPost by remember { mutableStateOf<JSONObject?>(null) }
    var deleteComment by remember { mutableStateOf<JSONObject?>(null) }

    suspend fun reload() {
        loading = true
        try {
            val result = withContext(Dispatchers.IO) {
                listOf(
                    AppGraph.repo.table("announcements", "select=*&order=pinned.desc&order=publish_at.desc&limit=200").rows(),
                    AppGraph.repo.table("forum_posts", "select=*&order=pinned.desc&order=created_at.desc&limit=200").rows(),
                    AppGraph.repo.table("forum_comments", "select=*&order=created_at.asc&limit=1000").rows(),
                    AppGraph.repo.table("halaqas", "select=id,name&active=eq.true&order=name.asc&limit=100").rows(),
                )
            }
            announcements = result[0]; posts = result[1]; comments = result[2]; halaqas = result[3]
            message = null
        } catch (e: Exception) { message = e.message ?: "تعذر تحميل المجتمع" }
        finally { loading = false }
    }
    LaunchedEffect(Unit) { reload() }

    Column {
        AppTopBar("الإعلانات ومنتدى الحلقة", onRefresh = { scope.launch { reload() }; onRefresh() }, pending = pending)
        SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth().padding(horizontal = 12.dp)) {
            SegmentedButton(selected = tab == "announcements", onClick = { tab = "announcements" }, shape = SegmentedButtonDefaults.itemShape(0, 2)) { Text("الإعلانات") }
            SegmentedButton(selected = tab == "forum", onClick = { tab = "forum" }, shape = SegmentedButtonDefaults.itemShape(1, 2)) { Text("المنتدى") }
        }
        message?.let { StateNotice(it, kind = "error", modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)) }
        if (loading && announcements.isEmpty() && posts.isEmpty()) LoadingSkeleton(rows = 3, modifier = Modifier.padding(12.dp))

        Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.End) {
            if (tab == "announcements" && roleCanManage(profile.role)) {
                Button(onClick = { addAnnouncement = true }, modifier = Modifier.heightIn(min = HalaqatiUiTokens.TouchTarget)) { Icon(Icons.Default.Campaign, null); Spacer(Modifier.width(6.dp)); Text("إعلان") }
            }
            if (tab == "forum") {
                Button(onClick = { addPost = true }, modifier = Modifier.heightIn(min = HalaqatiUiTokens.TouchTarget)) { Icon(Icons.Default.AddComment, null); Spacer(Modifier.width(6.dp)); Text(if (roleCanManage(profile.role)) "منشور" else "استفسار") }
            }
        }

        if (tab == "announcements") {
            if (!loading && announcements.isEmpty()) EmptyState("لا توجد إعلانات")
            LazyColumn(contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(announcements, key = { it.optString("id") }) { a ->
                    ElevatedCard(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(if (a.optBoolean("pinned", false)) Icons.Default.PushPin else Icons.Default.Campaign, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                Spacer(Modifier.width(8.dp))
                                Text(a.optString("title", "إعلان"), fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                                Surface(color = MaterialTheme.colorScheme.secondaryContainer, contentColor = MaterialTheme.colorScheme.onSecondaryContainer, shape = MaterialTheme.shapes.extraLarge) {
                                    Text(announcementCategoryAr(a.optString("category")), Modifier.padding(horizontal = 10.dp, vertical = 7.dp), style = MaterialTheme.typography.labelLarge)
                                }
                                if (roleCanManage(profile.role)) {
                                    IconButton(onClick = { editAnnouncement = a }, modifier = Modifier.size(48.dp)) {
                                        Icon(Icons.Default.Edit, contentDescription = "تعديل الإعلان")
                                    }
                                    IconButton(onClick = { deleteAnnouncement = a }, modifier = Modifier.size(48.dp)) {
                                        Icon(Icons.Default.DeleteOutline, contentDescription = "حذف الإعلان", tint = MaterialTheme.colorScheme.error)
                                    }
                                }
                            }
                            Text(a.optString("body"), style = MaterialTheme.typography.bodyMedium)
                            Text(
                                "الجمهور: ${audienceAr(a.optString("audience"))} · الأولوية: ${priorityAr(a.optString("priority"))}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                }
            }
        } else {
            if (!loading && posts.isEmpty()) EmptyState("لا توجد منشورات")
            LazyColumn(contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(posts, key = { it.optString("id") }) { p ->
                    val postComments = comments.filter { it.optString("post_id") == p.optString("id") }
                    ElevatedCard(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(if (p.optBoolean("pinned", false)) Icons.Default.PushPin else Icons.Default.Forum, null, tint = MaterialTheme.colorScheme.primary)
                                Spacer(Modifier.width(8.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(p.optString("title", "منشور"), fontWeight = FontWeight.Bold)
                                    Text(p.optString("author_name", "عضو الحلقة"), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                Surface(color = MaterialTheme.colorScheme.secondaryContainer, contentColor = MaterialTheme.colorScheme.onSecondaryContainer, shape = MaterialTheme.shapes.extraLarge) {
                                    Text(postTypeAr(p.optString("post_type")), Modifier.padding(horizontal = 10.dp, vertical = 7.dp), style = MaterialTheme.typography.labelLarge)
                                }
                                if (p.optString("author_id") == profile.id || roleCanAdmin(profile.role)) {
                                    IconButton(onClick = { editPost = p }, modifier = Modifier.size(48.dp)) {
                                        Icon(Icons.Default.Edit, contentDescription = "تعديل المنشور")
                                    }
                                    IconButton(onClick = { deletePost = p }, modifier = Modifier.size(48.dp)) {
                                        Icon(Icons.Default.DeleteOutline, contentDescription = "حذف المنشور", tint = MaterialTheme.colorScheme.error)
                                    }
                                }
                            }
                            Text(p.optString("body"))
                            HorizontalDivider()
                            Text("${postComments.size} تعليق", style = MaterialTheme.typography.labelMedium)
                            postComments.take(3).forEach { c ->
                                Surface(color = MaterialTheme.colorScheme.surfaceVariant, shape = MaterialTheme.shapes.medium) {
                                    Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Column(Modifier.weight(1f)) {
                                            Text(c.optString("author_name", "عضو"), fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium)
                                            Text(c.optString("body"), style = MaterialTheme.typography.bodyMedium)
                                        }
                                        if (c.optString("author_id") == profile.id || roleCanAdmin(profile.role)) {
                                            IconButton(onClick = { deleteComment = c }, modifier = Modifier.size(48.dp)) {
                                                Icon(Icons.Default.DeleteOutline, contentDescription = "حذف التعليق")
                                            }
                                        }
                                    }
                                }
                            }
                            if (p.optBoolean("comments_enabled", true)) {
                                TextButton(onClick = { commentPost = p }, modifier = Modifier.align(Alignment.End)) { Text("إضافة تعليق") }
                            }
                        }
                    }
                }
            }
        }
    }

    if (addAnnouncement) {
        AnnouncementDialog(halaqas = halaqas, current = null, close = { addAnnouncement = false }) { halaqaId, title, body, audience, priority, pinned, category ->
            scope.launch {
                try {
                    withContext(Dispatchers.IO) {
                        val obj = JSONObject()
                            .put("title", title)
                            .put("body", body)
                            .put("audience", audience)
                            .put("priority", priority)
                            .put("pinned", pinned)
                            .put("category", category)
                            .put("publish_at", Instant.now().toString())
                        if (halaqaId.isNotBlank()) obj.put("halaqa_id", halaqaId)
                        AppGraph.repo.store.load()?.userId?.let { obj.put("created_by", it) }
                        AppGraph.repo.write("announcements", obj, dedupe = "announcement:${title.lowercase()}:${System.currentTimeMillis()}")
                    }
                    addAnnouncement = false; reload(); onRefresh()
                } catch (e: Exception) { message = e.message }
            }
        }
    }
    editAnnouncement?.let { current ->
        AnnouncementDialog(halaqas = halaqas, current = current, close = { editAnnouncement = null }) { halaqaId, title, body, audience, priority, pinned, category ->
            scope.launch {
                try {
                    withContext(Dispatchers.IO) {
                        AppGraph.repo.patch(
                            "announcements",
                            "id=eq.${current.optString("id")}",
                            JSONObject()
                                .put("halaqa_id", halaqaId.takeIf { it.isNotBlank() } ?: JSONObject.NULL)
                                .put("title", title)
                                .put("body", body)
                                .put("audience", audience)
                                .put("priority", priority)
                                .put("pinned", pinned)
                                .put("category", category),
                            dedupe = "announcement:${current.optString("id")}",
                        )
                    }
                    editAnnouncement = null; reload(); onRefresh()
                } catch (e: Exception) { message = e.message ?: "تعذر تعديل الإعلان" }
            }
        }
    }
    deleteAnnouncement?.let { current ->
        ConfirmDeleteDialog(
            title = "حذف الإعلان",
            message = "سيتم حذف الإعلان «${current.optString("title") }» نهائيًا.",
            close = { deleteAnnouncement = null },
            confirm = {
                scope.launch {
                    try {
                        withContext(Dispatchers.IO) { AppGraph.repo.delete("announcements", "id=eq.${current.optString("id")}", "announcement-delete:${current.optString("id")}") }
                        deleteAnnouncement = null; reload(); onRefresh()
                    } catch (e: Exception) { message = e.message ?: "تعذر حذف الإعلان" }
                }
            },
        )
    }

    if (addPost) {
        ForumPostDialog(profile = profile, halaqas = halaqas, current = null, close = { addPost = false }) { halaqaId, type, title, body, commentsEnabled, pinned ->
            scope.launch {
                try {
                    withContext(Dispatchers.IO) {
                        val uid = AppGraph.repo.store.load()?.userId ?: error("الجلسة غير صالحة")
                        val obj = JSONObject()
                            .put("halaqa_id", halaqaId)
                            .put("author_id", uid)
                            .put("author_name", profile.fullName)
                            .put("post_type", type)
                            .put("title", title)
                            .put("body", body)
                            .put("comments_enabled", commentsEnabled)
                            .put("pinned", pinned && roleCanManage(profile.role))
                        AppGraph.repo.write("forum_posts", obj, dedupe = "forum:$uid:${System.currentTimeMillis()}")
                    }
                    addPost = false; reload(); onRefresh()
                } catch (e: Exception) { message = e.message }
            }
        }
    }
    editPost?.let { current ->
        ForumPostDialog(profile = profile, halaqas = halaqas, current = current, close = { editPost = null }) { halaqaId, type, title, body, commentsEnabled, pinned ->
            scope.launch {
                try {
                    withContext(Dispatchers.IO) {
                        AppGraph.repo.patch(
                            "forum_posts",
                            "id=eq.${current.optString("id")}",
                            JSONObject()
                                .put("halaqa_id", halaqaId)
                                .put("post_type", type)
                                .put("title", title)
                                .put("body", body)
                                .put("comments_enabled", commentsEnabled)
                                .put("pinned", pinned && roleCanManage(profile.role))
                                .put("updated_at", Instant.now().toString()),
                            dedupe = "forum:${current.optString("id")}",
                        )
                    }
                    editPost = null; reload(); onRefresh()
                } catch (e: Exception) { message = e.message ?: "تعذر تعديل المنشور" }
            }
        }
    }
    deletePost?.let { current ->
        ConfirmDeleteDialog(
            title = "حذف المنشور",
            message = "سيتم حذف المنشور وتعليقاته المرتبطة وفق سياسات قاعدة البيانات.",
            close = { deletePost = null },
            confirm = {
                scope.launch {
                    try {
                        val id = current.optString("id")
                        withContext(Dispatchers.IO) {
                            // Delete comments first so this remains safe even if the FK has no cascade.
                            AppGraph.repo.delete("forum_comments", "post_id=eq.$id", "forum-comments-delete:$id")
                            AppGraph.repo.delete("forum_posts", "id=eq.$id", "forum-delete:$id")
                        }
                        deletePost = null; reload(); onRefresh()
                    } catch (e: Exception) { message = e.message ?: "تعذر حذف المنشور" }
                }
            },
        )
    }
    deleteComment?.let { current ->
        ConfirmDeleteDialog(
            title = "حذف التعليق",
            message = "هل تريد حذف هذا التعليق؟",
            close = { deleteComment = null },
            confirm = {
                scope.launch {
                    try {
                        withContext(Dispatchers.IO) { AppGraph.repo.delete("forum_comments", "id=eq.${current.optString("id")}", "comment-delete:${current.optString("id")}") }
                        deleteComment = null; reload(); onRefresh()
                    } catch (e: Exception) { message = e.message ?: "تعذر حذف التعليق" }
                }
            },
        )
    }

    commentPost?.let { post ->
        CommentDialog(close = { commentPost = null }) { body ->
            scope.launch {
                try {
                    withContext(Dispatchers.IO) {
                        val uid = AppGraph.repo.store.load()?.userId ?: error("الجلسة غير صالحة")
                        AppGraph.repo.write(
                            "forum_comments",
                            JSONObject()
                                .put("post_id", post.optString("id"))
                                .put("author_id", uid)
                                .put("author_name", profile.fullName)
                                .put("body", body),
                            dedupe = "comment:${post.optString("id")}:$uid:${System.currentTimeMillis()}",
                        )
                    }
                    commentPost = null; reload(); onRefresh()
                } catch (e: Exception) { message = e.message }
            }
        }
    }
}

private fun announcementCategoryAr(v: String) = mapOf("daily" to "يومي", "monthly" to "شهري", "schedule" to "جدول", "urgent" to "عاجل", "achievement" to "إنجاز", "general" to "عام")[v] ?: "عام"
private fun audienceAr(v: String) = mapOf("all" to "الكل", "teachers" to "المحفّظين", "guardians" to "أولياء الأمور", "students" to "الطلاب")[v] ?: "الكل"
private fun priorityAr(v: String) = mapOf("urgent" to "عاجل", "important" to "مهم", "normal" to "عادي")[v] ?: "عادي"
private fun postTypeAr(v: String) = mapOf("question" to "استفسار", "achievement" to "إنجاز", "notice" to "ملاحظة", "discussion" to "نقاش")[v] ?: "نقاش"

@Composable
private fun AnnouncementDialog(
    halaqas: List<JSONObject>,
    current: JSONObject? = null,
    close: () -> Unit,
    save: (String, String, String, String, String, Boolean, String) -> Unit,
) {
    var halaqaId by remember(current?.optString("id")) { mutableStateOf(current?.optString("halaqa_id").orEmpty().ifBlank { halaqas.firstOrNull()?.optString("id").orEmpty() }) }
    var title by remember(current?.optString("id")) { mutableStateOf(current?.optString("title").orEmpty()) }
    var body by remember(current?.optString("id")) { mutableStateOf(current?.optString("body").orEmpty()) }
    var audience by remember(current?.optString("id")) { mutableStateOf(current?.optString("audience", "all") ?: "all") }
    var priority by remember(current?.optString("id")) { mutableStateOf(current?.optString("priority", "normal") ?: "normal") }
    var category by remember(current?.optString("id")) { mutableStateOf(current?.optString("category", "general") ?: "general") }
    var pinned by remember(current?.optString("id")) { mutableStateOf(current?.optBoolean("pinned", false) ?: false) }
    AlertDialog(
        onDismissRequest = close,
        title = { Text(if (current == null) "إعلان جديد" else "تعديل الإعلان") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("الحلقة", style = MaterialTheme.typography.labelLarge)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    halaqas.forEach { h -> ProFilterChip(halaqaId == h.optString("id"), { halaqaId = h.optString("id") }, h.optString("name", "حلقة")) }
                }
                OutlinedTextField(title, { title = it }, label = { Text("العنوان") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(body, { body = it }, label = { Text("نص الإعلان") }, minLines = 3, modifier = Modifier.fillMaxWidth())
                Text("الجمهور", style = MaterialTheme.typography.labelLarge)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("all", "guardians", "teachers", "students").forEach { v -> ProFilterChip(audience == v, { audience = v }, audienceAr(v)) }
                }
                Text("الأولوية", style = MaterialTheme.typography.labelLarge)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("normal", "important", "urgent").forEach { v -> ProFilterChip(priority == v, { priority = v }, priorityAr(v)) }
                }
                Text("التصنيف", style = MaterialTheme.typography.labelLarge)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("general", "daily", "monthly", "schedule", "achievement", "urgent").forEach { v -> ProFilterChip(category == v, { category = v }, announcementCategoryAr(v)) }
                }
                Row(verticalAlignment = Alignment.CenterVertically) { Switch(pinned, { pinned = it }); Spacer(Modifier.width(8.dp)); Text("تثبيت الإعلان") }
            }
        },
        confirmButton = { Button(onClick = { save(halaqaId, title.trim(), body.trim(), audience, priority, pinned, category) }, enabled = title.trim().length >= 2 && body.trim().length >= 2, modifier = Modifier.heightIn(min = 48.dp)) { Text(if (current == null) "نشر" else "حفظ") } },
        dismissButton = { TextButton(onClick = close) { Text("إلغاء") } },
    )
}

@Composable
private fun ForumPostDialog(
    profile: Profile,
    halaqas: List<JSONObject>,
    current: JSONObject? = null,
    close: () -> Unit,
    save: (String, String, String, String, Boolean, Boolean) -> Unit,
) {
    var halaqaId by remember(current?.optString("id")) { mutableStateOf(current?.optString("halaqa_id").orEmpty().ifBlank { halaqas.firstOrNull()?.optString("id").orEmpty() }) }
    var type by remember(current?.optString("id")) { mutableStateOf(current?.optString("post_type").orEmpty().ifBlank { if (roleCanManage(profile.role)) "discussion" else "question" }) }
    var title by remember(current?.optString("id")) { mutableStateOf(current?.optString("title").orEmpty()) }
    var body by remember(current?.optString("id")) { mutableStateOf(current?.optString("body").orEmpty()) }
    var commentsEnabled by remember(current?.optString("id")) { mutableStateOf(current?.optBoolean("comments_enabled", true) ?: true) }
    var pinned by remember(current?.optString("id")) { mutableStateOf(current?.optBoolean("pinned", false) ?: false) }
    AlertDialog(
        onDismissRequest = close,
        title = { Text(if (current != null) "تعديل المنشور" else if (roleCanManage(profile.role)) "منشور جديد" else "استفسار جديد") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    halaqas.forEach { h -> ProFilterChip(halaqaId == h.optString("id"), { halaqaId = h.optString("id") }, h.optString("name", "حلقة")) }
                }
                if (roleCanManage(profile.role)) {
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("discussion", "question", "achievement", "notice").forEach { v -> ProFilterChip(type == v, { type = v }, postTypeAr(v)) }
                    }
                }
                OutlinedTextField(title, { title = it }, label = { Text("العنوان") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(body, { body = it }, label = { Text("المحتوى") }, minLines = 3, modifier = Modifier.fillMaxWidth())
                Row(verticalAlignment = Alignment.CenterVertically) { Switch(commentsEnabled, { commentsEnabled = it }); Spacer(Modifier.width(8.dp)); Text("السماح بالتعليقات") }
                if (roleCanManage(profile.role)) Row(verticalAlignment = Alignment.CenterVertically) { Switch(pinned, { pinned = it }); Spacer(Modifier.width(8.dp)); Text("تثبيت المنشور") }
            }
        },
        confirmButton = { Button(onClick = { save(halaqaId, type, title.trim(), body.trim(), commentsEnabled, pinned) }, enabled = halaqaId.isNotBlank() && title.trim().length >= 2 && body.trim().length >= 2, modifier = Modifier.heightIn(min = 48.dp)) { Text(if (current == null) "نشر" else "حفظ") } },
        dismissButton = { TextButton(onClick = close) { Text("إلغاء") } },
    )
}

@Composable
private fun CommentDialog(close: () -> Unit, save: (String) -> Unit) {
    var body by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = close,
        title = { Text("إضافة تعليق") },
        text = { OutlinedTextField(body, { body = it }, label = { Text("التعليق") }, minLines = 2, modifier = Modifier.fillMaxWidth()) },
        confirmButton = { Button(onClick = { save(body.trim()) }, enabled = body.trim().isNotBlank()) { Text("إرسال") } },
        dismissButton = { TextButton(onClick = close) { Text("إلغاء") } },
    )
}

@Composable
private fun ConfirmDeleteDialog(title: String, message: String, close: () -> Unit, confirm: () -> Unit) {
    AlertDialog(
        onDismissRequest = close,
        icon = { Icon(Icons.Default.DeleteForever, contentDescription = null, tint = MaterialTheme.colorScheme.error) },
        title = { Text(title) },
        text = { Text(message) },
        confirmButton = {
            Button(
                onClick = confirm,
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                modifier = Modifier.heightIn(min = 48.dp),
            ) { Text("حذف") }
        },
        dismissButton = { TextButton(onClick = close, modifier = Modifier.heightIn(min = 48.dp)) { Text("إلغاء") } },
    )
}

@Composable
fun NotificationsNativeScreen(profile: Profile, pending: Int, onRefresh: () -> Unit) {
    val scope = rememberCoroutineScope()
    var rows by remember { mutableStateOf<List<JSONObject>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var unreadOnly by remember { mutableStateOf(false) }
    var preferences by remember { mutableStateOf<JSONObject?>(null) }
    var showPreferences by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }

    suspend fun reload() {
        loading = true
        try {
            val result = withContext(Dispatchers.IO) {
                val notifications = AppGraph.repo.table("notifications", "select=*&order=created_at.desc&limit=400").rows()
                val prefs = AppGraph.repo.table("notification_preferences", "select=*&user_id=eq.${profile.id}&limit=1").rows().firstOrNull()
                notifications to prefs
            }
            rows = result.first
            preferences = result.second ?: JSONObject()
                .put("user_id", profile.id)
                .put("push_enabled", true)
                .put("attendance", true)
                .put("recitation", true)
                .put("behavior", true)
                .put("announcements", true)
                .put("achievements", true)
            message = null
        } catch (e: Exception) { message = e.message ?: "تعذر تحميل الإشعارات" }
        finally { loading = false }
    }
    LaunchedEffect(Unit) { reload() }
    val shown = rows.filter { !unreadOnly || it.isNull("read_at") || it.optString("read_at").isBlank() }
    val unread = rows.count { it.isNull("read_at") || it.optString("read_at").isBlank() }

    Column {
        AppTopBar("الإشعارات", onRefresh = { scope.launch { reload() }; onRefresh() }, pending = pending)
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { showPreferences = true }, modifier = Modifier.size(48.dp)) {
                Icon(Icons.Default.Tune, contentDescription = "تفضيلات الإشعارات")
            }
            Spacer(Modifier.width(4.dp))
            ProFilterChip(unreadOnly, { unreadOnly = !unreadOnly }, "غير المقروءة ($unread)")
            Spacer(Modifier.weight(1f))
            if (unread > 0) TextButton(onClick = {
                scope.launch {
                    try {
                        withContext(Dispatchers.IO) {
                            rows.filter { it.isNull("read_at") || it.optString("read_at").isBlank() }.forEach { n ->
                                AppGraph.repo.patch("notifications", "id=eq.${n.optString("id")}", JSONObject().put("read_at", Instant.now().toString()), dedupe = "notification-read:${n.optString("id")}")
                            }
                        }
                        reload(); onRefresh()
                    } catch (e: Exception) { message = e.message }
                }
            }) { Text("تحديد الكل كمقروء") }
        }
        message?.let { StateNotice(it, kind = "error", modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)) }
        if (loading && rows.isEmpty()) LoadingSkeleton(rows = 4, modifier = Modifier.padding(12.dp))
        if (!loading && shown.isEmpty()) EmptyState("لا توجد إشعارات")
        LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(shown, key = { it.optString("id") }) { n ->
                val isUnread = n.isNull("read_at") || n.optString("read_at").isBlank()
                ElevatedCard(Modifier.fillMaxWidth()) {
                    ListItem(
                        headlineContent = { Text(n.optString("title", "إشعار"), fontWeight = if (isUnread) FontWeight.Bold else FontWeight.Medium) },
                        supportingContent = {
                            Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                Text(n.optString("body"), style = MaterialTheme.typography.bodyMedium)
                                Text(
                                    notificationKindAr(n.optString("kind")) + n.optString("created_at").takeIf { it.isNotBlank() }?.let { " · ${notificationTime(it)}" }.orEmpty(),
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            }
                        },
                        leadingContent = { Icon(notificationIcon(n.optString("kind")), contentDescription = null, tint = if (isUnread) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant) },
                        trailingContent = {
                            if (isUnread) {
                                BadgedBox(badge = { Badge() }) {
                                    IconButton(onClick = {
                                        scope.launch {
                                            try {
                                                withContext(Dispatchers.IO) {
                                                    AppGraph.repo.patch("notifications", "id=eq.${n.optString("id")}", JSONObject().put("read_at", Instant.now().toString()), dedupe = "notification-read:${n.optString("id")}")
                                                }
                                                reload()
                                            } catch (e: Exception) { message = e.message }
                                        }
                                    }, modifier = Modifier.size(HalaqatiUiTokens.TouchTarget)) { Icon(Icons.Default.Done, contentDescription = "تحديد كمقروء") }
                                }
                            }
                        },
                    )
                }
            }
        }
    }

    if (showPreferences) {
        NotificationPreferencesDialog(
            current = preferences,
            close = { showPreferences = false },
            save = { updated ->
                scope.launch {
                    try {
                        withContext(Dispatchers.IO) {
                            AppGraph.repo.write(
                                "notification_preferences",
                                updated.put("user_id", profile.id).put("updated_at", Instant.now().toString()),
                                onConflict = "user_id",
                                dedupe = "notification-preferences:${profile.id}",
                            )
                        }
                        preferences = updated
                        showPreferences = false
                        onRefresh()
                    } catch (e: Exception) { message = e.message ?: "تعذر حفظ تفضيلات الإشعارات" }
                }
            },
        )
    }
}

@Composable
internal fun NotificationPreferencesDialog(
    current: JSONObject?,
    close: () -> Unit,
    save: (JSONObject) -> Unit,
) {
    var push by remember(current?.toString()) { mutableStateOf(current?.optBoolean("push_enabled", true) ?: true) }
    var attendance by remember(current?.toString()) { mutableStateOf(current?.optBoolean("attendance", true) ?: true) }
    var recitation by remember(current?.toString()) { mutableStateOf(current?.optBoolean("recitation", true) ?: true) }
    var behavior by remember(current?.toString()) { mutableStateOf(current?.optBoolean("behavior", true) ?: true) }
    var announcements by remember(current?.toString()) { mutableStateOf(current?.optBoolean("announcements", true) ?: true) }
    var achievements by remember(current?.toString()) { mutableStateOf(current?.optBoolean("achievements", true) ?: true) }
    val rows = listOf(
        Triple("الإشعارات الفورية", "تشغيل أو إيقاف Push على هذا الحساب", push),
        Triple("الحضور والغياب", "تنبيهات الحضور والتأخر والغياب", attendance),
        Triple("التسميع", "نتائج الحفظ والمراجعة والسرد", recitation),
        Triple("السلوك والمتابعة", "ملاحظات السلوك والمتابعة اليومية", behavior),
        Triple("الإعلانات", "إعلانات الحلقة والمواعيد", announcements),
        Triple("الإنجازات", "الشهادات والإنجازات", achievements),
    )
    AlertDialog(
        onDismissRequest = close,
        title = { Text("تفضيلات الإشعارات") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                rows.forEachIndexed { index, row ->
                    val checked = row.third
                    ListItem(
                        headlineContent = { Text(row.first) },
                        supportingContent = { Text(row.second, style = MaterialTheme.typography.bodySmall) },
                        trailingContent = {
                            Switch(
                                checked = checked,
                                onCheckedChange = { value ->
                                    when (index) {
                                        0 -> push = value
                                        1 -> attendance = value
                                        2 -> recitation = value
                                        3 -> behavior = value
                                        4 -> announcements = value
                                        5 -> achievements = value
                                    }
                                },
                            )
                        },
                        modifier = Modifier.heightIn(min = 56.dp),
                    )
                }
                Text(
                    "إيقاف نوع معيّن لا يحذف الإشعارات الموجودة داخل التطبيق؛ بل يضبط التفضيلات المستخدمة عند الإرسال.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    save(
                        JSONObject()
                            .put("push_enabled", push)
                            .put("attendance", attendance)
                            .put("recitation", recitation)
                            .put("behavior", behavior)
                            .put("announcements", announcements)
                            .put("achievements", achievements),
                    )
                },
                modifier = Modifier.heightIn(min = 48.dp),
            ) { Text("حفظ") }
        },
        dismissButton = { TextButton(onClick = close, modifier = Modifier.heightIn(min = 48.dp)) { Text("إلغاء") } },
    )
}

private fun notificationTime(value: String): String = runCatching {
    Instant.parse(value).atZone(ZoneId.systemDefault()).format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm"))
}.getOrDefault(value.take(16).replace('T', ' '))

private fun notificationKindAr(v: String) = mapOf("attendance" to "الحضور", "recitation" to "التسميع", "behavior" to "السلوك", "announcement" to "إعلان", "achievement" to "إنجاز", "manual" to "إشعار", "system" to "النظام")[v] ?: "إشعار"
private fun notificationIcon(v: String) = when (v) {
    "attendance" -> Icons.Default.HowToReg
    "recitation" -> Icons.Default.MenuBook
    "behavior" -> Icons.Default.Psychology
    "announcement" -> Icons.Default.Campaign
    "achievement" -> Icons.Default.EmojiEvents
    "system" -> Icons.Default.Settings
    else -> Icons.Default.Notifications
}

private data class SupervisionFollowup(val student: Student, val reasons: List<String>, val score: Int)

private fun supervisionPlanCovers(plan: JSONObject, student: Student, today: String): Boolean {
    if (plan.optString("status") == "archived") return false
    val start = plan.optString("start_date")
    val end = plan.optString("end_date")
    if (start.isNotBlank() && start > today) return false
    if (end.isNotBlank() && end < today) return false
    if (plan.optString("halaqa_id") != student.halaqaId) return false
    val scope = plan.optString("scope_type", "student")
    val inScope = when (scope) {
        "halaqa" -> true
        "category" -> plan.optString("category_id").isNotBlank() && plan.optString("category_id") == student.categoryId
        else -> plan.optString("student_id") == student.id
    }
    if (!inScope) return false
    if (plan.optString("plan_type") != "hifz" || scope == "student") return true
    val ranges = plan.optJSONObject("settings")?.optJSONObject("student_ranges")
    return ranges?.has(student.id) == true
}

@Composable
fun SupervisionNativeScreen(profile: Profile, pending: Int, onRefresh: () -> Unit, navigate: (String) -> Unit) {
    val scope = rememberCoroutineScope()
    var sessions by remember { mutableStateOf<List<JSONObject>>(emptyList()) }
    var students by remember { mutableStateOf<List<Student>>(emptyList()) }
    var plans by remember { mutableStateOf<List<JSONObject>>(emptyList()) }
    var visits by remember { mutableStateOf<List<JSONObject>>(emptyList()) }
    var halaqas by remember { mutableStateOf<List<JSONObject>>(emptyList()) }
    var goals by remember { mutableStateOf<List<JSONObject>>(emptyList()) }
    var todayAttendance by remember { mutableStateOf<List<JSONObject>>(emptyList()) }
    var monthRecitations by remember { mutableStateOf<List<JSONObject>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var message by remember { mutableStateOf<String?>(null) }
    var addVisit by remember { mutableStateOf(false) }
    var selectedHalaqa by remember { mutableStateOf("all") }

    suspend fun reload() {
        loading = true
        try {
            val result = withContext(Dispatchers.IO) {
                val today = LocalDate.now().toString()
                val monthStart = LocalDate.now().withDayOfMonth(1).toString()
                val ses = AppGraph.repo.table("sessions", "select=*&order=session_date.desc&limit=300").rows()
                val st = AppGraph.repo.students()
                val pl = AppGraph.repo.table(
                    "smart_plans",
                    "select=id,scope_type,halaqa_id,student_id,category_id,plan_type,start_date,end_date,status,settings&status=neq.archived&limit=1000",
                ).rows()
                val vi = AppGraph.repo.table("supervisor_visits", "select=*&order=visit_date.desc&limit=300").rows()
                val ha = AppGraph.repo.table("halaqas", "select=id,name&active=eq.true&order=name.asc&limit=100").rows()
                val go = AppGraph.repo.table("student_goals", "select=*&period_start=lte.$today&period_end=gte.$today&limit=1000").rows()
                val todaySessionIds = ses.filter { it.optString("session_date") == today && it.optString("status") != "cancelled" }.map { it.optString("id") }.filter { it.isNotBlank() }
                val at = if (todaySessionIds.isEmpty()) emptyList() else AppGraph.repo.table(
                    "attendance_records",
                    "select=student_id,status&session_id=in.(${todaySessionIds.joinToString(",")})&limit=3000",
                ).rows()
                val rec = AppGraph.repo.reportRecitations(monthStart, today, "all").rows()
                listOf(ses, pl, vi, ha, go, at, rec) to st
            }
            sessions = result.first[0]
            plans = result.first[1]
            visits = result.first[2]
            halaqas = result.first[3]
            goals = result.first[4]
            todayAttendance = result.first[5]
            monthRecitations = result.first[6]
            students = result.second
            message = null
        } catch (e: Exception) { message = e.message ?: "تعذر تحميل المتابعة" }
        finally { loading = false }
    }
    LaunchedEffect(Unit) { reload() }

    val monthStart = LocalDate.now().withDayOfMonth(1).toString()
    val today = LocalDate.now().toString()
    val scopedSessions = sessions.filter { selectedHalaqa == "all" || it.optString("halaqa_id") == selectedHalaqa }
    val scopedVisits = visits.filter { selectedHalaqa == "all" || it.optString("halaqa_id") == selectedHalaqa }
    val monthSessions = scopedSessions.count { it.optString("session_date") in monthStart..today && it.optString("status") != "cancelled" }
    val activeStudents = students.filter { it.status == "active" && (selectedHalaqa == "all" || it.halaqaId == selectedHalaqa) }
    val activeStudentIds = activeStudents.map { it.id }.toSet()
    val hasPlan = activeStudents.associate { student -> student.id to plans.any { supervisionPlanCovers(it, student, today) } }
    val withoutPlan = activeStudents.count { hasPlan[it.id] != true }
    val sessionCountByHalaqa = scopedSessions
        .filter { it.optString("session_date") in monthStart..today && it.optString("status") != "cancelled" }
        .groupingBy { it.optString("halaqa_id") }
        .eachCount()
    val monthlyHifzByStudent = monthRecitations
        .filter { it.optString("activity_type") == "new_hifz" }
        .groupBy { it.optString("student_id") }
        .mapValues { (_, values) -> values.sumOf { it.optDouble("pages_count", 0.0) } }
    val absentIds = todayAttendance
        .filter { it.optString("status") == "absent" && it.optString("student_id") in activeStudentIds }
        .map { it.optString("student_id") }
        .toSet()
    val followup = activeStudents.mapNotNull { student ->
        val reasons = mutableListOf<String>()
        var score = 0
        if (student.id in absentIds) { reasons += "غائب اليوم"; score += 50 }
        if (hasPlan[student.id] != true) { reasons += "لا توجد خطة ذكية فعالة"; score += 30 }
        val goal = goals.firstOrNull { it.optString("student_id") == student.id }
        val target = goal?.optDouble("target_hifz_pages", 0.0) ?: 0.0
        if (target > 0.0) {
            val held = sessionCountByHalaqa[student.halaqaId] ?: 0
            val expectedDays = (goal?.optInt("expected_session_days", 20) ?: 20).coerceAtLeast(1)
            val expected = target * minOf(1.0, held.toDouble() / expectedDays.toDouble())
            val actual = monthlyHifzByStudent[student.id] ?: 0.0
            val gap = (expected - actual).coerceAtLeast(0.0)
            if (gap >= 0.5) {
                reasons += "متأخر ${plainNumber(gap)} ص عن وتيرة الشهر"
                score += minOf(20, kotlin.math.ceil(gap * 4.0).toInt())
            }
        }
        if (reasons.isEmpty()) null else SupervisionFollowup(student, reasons, score)
    }.sortedWith(compareByDescending<SupervisionFollowup> { it.score }.thenBy { it.student.fullName }).take(10)

    Column {
        AppTopBar("متابعة المحفّظ", onRefresh = { scope.launch { reload() }; onRefresh() }, pending = pending)
        message?.let { StateNotice(it, kind = "error", modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)) }
        if (loading && students.isEmpty()) LoadingSkeleton(rows = 3, modifier = Modifier.padding(12.dp))
        if (halaqas.isNotEmpty()) {
            Row(
                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                ProFilterChip(selectedHalaqa == "all", { selectedHalaqa = "all" }, "كل الحلقات")
                halaqas.forEach { h ->
                    val id = h.optString("id")
                    ProFilterChip(selectedHalaqa == id, { selectedHalaqa = id }, h.optString("name", "حلقة"))
                }
            }
        }
        LazyColumn(
            contentPadding = PaddingValues(start = 12.dp, end = 12.dp, top = 12.dp, bottom = 96.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    SmallStat("جلسات الشهر", monthSessions.toString(), Modifier.weight(1f))
                    SmallStat("بلا خطة", withoutPlan.toString(), Modifier.weight(1f))
                    SmallStat("الزيارات", scopedVisits.size.toString(), Modifier.weight(1f))
                }
            }
            item {
                ElevatedCard(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("يحتاج متابعة الآن", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                                Text("مرتبة حسب الأولوية التشغيلية", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Badge(containerColor = if (followup.isEmpty()) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.tertiary) { Text(followup.size.toString()) }
                        }
                        if (followup.isEmpty()) {
                            Text("✓ لا توجد حالات عاجلة في البيانات الحالية.", color = MaterialTheme.colorScheme.primary)
                        } else {
                            followup.forEach { row ->
                                Surface(color = MaterialTheme.colorScheme.surfaceVariant, shape = MaterialTheme.shapes.medium) {
                                    Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Text(row.student.fullName, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                                            Surface(color = MaterialTheme.colorScheme.tertiaryContainer, contentColor = MaterialTheme.colorScheme.onTertiaryContainer, shape = MaterialTheme.shapes.extraLarge) {
                                                Text("درجة ${row.score}", Modifier.padding(horizontal = 10.dp, vertical = 7.dp), style = MaterialTheme.typography.labelLarge)
                                            }
                                        }
                                        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                            row.reasons.forEach { reason -> StatusPill(reason, kind = "warning") }
                                        }
                                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                            TextButton(onClick = { navigate("students") }, modifier = Modifier.heightIn(min = 48.dp)) { Text("فتح الطلاب") }
                                            TextButton(onClick = { navigate("plans") }, modifier = Modifier.heightIn(min = 48.dp)) { Text("الخطة") }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            item {
                ElevatedCard(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("اختصارات العمل", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                        listOf(
                            Triple("الجلسات اليومية", "الحضور والتسميع", "sessions"),
                            Triple("الخطط الذكية", "المقرر والتأخر والتعويض", "plans"),
                            Triple("التقارير", "تقارير الحلقة والمسارات", "reports"),
                            Triple("الترتيب", "النقاط والإنجازات", "rankings"),
                            Triple("الطلاب", "ملفات الطلاب", "students"),
                            Triple("الإعلانات", "التواصل مع أولياء الأمور", "community"),
                        ).forEach { (title, sub, route) ->
                            OutlinedButton(onClick = { navigate(route) }, modifier = Modifier.fillMaxWidth().heightIn(min = HalaqatiUiTokens.TouchTarget), contentPadding = PaddingValues(12.dp)) {
                                Column(Modifier.weight(1f), horizontalAlignment = Alignment.Start) { Text(title, fontWeight = FontWeight.Bold); Text(sub, style = MaterialTheme.typography.labelSmall) }
                                Icon(Icons.Default.ChevronLeft, null)
                            }
                        }
                    }
                }
            }
            item {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text("زيارات المشرف", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    if (roleCanAdmin(profile.role)) Button(onClick = { addVisit = true }, modifier = Modifier.heightIn(min = HalaqatiUiTokens.TouchTarget)) { Text("إضافة زيارة") }
                }
            }
            if (!loading && scopedVisits.isEmpty()) item { EmptyState("لا توجد زيارات مسجلة للحلقة المختارة") }
            items(scopedVisits, key = { it.optString("id") }) { v ->
                val hName = halaqas.firstOrNull { it.optString("id") == v.optString("halaqa_id") }?.optString("name") ?: "حلقة"
                ElevatedCard(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row { Text(hName, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f)); Text(v.optString("visit_date"), style = MaterialTheme.typography.labelMedium) }
                        Text("التنظيم ${scoreText(v, "organization_score")} · التدريس ${scoreText(v, "teaching_score")} · المتابعة ${scoreText(v, "followup_score")}", style = MaterialTheme.typography.bodySmall)
                        if (v.optString("notes").isNotBlank()) Text(v.optString("notes"))
                        if (v.optString("action_items").isNotBlank()) Text("المتابعة: ${v.optString("action_items")}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
    }

    if (addVisit) {
        SupervisorVisitDialog(halaqas, close = { addVisit = false }) { halaqaId, org, teach, follow, notes, actions ->
            scope.launch {
                try {
                    withContext(Dispatchers.IO) {
                        val uid = AppGraph.repo.store.load()?.userId ?: error("الجلسة غير صالحة")
                        AppGraph.repo.write(
                            "supervisor_visits",
                            JSONObject()
                                .put("halaqa_id", halaqaId)
                                .put("supervisor_id", uid)
                                .put("visit_date", LocalDate.now().toString())
                                .put("organization_score", org)
                                .put("teaching_score", teach)
                                .put("followup_score", follow)
                                .put("notes", notes.takeIf { it.isNotBlank() } ?: JSONObject.NULL)
                                .put("action_items", actions.takeIf { it.isNotBlank() } ?: JSONObject.NULL),
                            dedupe = "supervisor-visit:$uid:$halaqaId:${LocalDate.now()}:${System.currentTimeMillis()}",
                        )
                    }
                    addVisit = false; reload(); onRefresh()
                } catch (e: Exception) { message = e.message }
            }
        }
    }
}

private fun scoreText(v: JSONObject, key: String): String = if (v.isNull(key) || !v.has(key)) "—" else "${v.optInt(key)}/5"

@Composable
private fun SupervisorVisitDialog(halaqas: List<JSONObject>, close: () -> Unit, save: (String, Int, Int, Int, String, String) -> Unit) {
    var halaqaId by remember { mutableStateOf(halaqas.firstOrNull()?.optString("id").orEmpty()) }
    var org by remember { mutableIntStateOf(3) }
    var teach by remember { mutableIntStateOf(3) }
    var follow by remember { mutableIntStateOf(3) }
    var notes by remember { mutableStateOf("") }
    var actions by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = close,
        title = { Text("زيارة إشرافية") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) { halaqas.forEach { h -> ProFilterChip(halaqaId == h.optString("id"), { halaqaId = h.optString("id") }, h.optString("name", "حلقة")) } }
                ScorePicker("التنظيم", org) { org = it }
                ScorePicker("التدريس", teach) { teach = it }
                ScorePicker("المتابعة", follow) { follow = it }
                OutlinedTextField(notes, { notes = it }, label = { Text("ملاحظات") }, minLines = 2, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(actions, { actions = it }, label = { Text("بنود المتابعة") }, minLines = 2, modifier = Modifier.fillMaxWidth())
            }
        },
        confirmButton = {
            Button(
                onClick = { save(halaqaId, org, teach, follow, notes.trim(), actions.trim()) },
                enabled = halaqaId.isNotBlank(),
                modifier = Modifier.heightIn(min = HalaqatiUiTokens.TouchTarget),
            ) { Text("حفظ") }
        },
        dismissButton = { TextButton(onClick = close, modifier = Modifier.heightIn(min = HalaqatiUiTokens.TouchTarget)) { Text("إلغاء") } },
    )
}

@Composable
private fun ScorePicker(label: String, value: Int, onChange: (Int) -> Unit) {
    Column {
        Text("$label: $value/5", style = MaterialTheme.typography.labelLarge)
        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            (1..5).forEach { n -> ProFilterChip(value == n, { onChange(n) }, n.toString()) }
        }
    }
}

private data class GuardianAnalyticsRow(
    val student: Student,
    val month: JSONObject,
    val trend: JSONObject,
    val today: JSONObject,
    val plan: PlanSnapshot?,
)

@Composable
fun GuardianProfileNativeScreen(
    profile: Profile,
    online: Boolean,
    pending: Int,
    onRefresh: () -> Unit,
    initialStudentId: String? = null,
) {
    val scope = rememberCoroutineScope()
    var rows by remember { mutableStateOf<List<GuardianAnalyticsRow>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var message by remember { mutableStateOf<String?>(null) }
    var trendDays by remember { mutableIntStateOf(7) }

    suspend fun reload() {
        if (!online) {
            loading = false
            if (rows.isEmpty()) message = "لا يوجد اتصال بالإنترنت. ستظهر بيانات ولي الأمر بعد استعادة الاتصال."
            return
        }
        loading = true
        try {
            rows = withContext(Dispatchers.IO) {
                val students = AppGraph.repo.students().filter { it.status == "active" }
                val snapshots = AppGraph.repo.planSnapshots()
                val monthStart = LocalDate.now().withDayOfMonth(1).toString()
                val monthEnd = LocalDate.now().toString()
                val trendStart = LocalDate.now().minusDays(29).toString()
                students.map { student ->
                    val month = AppGraph.repo.guardianDashboard(student.id, monthStart, monthEnd)
                    val trend = AppGraph.repo.guardianDashboard(student.id, trendStart, monthEnd)
                    val today = AppGraph.repo.guardianDashboard(student.id, monthEnd, monthEnd)
                    val plan = snapshots
                        .filter { it.student.id == student.id }
                        .sortedBy { if (it.plan.type == "hifz") 0 else 1 }
                        .firstOrNull()
                    GuardianAnalyticsRow(student, month, trend, today, plan)
                }.sortedWith(
                    compareBy<GuardianAnalyticsRow> { if (it.student.id == initialStudentId) 0 else 1 }
                        .thenBy { it.student.fullName },
                )
            }
            message = null
        } catch (e: Exception) {
            message = e.message ?: "تعذر تحميل ملف الطالب"
        } finally {
            loading = false
        }
    }
    LaunchedEffect(online, initialStudentId) { reload() }

    Column {
        AppTopBar(
            if (profile.role == UserRole.GUARDIAN) "متابعة أبنائي" else "ملف الطالب",
            onRefresh = { scope.launch { reload() }; onRefresh() },
            pending = pending,
        )
        if (!online) {
            StateNotice(
                "وضع عدم الاتصال: لن تُعرض تحديثات جديدة حتى استعادة الشبكة، ولن تُعرض نتيجة قديمة على أنها محدثة.",
                kind = "warning",
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
            )
        }
        message?.let { StateNotice(it, kind = if (online) "error" else "warning", modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)) }
        if (loading && rows.isEmpty()) LoadingSkeleton(rows = 3, modifier = Modifier.padding(12.dp))
        LazyColumn(
            contentPadding = PaddingValues(start = 12.dp, end = 12.dp, top = 12.dp, bottom = 96.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item {
                ElevatedCard(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(
                            if (profile.role == UserRole.GUARDIAN) "ملخص المتابعة" else "ملخص الأداء",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                        )
                        Text(
                            "الحفظ والحضور والترتيب وجودة التسميع وإنجاز الخطة من البيانات الفعلية.",
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            style = MaterialTheme.typography.bodyMedium,
                        )
                    }
                }
            }
            if (!loading && rows.isEmpty()) item { EmptyState("لا توجد ملفات طلاب مرتبطة بهذا الحساب") }
            items(rows, key = { it.student.id }) { row ->
                GuardianAnalyticsCard(row, trendDays, onTrendDays = { trendDays = it })
            }
        }
    }
}

@Composable
private fun GuardianAnalyticsCard(
    row: GuardianAnalyticsRow,
    trendDays: Int,
    onTrendDays: (Int) -> Unit,
) {
    val student = row.student
    val ranks = row.month.optJSONObject("ranks") ?: JSONObject()
    val hifz = ranks.optJSONObject("hifz") ?: JSONObject()
    val attendance = row.month.optJSONObject("attendance") ?: JSONObject()
    val hifzPages = hifz.optDouble("pages", 0.0)
    val present = attendance.optInt("present", 0)
    val safety = latestGuardianSafety(row.trend)
    val planProgress = row.plan?.progress
    val categoryRank = guardianRankText(hifz, "category")
    val halaqaRank = guardianRankText(hifz, "halaqa")
    val planText = planProgress?.let { "${guardianNumber(it.completed)} / ${guardianNumber(it.completed + it.remaining)} ص" } ?: "—"

    ElevatedCard(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.AccountCircle, contentDescription = null, modifier = Modifier.size(42.dp), tint = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(student.fullName, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text(
                        if (student.track == "tathbit") "مسار التثبيت" else "مسار الحفظ العام",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }

            GuardianTodayAlert(row.today)

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                GuardianMetric("حفظ الشهر", "${guardianNumber(hifzPages)} ص", Modifier.weight(1f))
                GuardianMetric("الحضور", present.toString(), Modifier.weight(1f))
                GuardianMetric("ترتيب الفئة", categoryRank, Modifier.weight(1f))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                GuardianMetric("ترتيب الحلقة", halaqaRank, Modifier.weight(1f))
                GuardianMetric("جودة آخر تسميع", safety?.let { "${guardianNumber(it)}%" } ?: "—", Modifier.weight(1f))
                GuardianMetric("إنجاز الخطة", planText, Modifier.weight(1f))
            }

            Surface(color = MaterialTheme.colorScheme.primaryContainer, shape = MaterialTheme.shapes.medium) {
                Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.Top) {
                    Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Spacer(Modifier.width(8.dp))
                    Column {
                        Text("ملخص المتابعة", fontWeight = FontWeight.Bold)
                        Text(
                            guardianSummary(row),
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onPrimaryContainer,
                        )
                    }
                }
            }

            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("تطور الحفظ", fontWeight = FontWeight.Bold)
                        Text("صفحات التسميع يومًا بيوم", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        listOf(7, 14, 30).forEach { days ->
                            ProFilterChip(trendDays == days, { onTrendDays(days) }, days.toString())
                        }
                    }
                }
                GuardianTrend(row.trend, trendDays)
            }

            row.plan?.let { snapshot ->
                val a = snapshot.progress.assignment
                Surface(color = MaterialTheme.colorScheme.surfaceVariant, shape = MaterialTheme.shapes.medium) {
                    Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.MenuBook, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            Spacer(Modifier.width(8.dp))
                            Text("خطة اليوم", fontWeight = FontWeight.Bold)
                        }
                        Text(
                            when {
                                a.milestone != null -> a.milestone.label
                                a.pages > 0.0 -> "${guardianNumber(a.pages)} صفحة · ${guardianPageRange(a.startPage, a.endPage)}"
                                snapshot.progress.remaining <= 0.0 -> "تم إكمال الخطة"
                                else -> "لا يوجد مقرر اليوم"
                            },
                            style = MaterialTheme.typography.bodyMedium,
                        )
                        if (snapshot.progress.behindBy > 0.0) {
                            Text(
                                "متأخر ${guardianNumber(snapshot.progress.behindBy)} صفحة، والتعويض موزع على الأيام القادمة.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.error,
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun GuardianTodayAlert(todayDashboard: JSONObject) {
    val attendance = todayDashboard.optJSONObject("attendance") ?: JSONObject()
    val daily = todayDashboard.optJSONArray("daily") ?: JSONArray()
    val today = LocalDate.now().toString()
    val activity = (0 until daily.length())
        .mapNotNull { daily.optJSONObject(it) }
        .firstOrNull { it.optString("date") == today }
    val present = attendance.optInt("present", 0)
    val absent = attendance.optInt("absent", 0)
    val excused = attendance.optInt("excused", 0)
    val late = attendance.optInt("late", 0)
    val hifz = activity?.optDouble("hifz", 0.0) ?: 0.0
    val review = activity?.optDouble("review", 0.0) ?: 0.0
    val sard = activity?.optDouble("sard", 0.0) ?: 0.0
    val hasRecitation = hifz > 0.0 || review > 0.0 || sard > 0.0
    val attendanceText = when {
        late > 0 -> "متأخر"
        present > 0 -> "حاضر"
        excused > 0 -> "غائب بعذر"
        absent > 0 -> "غائب"
        else -> "لم يُسجل الحضور بعد"
    }
    val kind = when {
        absent > 0 -> "error"
        excused > 0 || late > 0 -> "warning"
        present > 0 && hasRecitation -> "success"
        else -> "info"
    }
    val detail = buildList {
        add(attendanceText)
        if (hifz > 0.0) add("حفظ ${guardianNumber(hifz)} ص")
        if (review > 0.0) add("مراجعة ${guardianNumber(review)} ص")
        if (sard > 0.0) add("سرد ${guardianNumber(sard)} ص")
        activity?.takeIf { !it.isNull("safety") }?.optDouble("safety")?.let { add("جودة ${guardianNumber(it)}%") }
    }.joinToString(" · ")
    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = when (kind) {
            "error" -> MaterialTheme.colorScheme.errorContainer
            "warning" -> MaterialTheme.colorScheme.tertiaryContainer
            "success" -> MaterialTheme.colorScheme.primaryContainer
            else -> MaterialTheme.colorScheme.secondaryContainer
        },
        contentColor = when (kind) {
            "error" -> MaterialTheme.colorScheme.onErrorContainer
            "warning" -> MaterialTheme.colorScheme.onTertiaryContainer
            "success" -> MaterialTheme.colorScheme.onPrimaryContainer
            else -> MaterialTheme.colorScheme.onSecondaryContainer
        },
        shape = MaterialTheme.shapes.medium,
    ) {
        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(
                when {
                    absent > 0 -> Icons.Default.EventBusy
                    present > 0 && hasRecitation -> Icons.Default.CheckCircle
                    else -> Icons.Default.Today
                },
                contentDescription = null,
            )
            Spacer(Modifier.width(8.dp))
            Column(Modifier.weight(1f)) {
                Text("حالة اليوم", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                Text(detail.ifBlank { "لم يُسجل نشاط اليوم بعد" }, style = MaterialTheme.typography.bodyMedium)
            }
        }
    }
}

@Composable
private fun GuardianMetric(label: String, value: String, modifier: Modifier = Modifier) {
    Surface(modifier, color = MaterialTheme.colorScheme.surfaceVariant, shape = MaterialTheme.shapes.medium) {
        Column(Modifier.padding(horizontal = 7.dp, vertical = 10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(value, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Text(label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun GuardianTrend(dashboard: JSONObject, days: Int) {
    val daily = dashboard.optJSONArray("daily") ?: JSONArray()
    val byDate = (0 until daily.length()).mapNotNull { daily.optJSONObject(it) }.associateBy { it.optString("date") }
    val end = LocalDate.now()
    val series = (days - 1 downTo 0).map { offset ->
        val date = end.minusDays(offset.toLong())
        date to (byDate[date.toString()]?.optDouble("hifz", 0.0) ?: 0.0)
    }
    val total = series.sumOf { it.second }
    val max = series.maxOfOrNull { it.second }?.coerceAtLeast(1.0) ?: 1.0
    Text(
        "إجمالي الفترة ${guardianNumber(total)} ص · أيام الحفظ ${series.count { it.second > 0.0 }}",
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
    )
    Row(
        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalAlignment = Alignment.Bottom,
    ) {
        series.forEach { (date, value) ->
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Box(Modifier.width(14.dp).height(72.dp), contentAlignment = Alignment.BottomCenter) {
                    val height = if (value <= 0.0) 2.dp else (8 + (56 * (value / max))).dp
                    Box(
                        Modifier.width(12.dp).height(height).background(
                            if (value > 0.0) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant,
                        ),
                    )
                }
                val showLabel = days <= 7 || date == end || date.dayOfMonth % 7 == 0
                Text(if (showLabel) date.dayOfMonth.toString() else "", style = MaterialTheme.typography.labelSmall)
            }
        }
    }
}

private fun guardianRankText(metric: JSONObject, scope: String): String {
    val pages = metric.optDouble("pages", 0.0)
    val rank = metric.optInt("${scope}_rank", 0)
    val total = metric.optInt("${scope}_total", 0)
    return if (pages > 0.0 && rank > 0 && total > 0) "$rank / $total" else "—"
}

private fun latestGuardianSafety(dashboard: JSONObject): Double? {
    val daily = dashboard.optJSONArray("daily") ?: return null
    for (index in daily.length() - 1 downTo 0) {
        val row = daily.optJSONObject(index) ?: continue
        if (row.has("safety") && !row.isNull("safety")) return row.optDouble("safety")
    }
    return null
}

private fun guardianSummary(row: GuardianAnalyticsRow): String {
    val p = row.plan?.progress
    val hifz = row.month.optJSONObject("ranks")?.optJSONObject("hifz")?.optDouble("pages", 0.0) ?: 0.0
    val attendance = row.month.optJSONObject("attendance") ?: JSONObject()
    val absent = attendance.optInt("absent", 0)
    return when {
        p != null && p.health == "red" -> "الخطة تحتاج تدخلاً: يوجد تأخر ${guardianNumber(p.behindBy)} صفحة. يُفضّل الالتزام بالمقرر والتعويض الموزع."
        p != null && p.health == "yellow" -> "التقدم قريب من المطلوب، لكن توجد فجوة ${guardianNumber(p.behindBy)} صفحة تحتاج متابعة خلال الأيام القادمة."
        hifz <= 0.0 -> "لا توجد صفحات حفظ مسجلة في هذا الشهر حتى الآن."
        absent >= 3 -> "التقدم المسجل ${guardianNumber(hifz)} صفحة، مع $absent أيام غياب تحتاج متابعة."
        p != null -> "التقدم مستقر: ${guardianNumber(hifz)} صفحة حفظ هذا الشهر، وإنجاز الخطة ${guardianNumber(p.percentage)}%."
        else -> "تم تسجيل ${guardianNumber(hifz)} صفحة حفظ هذا الشهر."
    }
}

private fun guardianNumber(value: Double): String {
    val rounded = kotlin.math.round(value * 100.0) / 100.0
    return if (kotlin.math.abs(rounded - rounded.toInt()) < 0.000001) rounded.toInt().toString()
    else rounded.toString().trimEnd('0').trimEnd('.')
}

private fun guardianPageRange(start: Int?, end: Int?): String =
    if (start == null && end == null) "حسب الخطة" else RecitationParityRules.pageRangeQuranLabel(start, end)

