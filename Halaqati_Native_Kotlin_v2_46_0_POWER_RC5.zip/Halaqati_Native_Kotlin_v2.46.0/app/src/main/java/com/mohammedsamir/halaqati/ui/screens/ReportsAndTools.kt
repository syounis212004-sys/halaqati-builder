@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.mohammedsamir.halaqati.ui.screens

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.provider.Settings
import android.text.Layout
import android.text.StaticLayout
import android.text.TextDirectionHeuristics
import android.text.TextPaint
import android.util.Base64
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.res.ResourcesCompat
import com.mohammedsamir.halaqati.R
import com.mohammedsamir.halaqati.BuildConfig
import com.mohammedsamir.halaqati.data.AppGraph
import com.mohammedsamir.halaqati.data.ImportRules
import com.mohammedsamir.halaqati.data.LocalAccountScopeRules
import com.mohammedsamir.halaqati.data.SafetyScoring
import com.mohammedsamir.halaqati.data.StudentTrackRules
import com.mohammedsamir.halaqati.data.ThemeMode
import com.mohammedsamir.halaqati.data.UiDensity
import com.mohammedsamir.halaqati.model.Profile
import com.mohammedsamir.halaqati.model.UserRole
import com.mohammedsamir.halaqati.quran.QuranMetadata
import com.mohammedsamir.halaqati.ui.components.AppTopBar
import com.mohammedsamir.halaqati.ui.components.EmptyState
import com.mohammedsamir.halaqati.ui.components.MetricCard
import com.mohammedsamir.halaqati.ui.components.GoldenFeatureHero
import com.mohammedsamir.halaqati.ui.components.LoadingSkeleton
import com.mohammedsamir.halaqati.ui.components.ProFilterChip
import com.mohammedsamir.halaqati.ui.components.StateNotice
import com.mohammedsamir.halaqati.ui.components.StatusPill
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.time.LocalDate
import java.time.YearMonth
import java.util.zip.ZipInputStream
import javax.xml.parsers.DocumentBuilderFactory

@Composable
fun ReportsScreen(profile: Profile, pending: Int, onRefresh: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var summaryRows by remember { mutableStateOf<List<JSONObject>>(emptyList()) }
    var detailRows by remember { mutableStateOf<List<JSONObject>>(emptyList()) }
    var reportView by remember { mutableStateOf("summary") }
    var mode by remember { mutableStateOf("month") }
    var track by remember { mutableStateOf("all") }
    var halaqas by remember { mutableStateOf<List<JSONObject>>(emptyList()) }
    var halaqaId by remember { mutableStateOf("all") }
    var sessionType by remember { mutableStateOf("all") }
    var from by remember { mutableStateOf(YearMonth.now().atDay(1).toString()) }
    var to by remember { mutableStateOf(LocalDate.now().toString()) }
    var loading by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("") }
    var reportStyle by remember { mutableStateOf(NativeReportStyle()) }
    var monthComparison by remember { mutableStateOf<MonthComparison?>(null) }

    fun applyMode(value: String) {
        mode = value
        when (value) {
            "day" -> { from = LocalDate.now().toString(); to = LocalDate.now().toString() }
            "month" -> { from = YearMonth.now().atDay(1).toString(); to = YearMonth.now().atEndOfMonth().toString() }
        }
    }

    suspend fun reload() {
        val start = runCatching { LocalDate.parse(from) }.getOrNull()
        val end = runCatching { LocalDate.parse(to) }.getOrNull()
        if (start == null || end == null || start > end) { message = "تأكد من تاريخ البداية والنهاية"; return }
        loading = true; message = ""
        try {
            val triple = withContext(Dispatchers.IO) {
                val currentSummary = AppGraph.repo.reportSummary(start.toString(), end.toString(), track, halaqaId, sessionType)
                val details = AppGraph.repo.reportRecitations(start.toString(), end.toString(), track, halaqaId, sessionType)
                val previousSummary = if (mode == "month") {
                    val ym = YearMonth.from(start)
                    val prev = ym.minusMonths(1)
                    AppGraph.repo.reportSummary(prev.atDay(1).toString(), prev.atEndOfMonth().toString(), track, halaqaId, sessionType)
                } else JSONArray()
                Triple(currentSummary, details, previousSummary)
            }
            summaryRows = (0 until triple.first.length()).mapNotNull { triple.first.optJSONObject(it) }
            detailRows = (0 until triple.second.length()).mapNotNull { triple.second.optJSONObject(it) }
            monthComparison = if (mode == "month") buildMonthComparison(triple.first, triple.third) else null
            NativeReportCache.save(context, NativeReportCache.key(profile.id, from, to, track, halaqaId, sessionType), summaryRows, detailRows)
            message = "تم تجهيز التقرير من الخادم: ${summaryRows.size} طالب · ${detailRows.size} تسميع"
        } catch (e: Exception) {
            monthComparison = null
            val cached = NativeReportCache.load(context, NativeReportCache.key(profile.id, from, to, track, halaqaId, sessionType))
            if (cached != null) {
                summaryRows = cached.summary
                detailRows = cached.details
                message = "تعذر الوصول للخادم؛ هذه آخر نسخة كاملة محفوظة للتقرير · ${cached.savedAt}"
            } else {
                message = "تعذر تجهيز التقرير: ${e.message ?: "خطأ"}"
            }
        } finally { loading = false }
    }

    val createPdf = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
        if (uri != null) scope.launch {
            try {
                withContext(Dispatchers.IO) {
                    val halaqaLabel = if (halaqaId == "all") "جميع الحلقات" else halaqas.firstOrNull { it.optString("id") == halaqaId }?.optString("name", "حلقة") ?: "حلقة"
                    if (reportView == "summary") {
                        ReportStudioPdf.exportSummary(context, uri, summaryRows, reportStyle.copy(title = reportStyle.title.ifBlank { "تقرير الحلقة · $halaqaLabel" }), from, to, track)
                    } else {
                        ReportStudioPdf.exportDetails(context, uri, detailRows, reportStyle.copy(title = reportStyle.title.ifBlank { "تفاصيل التسميعات · $halaqaLabel" }), from, to, track)
                    }
                }
                message = "تم إنشاء تقرير PDF Native"
            } catch (e: Exception) { message = "تعذر إنشاء PDF: ${e.message ?: "خطأ"}" }
        }
    }

    fun exportTable(): NativeReportExport.Table = NativeReportExport.table(
        if (reportView == "summary") summaryRows else detailRows,
        details = reportView == "details",
    )
    fun exportTitle(): String = reportStyle.title.ifBlank {
        if (reportView == "summary") "تقرير حلقتي" else "تفاصيل التسميعات · حلقتي"
    }
    fun exportSubtitle(): String = "الفترة: $from — $to · ${when (track) { "general_hifz" -> "الحفظ العام"; "tathbit" -> "التثبيت"; else -> "جميع المسارات" }}"
    val createReportXlsx = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"),
    ) { uri ->
        if (uri != null) scope.launch {
            runCatching { withContext(Dispatchers.IO) { NativeReportExport.exportXlsx(context, uri, exportTable()) } }
                .onSuccess { message = "تم تصدير التقرير Excel" }
                .onFailure { message = "تعذر تصدير Excel: ${it.message ?: "خطأ"}" }
        }
    }
    val createReportWord = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/msword"),
    ) { uri ->
        if (uri != null) scope.launch {
            runCatching { withContext(Dispatchers.IO) { NativeReportExport.exportWord(context, uri, exportTable(), exportTitle(), exportSubtitle()) } }
                .onSuccess { message = "تم تصدير التقرير Word" }
                .onFailure { message = "تعذر تصدير Word: ${it.message ?: "خطأ"}" }
        }
    }
    val createReportPng = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("image/png"),
    ) { uri ->
        if (uri != null) scope.launch {
            runCatching { withContext(Dispatchers.IO) { NativeReportExport.exportPng(context, uri, exportTable(), exportTitle(), exportSubtitle()) } }
                .onSuccess { message = "تم تصدير التقرير صورة PNG" }
                .onFailure { message = "تعذر تصدير الصورة: ${it.message ?: "خطأ"}" }
        }
    }

    LaunchedEffect(profile.id) {
        runCatching {
            withContext(Dispatchers.IO) {
                val data = AppGraph.repo.table("halaqas", "select=id,name,active&active=eq.true&order=name.asc&limit=100")
                (0 until data.length()).mapNotNull { data.optJSONObject(it) }
            }
        }.onSuccess { halaqas = it }
        reload()
    }

    val totalPages = summaryRows.sumOf { it.optDouble("total_pages", 0.0) }
    val totalPresent = summaryRows.sumOf { it.optInt("present", 0) + it.optInt("late", 0) }
    val totalAbsent = summaryRows.sumOf { it.optInt("absent", 0) }

    Column {
        AppTopBar(if (profile.role == UserRole.GUARDIAN) "تقارير أولياء الأمور" else "التقارير", onRefresh = { scope.launch { reload() }; onRefresh() }, pending = pending)
        GoldenFeatureHero(
            title = "استوديو التقارير",
            subtitle = if (profile.role == UserRole.GUARDIAN) "تقارير أولياء الأمور للأبناء المرتبطين: يومية وشهرية وفترات مخصصة." else "تقارير يومية أو لفترة أو لشهر مع فصل مسار الحفظ العام عن مسار التثبيت وترتيب مستقل لكل مسار.",
            badge = "PDF Vector",
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
        )
        monthComparison?.let { cmp ->
            ElevatedCard(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        "هذا الشهر مقابل الشهر الماضي · ${if (track == "tathbit") "مسار التثبيت" else if (track == "general_hifz") "مسار الحفظ العام" else "كل المسارات"}",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                    )
                    MonthComparisonRow("الحفظ / التثبيت", cmp.previousPages, cmp.currentPages, " ص", positiveUp = true)
                    HorizontalDivider()
                    MonthComparisonRow("الغياب", cmp.previousAbsent.toDouble(), cmp.currentAbsent.toDouble(), "", positiveUp = false)
                    HorizontalDivider()
                    MonthComparisonRow("السلامة", cmp.previousSafety, cmp.currentSafety, "%", positiveUp = true)
                }
            }
        }
        Column(Modifier.padding(horizontal = 12.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            ReportStudioControls(
                style = reportStyle,
                detailsMode = reportView == "details",
                onChange = { reportStyle = it },
            )
            ReportLivePreview(
                style = reportStyle,
                detailsMode = reportView == "details",
                summaryRows = summaryRows,
                detailRows = detailRows,
                from = from,
                to = to,
                track = track,
            )
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("day" to "اليوم", "month" to "الشهر", "custom" to "فترة").forEach { (value, label) ->
                    ProFilterChip(selected = mode == value, onClick = { applyMode(value) }, label = label)
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = from, onValueChange = { from = it; mode = "custom" }, label = { Text("من") }, modifier = Modifier.weight(1f), singleLine = true)
                OutlinedTextField(value = to, onValueChange = { to = it; mode = "custom" }, label = { Text("إلى") }, modifier = Modifier.weight(1f), singleLine = true)
            }
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("all" to "جميع المسارات", "general_hifz" to "الحفظ العام", "tathbit" to "التثبيت").forEach { (value, label) ->
                    ProFilterChip(selected = track == value, onClick = { track = value }, label = label)
                }
            }
            Text("الحلقة", style = MaterialTheme.typography.labelLarge)
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                ProFilterChip(selected = halaqaId == "all", onClick = { halaqaId = "all" }, label = "جميع الحلقات")
                halaqas.forEach { h ->
                    val id = h.optString("id")
                    ProFilterChip(selected = halaqaId == id, onClick = { halaqaId = id }, label = h.optString("name", "حلقة"))
                }
            }
            Text("نوع اللقاء", style = MaterialTheme.typography.labelLarge)
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf(
                    "all" to "كل الأنواع", "tasmee" to "تسميع", "sard" to "سرد", "review" to "مراجعة",
                    "test" to "اختبار", "tajweed" to "تجويد", "lesson" to "درس", "other" to "أخرى",
                ).forEach { (value, label) ->
                    ProFilterChip(selected = sessionType == value, onClick = { sessionType = value }, label = label)
                }
            }
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                ProFilterChip(selected = reportView == "summary", onClick = { reportView = "summary"; reportStyle = reportStyle.copy(visibleColumns = setOf("rank","student","category","hifz","tathbit","review","sard","attendance","absence","points")) }, label = "ملخص الطلاب")
                ProFilterChip(selected = reportView == "details", onClick = { reportView = "details"; reportStyle = reportStyle.copy(visibleColumns = setOf("rank","student","date","activity","pages","evaluation","safety")) }, label = "تفاصيل التسميعات")
            }
            val hasReportData = !loading && if (reportView == "summary") summaryRows.isNotEmpty() else detailRows.isNotEmpty()
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { scope.launch { reload() } }, enabled = !loading, modifier = Modifier.heightIn(min = 48.dp)) {
                    Icon(Icons.Default.Refresh, contentDescription = null); Spacer(Modifier.width(6.dp)); Text("تجهيز")
                }
                Button(
                    onClick = { createPdf.launch("تقرير_حلقتي_${if (reportView == "summary") "ملخص" else "تفاصيل"}_${from}_إلى_${to}.pdf") },
                    enabled = hasReportData,
                    modifier = Modifier.heightIn(min = 48.dp),
                ) { Icon(Icons.Default.PictureAsPdf, contentDescription = null); Spacer(Modifier.width(6.dp)); Text("PDF") }
                OutlinedButton(
                    onClick = { createReportXlsx.launch("تقرير_حلقتي_${from}_إلى_${to}.xlsx") },
                    enabled = hasReportData,
                    modifier = Modifier.heightIn(min = 48.dp),
                ) { Icon(Icons.Default.TableView, contentDescription = null); Spacer(Modifier.width(6.dp)); Text("Excel") }
                OutlinedButton(
                    onClick = { createReportWord.launch("تقرير_حلقتي_${from}_إلى_${to}.doc") },
                    enabled = hasReportData,
                    modifier = Modifier.heightIn(min = 48.dp),
                ) { Icon(Icons.Default.Description, contentDescription = null); Spacer(Modifier.width(6.dp)); Text("Word") }
                OutlinedButton(
                    onClick = { createReportPng.launch("تقرير_حلقتي_${from}_إلى_${to}.png") },
                    enabled = hasReportData,
                    modifier = Modifier.heightIn(min = 48.dp),
                ) { Icon(Icons.Default.Image, contentDescription = null); Spacer(Modifier.width(6.dp)); Text("صورة") }
                OutlinedButton(
                    onClick = { NativeReportExport.shareText(context, exportTable(), exportTitle(), exportSubtitle()) },
                    enabled = hasReportData,
                    modifier = Modifier.heightIn(min = 48.dp),
                ) { Icon(Icons.Default.Share, contentDescription = null); Spacer(Modifier.width(6.dp)); Text("مشاركة") }
            }
            if (loading) LinearProgressIndicator(Modifier.fillMaxWidth())
            if (message.isNotBlank()) {
                StateNotice(
                    text = message,
                    kind = if (message.startsWith("تعذر")) "error" else if (message.startsWith("تم")) "success" else "info",
                )
            }
        }

        if (loading && summaryRows.isEmpty() && detailRows.isEmpty()) {
            LoadingSkeleton(rows = 4, modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp))
        }

        if (reportView == "summary") {
            if (!loading && summaryRows.isEmpty()) EmptyState("لا يوجد طلاب متاحون للمسار المحدد")
            if (summaryRows.isNotEmpty()) {
                Row(Modifier.padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Box(Modifier.weight(1f)) { MetricCard("الطلاب", summaryRows.size.toString(), "يشمل أصحاب النشاط الصفري") }
                    Box(Modifier.weight(1f)) { MetricCard("الصفحات", formatNumber(totalPages), "جميع الأنشطة") }
                }
                Row(Modifier.padding(horizontal = 12.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Box(Modifier.weight(1f)) { MetricCard("الحضور", totalPresent.toString(), "حاضر + متأخر") }
                    Box(Modifier.weight(1f)) { MetricCard("الغياب", totalAbsent.toString(), "بدون المعذور") }
                }
            }
            LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                itemsIndexed(summaryRows, key = { _, item -> item.optString("student_id").ifBlank { item.optString("student_name") } }, contentType = { _, _ -> "report_summary" }) { index, item ->
                    ElevatedCard(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("${index + 1}. ${item.optString("student_name", "طالب")}", fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                                Text(formatNumber(item.optDouble("points", 0.0)) + " نقطة", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                            }
                            val primary = if (item.optString("track_code") == "tathbit") "تثبيت ${formatNumber(item.optDouble("tathbit_pages", 0.0))}" else "حفظ ${formatNumber(item.optDouble("hifz_pages", 0.0))}"
                            Text("$primary · مراجعة ${formatNumber(item.optDouble("review_pages", 0.0))} · سرد ${formatNumber(item.optDouble("sard_pages", 0.0))}", style = MaterialTheme.typography.bodyMedium)
                            Text("حضور ${item.optInt("present", 0)} · متأخر ${item.optInt("late", 0)} · غياب ${item.optInt("absent", 0)} · بعذر ${item.optInt("excused", 0)} · ${item.optString("category_name").ifBlank { "بدون فئة" }}", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        } else {
            if (!loading && detailRows.isEmpty()) EmptyState("لا توجد تسميعات في الفترة المحددة")
            LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(detailRows.take(1000), key = { item -> item.optString("id").ifBlank { "${item.optString("student_id")}:${item.optString("created_at")}" } }, contentType = { "report_detail" }) { item ->
                    val student = item.optJSONObject("students"); val session = item.optJSONObject("sessions")
                    ElevatedCard(Modifier.fillMaxWidth()) {
                        ListItem(
                            headlineContent = { Text(student?.optString("full_name") ?: "طالب") },
                            supportingContent = { Text("${session?.optString("session_date").orEmpty()} · ${activityAr(item.optString("activity_type"))} · ${formatNumber(item.optDouble("pages_count", 0.0))} صفحة · ${evaluationAr(item.optString("evaluation"))} · أمان ${item.optDouble("safety_percentage", 0.0).toInt()}%") },
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ReportLivePreview(
    style: NativeReportStyle,
    detailsMode: Boolean,
    summaryRows: List<JSONObject>,
    detailRows: List<JSONObject>,
    from: String,
    to: String,
    track: String,
) {
    val primary = androidx.compose.ui.graphics.Color(style.primaryColor)
    val ink = androidx.compose.ui.graphics.Color(style.textColor)
    val ratio = if (style.orientation == ReportOrientation.LANDSCAPE) 1.414f else .707f
    val columnLabels = if (detailsMode) {
        listOf("rank" to "#", "student" to "الطالب", "date" to "التاريخ", "activity" to "النوع", "pages" to "الصفحات", "evaluation" to "التقييم", "safety" to "الأمان")
    } else {
        listOf("rank" to "#", "student" to "الطالب", "category" to "الفئة", "hifz" to "الحفظ", "tathbit" to "التثبيت", "review" to "المراجعة", "sard" to "السرد", "attendance" to "الحضور", "absence" to "الغياب", "points" to "النقاط")
    }.filter { it.first in style.visibleColumns }.take(6)
    val previewRows = if (detailsMode) detailRows.take(3) else summaryRows.take(3)
    val trackLabel = when (track) { "general_hifz" -> "الحفظ العام"; "tathbit" -> "التثبيت"; else -> "جميع المسارات" }

    ElevatedCard(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Visibility, contentDescription = null, tint = primary)
                Spacer(Modifier.width(8.dp))
                Text("المعاينة المباشرة", fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                Text(if (style.orientation == ReportOrientation.LANDSCAPE) "A4 أفقي" else "A4 رأسي", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Surface(
                modifier = Modifier.fillMaxWidth().aspectRatio(ratio.coerceIn(.62f, 1.5f)),
                color = androidx.compose.ui.graphics.Color.White,
                shape = MaterialTheme.shapes.medium,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
            ) {
                Column(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(style.title.ifBlank { "تقرير حلقتي" }, color = primary, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                    Text("$trackLabel · $from — $to · خط ${style.fontFamily} ${(style.fontScale * 100).toInt()}%", color = ink, style = MaterialTheme.typography.labelSmall)
                    HorizontalDivider(color = primary.copy(alpha = .35f))
                    if (columnLabels.isEmpty()) {
                        Text("اختر عمودًا واحدًا على الأقل للمعاينة", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                    } else {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            columnLabels.forEach { (_, label) ->
                                Text(label, color = primary, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelSmall, modifier = Modifier.weight(1f), maxLines = 1)
                            }
                        }
                        HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = .45f))
                        if (previewRows.isEmpty()) {
                            Text("بعد تجهيز التقرير ستظهر هنا عينة من البيانات قبل الحفظ.", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                        } else {
                            previewRows.forEachIndexed { index, row ->
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                    columnLabels.forEach { (key, _) ->
                                        val value = if (detailsMode) reportDetailPreviewValue(row, index, key) else reportSummaryPreviewValue(row, index, key)
                                        Text(value, color = ink, style = MaterialTheme.typography.labelSmall, modifier = Modifier.weight(1f), maxLines = 1)
                                    }
                                }
                                HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = .22f))
                            }
                        }
                    }
                    Spacer(Modifier.weight(1f))
                    Text(style.footer, color = ink.copy(alpha = .72f), style = MaterialTheme.typography.labelSmall, maxLines = 1)
                }
            }
        }
    }
}

private fun reportSummaryPreviewValue(row: JSONObject, index: Int, key: String): String = when (key) {
    "rank" -> (index + 1).toString()
    "student" -> row.optString("student_name", "طالب")
    "category" -> row.optString("category_name").ifBlank { "—" }
    "hifz" -> formatNumber(row.optDouble("hifz_pages", 0.0))
    "tathbit" -> formatNumber(row.optDouble("tathbit_pages", 0.0))
    "review" -> formatNumber(row.optDouble("review_pages", 0.0))
    "sard" -> formatNumber(row.optDouble("sard_pages", 0.0))
    "attendance" -> (row.optInt("present", 0) + row.optInt("late", 0)).toString()
    "absence" -> row.optInt("absent", 0).toString()
    "points" -> formatNumber(row.optDouble("points", 0.0))
    else -> "—"
}

private fun reportDetailPreviewValue(row: JSONObject, index: Int, key: String): String = when (key) {
    "rank" -> (index + 1).toString()
    "student" -> row.optJSONObject("students")?.optString("full_name") ?: "طالب"
    "date" -> row.optJSONObject("sessions")?.optString("session_date").orEmpty()
    "activity" -> activityAr(row.optString("activity_type"))
    "pages" -> formatNumber(row.optDouble("pages_count", 0.0))
    "evaluation" -> evaluationAr(row.optString("evaluation"))
    "safety" -> "${row.optDouble("safety_percentage", 0.0).toInt()}%"
    else -> "—"
}

private fun activityAr(value: String) = when (value) {
    "new_hifz" -> "حفظ"
    "review_near" -> "مراجعة قريبة"
    "review_far" -> "مراجعة بعيدة"
    "sard" -> "سرد"
    "tilawah" -> "تلاوة"
    "test" -> "اختبار"
    else -> value
}

private fun evaluationAr(value: String) = when (value) {
    "excellent" -> "ممتاز"
    "very_good" -> "جيد جدًا"
    "good" -> "جيد"
    "repeat" -> "إعادة"
    "not_rated" -> "غير مقيم"
    else -> value
}

private fun formatNumber(value: Double): String =
    if (value % 1.0 == 0.0) value.toInt().toString() else "%.2f".format(value).trimEnd('0').trimEnd('.')

data class NativeReportCacheEntry(
    val summary: List<JSONObject>,
    val details: List<JSONObject>,
    val savedAt: String,
)

object NativeReportCache {
    private const val PREFS = "halaqati_native_report_cache"

    fun key(userId: String, from: String, to: String, track: String, halaqaId: String, sessionType: String): String =
        listOf(userId, from, to, track, halaqaId, sessionType).joinToString("|")

    fun save(context: Context, key: String, summary: List<JSONObject>, details: List<JSONObject>) {
        val root = JSONObject()
            .put("version", 1)
            .put("saved_at", java.time.Instant.now().toString())
            .put("summary", JSONArray().apply { summary.forEach { put(it) } })
            .put("details", JSONArray().apply { details.forEach { put(it) } })
        val raw = root.toString()
        if (raw.length <= 3_800_000) context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(key, raw).apply()
    }

    fun load(context: Context, key: String): NativeReportCacheEntry? {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(key, null) ?: return null
        val root = runCatching { JSONObject(raw) }.getOrNull() ?: return null
        if (root.optInt("version") != 1) return null
        val summaryArray = root.optJSONArray("summary") ?: return null
        val detailArray = root.optJSONArray("details") ?: return null
        val summary = (0 until summaryArray.length()).mapNotNull { summaryArray.optJSONObject(it) }
        val details = (0 until detailArray.length()).mapNotNull { detailArray.optJSONObject(it) }
        return NativeReportCacheEntry(summary, details, root.optString("saved_at", "نسخة محلية"))
    }
}

object NativePdf {
    private const val PAGE_WIDTH = 842
    private const val PAGE_HEIGHT = 595
    private const val MARGIN = 32f
    private const val ROW_HEIGHT = 30f

    fun exportSummaryReport(
        context: Context,
        uri: Uri,
        rows: List<JSONObject>,
        title: String,
        from: String,
        to: String,
        track: String,
    ) {
        require(rows.isNotEmpty()) { "لا توجد بيانات لطباعة التقرير" }
        val pdf = PdfDocument()
        val normal = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(28, 48, 42); textSize = 10.3f
            typeface = Typeface.create("sans-serif", Typeface.NORMAL)
        }
        val bold = TextPaint(normal).apply { textSize = 10.8f; typeface = Typeface.create("sans-serif", Typeface.BOLD) }
        val titlePaint = TextPaint(normal).apply {
            textSize = 19f; typeface = Typeface.create("sans-serif", Typeface.BOLD); color = Color.rgb(11, 79, 75)
        }
        val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(202, 211, 206); strokeWidth = 0.8f }
        val headerFill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(233, 243, 238) }
        val altFill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(249, 250, 249) }
        val tableTop = 142f
        val rowHeight = 28f
        val rowsPerPage = ((PAGE_HEIGHT - tableTop - 42f) / rowHeight).toInt().coerceAtLeast(1)
        val totalPages = ((rows.size + rowsPerPage - 1) / rowsPerPage).coerceAtLeast(1)
        val headers = listOf("#", "الطالب", "الفئة", "الحفظ", "التثبيت", "المراجعة", "السرد", "الحضور", "الغياب", "النقاط")
        val widths = intArrayOf(31, 200, 90, 58, 58, 64, 58, 58, 58, 64)

        fun drawRtl(canvas: Canvas, text: String, x: Float, top: Float, width: Int, paint: TextPaint, center: Boolean = false) {
            if (text.isBlank()) return
            val layout = StaticLayout.Builder.obtain(text, 0, text.length, paint, width.coerceAtLeast(1))
                .setAlignment(if (center) Layout.Alignment.ALIGN_CENTER else Layout.Alignment.ALIGN_OPPOSITE)
                .setTextDirection(TextDirectionHeuristics.RTL).setIncludePad(false).setMaxLines(1).build()
            canvas.save(); canvas.translate(x, top); layout.draw(canvas); canvas.restore()
        }

        fun drawRow(canvas: Canvas, top: Float, values: List<String>, paint: TextPaint, header: Boolean = false) {
            var right = PAGE_WIDTH - MARGIN
            values.forEachIndexed { index, value ->
                val width = widths.getOrElse(index) { 60 }
                val left = right - width
                val center = index != 1 && index != 2
                drawRtl(canvas, value, left + 3f, top + 7f, width - 6, paint, center)
                canvas.drawLine(left, top, left, top + rowHeight, linePaint)
                right = left
            }
            canvas.drawLine(right, top, right, top + rowHeight, linePaint)
            canvas.drawLine(right, top + rowHeight, PAGE_WIDTH - MARGIN, top + rowHeight, linePaint)
            if (header) canvas.drawLine(right, top, PAGE_WIDTH - MARGIN, top, linePaint)
        }

        val trackText = when (track) {
            "general_hifz" -> "مسار الحفظ العام"
            "tathbit" -> "مسار التثبيت"
            else -> "جميع المسارات"
        }
        val totalPagesRecited = rows.sumOf { it.optDouble("total_pages", 0.0) }
        val attendance = rows.sumOf { it.optInt("present", 0) + it.optInt("late", 0) }

        rows.chunked(rowsPerPage).forEachIndexed { pageIndex, chunk ->
            val page = pdf.startPage(PdfDocument.PageInfo.Builder(PAGE_WIDTH, PAGE_HEIGHT, pageIndex + 1).create())
            val canvas = page.canvas
            canvas.drawColor(Color.WHITE)
            runCatching {
                val leftLogo = BitmapFactory.decodeResource(context.resources, R.drawable.center_logo)
                val rightLogo = BitmapFactory.decodeResource(context.resources, R.drawable.halaqa_logo)
                canvas.drawBitmap(leftLogo, null, android.graphics.RectF(42f, 20f, 94f, 72f), null)
                canvas.drawBitmap(rightLogo, null, android.graphics.RectF(748f, 20f, 800f, 72f), null)
            }
            drawRtl(canvas, title, 190f, 26f, 460, titlePaint, true)
            drawRtl(canvas, "$trackText · الفترة: $from إلى $to", 150f, 55f, 540, normal, true)
            drawRtl(canvas, "الطلاب: ${rows.size} · مجموع الصفحات: ${formatNumber(totalPagesRecited)} · الحضور: $attendance", 150f, 76f, 540, bold, true)
            drawRtl(canvas, "إعداد: د. محمد سمير أبو يونس", 150f, 96f, 540, normal, true)
            canvas.drawLine(MARGIN, 122f, PAGE_WIDTH - MARGIN, 122f, linePaint)

            canvas.drawRect(PAGE_WIDTH - MARGIN - widths.sum(), tableTop, PAGE_WIDTH - MARGIN, tableTop + rowHeight, headerFill)
            drawRow(canvas, tableTop, headers, bold, header = true)
            var y = tableTop + rowHeight
            chunk.forEachIndexed { chunkIndex, item ->
                val globalIndex = pageIndex * rowsPerPage + chunkIndex
                if (globalIndex % 2 == 1) canvas.drawRect(PAGE_WIDTH - MARGIN - widths.sum(), y, PAGE_WIDTH - MARGIN, y + rowHeight, altFill)
                drawRow(
                    canvas,
                    y,
                    listOf(
                        (globalIndex + 1).toString(), item.optString("student_name", "طالب"), item.optString("category_name").ifBlank { "—" },
                        formatNumber(item.optDouble("hifz_pages", 0.0)), formatNumber(item.optDouble("tathbit_pages", 0.0)),
                        formatNumber(item.optDouble("review_pages", 0.0)), formatNumber(item.optDouble("sard_pages", 0.0)),
                        (item.optInt("present", 0) + item.optInt("late", 0)).toString(), item.optInt("absent", 0).toString(),
                        formatNumber(item.optDouble("points", 0.0)),
                    ),
                    normal,
                )
                y += rowHeight
            }
            drawRtl(canvas, "صفحة ${pageIndex + 1} من $totalPages", 340f, PAGE_HEIGHT - 25f, 160, normal, true)
            drawRtl(canvas, "حلقتي · حلقة معاوية بن أبي سفيان", 565f, PAGE_HEIGHT - 25f, 235, normal)
            pdf.finishPage(page)
        }
        context.contentResolver.openOutputStream(uri)?.use { pdf.writeTo(it) } ?: error("تعذر فتح ملف الحفظ")
        pdf.close()
    }

    fun exportReport(
        context: Context,
        uri: Uri,
        rows: List<JSONObject>,
        title: String,
        from: String,
        to: String,
        track: String,
    ) {
        require(rows.isNotEmpty()) { "لا توجد بيانات لطباعة التقرير" }
        val pdf = PdfDocument()
        val normal = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(28, 48, 42)
            textSize = 10.5f
            typeface = Typeface.create("sans-serif", Typeface.NORMAL)
        }
        val bold = TextPaint(normal).apply {
            textSize = 11f
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
        }
        val titlePaint = TextPaint(normal).apply {
            textSize = 20f
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
            color = Color.rgb(13, 59, 47)
        }
        val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(190, 202, 195)
            strokeWidth = 1f
        }
        val headerFill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(231, 241, 237) }

        var pageNumber = 0
        lateinit var page: PdfDocument.Page
        lateinit var canvas: Canvas
        var y = 0f

        fun drawRtlText(text: String, x: Float, top: Float, width: Int, paint: TextPaint, maxLines: Int = 1) {
            if (text.isBlank()) return
            val layout = StaticLayout.Builder
                .obtain(text, 0, text.length, paint, width.coerceAtLeast(1))
                .setAlignment(Layout.Alignment.ALIGN_OPPOSITE)
                .setTextDirection(TextDirectionHeuristics.RTL)
                .setIncludePad(false)
                .setMaxLines(maxLines)
                .build()
            canvas.save()
            canvas.translate(x, top)
            layout.draw(canvas)
            canvas.restore()
        }

        fun newPage() {
            if (pageNumber > 0) pdf.finishPage(page)
            pageNumber += 1
            page = pdf.startPage(PdfDocument.PageInfo.Builder(PAGE_WIDTH, PAGE_HEIGHT, pageNumber).create())
            canvas = page.canvas
            canvas.drawColor(Color.WHITE)

            runCatching {
                val left = BitmapFactory.decodeResource(context.resources, R.drawable.center_logo)
                val right = BitmapFactory.decodeResource(context.resources, R.drawable.halaqa_logo)
                canvas.drawBitmap(left, null, android.graphics.RectF(40f, 22f, 92f, 74f), null)
                canvas.drawBitmap(right, null, android.graphics.RectF(750f, 22f, 802f, 74f), null)
            }

            drawRtlText(title, 190f, 28f, 460, titlePaint)
            val trackText = when (track) {
                "general_hifz" -> "مسار الحفظ العام"
                "tathbit" -> "مسار التثبيت"
                else -> "جميع المسارات"
            }
            drawRtlText("الفترة: $from إلى $to · $trackText", 160f, 57f, 520, normal)
            drawRtlText("إعداد: د. محمد سمير أبو يونس", 160f, 75f, 520, normal)
            canvas.drawLine(MARGIN, 99f, PAGE_WIDTH - MARGIN, 99f, linePaint)

            y = 108f
            canvas.drawRect(MARGIN, y, PAGE_WIDTH - MARGIN, y + ROW_HEIGHT, headerFill)
            drawTableRow(
                canvas,
                y,
                listOf("#", "الطالب", "التاريخ", "النوع", "الصفحات", "التقييم", "الأمان"),
                bold,
                ::drawRtlText,
            )
            y += ROW_HEIGHT
        }

        newPage()
        rows.forEachIndexed { index, item ->
            if (y + ROW_HEIGHT > PAGE_HEIGHT - 32f) newPage()
            if (index % 2 == 1) {
                val alt = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(248, 250, 249) }
                canvas.drawRect(MARGIN, y, PAGE_WIDTH - MARGIN, y + ROW_HEIGHT, alt)
            }
            val student = item.optJSONObject("students")
            val session = item.optJSONObject("sessions")
            drawTableRow(
                canvas,
                y,
                listOf(
                    (index + 1).toString(),
                    student?.optString("full_name") ?: "طالب",
                    session?.optString("session_date").orEmpty(),
                    activityAr(item.optString("activity_type")),
                    formatNumber(item.optDouble("pages_count", 0.0)),
                    evaluationAr(item.optString("evaluation")),
                    "${item.optDouble("safety_percentage", 0.0).toInt()}%",
                ),
                normal,
                ::drawRtlText,
            )
            canvas.drawLine(MARGIN, y + ROW_HEIGHT, PAGE_WIDTH - MARGIN, y + ROW_HEIGHT, linePaint)
            y += ROW_HEIGHT
        }

        drawRtlText("صفحة $pageNumber", 360f, PAGE_HEIGHT - 23f, 120, normal)
        pdf.finishPage(page)
        context.contentResolver.openOutputStream(uri)?.use { pdf.writeTo(it) }
            ?: error("تعذر فتح ملف الحفظ")
        pdf.close()
    }

    private fun drawTableRow(
        canvas: Canvas,
        y: Float,
        values: List<String>,
        paint: TextPaint,
        drawText: (String, Float, Float, Int, TextPaint, Int) -> Unit,
    ) {
        // Left-to-right column geometry; each cell's text is independently RTL-aware.
        val widths = intArrayOf(34, 220, 90, 120, 76, 110, 70)
        var x = MARGIN
        values.forEachIndexed { index, text ->
            val width = widths.getOrElse(index) { 80 }
            if (index == 0 || index == 4 || index == 6) {
                val p = Paint(paint).apply { textAlign = Paint.Align.CENTER }
                canvas.drawText(text, x + width / 2f, y + 19f, p)
            } else {
                drawText(text, x + 4f, y + 7f, width - 8, paint, 1)
            }
            x += width
        }
    }
}

data class NativeCertificateStyle(
    val template: String = "emerald",
    val fontFamily: String = "Cairo",
    val titleSize: Float = 44f,
    val studentSize: Float = 38f,
    val bodySize: Float = 20f,
    val logoSize: Float = 168f,
    val borderWidth: Float = 3f,
    val ornamentStrength: Float = .82f,
    val primaryHex: String = "",
    val accentHex: String = "",
    val secondaryHex: String = "",
    val paperHex: String = "",
    val inkHex: String = "",
    val showVerse: Boolean = true,
    val showLogos: Boolean = true,
    val showSignatures: Boolean = true,
    val showStamp: Boolean = true,
    val showDate: Boolean = true,
    val showNumber: Boolean = true,
    val numberPosition: String = "under_logo",
)

data class NativeCertificateDraft(
    val number: String,
    val studentName: String,
    val type: String,
    val title: String,
    val achievement: String,
    val date: String,
    val intro: String = "تتشرف إدارة مركز إبراهيم خليل الرحمن لتحفيظ القرآن الكريم بمنح هذه الشهادة للطالب",
    val dua: String = "سائلين الله تعالى أن يثبت القرآن في صدره، وأن يجعله له نورًا وهدًى ورفعةً في الدنيا والآخرة.",
    val centerName: String = "مركز إبراهيم خليل الرحمن لتحفيظ القرآن الكريم",
    val halaqaName: String = "حلقة معاوية بن أبي سفيان",
    val teacherName: String = "د. محمد سمير أبو يونس",
    val supervisorName: String = "الشيخ محمد حلمي أبو عنزة",
    val fromJuz: Int = 1,
    val toJuz: Int = 1,
    val month: String = "",
    val rank: Int = 1,
    val track: String = "general_hifz",
    val idealScore: Double? = null,
    val style: NativeCertificateStyle = NativeCertificateStyle(),
)

data class NativeCertificateAssets(
    val centerLogo: String? = null,
    val halaqaLogo: String? = null,
    val teacherSignature: String? = null,
    val supervisorSignature: String? = null,
    val stamp: String? = null,
) {
    fun value(kind: String): String? = when (kind) {
        "center_logo" -> centerLogo
        "halaqa_logo" -> halaqaLogo
        "teacher_signature" -> teacherSignature
        "supervisor_signature" -> supervisorSignature
        "stamp" -> stamp
        else -> null
    }
}

@Composable
fun CertificatesScreen(profile: Profile, pending: Int, onRefresh: () -> Unit) {
    val context = LocalContext.current
    val ownerUserId = profile.id
    val scope = rememberCoroutineScope()
    var students by remember { mutableStateOf<List<com.mohammedsamir.halaqati.model.Student>>(emptyList()) }
    var studentsLoading by remember { mutableStateOf(true) }
    var selectedStudentId by remember { mutableStateOf("") }
    var selectedStudentIds by remember { mutableStateOf<Set<String>>(emptySet()) }
    var bulkMode by remember { mutableStateOf(false) }
    var studentSearch by remember { mutableStateOf("") }
    var studentMenu by remember { mutableStateOf(false) }
    var type by remember { mutableStateOf("sard") }
    var number by remember(ownerUserId) { mutableStateOf(NativeCertificate.peekNumber(context, ownerUserId)) }
    var date by remember { mutableStateOf(LocalDate.now().toString()) }
    var fromJuz by remember { mutableStateOf("1") }
    var toJuz by remember { mutableStateOf("1") }
    var month by remember { mutableStateOf(YearMonth.now().toString()) }
    var rank by remember { mutableStateOf("1") }
    var track by remember { mutableStateOf("general_hifz") }
    var monthlyReason by remember { mutableStateOf("التميز في الحفظ والانضباط") }
    var ethics by remember { mutableStateOf("100") }
    var discipline by remember { mutableStateOf("100") }
    var attendance by remember { mutableStateOf("100") }
    var memorization by remember { mutableStateOf("100") }
    var customAchievement by remember { mutableStateOf("") }
    var customEdited by remember { mutableStateOf(false) }
    var customTitle by remember { mutableStateOf("") }
    var introText by remember { mutableStateOf("تتشرف إدارة مركز إبراهيم خليل الرحمن لتحفيظ القرآن الكريم بمنح هذه الشهادة للطالب") }
    var duaText by remember { mutableStateOf("سائلين الله تعالى أن يثبت القرآن في صدره، وأن يجعله له نورًا وهدًى ورفعةً في الدنيا والآخرة.") }
    var centerName by remember { mutableStateOf("مركز إبراهيم خليل الرحمن لتحفيظ القرآن الكريم") }
    var halaqaName by remember { mutableStateOf("حلقة معاوية بن أبي سفيان") }
    var teacherName by remember { mutableStateOf("د. محمد سمير أبو يونس") }
    var supervisorName by remember { mutableStateOf("الشيخ محمد حلمي أبو عنزة") }
    var certificateStyle by remember(ownerUserId) { mutableStateOf(NativeCertificate.loadStyle(context, ownerUserId)) }
    var previewZoom by remember { mutableStateOf(94f) }
    var certificateAssets by remember(ownerUserId) { mutableStateOf(NativeCertificate.loadAssets(context, ownerUserId)) }
    var assetPickerTarget by remember { mutableStateOf<String?>(null) }
    var styleExpanded by remember { mutableStateOf(false) }
    var archiveSearch by remember { mutableStateOf("") }
    var archive by remember(ownerUserId) { mutableStateOf(NativeCertificate.listArchive(context, ownerUserId)) }
    var pendingSingle by remember { mutableStateOf<NativeCertificateDraft?>(null) }
    var pendingBatch by remember { mutableStateOf<List<NativeCertificateDraft>>(emptyList()) }
    var message by remember { mutableStateOf("") }

    LaunchedEffect(ownerUserId, certificateStyle) { NativeCertificate.saveStyle(context, ownerUserId, certificateStyle) }

    LaunchedEffect(Unit) {
        studentsLoading = true
        runCatching { withContext(Dispatchers.IO) { AppGraph.repo.students().filter { it.status == "active" } } }
            .onSuccess { list ->
                students = list
                if (selectedStudentId.isBlank()) selectedStudentId = list.firstOrNull()?.id.orEmpty()
            }
            .onFailure { message = "تعذر تحميل الطلاب: ${it.message ?: "خطأ"}" }
        studentsLoading = false
    }

    val studentName = students.firstOrNull { it.id == selectedStudentId }?.fullName.orEmpty()
    val idealScore = remember(ethics, discipline, attendance, memorization) {
        val e = ethics.toDoubleOrNull()?.coerceIn(0.0, 100.0) ?: 0.0
        val d = discipline.toDoubleOrNull()?.coerceIn(0.0, 100.0) ?: 0.0
        val a = attendance.toDoubleOrNull()?.coerceIn(0.0, 100.0) ?: 0.0
        val m = memorization.toDoubleOrNull()?.coerceIn(0.0, 100.0) ?: 0.0
        kotlin.math.round((e * .35 + d * .30 + a * .20 + m * .15) * 10.0) / 10.0
    }
    val autoAchievement = certificateAchievement(type, fromJuz.toIntOrNull() ?: 1, toJuz.toIntOrNull() ?: 1, month, monthlyReason, rank.toIntOrNull() ?: 1, track, idealScore)
    val achievement = if (customEdited) customAchievement else autoAchievement
    val title = customTitle.ifBlank { certificateTitle(type) }

    fun resetAutoText() { customEdited = false; customAchievement = "" }
    fun draftFor(name: String, certNumber: String) = NativeCertificateDraft(
        number = certNumber.trim(), studentName = name, type = type, title = title,
        achievement = achievement, date = date,
        intro = introText, dua = duaText, centerName = centerName, halaqaName = halaqaName,
        teacherName = teacherName, supervisorName = supervisorName,
        fromJuz = (fromJuz.toIntOrNull() ?: 1).coerceIn(1, 30),
        toJuz = (toJuz.toIntOrNull() ?: 1).coerceIn(1, 30), month = month,
        rank = (rank.toIntOrNull() ?: 1).coerceIn(1, 3), track = track,
        idealScore = idealScore.takeIf { type == "ideal" },
        style = certificateStyle,
    )

    val previewStudentName = if (bulkMode) {
        students.firstOrNull { it.id in selectedStudentIds }?.fullName ?: studentName.ifBlank { "اسم الطالب" }
    } else studentName.ifBlank { "اسم الطالب" }
    val previewNumber = number.ifBlank { NativeCertificate.peekNumber(context, ownerUserId) }
    val previewDraft = draftFor(previewStudentName, previewNumber)
    val certificatePreview = remember(previewDraft, certificateAssets) {
        runCatching { NativeCertificate.previewBitmap(context, ownerUserId, previewDraft) }.getOrNull()
    }
    DisposableEffect(certificatePreview) {
        onDispose { certificatePreview?.takeIf { !it.isRecycled }?.recycle() }
    }

    val assetPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        val kind = assetPickerTarget
        assetPickerTarget = null
        if (uri != null && kind != null) scope.launch {
            try {
                withContext(Dispatchers.IO) { NativeCertificate.importAsset(context, ownerUserId, kind, uri) }
                certificateAssets = NativeCertificate.loadAssets(context, ownerUserId)
                message = "تم حفظ صورة الشهادة للحساب الحالي فقط"
            } catch (e: Exception) {
                message = "تعذر حفظ الصورة: ${e.message ?: "خطأ"}"
            }
        }
    }

    val createSingle = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
        val draft = pendingSingle
        if (uri != null && draft != null) scope.launch {
            try {
                withContext(Dispatchers.IO) { NativeCertificate.export(context, uri, ownerUserId, draft) }
                NativeCertificate.commitNumber(context, ownerUserId, draft.number)
                NativeCertificate.archive(context, ownerUserId, listOf(draft))
                archive = NativeCertificate.listArchive(context, ownerUserId)
                number = NativeCertificate.peekNumber(context, ownerUserId)
                message = "تم حفظ وأرشفة الشهادة ${draft.number}"
            } catch (e: Exception) { message = "تعذر حفظ الشهادة: ${e.message ?: "خطأ"}" }
            finally { pendingSingle = null }
        }
    }

    val createBatch = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
        val drafts = pendingBatch
        if (uri != null && drafts.isNotEmpty()) scope.launch {
            try {
                withContext(Dispatchers.IO) { NativeCertificate.exportBatch(context, uri, ownerUserId, drafts) }
                drafts.lastOrNull()?.let { NativeCertificate.commitNumber(context, ownerUserId, it.number) }
                NativeCertificate.archive(context, ownerUserId, drafts)
                archive = NativeCertificate.listArchive(context, ownerUserId)
                number = NativeCertificate.peekNumber(context, ownerUserId)
                selectedStudentIds = emptySet()
                message = "تم إصدار ${drafts.size} شهادة في ملف PDF جماعي وأرشفتها"
            } catch (e: Exception) { message = "تعذر الإصدار الجماعي: ${e.message ?: "خطأ"}" }
            finally { pendingBatch = emptyList() }
        }
    }

    val exportArchiveIndex = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) scope.launch {
            try {
                val count = withContext(Dispatchers.IO) { NativeCertificate.exportArchiveIndex(context, ownerUserId, uri) }
                message = "تم تصدير فهرس أرشيف الشهادات ($count سجل)"
            } catch (e: Exception) { message = "تعذر تصدير الأرشيف: ${e.message ?: "خطأ"}" }
        }
    }
    val importArchiveIndex = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            try {
                val count = withContext(Dispatchers.IO) { NativeCertificate.importArchiveIndex(context, ownerUserId, uri) }
                archive = NativeCertificate.listArchive(context, ownerUserId)
                certificateStyle = NativeCertificate.loadStyle(context, ownerUserId)
                certificateAssets = NativeCertificate.loadAssets(context, ownerUserId)
                message = "تم استيراد/دمج $count سجل مع إعدادات الشهادة للحساب الحالي"
            } catch (e: Exception) { message = "تعذر استيراد الأرشيف: ${e.message ?: "خطأ"}" }
        }
    }

    val studentCandidates = remember(students, studentSearch) {
        val q = studentSearch.trim()
        if (q.isBlank()) students else students.filter { it.fullName.contains(q, true) }
    }
    val archiveFiltered = remember(archive, archiveSearch) {
        val q = archiveSearch.trim()
        if (q.isBlank()) archive else archive.filter {
            it.studentName.contains(q, true) || it.number.contains(q, true) || it.title.contains(q, true)
        }
    }

    Column {
        AppTopBar("الشهادات", onRefresh = {
            archive = NativeCertificate.listArchive(context, ownerUserId)
            onRefresh()
        }, pending = pending)
        GoldenFeatureHero(
            title = "مركز الشهادات",
            subtitle = "إصدار يدوي · PDF Vector · أرشيف محلي للحساب · معاينة قبل الحفظ والطباعة.",
            badge = "v${BuildConfig.VERSION_NAME}",
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
        )
        LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item {
                Text("نوع الشهادة", style = MaterialTheme.typography.titleSmall)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(
                        "sard" to "إتمام سرد", "khatam" to "ختم القرآن", "monthly" to "التميز الشهري",
                        "ideal" to "الطالب المثالي", "rank" to "المراكز الأولى",
                    ).forEach { (value, label) ->
                        ProFilterChip(selected = type == value, onClick = { type = value; resetAutoText() }, label = label)
                    }
                }
            }
            item {
                ElevatedCard(Modifier.fillMaxWidth()) {
                    Row(
                        Modifier.fillMaxWidth().padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        Icon(Icons.Default.Groups, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Column(Modifier.weight(1f)) {
                            Text("الإصدار الجماعي", style = MaterialTheme.typography.titleSmall)
                            Text("اختر عدة طلاب وأنشئ لكل طالب صفحة شهادة داخل PDF واحد", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Switch(checked = bulkMode, onCheckedChange = { enabled -> bulkMode = enabled; if (!enabled) selectedStudentIds = emptySet() })
                    }
                }
            }
            if (studentsLoading) {
                item { LoadingSkeleton(rows = 2) }
            } else if (students.isEmpty()) {
                item { StateNotice("لا يوجد طلاب نشطون لإصدار شهادة", "warning") }
            } else if (bulkMode) {
                item {
                    OutlinedTextField(
                        value = studentSearch,
                        onValueChange = { studentSearch = it },
                        label = { Text("بحث باسم الطالب") },
                        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                    )
                    Spacer(Modifier.height(8.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(
                            onClick = { selectedStudentIds = selectedStudentIds + studentCandidates.map { it.id } },
                            modifier = Modifier.weight(1f).heightIn(min = 48.dp),
                        ) { Text("تحديد الكل") }
                        OutlinedButton(
                            onClick = { selectedStudentIds = emptySet() },
                            enabled = selectedStudentIds.isNotEmpty(),
                            modifier = Modifier.weight(1f).heightIn(min = 48.dp),
                        ) { Text("إلغاء التحديد") }
                    }
                    Text("تم تحديد ${selectedStudentIds.size} طالب", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.primary)
                }
                items(studentCandidates, key = { "cert-bulk:${it.id}" }) { student ->
                    ElevatedCard(Modifier.fillMaxWidth()) {
                        Row(
                            Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Checkbox(
                                checked = student.id in selectedStudentIds,
                                onCheckedChange = { checked -> selectedStudentIds = if (checked) selectedStudentIds + student.id else selectedStudentIds - student.id },
                                modifier = Modifier.size(48.dp),
                            )
                            Text(student.fullName, Modifier.weight(1f), style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.SemiBold)
                            Text(if (student.track == "tathbit") "التثبيت" else "الحفظ العام", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            } else {
                item {
                    ExposedDropdownMenuBox(expanded = studentMenu, onExpandedChange = { studentMenu = it }) {
                        OutlinedTextField(
                            value = studentName,
                            onValueChange = {}, readOnly = true,
                            label = { Text("الطالب") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = studentMenu) },
                            modifier = Modifier.menuAnchor().fillMaxWidth(),
                        )
                        ExposedDropdownMenu(expanded = studentMenu, onDismissRequest = { studentMenu = false }) {
                            students.forEach { student ->
                                DropdownMenuItem(text = { Text(student.fullName) }, onClick = { selectedStudentId = student.id; studentMenu = false })
                            }
                        }
                    }
                }
            }
            if (!bulkMode) item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = number, onValueChange = { number = normalizeArabicDigits(it).take(40) }, label = { Text("رقم الشهادة") }, modifier = Modifier.weight(1f), singleLine = true)
                    OutlinedTextField(value = date, onValueChange = { date = normalizeArabicDigits(it).take(10) }, label = { Text("التاريخ") }, modifier = Modifier.weight(1f), singleLine = true)
                }
            } else item {
                OutlinedTextField(value = date, onValueChange = { date = normalizeArabicDigits(it).take(10) }, label = { Text("تاريخ الشهادات") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            }
            if (type == "sard") item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = fromJuz, onValueChange = { fromJuz = normalizeArabicDigits(it).filter(Char::isDigit).take(2); resetAutoText() }, label = { Text("من الجزء") }, modifier = Modifier.weight(1f), singleLine = true)
                    OutlinedTextField(value = toJuz, onValueChange = { toJuz = normalizeArabicDigits(it).filter(Char::isDigit).take(2); resetAutoText() }, label = { Text("إلى الجزء") }, modifier = Modifier.weight(1f), singleLine = true)
                }
            }
            if (type == "monthly") item {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = month, onValueChange = { month = normalizeArabicDigits(it).take(7); resetAutoText() }, label = { Text("الشهر YYYY-MM") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                    OutlinedTextField(value = monthlyReason, onValueChange = { monthlyReason = it; resetAutoText() }, label = { Text("سبب التميز") }, modifier = Modifier.fillMaxWidth())
                }
            }
            if (type == "ideal") item {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("معايير الطالب المثالي", style = MaterialTheme.typography.titleSmall)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(value = ethics, onValueChange = { ethics = normalizeArabicDigits(it).filter(Char::isDigit).take(3); resetAutoText() }, label = { Text("الأخلاق") }, modifier = Modifier.weight(1f))
                        OutlinedTextField(value = discipline, onValueChange = { discipline = normalizeArabicDigits(it).filter(Char::isDigit).take(3); resetAutoText() }, label = { Text("الالتزام") }, modifier = Modifier.weight(1f))
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(value = attendance, onValueChange = { attendance = normalizeArabicDigits(it).filter(Char::isDigit).take(3); resetAutoText() }, label = { Text("الحضور") }, modifier = Modifier.weight(1f))
                        OutlinedTextField(value = memorization, onValueChange = { memorization = normalizeArabicDigits(it).filter(Char::isDigit).take(3); resetAutoText() }, label = { Text("الحفظ") }, modifier = Modifier.weight(1f))
                    }
                    Text("الدرجة التقديرية: ${formatNumber(idealScore)}/100", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                }
            }
            if (type == "rank") item {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = rank, onValueChange = { rank = normalizeArabicDigits(it).filter(Char::isDigit).take(1); resetAutoText() }, label = { Text("المركز 1–3") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        ProFilterChip(selected = track == "general_hifz", onClick = { track = "general_hifz"; resetAutoText() }, label = "الحفظ العام")
                        ProFilterChip(selected = track == "tathbit", onClick = { track = "tathbit"; resetAutoText() }, label = "التثبيت")
                    }
                }
            }
            item {
                ElevatedCard(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Palette, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            Spacer(Modifier.width(8.dp))
                            Column(Modifier.weight(1f)) {
                                Text("تصميم الشهادة", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                                Text("قوالب وتحكم محلي مستقل؛ لا تُرفع إعدادات الشهادة إلى Supabase.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            TextButton(onClick = { styleExpanded = !styleExpanded }, modifier = Modifier.heightIn(min = 48.dp)) {
                                Text(if (styleExpanded) "إخفاء" else "تخصيص")
                            }
                        }
                        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf(
                                "emerald" to "زمردي", "gold" to "ذهبي", "blue" to "أزرق",
                                "burgundy" to "عنابي", "classic" to "كلاسيكي",
                            ).forEach { (value, label) ->
                                ProFilterChip(
                                    selected = certificateStyle.template == value,
                                    onClick = { certificateStyle = certificateStyle.copy(template = value) },
                                    label = label,
                                )
                            }
                        }
                        if (styleExpanded) {
                            Text("الخط", style = MaterialTheme.typography.labelLarge)
                            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                listOf("Cairo" to "Cairo", "Tahoma" to "Tahoma", "Arial" to "Arial", "serif" to "تقليدي").forEach { (value, label) ->
                                    ProFilterChip(
                                        selected = certificateStyle.fontFamily == value,
                                        onClick = { certificateStyle = certificateStyle.copy(fontFamily = value) },
                                        label = label,
                                    )
                                }
                            }
                            CertificateStyleSlider("حجم العنوان", certificateStyle.titleSize, 30f..64f) { certificateStyle = certificateStyle.copy(titleSize = it) }
                            CertificateStyleSlider("حجم اسم الطالب", certificateStyle.studentSize, 28f..58f) { certificateStyle = certificateStyle.copy(studentSize = it) }
                            CertificateStyleSlider("حجم نص الإنجاز", certificateStyle.bodySize, 15f..28f) { certificateStyle = certificateStyle.copy(bodySize = it) }
                            CertificateStyleSlider("حجم الشعارات", certificateStyle.logoSize, 100f..230f) { certificateStyle = certificateStyle.copy(logoSize = it) }
                            CertificateStyleSlider("سماكة الإطار", certificateStyle.borderWidth, 1f..6f) { certificateStyle = certificateStyle.copy(borderWidth = it) }
                            CertificateStyleSlider("قوة الزخارف", certificateStyle.ornamentStrength, 0f..1f) { certificateStyle = certificateStyle.copy(ornamentStrength = it) }
                            Text("ألوان الشهادة (HEX)", style = MaterialTheme.typography.labelLarge)
                            Text("اترك الحقل فارغًا لاستخدام لون القالب.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                CertificateColorField("الرئيسي", certificateStyle.primaryHex, Modifier.weight(1f)) { certificateStyle = certificateStyle.copy(primaryHex = it) }
                                CertificateColorField("الذهبي", certificateStyle.accentHex, Modifier.weight(1f)) { certificateStyle = certificateStyle.copy(accentHex = it) }
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                CertificateColorField("الثانوي", certificateStyle.secondaryHex, Modifier.weight(1f)) { certificateStyle = certificateStyle.copy(secondaryHex = it) }
                                CertificateColorField("الخلفية", certificateStyle.paperHex, Modifier.weight(1f)) { certificateStyle = certificateStyle.copy(paperHex = it) }
                            }
                            CertificateColorField("النص", certificateStyle.inkHex, Modifier.fillMaxWidth()) { certificateStyle = certificateStyle.copy(inkHex = it) }
                            Text("عناصر العرض", style = MaterialTheme.typography.labelLarge)
                            CertificateToggle("الآية", certificateStyle.showVerse) { certificateStyle = certificateStyle.copy(showVerse = it) }
                            CertificateToggle("الشعارات", certificateStyle.showLogos) { certificateStyle = certificateStyle.copy(showLogos = it) }
                            CertificateToggle("التوقيعات", certificateStyle.showSignatures) { certificateStyle = certificateStyle.copy(showSignatures = it) }
                            CertificateToggle("الختم", certificateStyle.showStamp) { certificateStyle = certificateStyle.copy(showStamp = it) }
                            CertificateToggle("التاريخ", certificateStyle.showDate) { certificateStyle = certificateStyle.copy(showDate = it) }
                            CertificateToggle("رقم الشهادة", certificateStyle.showNumber) { certificateStyle = certificateStyle.copy(showNumber = it) }
                            HorizontalDivider()
                            Text("الشعارات والتوقيعات والختم", style = MaterialTheme.typography.labelLarge)
                            Text(
                                "تُحفظ الصور محليًا ومفصولة حسب الحساب، ويمكن نقلها فقط عند تصدير أرشيف الشهادات JSON.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                            listOf(
                                "center_logo" to "شعار المركز",
                                "halaqa_logo" to "شعار الحلقة",
                                "teacher_signature" to "توقيع المحفظ",
                                "supervisor_signature" to "توقيع المشرف",
                                "stamp" to "الختم",
                            ).forEach { (kind, label) ->
                                CertificateAssetRow(
                                    label = label,
                                    hasCustom = certificateAssets.value(kind) != null,
                                    onPick = { assetPickerTarget = kind; assetPicker.launch("image/*") },
                                    onRemove = {
                                        NativeCertificate.removeAsset(context, ownerUserId, kind)
                                        certificateAssets = NativeCertificate.loadAssets(context, ownerUserId)
                                        message = "تمت إزالة $label المخصص"
                                    },
                                )
                            }
                            Text("موضع رقم الشهادة", style = MaterialTheme.typography.labelLarge)
                            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                listOf("under_logo" to "أسفل شعار المركز", "top" to "أعلى الوسط", "footer_start" to "أسفل يمين", "footer_end" to "أسفل يسار").forEach { (value, label) ->
                                    ProFilterChip(
                                        selected = certificateStyle.numberPosition == value,
                                        onClick = { certificateStyle = certificateStyle.copy(numberPosition = value) },
                                        label = label,
                                    )
                                }
                            }
                            OutlinedButton(
                                onClick = { certificateStyle = NativeCertificateStyle() },
                                modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp),
                            ) { Text("استعادة تصميم الشهادة الافتراضي") }
                        }
                    }
                }
            }
            item {
                ElevatedCard(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("نصوص وهوية الشهادة", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        OutlinedTextField(customTitle, { customTitle = it }, label = { Text("عنوان الشهادة (فارغ = تلقائي)") }, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(introText, { introText = it }, label = { Text("المقدمة") }, modifier = Modifier.fillMaxWidth(), minLines = 2)
                        OutlinedTextField(duaText, { duaText = it }, label = { Text("الدعاء / الخاتمة") }, modifier = Modifier.fillMaxWidth(), minLines = 2)
                        OutlinedTextField(centerName, { centerName = it }, label = { Text("اسم المركز") }, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(halaqaName, { halaqaName = it }, label = { Text("اسم الحلقة") }, modifier = Modifier.fillMaxWidth())
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(teacherName, { teacherName = it }, label = { Text("المحفظ") }, modifier = Modifier.weight(1f))
                            OutlinedTextField(supervisorName, { supervisorName = it }, label = { Text("المشرف") }, modifier = Modifier.weight(1f))
                        }
                    }
                }
            }
            item {
                OutlinedTextField(
                    value = achievement,
                    onValueChange = { customAchievement = it; customEdited = true },
                    label = { Text("نص الإنجاز") }, modifier = Modifier.fillMaxWidth().heightIn(min = 120.dp),
                    supportingText = { Text(if (customEdited) "النص معدل يدويًا" else "يُنشأ تلقائيًا حسب نوع الشهادة ويمكن تعديله") },
                )
                if (customEdited) TextButton(onClick = { resetAutoText() }, modifier = Modifier.heightIn(min = 48.dp)) { Text("استعادة النص التلقائي") }
            }
            item {
                ElevatedCard(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("المعاينة المباشرة", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Text("نفس محرّك الرسم المستخدم في PDF · المعاينة A4 أفقية ولا يؤثر تكبيرها على الملف.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            Text("تكبير المعاينة", style = MaterialTheme.typography.labelMedium)
                            Slider(
                                value = previewZoom,
                                onValueChange = { previewZoom = it },
                                valueRange = 70f..120f,
                                modifier = Modifier.weight(1f),
                            )
                            Text("${previewZoom.toInt()}%", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                        }
                        certificatePreview?.let { bitmap ->
                            Surface(
                                modifier = Modifier.fillMaxWidth(),
                                color = MaterialTheme.colorScheme.surface,
                                shape = RoundedCornerShape(16.dp),
                                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                            ) {
                                Box(Modifier.fillMaxWidth().padding(8.dp), contentAlignment = Alignment.Center) {
                                    Image(
                                        bitmap = bitmap.asImageBitmap(),
                                        contentDescription = "معاينة الشهادة",
                                        contentScale = ContentScale.Fit,
                                        modifier = Modifier
                                            .fillMaxWidth((previewZoom / 100f).coerceIn(.7f, 1f))
                                            .aspectRatio(1123f / 794f),
                                    )
                                }
                            }
                        } ?: StateNotice("تعذر إنشاء المعاينة. تحقق من اسم الطالب ورقم الشهادة والتاريخ.", "warning")
                    }
                }
            }
            item {
                if (bulkMode) {
                    Button(
                        onClick = {
                            val chosen = students.filter { it.id in selectedStudentIds }
                            val numbers = NativeCertificate.peekNumbers(context, ownerUserId, chosen.size)
                            val drafts = chosen.mapIndexed { index, student -> draftFor(student.fullName, numbers[index]) }
                            pendingBatch = drafts
                            createBatch.launch("شهادات_جماعية_${certificateTitle(type)}_${date}.pdf")
                        },
                        enabled = selectedStudentIds.isNotEmpty() && runCatching { LocalDate.parse(date) }.isSuccess,
                        modifier = Modifier.fillMaxWidth().heightIn(min = 52.dp),
                    ) { Icon(Icons.Default.Groups, contentDescription = null); Spacer(Modifier.width(8.dp)); Text("إصدار ${selectedStudentIds.size} شهادة PDF") }
                } else {
                    Button(
                        onClick = {
                            val draft = draftFor(studentName, number)
                            pendingSingle = draft
                            createSingle.launch("شهادة_${safeCertificateFileName(studentName.ifBlank { "حلقتي" })}_${safeCertificateFileName(number.ifBlank { "CERT" })}.pdf")
                        },
                        enabled = studentName.isNotBlank() && number.isNotBlank() && runCatching { LocalDate.parse(date) }.isSuccess,
                        modifier = Modifier.fillMaxWidth().heightIn(min = 52.dp),
                    ) { Icon(Icons.Default.WorkspacePremium, contentDescription = null); Spacer(Modifier.width(8.dp)); Text("إنشاء شهادة PDF") }
                }
            }
            if (message.isNotBlank()) item {
                StateNotice(message, if (message.startsWith("تعذر")) "error" else "success")
            }
            item {
                HorizontalDivider(Modifier.padding(vertical = 8.dp))
                Text("أرشيف الشهادات", style = MaterialTheme.typography.titleMedium)
                Text("محفوظ محليًا على الجهاز لسهولة المراجعة وتتبع أرقام الشهادات.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(
                        onClick = { exportArchiveIndex.launch("Halaqati_Certificates_Archive_${LocalDate.now()}.json") },
                        modifier = Modifier.weight(1f).heightIn(min = 48.dp),
                    ) { Text("تصدير JSON") }
                    OutlinedButton(
                        onClick = { importArchiveIndex.launch(arrayOf("application/json", "text/json", "text/plain")) },
                        modifier = Modifier.weight(1f).heightIn(min = 48.dp),
                    ) { Text("استيراد JSON") }
                }
                OutlinedTextField(
                    value = archiveSearch,
                    onValueChange = { archiveSearch = it },
                    label = { Text("بحث بالطالب أو رقم الشهادة") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                )
            }
            if (archiveFiltered.isEmpty()) {
                item { EmptyState("لا توجد شهادات مؤرشفة بعد") }
            } else {
                items(archiveFiltered.take(50), key = { "cert-archive:${it.number}:${it.studentName}" }) { item ->
                    ElevatedCard(Modifier.fillMaxWidth()) {
                        Column {
                            ListItem(
                                headlineContent = { Text(item.studentName, fontWeight = FontWeight.Bold) },
                                supportingContent = { Text("${item.title} · ${item.date}") },
                                leadingContent = { Icon(Icons.Default.WorkspacePremium, contentDescription = null, tint = MaterialTheme.colorScheme.tertiary) },
                                trailingContent = { Text(item.number, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary) },
                            )
                            TextButton(
                                onClick = {
                                    type = item.type
                                    date = LocalDate.now().toString()
                                    fromJuz = item.fromJuz.toString()
                                    toJuz = item.toJuz.toString()
                                    month = item.month.ifBlank { YearMonth.now().toString() }
                                    rank = item.rank.toString()
                                    track = item.track
                                    certificateStyle = item.style
                                    customAchievement = item.achievement
                                    customEdited = true
                                    customTitle = item.title
                                    introText = item.intro
                                    duaText = item.dua
                                    centerName = item.centerName
                                    halaqaName = item.halaqaName
                                    teacherName = item.teacherName
                                    supervisorName = item.supervisorName
                                    number = NativeCertificate.peekNumber(context, ownerUserId)
                                    selectedStudentId = students.firstOrNull { it.fullName == item.studentName }?.id.orEmpty()
                                    bulkMode = false
                                    message = "تم تحميل بيانات الشهادة المؤرشفة كنسخة جديدة برقم جديد"
                                },
                                modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp),
                            ) { Text("إعادة إنشاء كنسخة جديدة") }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun CertificateColorField(label: String, value: String, modifier: Modifier = Modifier, onChange: (String) -> Unit) {
    OutlinedTextField(
        value = value,
        onValueChange = { raw -> onChange(raw.filter { it.isLetterOrDigit() || it == '#' }.take(7)) },
        label = { Text(label) },
        placeholder = { Text("#0D3B2F") },
        singleLine = true,
        modifier = modifier,
    )
}

@Composable
private fun CertificateStyleSlider(label: String, value: Float, range: ClosedFloatingPointRange<Float>, onValueChange: (Float) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(label, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
            Text(kotlin.math.round(value * 10f).div(10f).toString(), style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
        }
        Slider(value = value.coerceIn(range.start, range.endInclusive), onValueChange = onValueChange, valueRange = range)
    }
}

@Composable
private fun CertificateToggle(label: String, checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().heightIn(min = 48.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}

@Composable
private fun CertificateAssetRow(label: String, hasCustom: Boolean, onPick: () -> Unit, onRemove: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().heightIn(min = 52.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Column(Modifier.weight(1f)) {
            Text(label, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
            Text(
                if (hasCustom) "صورة مخصصة محفوظة" else "يُستخدم الافتراضي عند توفره",
                style = MaterialTheme.typography.bodySmall,
                color = if (hasCustom) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        OutlinedButton(onClick = onPick, modifier = Modifier.heightIn(min = 48.dp)) {
            Text(if (hasCustom) "استبدال" else "اختيار")
        }
        if (hasCustom) {
            IconButton(onClick = onRemove, modifier = Modifier.size(48.dp)) {
                Icon(Icons.Default.DeleteOutline, contentDescription = "إزالة $label")
            }
        }
    }
}

private fun safeCertificateFileName(value: String): String = value.replace(Regex("[\\/:*?\"<>|]"), "_").take(70)

private fun certificateTitle(type: String) = when (type) {
    "sard" -> "إتمام سرد أجزاء من القرآن الكريم"
    "khatam" -> "ختم القرآن الكريم"
    "monthly" -> "شهادة التميز الشهري"
    "ideal" -> "شهادة الطالب المثالي"
    "rank" -> "شهادة تفوق وتميز"
    else -> "شهادة تقدير"
}

private fun certificateAchievement(type: String, fromJuz: Int, toJuz: Int, month: String, reason: String, rank: Int, track: String, idealScore: Double): String = when (type) {
    "sard" -> {
        val a = minOf(fromJuz.coerceIn(1, 30), toJuz.coerceIn(1, 30)); val b = maxOf(fromJuz.coerceIn(1, 30), toJuz.coerceIn(1, 30))
        if (a == b) "تقديرًا لإتمامه بحمد الله سرد الجزء $a من كتاب الله تعالى"
        else "تقديرًا لإتمامه بحمد الله سرد الأجزاء من الجزء $a إلى الجزء $b من كتاب الله تعالى"
    }
    "khatam" -> "تقديرًا لإتمامه بحمد الله ختم القرآن الكريم كاملًا، سائلين الله أن يجعله من أهل القرآن وخاصته."
    "monthly" -> "تقديرًا لتميزه خلال شهر ${normalizeArabicDigits(month)}، وذلك لـ${reason.trim().ifBlank { "التميز في الحلقة" }}."
    "ideal" -> "تقديرًا لاختياره الطالب المثالي بما جمعه من حسن الأخلاق والالتزام والمواظبة والجدية في حفظ كتاب الله. الدرجة التقديرية: ${formatNumber(idealScore)}/100."
    "rank" -> "تقديرًا لحصوله على المركز ${(rank.coerceIn(1, 3))} في ${if (track == "tathbit") "مسار التثبيت" else "مسار الحفظ العام"}."
    else -> "تقديرًا لتميزه في حفظ كتاب الله تعالى."
}

private data class CertificatePalette(val background: Int, val primary: Int, val accent: Int, val secondary: Int, val text: Int)

private fun certificatePalette(template: String): CertificatePalette = when (template) {
    "gold" -> CertificatePalette(Color.rgb(253, 248, 235), Color.rgb(122, 82, 18), Color.rgb(191, 148, 58), Color.rgb(134, 88, 33), Color.rgb(42, 35, 24))
    "blue" -> CertificatePalette(Color.rgb(246, 250, 252), Color.rgb(36, 90, 122), Color.rgb(166, 140, 90), Color.rgb(72, 99, 120), Color.rgb(27, 39, 48))
    "burgundy" -> CertificatePalette(Color.rgb(252, 247, 245), Color.rgb(122, 38, 58), Color.rgb(185, 149, 74), Color.rgb(105, 57, 67), Color.rgb(45, 30, 33))
    "classic" -> CertificatePalette(Color.WHITE, Color.rgb(35, 35, 35), Color.rgb(120, 98, 62), Color.rgb(92, 70, 45), Color.rgb(30, 30, 30))
    else -> CertificatePalette(Color.rgb(251, 247, 235), Color.rgb(11, 95, 91), Color.rgb(185, 149, 74), Color.rgb(138, 77, 34), Color.rgb(24, 33, 30))
}

private fun parseCertificateColor(value: String, fallback: Int): Int = runCatching {
    val raw = value.trim()
    if (raw.isBlank()) fallback else Color.parseColor(if (raw.startsWith("#")) raw else "#$raw")
}.getOrDefault(fallback)

private fun certificatePalette(style: NativeCertificateStyle): CertificatePalette {
    val base = certificatePalette(style.template)
    return CertificatePalette(
        background = parseCertificateColor(style.paperHex, base.background),
        primary = parseCertificateColor(style.primaryHex, base.primary),
        accent = parseCertificateColor(style.accentHex, base.accent),
        secondary = parseCertificateColor(style.secondaryHex, base.secondary),
        text = parseCertificateColor(style.inkHex, base.text),
    )
}

object NativeCertificate {
    private const val PREFS = "halaqati_native_certificates"
    private const val ARCHIVE_KEY = "archive_v3"
    private const val STYLE_KEY = "style_v2"
    private const val ASSETS_KEY = "assets_v1"
    private const val MAX_SOURCE_ASSET_BYTES = 5_000_000
    private const val MAX_STORED_ASSET_BYTES = 800_000
    private const val MAX_ARCHIVE_IMPORT_BYTES = 8_000_000
    private val assetKinds = setOf("center_logo", "halaqa_logo", "teacher_signature", "supervisor_signature", "stamp")

    private fun scoped(ownerUserId: String, suffix: String): String = LocalAccountScopeRules.ownerKey(ownerUserId, suffix)

    fun loadStyle(context: Context, ownerUserId: String): NativeCertificateStyle {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(scoped(ownerUserId, STYLE_KEY), null) ?: return NativeCertificateStyle()
        return runCatching { styleFromJson(JSONObject(raw)) }.getOrElse { NativeCertificateStyle() }
    }

    fun saveStyle(context: Context, ownerUserId: String, style: NativeCertificateStyle) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(scoped(ownerUserId, STYLE_KEY), styleToJson(style).toString()).apply()
    }

    fun peekNumber(context: Context, ownerUserId: String): String = peekNumbers(context, ownerUserId, 1).first()

    fun peekNumbers(context: Context, ownerUserId: String, count: Int): List<String> {
        if (count <= 0) return emptyList()
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val year = LocalDate.now().year
        val yearKey = scoped(ownerUserId, "year")
        val seqKey = scoped(ownerUserId, "seq")
        val savedYear = prefs.getInt(yearKey, year)
        val current = if (savedYear == year) prefs.getInt(seqKey, 0) else 0
        return (1..count).map { offset -> "HAL-CERT-$year-${(current + offset).toString().padStart(4, '0')}" }
    }

    fun commitNumber(context: Context, ownerUserId: String, number: String) {
        val match = Regex("HAL-CERT-(\\d{4})-(\\d+)").matchEntire(number.trim()) ?: return
        val year = match.groupValues[1].toIntOrNull() ?: return
        val seq = match.groupValues[2].toIntOrNull() ?: return
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val yearKey = scoped(ownerUserId, "year")
        val seqKey = scoped(ownerUserId, "seq")
        val currentYear = prefs.getInt(yearKey, year)
        val currentSeq = if (currentYear == year) prefs.getInt(seqKey, 0) else 0
        if (seq > currentSeq) prefs.edit().putInt(yearKey, year).putInt(seqKey, seq).apply()
    }

    fun archive(context: Context, ownerUserId: String, drafts: List<NativeCertificateDraft>) {
        if (drafts.isEmpty()) return
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val archiveKey = scoped(ownerUserId, ARCHIVE_KEY)
        val current = runCatching { JSONArray(prefs.getString(archiveKey, "[]") ?: "[]") }.getOrElse { JSONArray() }
        val byNumber = LinkedHashMap<String, JSONObject>()
        drafts.asReversed().forEach { draft -> byNumber[draft.number] = toJson(draft) }
        for (i in 0 until current.length()) {
            current.optJSONObject(i)?.let { obj ->
                val number = obj.optString("number")
                if (number.isNotBlank() && number !in byNumber) byNumber[number] = obj
            }
        }
        val out = JSONArray()
        byNumber.values.take(250).forEach { out.put(it) }
        prefs.edit().putString(archiveKey, out.toString()).apply()
    }

    fun listArchive(context: Context, ownerUserId: String): List<NativeCertificateDraft> {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(scoped(ownerUserId, ARCHIVE_KEY), "[]") ?: "[]"
        val arr = runCatching { JSONArray(raw) }.getOrElse { JSONArray() }
        return (0 until arr.length()).mapNotNull { index -> arr.optJSONObject(index)?.let(::fromJson) }
    }

    private fun toJson(draft: NativeCertificateDraft) = JSONObject()
        .put("number", draft.number)
        .put("student_name", draft.studentName)
        .put("type", draft.type)
        .put("title", draft.title)
        .put("achievement", draft.achievement)
        .put("date", draft.date)
        .put("intro", draft.intro)
        .put("dua", draft.dua)
        .put("center_name", draft.centerName)
        .put("halaqa_name", draft.halaqaName)
        .put("teacher_name", draft.teacherName)
        .put("supervisor_name", draft.supervisorName)
        .put("from_juz", draft.fromJuz)
        .put("to_juz", draft.toJuz)
        .put("month", draft.month)
        .put("rank", draft.rank)
        .put("track", draft.track)
        .put("ideal_score", draft.idealScore ?: JSONObject.NULL)
        .put("style", styleToJson(draft.style))

    private fun fromJson(obj: JSONObject): NativeCertificateDraft? {
        val number = obj.optString("number")
        val student = obj.optString("student_name")
        if (number.isBlank() || student.isBlank()) return null
        return NativeCertificateDraft(
            number = number,
            studentName = student,
            type = obj.optString("type", "sard"),
            title = obj.optString("title", "شهادة تقدير"),
            achievement = obj.optString("achievement"),
            date = obj.optString("date"),
            intro = obj.optString("intro", "تتشرف إدارة مركز إبراهيم خليل الرحمن لتحفيظ القرآن الكريم بمنح هذه الشهادة للطالب"),
            dua = obj.optString("dua", "سائلين الله تعالى أن يثبت القرآن في صدره، وأن يجعله له نورًا وهدًى ورفعةً في الدنيا والآخرة."),
            centerName = obj.optString("center_name", "مركز إبراهيم خليل الرحمن لتحفيظ القرآن الكريم"),
            halaqaName = obj.optString("halaqa_name", "حلقة معاوية بن أبي سفيان"),
            teacherName = obj.optString("teacher_name", "د. محمد سمير أبو يونس"),
            supervisorName = obj.optString("supervisor_name", "الشيخ محمد حلمي أبو عنزة"),
            fromJuz = obj.optInt("from_juz", 1),
            toJuz = obj.optInt("to_juz", 1),
            month = obj.optString("month"),
            rank = obj.optInt("rank", 1),
            track = obj.optString("track", "general_hifz"),
            idealScore = if (obj.isNull("ideal_score")) null else obj.optDouble("ideal_score"),
            style = obj.optJSONObject("style")?.let(::styleFromJson) ?: NativeCertificateStyle(),
        )
    }

    private fun styleToJson(style: NativeCertificateStyle) = JSONObject()
        .put("template", style.template)
        .put("font_family", style.fontFamily)
        .put("title_size", style.titleSize.toDouble())
        .put("student_size", style.studentSize.toDouble())
        .put("body_size", style.bodySize.toDouble())
        .put("logo_size", style.logoSize.toDouble())
        .put("border_width", style.borderWidth.toDouble())
        .put("ornament_strength", style.ornamentStrength.toDouble())
        .put("primary_hex", style.primaryHex)
        .put("accent_hex", style.accentHex)
        .put("secondary_hex", style.secondaryHex)
        .put("paper_hex", style.paperHex)
        .put("ink_hex", style.inkHex)
        .put("show_verse", style.showVerse)
        .put("show_logos", style.showLogos)
        .put("show_signatures", style.showSignatures)
        .put("show_stamp", style.showStamp)
        .put("show_date", style.showDate)
        .put("show_number", style.showNumber)
        .put("number_position", style.numberPosition)

    private fun styleFromJson(obj: JSONObject) = NativeCertificateStyle(
        template = obj.optString("template", "emerald").takeIf { it in setOf("emerald", "gold", "blue", "burgundy", "classic") } ?: "emerald",
        fontFamily = obj.optString("font_family", "Cairo").takeIf { it in setOf("Cairo", "Tahoma", "Arial", "serif") } ?: "Cairo",
        titleSize = obj.optDouble("title_size", 44.0).toFloat().coerceIn(30f, 64f),
        studentSize = obj.optDouble("student_size", 38.0).toFloat().coerceIn(28f, 58f),
        bodySize = obj.optDouble("body_size", 20.0).toFloat().coerceIn(15f, 28f),
        logoSize = obj.optDouble("logo_size", 168.0).toFloat().coerceIn(100f, 230f),
        borderWidth = obj.optDouble("border_width", 3.0).toFloat().coerceIn(1f, 14f),
        ornamentStrength = obj.optDouble("ornament_strength", .82).toFloat().coerceIn(0f, 1f),
        primaryHex = obj.optString("primary_hex"),
        accentHex = obj.optString("accent_hex"),
        secondaryHex = obj.optString("secondary_hex"),
        paperHex = obj.optString("paper_hex"),
        inkHex = obj.optString("ink_hex"),
        showVerse = obj.optBoolean("show_verse", true),
        showLogos = obj.optBoolean("show_logos", true),
        showSignatures = obj.optBoolean("show_signatures", true),
        showStamp = obj.optBoolean("show_stamp", true),
        showDate = obj.optBoolean("show_date", true),
        showNumber = obj.optBoolean("show_number", true),
        numberPosition = obj.optString("number_position", "under_logo").takeIf { it in setOf("under_logo", "top", "footer_start", "footer_end", "header") } ?: "under_logo",
    )

    fun loadAssets(context: Context, ownerUserId: String): NativeCertificateAssets {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(scoped(ownerUserId, ASSETS_KEY), null)
            ?: return NativeCertificateAssets()
        return runCatching { assetsFromJson(JSONObject(raw)) }.getOrElse { NativeCertificateAssets() }
    }

    fun importAsset(context: Context, ownerUserId: String, kind: String, uri: Uri) {
        require(kind in assetKinds) { "نوع أصل الشهادة غير معروف" }
        val bytes = context.contentResolver.openInputStream(uri)?.use { readLimited(it, MAX_SOURCE_ASSET_BYTES) }
            ?: error("تعذر قراءة الصورة")
        val options = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, options)
        require(options.outWidth in 1..12000 && options.outHeight in 1..12000) { "أبعاد الصورة غير صالحة" }
        require(options.outWidth.toLong() * options.outHeight.toLong() <= 60_000_000L) { "الصورة كبيرة جدًا" }
        var sample = 1
        while (maxOf(options.outWidth / sample, options.outHeight / sample) > 1800) sample *= 2
        val bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = sample })
            ?: error("صيغة الصورة غير مدعومة")
        val normalized = normalizeAssetBitmap(bitmap)
        if (normalized !== bitmap) bitmap.recycle()
        val png = compressAssetPng(normalized)
        normalized.recycle()
        val dataUrl = "data:image/png;base64," + Base64.encodeToString(png, Base64.NO_WRAP)
        val current = loadAssets(context, ownerUserId)
        val updated = when (kind) {
            "center_logo" -> current.copy(centerLogo = dataUrl)
            "halaqa_logo" -> current.copy(halaqaLogo = dataUrl)
            "teacher_signature" -> current.copy(teacherSignature = dataUrl)
            "supervisor_signature" -> current.copy(supervisorSignature = dataUrl)
            "stamp" -> current.copy(stamp = dataUrl)
            else -> current
        }
        saveAssets(context, ownerUserId, updated)
    }

    fun removeAsset(context: Context, ownerUserId: String, kind: String) {
        require(kind in assetKinds) { "نوع أصل الشهادة غير معروف" }
        val current = loadAssets(context, ownerUserId)
        val updated = when (kind) {
            "center_logo" -> current.copy(centerLogo = null)
            "halaqa_logo" -> current.copy(halaqaLogo = null)
            "teacher_signature" -> current.copy(teacherSignature = null)
            "supervisor_signature" -> current.copy(supervisorSignature = null)
            "stamp" -> current.copy(stamp = null)
            else -> current
        }
        saveAssets(context, ownerUserId, updated)
    }

    private fun saveAssets(context: Context, ownerUserId: String, assets: NativeCertificateAssets) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(scoped(ownerUserId, ASSETS_KEY), assetsToJson(assets).toString())
            .apply()
    }

    private fun assetsToJson(assets: NativeCertificateAssets) = JSONObject().apply {
        assets.centerLogo?.let { put("center_logo", it) }
        assets.halaqaLogo?.let { put("halaqa_logo", it) }
        assets.teacherSignature?.let { put("teacher_signature", it) }
        assets.supervisorSignature?.let { put("supervisor_signature", it) }
        assets.stamp?.let { put("stamp", it) }
    }

    private fun assetsFromJson(obj: JSONObject): NativeCertificateAssets = NativeCertificateAssets(
        centerLogo = sanitizeStoredAsset(obj.optString("center_logo").takeIf(String::isNotBlank)),
        halaqaLogo = sanitizeStoredAsset(obj.optString("halaqa_logo").takeIf(String::isNotBlank)),
        teacherSignature = sanitizeStoredAsset(obj.optString("teacher_signature").takeIf(String::isNotBlank)),
        supervisorSignature = sanitizeStoredAsset(obj.optString("supervisor_signature").takeIf(String::isNotBlank)),
        stamp = sanitizeStoredAsset(obj.optString("stamp").takeIf(String::isNotBlank)),
    )

    private fun sanitizeStoredAsset(value: String?): String? {
        if (value == null || !value.startsWith("data:image/png;base64,")) return null
        val encoded = value.substringAfter(',')
        val decoded = runCatching { Base64.decode(encoded, Base64.DEFAULT) }.getOrNull() ?: return null
        if (decoded.isEmpty() || decoded.size > MAX_STORED_ASSET_BYTES) return null
        val options = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(decoded, 0, decoded.size, options)
        if (options.outWidth !in 1..1200 || options.outHeight !in 1..1200) return null
        return "data:image/png;base64," + Base64.encodeToString(decoded, Base64.NO_WRAP)
    }

    private fun normalizeAssetBitmap(source: Bitmap): Bitmap {
        val maxDim = maxOf(source.width, source.height)
        if (maxDim <= 900) return source
        val scale = 900f / maxDim.toFloat()
        return Bitmap.createScaledBitmap(source, (source.width * scale).toInt().coerceAtLeast(1), (source.height * scale).toInt().coerceAtLeast(1), true)
    }

    private fun compressAssetPng(source: Bitmap): ByteArray {
        var working = source
        repeat(4) { attempt ->
            val out = ByteArrayOutputStream()
            require(working.compress(Bitmap.CompressFormat.PNG, 100, out)) { "تعذر ضغط الصورة" }
            val bytes = out.toByteArray()
            if (bytes.size <= MAX_STORED_ASSET_BYTES) {
                if (working !== source) working.recycle()
                return bytes
            }
            if (attempt == 3) error("حجم الصورة بعد المعالجة ما زال كبيرًا")
            val next = Bitmap.createScaledBitmap(working, (working.width * .75f).toInt().coerceAtLeast(1), (working.height * .75f).toInt().coerceAtLeast(1), true)
            if (working !== source) working.recycle()
            working = next
        }
        error("تعذر معالجة الصورة")
    }

    private fun readLimited(input: java.io.InputStream, maxBytes: Int): ByteArray {
        val out = ByteArrayOutputStream()
        val buffer = ByteArray(16 * 1024)
        var total = 0
        while (true) {
            val read = input.read(buffer)
            if (read < 0) break
            total += read
            require(total <= maxBytes) { "الملف أكبر من الحد المسموح" }
            out.write(buffer, 0, read)
        }
        return out.toByteArray()
    }

    private fun bitmapFromDataUrl(value: String?): Bitmap? {
        val safe = sanitizeStoredAsset(value) ?: return null
        val bytes = runCatching { Base64.decode(safe.substringAfter(','), Base64.DEFAULT) }.getOrNull() ?: return null
        return BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
    }

    fun exportArchiveIndex(context: Context, ownerUserId: String, uri: Uri): Int {
        val items = listArchive(context, ownerUserId)
        val archiveJson = JSONArray().apply { items.forEach { put(toJson(it)) } }
        val assets = assetsToJson(loadAssets(context, ownerUserId))
        val root = JSONObject()
            .put("schema", "halaqati_certificate_archive")
            .put("version", 3)
            .put("exported_at", java.time.Instant.now().toString())
            .put("archive", archiveJson)
            .put("style", styleToJson(loadStyle(context, ownerUserId)))
            .put("assets", assets)
        context.contentResolver.openOutputStream(uri)?.use { it.write(root.toString(2).toByteArray(Charsets.UTF_8)) }
            ?: error("تعذر فتح ملف الأرشيف")
        return items.size
    }

    fun importArchiveIndex(context: Context, ownerUserId: String, uri: Uri): Int {
        val bytes = context.contentResolver.openInputStream(uri)?.use { readLimited(it, MAX_ARCHIVE_IMPORT_BYTES) }
            ?: error("تعذر قراءة ملف الأرشيف")
        val text = bytes.toString(Charsets.UTF_8).trim()
        require(text.isNotEmpty()) { "ملف الأرشيف فارغ" }
        val (arr, importedStyle, importedAssets) = if (text.startsWith("[")) {
            Triple(JSONArray(text), null, null)
        } else {
            val root = JSONObject(text)
            require(root.optString("schema") == "halaqati_certificate_archive") { "صيغة أرشيف الشهادات غير معروفة" }
            require(root.optInt("version", 0) in 1..3) { "إصدار أرشيف الشهادات غير مدعوم" }
            Triple(
                root.optJSONArray("archive") ?: JSONArray(),
                root.optJSONObject("style")?.let(::styleFromJson),
                root.optJSONObject("assets")?.let(::assetsFromJson),
            )
        }
        val imported = (0 until arr.length()).mapNotNull { arr.optJSONObject(it)?.let(::fromJson) }
        require(imported.isNotEmpty() || arr.length() == 0) { "ملف الأرشيف لا يحتوي سجلات شهادات صالحة" }
        archive(context, ownerUserId, imported)
        importedStyle?.let { saveStyle(context, ownerUserId, it) }
        importedAssets?.let { saveAssets(context, ownerUserId, it) }
        return imported.size
    }

    fun export(context: Context, uri: Uri, ownerUserId: String, draft: NativeCertificateDraft) = exportBatch(context, uri, ownerUserId, listOf(draft))

    fun exportBatch(context: Context, uri: Uri, ownerUserId: String, drafts: List<NativeCertificateDraft>) {
        require(drafts.isNotEmpty()) { "لا توجد شهادات للإصدار" }
        drafts.forEach(::validate)
        val pdf = PdfDocument()
        val assets = loadAssets(context, ownerUserId)
        try {
            drafts.forEachIndexed { index, draft -> renderPage(context, pdf, draft, assets, index + 1) }
            context.contentResolver.openOutputStream(uri)?.use { pdf.writeTo(it) } ?: error("تعذر فتح ملف الحفظ")
        } finally {
            pdf.close()
        }
    }

    private fun validate(draft: NativeCertificateDraft) {
        require(draft.studentName.isNotBlank()) { "اسم الطالب مطلوب" }
        require(draft.number.isNotBlank()) { "رقم الشهادة مطلوب" }
        require(runCatching { LocalDate.parse(draft.date) }.isSuccess) { "تاريخ الشهادة غير صالح" }
    }

    fun previewBitmap(context: Context, ownerUserId: String, draft: NativeCertificateDraft): Bitmap {
        validate(draft)
        val bitmap = Bitmap.createBitmap(1123, 794, Bitmap.Config.ARGB_8888)
        drawCertificateCanvas(context, Canvas(bitmap), draft, loadAssets(context, ownerUserId))
        return bitmap
    }

    private fun renderPage(context: Context, pdf: PdfDocument, draft: NativeCertificateDraft, assets: NativeCertificateAssets, pageNumber: Int) {
        val page = pdf.startPage(PdfDocument.PageInfo.Builder(1123, 794, pageNumber).create())
        drawCertificateCanvas(context, page.canvas, draft, assets)
        pdf.finishPage(page)
    }

    private fun drawCertificateCanvas(context: Context, canvas: Canvas, draft: NativeCertificateDraft, assets: NativeCertificateAssets) {
        val style = draft.style
        val palette = certificatePalette(style)
        canvas.drawColor(palette.background)

        val outer = Paint(Paint.ANTI_ALIAS_FLAG).apply { this.style = Paint.Style.STROKE; strokeWidth = style.borderWidth; color = palette.primary }
        val gold = Paint(Paint.ANTI_ALIAS_FLAG).apply { this.style = Paint.Style.STROKE; strokeWidth = 2.5f; color = palette.accent; alpha = (255 * style.ornamentStrength).toInt().coerceIn(64, 255) }
        val brown = Paint(Paint.ANTI_ALIAS_FLAG).apply { this.style = Paint.Style.STROKE; strokeWidth = 1.4f; color = palette.secondary; alpha = (255 * style.ornamentStrength).toInt().coerceIn(64, 255) }
        canvas.drawRect(34f, 34f, 1089f, 760f, outer)
        canvas.drawRect(50f, 50f, 1073f, 744f, gold)
        canvas.drawRect(61f, 61f, 1062f, 733f, brown)
        repeat(4) { i ->
            val left = i % 2 == 0
            val top = i < 2
            val cx = if (left) 82f else 1041f
            val cy = if (top) 82f else 712f
            canvas.drawCircle(cx, cy, 13f, gold)
            canvas.drawCircle(cx, cy, 6f, brown)
        }

        if (style.showLogos) runCatching {
            val customLeft = bitmapFromDataUrl(assets.centerLogo)
            val customRight = bitmapFromDataUrl(assets.halaqaLogo)
            val left = customLeft ?: BitmapFactory.decodeResource(context.resources, R.drawable.center_logo)
            val right = customRight ?: BitmapFactory.decodeResource(context.resources, R.drawable.halaqa_logo)
            val logo = style.logoSize
            val half = logo / 2f
            canvas.drawBitmap(left, null, android.graphics.RectF(132f - half, 128f - half, 132f + half, 128f + half), null)
            canvas.drawBitmap(right, null, android.graphics.RectF(991f - half, 128f - half, 991f + half, 128f + half), null)
            left.recycle(); right.recycle()
        }

        fun text(value: String, y: Float, size: Float, bold: Boolean = false, color: Int = Color.rgb(24, 33, 30), maxLines: Int = 2) {
            val paint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
                textSize = size; this.color = color
                val base = if (style.fontFamily == "Cairo") ResourcesCompat.getFont(context, R.font.cairo) ?: Typeface.DEFAULT else Typeface.create(style.fontFamily, Typeface.NORMAL)
                typeface = Typeface.create(base, if (bold) Typeface.BOLD else Typeface.NORMAL)
            }
            val layout = StaticLayout.Builder.obtain(value, 0, value.length, paint, 900)
                .setAlignment(Layout.Alignment.ALIGN_CENTER).setTextDirection(TextDirectionHeuristics.RTL)
                .setIncludePad(false).setMaxLines(maxLines).build()
            canvas.save(); canvas.translate(111f, y); layout.draw(canvas); canvas.restore()
        }

        text(draft.centerName, 86f, 18f, true, palette.primary)
        if (style.showNumber && style.numberPosition in setOf("header", "top")) text("رقم الشهادة: ${draft.number}", 112f, 15f, true, palette.primary)
        if (style.showNumber && style.numberPosition == "under_logo") text("رقم الشهادة: ${draft.number}", 166f, 14f, true, palette.primary)
        if (style.showVerse) text("﴿ وَقُلْ رَبِّ زِدْنِي عِلْمًا ﴾", 142f, 20f, false, palette.secondary)
        text(draft.title, 191f, style.titleSize, true, palette.primary)
        text(draft.intro, 282f, 22f, false, palette.text)
        text(draft.studentName, 332f, style.studentSize, true, palette.secondary)
        text(draft.achievement, 420f, style.bodySize, false, palette.text, 3)
        text(draft.dua, 510f, 19f, false, palette.text, 2)
        val footerParts = buildList {
            if (style.showDate) add("التاريخ: ${draft.date}")
            if (style.showNumber && style.numberPosition == "footer_start") add("رقم الشهادة: ${draft.number}")
        }
        if (footerParts.isNotEmpty()) text(footerParts.joinToString("    ·    "), 582f, 17f, true, palette.primary)
        if (style.showNumber && style.numberPosition == "footer_end") text("رقم الشهادة: ${draft.number}", 610f, 15f, true, palette.primary)
        if (style.showSignatures) {
            text("المحفظ: ${draft.teacherName}", 650f, 15f, true, palette.primary)
            text("المشرف: ${draft.supervisorName}", 680f, 15f, true, palette.primary)
            val teacher = bitmapFromDataUrl(assets.teacherSignature)
            val supervisor = bitmapFromDataUrl(assets.supervisorSignature)
            if (teacher != null || supervisor != null) {
                teacher?.let { bmp ->
                    canvas.drawBitmap(bmp, null, android.graphics.RectF(230f, 610f, 420f, 670f), null)
                    bmp.recycle()
                }
                supervisor?.let { bmp ->
                    canvas.drawBitmap(bmp, null, android.graphics.RectF(704f, 610f, 894f, 670f), null)
                    bmp.recycle()
                }
                text("المحفظ                    المشرف", 674f, 15f, false, palette.text)
            } else {
                text("المحفظ: د. محمد سمير أبو يونس                    المشرف: الشيخ محمد حلمي أبو عنزة", 646f, 17f, false, palette.text)
            }
        }
        if (style.showStamp) {
            bitmapFromDataUrl(assets.stamp)?.let { bmp ->
                canvas.drawBitmap(bmp, null, android.graphics.RectF(511f, 603f, 611f, 703f), null)
                bmp.recycle()
            }
        }
        text("حلقة معاوية بن أبي سفيان · مركز إبراهيم خليل الرحمن", 714f, 16f, true, palette.secondary)

    }
}

private data class MonthComparison(
    val currentPages: Double,
    val previousPages: Double,
    val currentAbsent: Int,
    val previousAbsent: Int,
    val currentSafety: Double,
    val previousSafety: Double,
)

private fun buildMonthComparison(current: JSONArray, previous: JSONArray): MonthComparison {
    fun metrics(arr: JSONArray): Triple<Double, Int, Double> {
        var pages = 0.0
        var absent = 0
        var mistakes = 0
        var prompts = 0
        for (i in 0 until arr.length()) {
            val row = arr.optJSONObject(i) ?: continue
            pages += row.optDouble("total_pages", 0.0)
            absent += row.optInt("absent", 0) + row.optInt("excused", 0)
            mistakes += row.optInt("mistakes", 0)
            prompts += row.optInt("prompts", 0)
        }
        return Triple(pages, absent, SafetyScoring.calculate(pages, mistakes, prompts))
    }
    val c = metrics(current); val p = metrics(previous)
    return MonthComparison(c.first, p.first, c.second, p.second, c.third, p.third)
}

@Composable
private fun MonthComparisonRow(label: String, previous: Double, current: Double, suffix: String, positiveUp: Boolean) {
    val delta = current - previous
    val favorable = if (positiveUp) delta >= 0 else delta <= 0
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, modifier = Modifier.weight(1f), style = MaterialTheme.typography.titleMedium)
        Text("${formatNumber(previous)}$suffix ← ${formatNumber(current)}$suffix", fontWeight = FontWeight.Bold)
        Spacer(Modifier.width(10.dp))
        Text(
            (if (delta >= 0) "+" else "") + formatNumber(delta) + suffix + if (delta >= 0) " ↑" else " ↓",
            color = if (favorable) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error,
            fontWeight = FontWeight.Bold,
        )
    }
}

@Composable
fun QuranCalculatorScreen() {
    var first by remember { mutableStateOf("") }
    var second by remember { mutableStateOf("") }
    var picker by remember { mutableStateOf(false) }
    val page1 = first.toIntOrNull()
    val page2 = second.toIntOrNull()
    val range = if (page1 != null && page2 != null && page1 in 1..604 && page2 in 1..604) {
        runCatching { QuranMetadata.rangeForPages(page1, page2) }.getOrNull()
    } else null

    Column {
        AppTopBar("المصحف والاختيار الدقيق")
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(
                "مصحف المدينة — حفص · 604 صفحة · 30 جزءًا · 240 ربع حزب",
                style = MaterialTheme.typography.titleMedium,
            )
            Button(
                onClick = { picker = true },
                modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp),
            ) {
                Icon(Icons.Default.MenuBook, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("اختيار سورة / آية / صفحة / جزء / ربع")
            }
            HorizontalDivider()
            Text("الحاسبة السريعة بالصفحات", style = MaterialTheme.typography.titleSmall)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = first,
                    onValueChange = { first = it.filter(Char::isDigit).take(3) },
                    label = { Text("الصفحة الأولى") },
                    modifier = Modifier.weight(1f),
                    singleLine = true,
                )
                OutlinedTextField(
                    value = second,
                    onValueChange = { second = it.filter(Char::isDigit).take(3) },
                    label = { Text("الصفحة الثانية") },
                    modifier = Modifier.weight(1f),
                    singleLine = true,
                )
            }
            MetricCard("عدد الصفحات", range?.pageCount?.toString() ?: "—", "يُحسب شاملًا صفحة البداية والنهاية")
            range?.let { selected ->
                ElevatedCard(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                        Text("من ${selected.start.label} إلى ${selected.end.label}", style = MaterialTheme.typography.titleSmall)
                        Text("الصفحات ${selected.normalizedStartPage}–${selected.normalizedEndPage}")
                        Text(
                            "الأجزاء ${QuranMetadata.juzFor(selected.start.surah, selected.start.ayah)}–" +
                                "${QuranMetadata.juzFor(selected.end.surah, selected.end.ayah)} · " +
                                "أرباع الحزب ${QuranMetadata.rubFor(selected.start.surah, selected.start.ayah)}–" +
                                "${QuranMetadata.rubFor(selected.end.surah, selected.end.ayah)}",
                            style = MaterialTheme.typography.bodyMedium,
                        )
                    }
                }
            }
            Text(
                "يُعرض النطاق دائمًا من البداية الأقل إلى النهاية الأعلى بصريًا، حتى عند استخدام مسار حفظ عكسي من الناس باتجاه البقرة.",
                style = MaterialTheme.typography.bodySmall,
            )
        }
    }

    if (picker) {
        QuranRangePickerDialog(
            initialStartPage = page1,
            initialEndPage = page2,
            onDismiss = { picker = false },
            onConfirm = { selected ->
                first = selected.normalizedStartPage.toString()
                second = selected.normalizedEndPage.toString()
                picker = false
            },
        )
    }
}

@Composable
fun RankingsScreen(profile: Profile, pending: Int, onRefresh: () -> Unit) {
    val scope = rememberCoroutineScope()
    var rows by remember { mutableStateOf<List<JSONObject>>(emptyList()) }
    var loading by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }
    var periodDays by remember { mutableIntStateOf(30) }

    suspend fun reload() {
        loading = true
        try {
            val from = LocalDate.now().minusDays((periodDays - 1).toLong()).toString()
            val to = LocalDate.now().toString()
            rows = withContext(Dispatchers.IO) {
                if (profile.role == UserRole.GUARDIAN) {
                    val children = AppGraph.repo.students().filter { it.status == "active" }
                    buildList {
                        children.forEach { child ->
                            val dashboard = AppGraph.repo.guardianDashboard(child.id, from, to)
                            val ranks = dashboard.optJSONObject("ranks") ?: JSONObject()
                            listOf("hifz", "review", "sard").forEach { track ->
                                val metric = ranks.optJSONObject(track) ?: JSONObject()
                                add(
                                    JSONObject()
                                        .put("student_id", child.id)
                                        .put("student_name", child.fullName)
                                        .put("track", track)
                                        .put("rank_no", metric.optInt("halaqa_rank", 0))
                                        .put("total_students", metric.optInt("halaqa_total", 0))
                                        .put("category_rank", metric.optInt("category_rank", 0))
                                        .put("category_total", metric.optInt("category_total", 0))
                                        .put("points", metric.optDouble("points", 0.0))
                                        .put("pages", metric.optDouble("pages", 0.0)),
                                )
                            }
                        }
                    }
                } else {
                    val data = AppGraph.repo.rankingRange(from, to)
                    (0 until data.length()).mapNotNull { data.optJSONObject(it) }
                }
            }
            message = null
        } catch (e: Exception) {
            message = e.message ?: "تعذر تحميل الترتيب"
        } finally {
            loading = false
        }
    }

    LaunchedEffect(periodDays) { reload() }

    Column {
        AppTopBar(
            "الترتيب والإحصائيات",
            onRefresh = {
                scope.launch { reload() }
                onRefresh()
            },
            pending = pending,
        )
        Row(
            Modifier.padding(horizontal = 12.dp, vertical = 8.dp).horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            listOf(7, 14, 30).forEach { days ->
                ProFilterChip(selected = periodDays == days, onClick = { periodDays = days }, label = "$days يوم")
            }
        }
        if (loading) LinearProgressIndicator(Modifier.fillMaxWidth())
        message?.let { StateNotice(it, "error", Modifier.padding(12.dp)) }
        if (!loading && rows.isEmpty()) EmptyState("لا توجد بيانات ترتيب في الفترة")
        LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (profile.role == UserRole.GUARDIAN) {
                items(rows, key = { "${it.optString("student_id")}:${it.optString("track")}" }) { item ->
                    val pages = item.optDouble("pages", 0.0)
                    val rank = item.optInt("rank_no", 0)
                    val total = item.optInt("total_students", 0)
                    val categoryRank = item.optInt("category_rank", 0)
                    val categoryTotal = item.optInt("category_total", 0)
                    ElevatedCard(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.EmojiEvents, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                Spacer(Modifier.width(8.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(item.optString("student_name", "طالب"), fontWeight = FontWeight.Bold)
                                    Text(activityTrackAr(item.optString("track")), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                Text(if (pages > 0 && rank > 0 && total > 0) "$rank / $total" else "—", style = MaterialTheme.typography.titleMedium)
                            }
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("النقاط ${formatNumber(item.optDouble("points", 0.0))}")
                                Text("الصفحات ${formatNumber(pages)}")
                            }
                            Text(
                                if (pages > 0 && categoryRank > 0 && categoryTotal > 0) "ترتيب الفئة: $categoryRank / $categoryTotal" else "ترتيب الفئة: —",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                }
            } else {
                itemsIndexed(rows) { index, item ->
                    val student = item.optJSONObject("students")
                    ElevatedCard(Modifier.fillMaxWidth()) {
                        ListItem(
                            headlineContent = {
                                Text(
                                    "${index + 1}. " +
                                        (student?.optString("full_name") ?: item.optString("student_name", "طالب")),
                                )
                            },
                            supportingContent = {
                                Text("${formatNumber(item.optDouble("points", item.optDouble("score", 0.0)))} نقطة · ${formatNumber(item.optDouble("pages", 0.0))} ص")
                            },
                            leadingContent = { Icon(Icons.Default.EmojiEvents, contentDescription = null) },
                        )
                    }
                }
            }
        }
    }
}

private fun activityTrackAr(value: String) = when (value) {
    "hifz" -> "الحفظ"
    "review" -> "المراجعة"
    "sard" -> "السرد"
    else -> value
}

@Composable
fun ImportExportScreen(profile: Profile, pending: Int, onRefresh: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var status by remember { mutableStateOf("") }
    var preview by remember { mutableStateOf<List<List<String>>>(emptyList()) }
    var fileName by remember { mutableStateOf("") }
    var importing by remember { mutableStateOf(false) }
    var importedCount by remember { mutableIntStateOf(0) }
    var failedCount by remember { mutableIntStateOf(0) }
    var skippedCount by remember { mutableIntStateOf(0) }
    var importKind by remember { mutableStateOf("students") }
    var halaqas by remember { mutableStateOf<List<JSONObject>>(emptyList()) }
    var selectedHalaqaId by remember { mutableStateOf("") }
    var manualText by remember { mutableStateOf("") }
    var showManualPaste by remember { mutableStateOf(false) }
    var mappingEpoch by remember { mutableIntStateOf(0) }
    var mappingEditorOpen by remember { mutableStateOf(false) }

    val canImport = profile.role in setOf(UserRole.ADMIN, UserRole.SUPERVISOR, UserRole.TEACHER)
    val advanced = profile.role in setOf(UserRole.ADMIN, UserRole.SUPERVISOR)

    LaunchedEffect(profile.id) {
        runCatching {
            withContext(Dispatchers.IO) {
                val data = AppGraph.repo.table("halaqas", "select=id,name,active&active=eq.true&order=name.asc&limit=100")
                (0 until data.length()).mapNotNull { data.optJSONObject(it) }
            }
        }.onSuccess {
            halaqas = it
            if (selectedHalaqaId.isBlank()) selectedHalaqaId = it.firstOrNull()?.optString("id").orEmpty()
        }.onFailure { status = "تعذر تحميل الحلقات: ${it.message ?: "خطأ"}" }
    }

    val open = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            scope.launch {
                try {
                    preview = withContext(Dispatchers.IO) { SmartImport.read(context, uri) }
                    mappingEpoch++
                    fileName = uri.lastPathSegment?.substringAfterLast('/') ?: "ملف مستورد"
                    importedCount = 0; failedCount = 0; skippedCount = 0
                    status = if (preview.isEmpty()) "لم يتم العثور على صفوف قابلة للقراءة" else "تمت القراءة: ${preview.size} صف. راجع الأعمدة والبيانات قبل الاعتماد."
                } catch (e: Exception) {
                    preview = emptyList()
                    status = "تعذر القراءة الآمنة: ${e.message ?: "خطأ"}"
                }
            }
        }
    }
    val create = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/json"),
    ) { uri ->
        if (uri != null) {
            scope.launch {
                try {
                    withContext(Dispatchers.IO) { Backup.export(context, uri) }
                    status = "تم إنشاء النسخة الاحتياطية"
                } catch (e: Exception) {
                    status = e.message ?: "تعذر إنشاء النسخة الاحتياطية"
                }
            }
        }
    }

    suspend fun studentExportRows(): List<NativeStudentExport.Row> = withContext(Dispatchers.IO) {
        val students = AppGraph.repo.students(forceRefresh = true)
        val h = AppGraph.repo.table("halaqas", "select=id,name&limit=500")
        val c = AppGraph.repo.table("student_categories", "select=id,name&limit=1000")
        val halaqaNames = (0 until h.length()).mapNotNull { h.optJSONObject(it) }.associate { it.optString("id") to it.optString("name") }
        val categoryNames = (0 until c.length()).mapNotNull { c.optJSONObject(it) }.associate { it.optString("id") to it.optString("name") }
        NativeStudentExport.rows(students, halaqaNames, categoryNames)
    }
    val exportXlsx = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"),
    ) { uri ->
        if (uri != null) scope.launch {
            runCatching {
                val data = studentExportRows()
                require(data.isNotEmpty()) { "لا يوجد طلاب للتصدير" }
                withContext(Dispatchers.IO) { NativeStudentExport.exportXlsx(context, uri, data) }
            }.onSuccess { status = "تم تصدير الطلاب Excel" }
                .onFailure { status = "تعذر تصدير Excel: ${it.message ?: "خطأ"}" }
        }
    }
    val exportWord = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/msword"),
    ) { uri ->
        if (uri != null) scope.launch {
            runCatching {
                val data = studentExportRows()
                require(data.isNotEmpty()) { "لا يوجد طلاب للتصدير" }
                withContext(Dispatchers.IO) { NativeStudentExport.exportWord(context, uri, data) }
            }.onSuccess { status = "تم تصدير الطلاب Word" }
                .onFailure { status = "تعذر تصدير Word: ${it.message ?: "خطأ"}" }
        }
    }
    val exportPdf = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/pdf"),
    ) { uri ->
        if (uri != null) scope.launch {
            runCatching {
                val data = studentExportRows()
                require(data.isNotEmpty()) { "لا يوجد طلاب للتصدير" }
                withContext(Dispatchers.IO) { NativeStudentExport.exportPdf(context, uri, data) }
            }.onSuccess { status = "تم تصدير الطلاب PDF" }
                .onFailure { status = "تعذر تصدير PDF: ${it.message ?: "خطأ"}" }
        }
    }

    val headers = preview.firstOrNull().orEmpty()
    val rows = if (preview.size > 1) preview.drop(1) else emptyList()
    var studentMapping by remember(mappingEpoch, headers) { mutableStateOf(ImportMapping.detect(headers)) }
    var recitationMapping by remember(mappingEpoch, headers) { mutableStateOf(RecitationImportMapping.detect(headers)) }
    var monthlyPlanMapping by remember(mappingEpoch, headers) { mutableStateOf(MonthlyPlanImportMapping.detect(headers)) }
    val preflight = remember(rows, importKind, studentMapping, recitationMapping, monthlyPlanMapping) {
        importPreflight(rows, importKind, studentMapping, recitationMapping, monthlyPlanMapping)
    }

    Column {
        AppTopBar("الاستيراد والتصدير", onRefresh = onRefresh, pending = pending)
        Column(Modifier.padding(horizontal = 12.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary),
            ) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("الاستيراد والتصدير", color = MaterialTheme.colorScheme.onPrimary, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                    Text("تصدير بيانات الطلاب الأساسية واستيراد البيانات مع مرحلة مراجعة قبل الحفظ.", color = MaterialTheme.colorScheme.onPrimary.copy(alpha = .82f))
                }
            }
            Text("تصدير بيانات الطلاب", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { exportXlsx.launch("طلاب_حلقتي_${LocalDate.now()}.xlsx") }, modifier = Modifier.heightIn(min = 48.dp)) {
                    Icon(Icons.Default.TableView, contentDescription = null); Spacer(Modifier.width(6.dp)); Text("تصدير الطلاب Excel")
                }
                OutlinedButton(onClick = { exportWord.launch("طلاب_حلقتي_${LocalDate.now()}.doc") }, modifier = Modifier.heightIn(min = 48.dp)) {
                    Icon(Icons.Default.Description, contentDescription = null); Spacer(Modifier.width(6.dp)); Text("تصدير الطلاب Word")
                }
                OutlinedButton(onClick = { exportPdf.launch("طلاب_حلقتي_${LocalDate.now()}.pdf") }, modifier = Modifier.heightIn(min = 48.dp)) {
                    Icon(Icons.Default.PictureAsPdf, contentDescription = null); Spacer(Modifier.width(6.dp)); Text("تصدير الطلاب PDF")
                }
            }
            if (canImport) {
                Text("نوع الاستيراد", style = MaterialTheme.typography.labelLarge)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ProFilterChip(selected = importKind == "students", onClick = { importKind = "students" }, label = "الطلاب")
                    if (advanced) {
                        ProFilterChip(selected = importKind == "recitations", onClick = { importKind = "recitations" }, label = "تسميعات سابقة")
                        ProFilterChip(selected = importKind == "plans", onClick = { importKind = "plans" }, label = "الأهداف الشهرية")
                    }
                }
                Text("الحلقة المستهدفة", style = MaterialTheme.typography.labelLarge)
                if (halaqas.isEmpty()) {
                    Text("لا توجد حلقة مفعلة متاحة لهذا الحساب", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodyMedium)
                } else {
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        halaqas.forEach { halaqa ->
                            val id = halaqa.optString("id")
                            ProFilterChip(
                                selected = selectedHalaqaId == id,
                                onClick = { selectedHalaqaId = id },
                                label = halaqa.optString("name", "حلقة"),
                            )
                        }
                    }
                }
            }
            Row(
                Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                if (canImport) Button(onClick = {
                    open.launch(
                        arrayOf(
                            "text/csv",
                            "text/plain",
                            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                            "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                            "application/pdf",
                            "image/*",
                        ),
                    )
                }, modifier = Modifier.heightIn(min = 48.dp)) {
                    Icon(Icons.Default.UploadFile, contentDescription = null)
                    Text(" اختيار ملف")
                }
                if (canImport) OutlinedButton(
                    onClick = { showManualPaste = !showManualPaste },
                    modifier = Modifier.heightIn(min = 48.dp),
                ) {
                    Icon(Icons.Default.ContentPaste, contentDescription = null)
                    Text(" لصق بيانات")
                }
                Button(onClick = { create.launch("Halaqati_Backup_${LocalDate.now()}_2.46.0.json") }, modifier = Modifier.heightIn(min = 48.dp)) {
                    Icon(Icons.Default.Download, contentDescription = null)
                    Text(" نسخة احتياطية")
                }
            }

            Surface(color = MaterialTheme.colorScheme.secondaryContainer, shape = MaterialTheme.shapes.medium) {
                Text(
                    "لا يتم حفظ أي صف أثناء المعاينة. CSV/TXT وXLSX وDOCX تُحلل محليًا. PDF والصور لا تُعتمد عبر OCR تلقائي؛ استخرج النص بأداة موثوقة ثم الصقه هنا وراجعه قبل الحفظ.",
                    Modifier.fillMaxWidth().padding(12.dp),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSecondaryContainer,
                )
            }
            if (showManualPaste && canImport) {
                OutlinedTextField(
                    value = manualText,
                    onValueChange = { manualText = it },
                    modifier = Modifier.fillMaxWidth().heightIn(min = 140.dp),
                    label = { Text("نص جدولي تمت مراجعته") },
                    supportingText = { Text("يدعم Tab أو فاصلة أو فاصلة منقوطة أو |. أول سطر يجب أن يحتوي أسماء الأعمدة.") },
                )
                Button(
                    onClick = {
                        preview = SmartImport.readText(manualText)
                        mappingEpoch++
                        fileName = "manual-reviewed-${LocalDate.now()}.txt"
                        importedCount = 0; failedCount = 0; skippedCount = 0
                        status = if (preview.size > 1) "تم تحليل النص يدويًا. راجع المعاينة ثم اعتمد." else "النص لا يحتوي جدولًا صالحًا"
                    },
                    enabled = manualText.isNotBlank(),
                    modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp),
                ) { Text("تحليل النص للمعاينة") }
            }
            if (status.isNotBlank()) Text(status, style = MaterialTheme.typography.bodyMedium)
        }

        if (preview.isNotEmpty()) {
            ElevatedCard(Modifier.fillMaxWidth().padding(horizontal = 12.dp)) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.TableView, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.width(8.dp))
                        Column(Modifier.weight(1f)) {
                            Text(fileName.ifBlank { "معاينة الملف" }, fontWeight = FontWeight.Bold)
                            Text("${rows.size} صف بيانات · ${headers.size} عمود", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                    if (headers.isNotEmpty()) {
                        Text("الأعمدة المكتشفة", style = MaterialTheme.typography.labelLarge)
                        Text(headers.joinToString(" | "), style = MaterialTheme.typography.bodyMedium)
                        OutlinedButton(
                            onClick = { mappingEditorOpen = true },
                            modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp),
                        ) {
                            Icon(Icons.Default.Tune, contentDescription = null)
                            Spacer(Modifier.width(8.dp))
                            Text("تعديل ربط الأعمدة")
                        }
                        Text("فحص ما قبل الاعتماد", style = MaterialTheme.typography.labelLarge)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            ImportResultBadge("صالح", preflight.valid, Modifier.weight(1f))
                            ImportResultBadge("سيتجاوز", preflight.skipped, Modifier.weight(1f))
                            ImportResultBadge("يحتاج تصحيح", preflight.invalid, Modifier.weight(1f))
                        }
                        if (preflight.invalid > 0) {
                            StateNotice("يوجد ${preflight.invalid} صف غير صالح بنيويًا. لن يتم تحويل القيم المجهولة أو السالبة إلى بيانات صحيحة تلقائيًا.", kind = "warning")
                        }
                    }

                    when (importKind) {
                        "students" -> {
                            val summary = buildList {
                                add("الاسم: ${studentMapping.fullName?.let { headers.getOrNull(it) } ?: "غير مكتشف"}")
                                studentMapping.track?.let { add("المسار: ${headers.getOrNull(it)}") }
                                studentMapping.category?.let { add("الفئة: ${headers.getOrNull(it)}") }
                                studentMapping.guardianPhone?.let { add("جوال ولي الأمر: ${headers.getOrNull(it)}") }
                            }
                            Text(summary.joinToString(" · "), style = MaterialTheme.typography.bodyMedium, color = if (studentMapping.fullName == null) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant)
                            ImportCommitButton(
                                importing = importing,
                                enabled = rows.isNotEmpty() && studentMapping.fullName != null && selectedHalaqaId.isNotBlank(),
                                label = "اعتماد الطلاب بعد المراجعة",
                            ) {
                                importing = true
                                scope.launch {
                                    try {
                                        val result = withContext(Dispatchers.IO) {
                                            importStudentsReviewed(rows, studentMapping, fileName.ifBlank { "import" }, selectedHalaqaId)
                                        }
                                        importedCount = result.imported; failedCount = result.failed; skippedCount = result.skipped
                                        status = importResultText(result)
                                        onRefresh()
                                    } catch (e: Exception) { status = e.message ?: "تعذر اعتماد الاستيراد" }
                                    finally { importing = false }
                                }
                            }
                        }
                        "recitations" -> {
                            val valid = recitationMapping.student != null && recitationMapping.date != null && recitationMapping.type != null && recitationMapping.pages != null
                            Text(
                                "الطالب: ${recitationMapping.student?.let { headers.getOrNull(it) } ?: "غير مكتشف"} · التاريخ: ${recitationMapping.date?.let { headers.getOrNull(it) } ?: "غير مكتشف"} · النوع: ${recitationMapping.type?.let { headers.getOrNull(it) } ?: "غير مكتشف"} · الصفحات: ${recitationMapping.pages?.let { headers.getOrNull(it) } ?: "غير مكتشف"}",
                                style = MaterialTheme.typography.bodyMedium,
                                color = if (valid) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.error,
                            )
                            Text("اعتماد التسميعات القديمة يتطلب اتصالًا بالإنترنت حتى يتم ربط كل صف بجلسة صحيحة ومنع التكرار. التقييم والنقاط تُعاد حسابها بمحرك V6 نفسه.", style = MaterialTheme.typography.bodyMedium)
                            ImportCommitButton(importing, valid && rows.isNotEmpty() && selectedHalaqaId.isNotBlank(), "اعتماد التسميعات بعد المراجعة") {
                                importing = true
                                scope.launch {
                                    try {
                                        val result = withContext(Dispatchers.IO) {
                                            importRecitationsReviewed(rows, recitationMapping, fileName.ifBlank { "import" }, selectedHalaqaId)
                                        }
                                        importedCount = result.imported; failedCount = result.failed; skippedCount = result.skipped
                                        status = importResultText(result)
                                        onRefresh()
                                    } catch (e: Exception) { status = e.message ?: "تعذر اعتماد التسميعات" }
                                    finally { importing = false }
                                }
                            }
                        }
                        "plans" -> {
                            val valid = monthlyPlanMapping.student != null && monthlyPlanMapping.month != null &&
                                listOf(monthlyPlanMapping.hifz, monthlyPlanMapping.review, monthlyPlanMapping.sard).any { it != null }
                            Text(
                                "الطالب: ${monthlyPlanMapping.student?.let { headers.getOrNull(it) } ?: "غير مكتشف"} · الشهر: ${monthlyPlanMapping.month?.let { headers.getOrNull(it) } ?: "غير مكتشف"} · أهداف الحفظ/المراجعة/السرد تُحدّث في student_goals ولا تُنشئ Smart Plan جديدة.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = if (valid) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.error,
                            )
                            ImportCommitButton(importing, valid && rows.isNotEmpty() && selectedHalaqaId.isNotBlank(), "اعتماد الأهداف الشهرية بعد المراجعة") {
                                importing = true
                                scope.launch {
                                    try {
                                        val result = withContext(Dispatchers.IO) {
                                            importMonthlyPlansReviewed(rows, monthlyPlanMapping, fileName.ifBlank { "import" }, selectedHalaqaId)
                                        }
                                        importedCount = result.imported; failedCount = result.failed; skippedCount = result.skipped
                                        status = importResultText(result)
                                        onRefresh()
                                    } catch (e: Exception) { status = e.message ?: "تعذر اعتماد الأهداف الشهرية" }
                                    finally { importing = false }
                                }
                            }
                        }
                    }
                    if (importedCount + failedCount + skippedCount > 0) {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            ImportResultBadge("مضاف/محدّث", importedCount, Modifier.weight(1f))
                            ImportResultBadge("متجاوز", skippedCount, Modifier.weight(1f))
                            ImportResultBadge("فشل", failedCount, Modifier.weight(1f))
                        }
                    }
                }
            }
            LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                itemsIndexed(rows.take(40)) { index, row ->
                    ElevatedCard(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                Text("صف ${index + 2}", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                                val disposition = importRowDisposition(row, importKind, studentMapping, recitationMapping, monthlyPlanMapping)
                                StatusPill(
                                    text = when (disposition) {
                                        ImportRules.RowDisposition.VALID -> "صالح"
                                        ImportRules.RowDisposition.SKIP -> "سيتجاوز"
                                        ImportRules.RowDisposition.INVALID -> "يحتاج تصحيح"
                                    },
                                    kind = when (disposition) {
                                        ImportRules.RowDisposition.VALID -> "success"
                                        ImportRules.RowDisposition.SKIP -> "info"
                                        ImportRules.RowDisposition.INVALID -> "warning"
                                    },
                                )
                            }
                            Text(row.joinToString(" | "), style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }
                if (rows.size > 40) item { Text("يتم عرض أول 40 صف فقط في المعاينة. الاعتماد يعالج جميع الصفوف.", style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(8.dp)) }
            }
        }
    }

    if (mappingEditorOpen && headers.isNotEmpty()) {
        ModalBottomSheet(onDismissRequest = { mappingEditorOpen = false }) {
            Column(
                Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                Text("ربط الأعمدة يدويًا", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Text("اختر العمود الصحيح لكل حقل. الحقول المعلّمة بـ * مطلوبة للاعتماد.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                when (importKind) {
                    "students" -> StudentImportMappingEditor(headers, studentMapping) { studentMapping = it }
                    "recitations" -> RecitationImportMappingEditor(headers, recitationMapping) { recitationMapping = it }
                    "plans" -> MonthlyPlanImportMappingEditor(headers, monthlyPlanMapping) { monthlyPlanMapping = it }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(
                        onClick = {
                            when (importKind) {
                                "students" -> studentMapping = ImportMapping.detect(headers)
                                "recitations" -> recitationMapping = RecitationImportMapping.detect(headers)
                                "plans" -> monthlyPlanMapping = MonthlyPlanImportMapping.detect(headers)
                            }
                        },
                        modifier = Modifier.weight(1f).heightIn(min = 48.dp),
                    ) { Text("اكتشاف تلقائي") }
                    Button(
                        onClick = { mappingEditorOpen = false },
                        modifier = Modifier.weight(1f).heightIn(min = 48.dp),
                    ) { Text("تم") }
                }
                Spacer(Modifier.height(24.dp))
            }
        }
    }
}

@Composable
private fun ImportCommitButton(importing: Boolean, enabled: Boolean, label: String, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        enabled = !importing && enabled,
        modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp),
    ) {
        if (importing) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp) else Icon(Icons.Default.CheckCircle, contentDescription = null)
        Spacer(Modifier.width(8.dp))
        Text(if (importing) "جاري الاعتماد…" else label)
    }
}

@Composable
private fun ImportResultBadge(label: String, value: Int, modifier: Modifier = Modifier) {
    Surface(modifier, color = MaterialTheme.colorScheme.surfaceVariant, shape = MaterialTheme.shapes.medium) {
        Column(Modifier.padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(value.toString(), fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
            Text(label, style = MaterialTheme.typography.labelMedium)
        }
    }
}

@Composable
private fun ImportColumnField(
    label: String,
    headers: List<String>,
    index: Int?,
    required: Boolean = false,
    onChange: (Int?) -> Unit,
) {
    var expanded by remember { mutableStateOf(false) }
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(if (required) "$label *" else label, style = MaterialTheme.typography.labelLarge)
        Box {
            OutlinedButton(
                onClick = { expanded = true },
                modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp),
            ) {
                Text(index?.let { headers.getOrNull(it) } ?: "غير محدد", Modifier.weight(1f))
                Icon(Icons.Default.ArrowDropDown, contentDescription = null)
            }
            DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                DropdownMenuItem(
                    text = { Text("غير محدد") },
                    onClick = { onChange(null); expanded = false },
                )
                headers.forEachIndexed { i, header ->
                    DropdownMenuItem(
                        text = { Text(header.ifBlank { "عمود ${i + 1}" }) },
                        onClick = { onChange(i); expanded = false },
                    )
                }
            }
        }
    }
}

@Composable
private fun StudentImportMappingEditor(headers: List<String>, m: ImportMapping, onChange: (ImportMapping) -> Unit) {
    ImportColumnField("اسم الطالب", headers, m.fullName, true) { onChange(m.copy(fullName = it)) }
    ImportColumnField("المسار", headers, m.track) { onChange(m.copy(track = it)) }
    ImportColumnField("الفئة", headers, m.category) { onChange(m.copy(category = it)) }
    ImportColumnField("الجنس", headers, m.gender) { onChange(m.copy(gender = it)) }
    ImportColumnField("رقم الهوية", headers, m.nationalId) { onChange(m.copy(nationalId = it)) }
    ImportColumnField("تاريخ الميلاد", headers, m.dateOfBirth) { onChange(m.copy(dateOfBirth = it)) }
    ImportColumnField("المرحلة الدراسية", headers, m.schoolGrade) { onChange(m.copy(schoolGrade = it)) }
    ImportColumnField("بريد ولي الأمر", headers, m.guardianEmail) { onChange(m.copy(guardianEmail = it)) }
    ImportColumnField("جوال ولي الأمر", headers, m.guardianPhone) { onChange(m.copy(guardianPhone = it)) }
    ImportColumnField("العنوان", headers, m.address) { onChange(m.copy(address = it)) }
}

@Composable
private fun RecitationImportMappingEditor(headers: List<String>, m: RecitationImportMapping, onChange: (RecitationImportMapping) -> Unit) {
    ImportColumnField("الطالب", headers, m.student, true) { onChange(m.copy(student = it)) }
    ImportColumnField("التاريخ", headers, m.date, true) { onChange(m.copy(date = it)) }
    ImportColumnField("نوع التسميع", headers, m.type, true) { onChange(m.copy(type = it)) }
    ImportColumnField("عدد الصفحات", headers, m.pages, true) { onChange(m.copy(pages = it)) }
    ImportColumnField("الأخطاء", headers, m.mistakes) { onChange(m.copy(mistakes = it)) }
    ImportColumnField("التلقين", headers, m.prompts) { onChange(m.copy(prompts = it)) }
    ImportColumnField("صفحة البداية", headers, m.startPage) { onChange(m.copy(startPage = it)) }
    ImportColumnField("صفحة النهاية", headers, m.endPage) { onChange(m.copy(endPage = it)) }
    ImportColumnField("الملاحظة", headers, m.note) { onChange(m.copy(note = it)) }
}

@Composable
private fun MonthlyPlanImportMappingEditor(headers: List<String>, m: MonthlyPlanImportMapping, onChange: (MonthlyPlanImportMapping) -> Unit) {
    ImportColumnField("الطالب", headers, m.student, true) { onChange(m.copy(student = it)) }
    ImportColumnField("الشهر", headers, m.month, true) { onChange(m.copy(month = it)) }
    ImportColumnField("هدف الحفظ", headers, m.hifz) { onChange(m.copy(hifz = it)) }
    ImportColumnField("هدف المراجعة", headers, m.review) { onChange(m.copy(review = it)) }
    ImportColumnField("هدف السرد", headers, m.sard) { onChange(m.copy(sard = it)) }
    ImportColumnField("أيام الحضور المتوقعة", headers, m.expectedDays) { onChange(m.copy(expectedDays = it)) }
    ImportColumnField("الملاحظة", headers, m.note) { onChange(m.copy(note = it)) }
}

data class ImportPreflight(val valid: Int, val skipped: Int, val invalid: Int)

private fun importPreflight(
    rows: List<List<String>>,
    kind: String,
    studentMapping: ImportMapping,
    recitationMapping: RecitationImportMapping,
    monthlyPlanMapping: MonthlyPlanImportMapping,
): ImportPreflight {
    var valid = 0; var skipped = 0; var invalid = 0
    rows.forEach { row ->
        when (importRowDisposition(row, kind, studentMapping, recitationMapping, monthlyPlanMapping)) {
            ImportRules.RowDisposition.VALID -> valid++
            ImportRules.RowDisposition.SKIP -> skipped++
            ImportRules.RowDisposition.INVALID -> invalid++
        }
    }
    return ImportPreflight(valid, skipped, invalid)
}

private fun importRowDisposition(
    row: List<String>,
    kind: String,
    studentMapping: ImportMapping,
    recitationMapping: RecitationImportMapping,
    monthlyPlanMapping: MonthlyPlanImportMapping,
): ImportRules.RowDisposition {
    return when (kind) {
    "students" -> {
        val nameIndex = studentMapping.fullName ?: return ImportRules.RowDisposition.INVALID
        ImportRules.studentDisposition(
            name = row.getOrNull(nameIndex).orEmpty(),
            track = cell(row, studentMapping.track),
            dateOfBirth = cell(row, studentMapping.dateOfBirth),
        )
    }
    "recitations" -> {
        val studentIndex = recitationMapping.student ?: return ImportRules.RowDisposition.INVALID
        val dateIndex = recitationMapping.date ?: return ImportRules.RowDisposition.INVALID
        val typeIndex = recitationMapping.type ?: return ImportRules.RowDisposition.INVALID
        val pagesIndex = recitationMapping.pages ?: return ImportRules.RowDisposition.INVALID
        ImportRules.recitationDisposition(
            student = row.getOrNull(studentIndex).orEmpty(),
            dateValue = row.getOrNull(dateIndex).orEmpty(),
            activityValue = row.getOrNull(typeIndex).orEmpty(),
            pagesValue = row.getOrNull(pagesIndex).orEmpty(),
            mistakesValue = cell(row, recitationMapping.mistakes),
            promptsValue = cell(row, recitationMapping.prompts),
            startPageValue = cell(row, recitationMapping.startPage),
            endPageValue = cell(row, recitationMapping.endPage),
        )
    }
    "plans" -> {
        val studentIndex = monthlyPlanMapping.student ?: return ImportRules.RowDisposition.INVALID
        val monthIndex = monthlyPlanMapping.month ?: return ImportRules.RowDisposition.INVALID
        if (listOf(monthlyPlanMapping.hifz, monthlyPlanMapping.review, monthlyPlanMapping.sard).none { it != null }) {
            return ImportRules.RowDisposition.INVALID
        }
        ImportRules.monthlyGoalDisposition(
            student = row.getOrNull(studentIndex).orEmpty(),
            monthValue = row.getOrNull(monthIndex).orEmpty(),
            hifzValue = cell(row, monthlyPlanMapping.hifz),
            reviewValue = cell(row, monthlyPlanMapping.review),
            sardValue = cell(row, monthlyPlanMapping.sard),
            expectedDaysValue = cell(row, monthlyPlanMapping.expectedDays),
        )
    }
        else -> ImportRules.RowDisposition.INVALID
    }
}

data class ImportMapping(
    val fullName: Int?, val track: Int?, val category: Int?, val gender: Int?, val nationalId: Int?,
    val dateOfBirth: Int?, val schoolGrade: Int?, val guardianEmail: Int?, val guardianPhone: Int?, val address: Int?,
) {
    companion object {
        fun detect(headers: List<String>): ImportMapping {
            val n = headers.map(::normalizeImportHeader)
            fun find(vararg names: String): Int? = findImportColumn(n, *names)
            return ImportMapping(
                fullName = find("اسم الطالب", "الاسم", "full name", "full_name", "name"),
                track = find("المسار", "track", "track_code"), category = find("الفئة", "category"),
                gender = find("الجنس", "gender"), nationalId = find("رقم الهوية", "الهوية", "national id", "national_id"),
                dateOfBirth = find("تاريخ الميلاد", "date of birth", "date_of_birth", "birth"),
                schoolGrade = find("المرحلة الدراسية", "الصف", "school grade", "school_grade", "grade"),
                guardianEmail = find("بريد ولي الأمر", "guardian email", "guardian_email"),
                guardianPhone = find("جوال ولي الأمر", "هاتف ولي الأمر", "guardian phone", "guardian_phone"),
                address = find("العنوان", "address"),
            )
        }
    }
}

data class RecitationImportMapping(
    val student: Int?, val date: Int?, val type: Int?, val pages: Int?, val mistakes: Int?, val prompts: Int?,
    val note: Int?, val startPage: Int?, val endPage: Int?,
) {
    companion object {
        fun detect(headers: List<String>): RecitationImportMapping {
            val n = headers.map(::normalizeImportHeader)
            fun find(vararg names: String): Int? = findImportColumn(n, *names)
            return RecitationImportMapping(
                student = find("اسم الطالب", "الطالب", "student", "student name", "name"),
                date = find("التاريخ", "تاريخ التسميع", "date", "session date"),
                type = find("النوع", "نوع التسميع", "activity", "activity type", "type"),
                pages = find("الصفحات", "عدد الصفحات", "pages", "pages count", "pages_count"),
                mistakes = find("الأخطاء", "عدد الأخطاء", "mistakes"), prompts = find("التلقين", "التلميحات", "prompts"),
                note = find("الملاحظة", "ملاحظة", "note", "teacher note"), startPage = find("صفحة البداية", "start page", "start_page"),
                endPage = find("صفحة النهاية", "end page", "end_page"),
            )
        }
    }
}

data class MonthlyPlanImportMapping(
    val student: Int?, val month: Int?, val hifz: Int?, val review: Int?, val sard: Int?, val expectedDays: Int?, val note: Int?,
) {
    companion object {
        fun detect(headers: List<String>): MonthlyPlanImportMapping {
            val n = headers.map(::normalizeImportHeader)
            fun find(vararg names: String): Int? = findImportColumn(n, *names)
            return MonthlyPlanImportMapping(
                student = find("اسم الطالب", "الطالب", "student", "student name", "name"),
                month = find("الشهر", "month", "month start", "period start", "period_start"),
                hifz = find("هدف الحفظ", "حفظ", "target hifz", "target_hifz_pages"),
                review = find("هدف المراجعة", "مراجعة", "target review", "target_review_pages"),
                sard = find("هدف السرد", "سرد", "target sard", "target_sard_pages"),
                expectedDays = find("أيام الحضور", "الايام المتوقعة", "expected days", "expected_session_days"),
                note = find("الملاحظة", "ملاحظة", "note"),
            )
        }
    }
}

data class ImportCommitResult(val imported: Int, val failed: Int, val skipped: Int)

private fun importResultText(result: ImportCommitResult) =
    "تم الاعتماد: ${result.imported} مضاف/محدّث · ${result.skipped} مكرر/متجاوز · ${result.failed} فشل"

private fun normalizeImportHeader(value: String): String = value
    .trim().lowercase()
    .replace("أ", "ا").replace("إ", "ا").replace("آ", "ا")
    .replace(Regex("[^a-z0-9\u0600-\u06ff]+"), " ")
    .replace(Regex("\\s+"), " ").trim()

private fun findImportColumn(normalizedHeaders: List<String>, vararg names: String): Int? =
    normalizedHeaders.indexOfFirst { h ->
        names.any { wanted ->
            val w = normalizeImportHeader(wanted)
            h == w || h.contains(w)
        }
    }.takeIf { it >= 0 }

private fun cell(row: List<String>, index: Int?): String = index?.let { row.getOrNull(it) }.orEmpty().trim()
private fun normalizedStudentName(value: String) = normalizeImportHeader(value)

private fun trackFromImport(value: String): String? = ImportRules.studentTrack(value)

private fun genderFromImport(value: String): String? = when {
    value.contains("ذكر") || value.equals("male", true) -> "male"
    value.contains("أنث") || value.contains("انث") || value.equals("female", true) -> "female"
    else -> null
}

private fun normalizeArabicDigits(value: String): String = ImportRules.normalizeDigits(value)
private fun importDouble(value: String): Double? = ImportRules.decimal(value)
private fun importInt(value: String): Int? = ImportRules.integer(value)
private fun importDate(value: String): LocalDate? = ImportRules.date(value)
private fun importMonth(value: String): YearMonth? = ImportRules.month(value)
private fun activityTypeFromImport(value: String): String? = ImportRules.activityType(value)

private fun importStudentsReviewed(rows: List<List<String>>, mapping: ImportMapping, fileName: String, halaqaId: String): ImportCommitResult {
    val nameIndex = mapping.fullName ?: error("تعذر اكتشاف عمود اسم الطالب")
    require(halaqaId.isNotBlank()) { "اختر الحلقة المستهدفة" }
    val existing = AppGraph.repo.students().filter { it.halaqaId == halaqaId }.map { normalizedStudentName(it.fullName) }.toMutableSet()
    val categories = AppGraph.repo.table("student_categories", "select=id,name,halaqa_id,active&halaqa_id=eq.$halaqaId&limit=500").let { a -> (0 until a.length()).mapNotNull { a.optJSONObject(it) } }.toMutableList()
    val uid = AppGraph.repo.store.load()?.userId
    var imported = 0; var failed = 0; var skipped = 0

    fun categoryId(name: String): String? {
        if (name.isBlank()) return null
        val normalized = normalizeImportHeader(name)
        categories.firstOrNull { normalizeImportHeader(it.optString("name")) == normalized }?.let { return it.optString("id") }
        val id = java.util.UUID.nameUUIDFromBytes("import-category:$halaqaId:$normalized".toByteArray()).toString()
        val obj = JSONObject().put("id", id).put("halaqa_id", halaqaId).put("name", name.trim()).put("active", true)
        uid?.let { obj.put("created_by", it) }
        AppGraph.repo.write("student_categories", obj, onConflict = "id", dedupe = "import-category:$halaqaId:$normalized")
        categories.add(JSONObject(obj.toString()))
        return id
    }

    rows.forEach { row ->
        try {
            val fullName = row.getOrNull(nameIndex).orEmpty().trim()
            if (fullName.length < 2) { skipped++; return@forEach }
            val normalized = normalizedStudentName(fullName)
            if (normalized in existing) { skipped++; return@forEach }
            val parsedTrack = trackFromImport(cell(row, mapping.track)) ?: run { skipped++; return@forEach }
            val obj = JSONObject().put("full_name", fullName).put("halaqa_id", halaqaId).put("status", "active").put("track_code", parsedTrack)
            categoryId(cell(row, mapping.category))?.let { obj.put("category_id", it) }
            genderFromImport(cell(row, mapping.gender))?.let { obj.put("gender", it) }
            cell(row, mapping.nationalId).takeIf { it.isNotBlank() }?.let { obj.put("national_id", it) }
            importDate(cell(row, mapping.dateOfBirth))?.let { obj.put("date_of_birth", it.toString()) }
            cell(row, mapping.schoolGrade).takeIf { it.isNotBlank() }?.let { obj.put("school_grade", it) }
            cell(row, mapping.guardianEmail).takeIf { it.isNotBlank() }?.let { obj.put("guardian_email", it) }
            cell(row, mapping.guardianPhone).takeIf { it.isNotBlank() }?.let { obj.put("guardian_phone", it) }
            cell(row, mapping.address).takeIf { it.isNotBlank() }?.let { obj.put("address", it) }
            AppGraph.repo.write("students", obj, dedupe = "import-student:$halaqaId:$normalized")
            existing.add(normalized); imported++
        } catch (_: Exception) { failed++ }
    }
    recordImportJob(halaqaId, fileName, "students", rows.size, imported, failed, skipped)
    return ImportCommitResult(imported, failed, skipped)
}

private fun importRecitationsReviewed(rows: List<List<String>>, mapping: RecitationImportMapping, fileName: String, halaqaId: String): ImportCommitResult {
    require(AppGraph.repo.online()) { "يلزم اتصال إنترنت لاعتماد التسميعات السابقة بأمان" }
    val studentIndex = mapping.student ?: error("تعذر اكتشاف عمود الطالب")
    val dateIndex = mapping.date ?: error("تعذر اكتشاف عمود التاريخ")
    val typeIndex = mapping.type ?: error("تعذر اكتشاف عمود نوع التسميع")
    val pagesIndex = mapping.pages ?: error("تعذر اكتشاف عمود عدد الصفحات")
    val students = AppGraph.repo.students().filter { it.halaqaId == halaqaId }
        .associateBy { normalizedStudentName(it.fullName) }
    var imported = 0; var failed = 0; var skipped = 0

    rows.forEachIndexed { rowIndex, row ->
        try {
            val student = students[normalizedStudentName(row.getOrNull(studentIndex).orEmpty())]
            if (student == null) { skipped++; return@forEachIndexed }
            val date = importDate(row.getOrNull(dateIndex).orEmpty()) ?: run { skipped++; return@forEachIndexed }
            val activity = activityTypeFromImport(row.getOrNull(typeIndex).orEmpty()) ?: run { skipped++; return@forEachIndexed }
            val pages = importDouble(row.getOrNull(pagesIndex).orEmpty()) ?: run { skipped++; return@forEachIndexed }
            val mistakesRaw = cell(row, mapping.mistakes)
            val promptsRaw = cell(row, mapping.prompts)
            val startRaw = cell(row, mapping.startPage)
            val endRaw = cell(row, mapping.endPage)
            val mistakes = if (mistakesRaw.isBlank()) 0 else importInt(mistakesRaw) ?: run { skipped++; return@forEachIndexed }
            val prompts = if (promptsRaw.isBlank()) 0 else importInt(promptsRaw) ?: run { skipped++; return@forEachIndexed }
            val startPage = if (startRaw.isBlank()) null else importInt(startRaw) ?: run { skipped++; return@forEachIndexed }
            val endPage = if (endRaw.isBlank()) null else importInt(endRaw) ?: run { skipped++; return@forEachIndexed }
            if (!ImportRules.validRecitation(activity, pages, mistakes, prompts, startPage, endPage)) { skipped++; return@forEachIndexed }
            val assignment = when (activity) { "sard" -> "sard"; "review_near", "review_far" -> "review"; "test" -> "test"; else -> "hifz" }
            val session = AppGraph.repo.ensureTodaySession(halaqaId, date.toString(), assignment)
            val clientId = java.util.UUID.nameUUIDFromBytes(
                "import-recitation:$halaqaId:${normalizeImportHeader(fileName)}:$rowIndex:${student.id}:$date:$activity:$pages:$mistakes:$prompts".toByteArray(),
            ).toString()
            val exists = AppGraph.repo.table("recitation_entries", "select=id&id=eq.$clientId&limit=1").length() > 0
            if (exists) { skipped++; return@forEachIndexed }
            AppGraph.repo.saveRecitation(
                com.mohammedsamir.halaqati.model.RecitationDraft(
                    studentId = student.id, sessionId = session.id, activityType = activity,
                    startPage = startPage, endPage = endPage, pages = pages, mistakes = mistakes, prompts = prompts,
                    evaluation = "not_rated", notes = cell(row, mapping.note), inputMethod = "import", clientId = clientId,
                ),
            )
            imported++
        } catch (_: Exception) { failed++ }
    }
    recordImportJob(halaqaId, fileName, "recitations", rows.size, imported, failed, skipped)
    return ImportCommitResult(imported, failed, skipped)
}

private fun importMonthlyPlansReviewed(rows: List<List<String>>, mapping: MonthlyPlanImportMapping, fileName: String, halaqaId: String): ImportCommitResult {
    require(AppGraph.repo.online()) { "يلزم اتصال إنترنت لاعتماد الأهداف الشهرية بأمان ومنع التكرار" }
    val studentIndex = mapping.student ?: error("تعذر اكتشاف عمود الطالب")
    val monthIndex = mapping.month ?: error("تعذر اكتشاف عمود الشهر")
    val students = AppGraph.repo.students().filter { it.halaqaId == halaqaId }.associateBy { normalizedStudentName(it.fullName) }
    val uid = AppGraph.repo.store.load()?.userId
    var imported = 0; var failed = 0; var skipped = 0

    rows.forEach { row ->
        try {
            val student = students[normalizedStudentName(row.getOrNull(studentIndex).orEmpty())]
            if (student == null) { skipped++; return@forEach }
            val month = importMonth(row.getOrNull(monthIndex).orEmpty()) ?: run { skipped++; return@forEach }
            fun parsedGoal(index: Int?): Double? {
                val raw = cell(row, index)
                return if (raw.isBlank()) 0.0 else importDouble(raw)
            }
            val hifz = parsedGoal(mapping.hifz) ?: run { skipped++; return@forEach }
            val review = parsedGoal(mapping.review) ?: run { skipped++; return@forEach }
            val sard = parsedGoal(mapping.sard) ?: run { skipped++; return@forEach }
            val expectedRaw = cell(row, mapping.expectedDays)
            val expectedDays = if (expectedRaw.isBlank()) 20 else importInt(expectedRaw) ?: run { skipped++; return@forEach }
            if (!ImportRules.validMonthlyGoals(hifz, review, sard, expectedDays)) { skipped++; return@forEach }
            if (hifz == 0.0 && review == 0.0 && sard == 0.0) { skipped++; return@forEach }
            val periodStart = month.atDay(1)
            val periodEnd = month.atEndOfMonth()
            val obj = JSONObject()
                .put("student_id", student.id).put("period_start", periodStart.toString()).put("period_end", periodEnd.toString())
                .put("target_hifz_pages", hifz).put("target_review_pages", review).put("target_sard_pages", sard)
                .put("target_daily_hifz_pages", hifz / expectedDays).put("target_daily_review_pages", review / expectedDays)
                .put("target_daily_sard_pages", sard / expectedDays).put("expected_session_days", expectedDays)
            cell(row, mapping.note).takeIf { it.isNotBlank() }?.let { obj.put("note", it) }
            uid?.let { obj.put("created_by", it) }
            val existing = AppGraph.repo.table("student_goals", "select=id&student_id=eq.${student.id}&period_start=eq.$periodStart&limit=1").optJSONObject(0)
            if (existing != null) {
                AppGraph.repo.patch("student_goals", "id=eq.${existing.optString("id")}", obj, dedupe = "import-goal:${student.id}:$periodStart")
            } else {
                obj.put("id", java.util.UUID.nameUUIDFromBytes("goal:${student.id}:$periodStart".toByteArray()).toString())
                AppGraph.repo.write("student_goals", obj, onConflict = "id", dedupe = "import-goal:${student.id}:$periodStart")
            }
            imported++
        } catch (_: Exception) { failed++ }
    }
    recordImportJob(halaqaId, fileName, "plans", rows.size, imported, failed, skipped)
    return ImportCommitResult(imported, failed, skipped)
}

private fun recordImportJob(halaqaId: String, fileName: String, kind: String, detected: Int, imported: Int, failed: Int, skipped: Int) {
    val uid = AppGraph.repo.store.load()?.userId
    runCatching {
        AppGraph.repo.write(
            "data_import_jobs",
            JSONObject().put("halaqa_id", halaqaId).put("file_name", fileName).put("file_type", "native_review")
                .put("import_kind", kind).put("rows_detected", detected).put("rows_imported", imported).put("rows_failed", failed)
                .put("status", when { failed == 0 -> "completed"; imported > 0 -> "partial"; else -> "failed" })
                .put("notes", "Native reviewed import; skipped=$skipped").apply { uid?.let { put("created_by", it) } },
            dedupe = "import-job:$kind:${normalizeImportHeader(fileName)}:${System.currentTimeMillis()}",
        )
    }
}

object SmartImport {
    fun read(context: Context, uri: Uri): List<List<String>> {
        val mime = context.contentResolver.getType(uri).orEmpty()
        val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: error("تعذر فتح الملف")
        return when {
            mime.contains("csv") || mime.startsWith("text/") || looksLikeDelimited(bytes) -> readText(bytes.toString(Charsets.UTF_8))
            mime.contains("spreadsheet") || mime.contains("officedocument.spreadsheet") -> readXlsx(bytes)
            mime.contains("wordprocessingml") -> readDocx(bytes)
            else -> throw IllegalArgumentException("PDF/الصورة تحتاج OCR موثوق ثم مراجعة يدوية؛ لم يتم إدخال أي بيانات")
        }.trimTable()
    }

    fun readText(text: String): List<List<String>> = parseDelimited(text).trimTable()

    private fun List<List<String>>.trimTable(): List<List<String>> =
        map { row -> row.map(String::trim) }.filter { row -> row.any { it.isNotBlank() } }

    private fun looksLikeDelimited(bytes: ByteArray): Boolean {
        val prefix = bytes.take(2048).toByteArray().toString(Charsets.UTF_8)
        return listOf('\t', ',', ';', '|').any { prefix.contains(it) }
    }

    private fun detectDelimiter(text: String): Char {
        val sample = text.lineSequence().filter { it.isNotBlank() }.take(5).toList()
        return listOf('\t', ',', ';', '|').maxByOrNull { d -> sample.sumOf { line -> line.count { it == d } } } ?: ','
    }

    private fun parseDelimited(text: String): List<List<String>> {
        if (text.isBlank()) return emptyList()
        val delimiter = detectDelimiter(text)
        val rows = mutableListOf<MutableList<String>>()
        var row = mutableListOf<String>()
        val cell = StringBuilder()
        var quoted = false
        var i = 0
        fun finishCell() { row.add(cell.toString()); cell.clear() }
        fun finishRow() { finishCell(); rows.add(row); row = mutableListOf() }
        while (i < text.length) {
            val c = text[i]
            when {
                c == '"' && quoted && i + 1 < text.length && text[i + 1] == '"' -> { cell.append('"'); i++ }
                c == '"' -> quoted = !quoted
                c == delimiter && !quoted -> finishCell()
                (c == '\n' || c == '\r') && !quoted -> {
                    if (c == '\r' && i + 1 < text.length && text[i + 1] == '\n') i++
                    finishRow()
                }
                else -> cell.append(c)
            }
            i++
        }
        if (cell.isNotEmpty() || row.isNotEmpty()) finishRow()
        return rows
    }

    private fun entries(bytes: ByteArray): Map<String, ByteArray> {
        val output = mutableMapOf<String, ByteArray>()
        ZipInputStream(ByteArrayInputStream(bytes)).use { zip ->
            var entry = zip.nextEntry
            while (entry != null) { output[entry.name] = zip.readBytes(); entry = zip.nextEntry }
        }
        return output
    }

    private fun xml(bytes: ByteArray) = DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(ByteArrayInputStream(bytes))

    private fun readXlsx(bytes: ByteArray): List<List<String>> {
        val e = entries(bytes)
        val shared = e["xl/sharedStrings.xml"]?.let { b ->
            val d = xml(b); (0 until d.getElementsByTagName("si").length).map { d.getElementsByTagName("si").item(it).textContent }
        } ?: emptyList()
        val sheet = e["xl/worksheets/sheet1.xml"] ?: return emptyList()
        val d = xml(sheet)
        val rowNodes = d.getElementsByTagName("row")
        val output = mutableListOf<List<String>>()
        for (r in 0 until rowNodes.length) {
            val node = rowNodes.item(r)
            val cells = node.childNodes
            val byColumn = mutableMapOf<Int, String>()
            var sequential = 0
            for (i in 0 until cells.length) {
                val c = cells.item(i)
                if (c.nodeName != "c") continue
                val element = c as? org.w3c.dom.Element ?: continue
                val ref = element.getAttribute("r")
                val col = xlsxColumnIndex(ref).takeIf { it >= 0 } ?: sequential
                sequential = col + 1
                val type = element.getAttribute("t")
                val valueNode = element.getElementsByTagName("v").item(0)
                val raw = valueNode?.textContent ?: element.textContent
                val value = when (type) {
                    "s" -> shared.getOrNull(raw.toIntOrNull() ?: -1) ?: raw
                    "inlineStr" -> element.getElementsByTagName("t").item(0)?.textContent ?: raw
                    else -> raw
                }
                byColumn[col] = value
            }
            val max = byColumn.keys.maxOrNull() ?: -1
            output += if (max < 0) emptyList() else (0..max).map { byColumn[it].orEmpty() }
        }
        return output
    }

    private fun xlsxColumnIndex(ref: String): Int {
        val letters = ref.takeWhile { it.isLetter() }.uppercase()
        if (letters.isBlank()) return -1
        var value = 0
        letters.forEach { value = value * 26 + (it.code - 'A'.code + 1) }
        return value - 1
    }

    private fun readDocx(bytes: ByteArray): List<List<String>> {
        val document = entries(bytes)["word/document.xml"] ?: return emptyList()
        val d = xml(document)
        val tableRows = d.getElementsByTagName("w:tr")
        if (tableRows.length > 0) {
            return (0 until tableRows.length).map { r ->
                val row = tableRows.item(r) as? org.w3c.dom.Element
                val cells = row?.getElementsByTagName("w:tc")
                if (cells == null) emptyList() else (0 until cells.length).map { c -> cells.item(c).textContent.trim() }
            }
        }
        val paragraphs = d.getElementsByTagName("w:p")
        val text = (0 until paragraphs.length).map { paragraphs.item(it).textContent }.filter { it.isNotBlank() }.joinToString("\n")
        return parseDelimited(text)
    }
}

object Backup {
    private val tables = listOf(
        "profiles",
        "halaqas",
        "halaqa_teachers",
        "halaqa_supervisors",
        "student_categories",
        "students",
        "student_guardians",
        "sessions",
        "attendance_records",
        "recitation_entries",
        "student_daily_notes",
        "student_goals",
        "monthly_comments",
        "announcements",
        "forum_posts",
        "forum_comments",
        "student_points",
        "app_settings",
        "smart_plans",
        "smart_plan_events",
        "notification_preferences",
    )

    fun export(context: Context, uri: Uri) {
        val root = JSONObject()
            .put("format", "halaqati-backup")
            .put("version", 2)
            .put("app_version", "2.46.0")
            .put("exported_at", java.time.Instant.now().toString())
        val tableData = JSONObject()
        tables.forEach { name ->
            try {
                tableData.put(name, AppGraph.repo.table(name, "select=*&limit=10000"))
            } catch (_: Exception) {
                // Keep backup export resilient across role-restricted tables.
            }
        }
        root.put("tables", tableData)
        context.contentResolver.openOutputStream(uri)?.use {
            it.write(root.toString(2).toByteArray(Charsets.UTF_8))
        } ?: error("تعذر فتح ملف النسخة الاحتياطية")
    }
}

@Composable
fun SettingsScreen(profile: Profile, onLogout: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val uiPreferences by AppGraph.uiPreferences.state.collectAsState()
    var notificationsEnabled by remember { mutableStateOf(NotificationManagerCompat.from(context).areNotificationsEnabled()) }
    var testingPush by remember { mutableStateOf(false) }
    var pushMessage by remember { mutableStateOf<String?>(null) }
    var pendingWrites by remember { mutableIntStateOf(0) }
    var blockedWrites by remember { mutableIntStateOf(0) }
    var showLogoutConfirm by remember { mutableStateOf(false) }
    var showPasswordDialog by remember { mutableStateOf(false) }
    var newPassword by remember { mutableStateOf("") }
    var confirmPassword by remember { mutableStateOf("") }
    var passwordMessage by remember { mutableStateOf<String?>(null) }
    var showNotificationPreferences by remember { mutableStateOf(false) }
    var notificationPreferences by remember { mutableStateOf<JSONObject?>(null) }
    var preferencesMessage by remember { mutableStateOf<String?>(null) }
    var savingPassword by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        val counts = withContext(Dispatchers.IO) {
            AppGraph.repo.pendingQueueSize() to AppGraph.repo.blockedQueueSize()
        }
        pendingWrites = counts.first
        blockedWrites = counts.second
        notificationPreferences = withContext(Dispatchers.IO) {
            runCatching { AppGraph.repo.table("notification_preferences", "select=*&user_id=eq.${profile.id}&limit=1").optJSONObject(0) }.getOrNull()
        } ?: JSONObject().put("user_id", profile.id).put("push_enabled", true).put("attendance", true).put("recitation", true).put("behavior", true).put("announcements", true).put("achievements", true)
    }

    if (showPasswordDialog) {
        AlertDialog(
            onDismissRequest = { if (!savingPassword) showPasswordDialog = false },
            title = { Text("تغيير كلمة المرور") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = newPassword,
                        onValueChange = { newPassword = it },
                        label = { Text("كلمة المرور الجديدة") },
                        singleLine = true,
                    )
                    OutlinedTextField(
                        value = confirmPassword,
                        onValueChange = { confirmPassword = it },
                        label = { Text("تأكيد كلمة المرور") },
                        singleLine = true,
                    )
                    Text(if (confirmPassword.isNotEmpty() && confirmPassword != newPassword) "كلمتا المرور غير متطابقتين" else "6 أحرف على الأقل", style = MaterialTheme.typography.bodySmall, color = if (confirmPassword.isNotEmpty() && confirmPassword != newPassword) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant)
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        savingPassword = true
                        passwordMessage = null
                        scope.launch {
                            val result = withContext(Dispatchers.IO) { runCatching { AppGraph.repo.updatePassword(newPassword) } }
                            savingPassword = false
                            result.onSuccess {
                                passwordMessage = "تم تغيير كلمة المرور"
                                newPassword = ""
                                confirmPassword = ""
                                showPasswordDialog = false
                            }.onFailure { passwordMessage = it.message ?: "تعذر تغيير كلمة المرور" }
                        }
                    },
                    enabled = newPassword.length >= 6 && newPassword == confirmPassword && !savingPassword,
                ) { Text(if (savingPassword) "جارٍ الحفظ…" else "حفظ") }
            },
            dismissButton = { TextButton(onClick = { showPasswordDialog = false }, enabled = !savingPassword) { Text("إلغاء") } },
        )
    }

    if (showLogoutConfirm) {
        AlertDialog(
            onDismissRequest = { showLogoutConfirm = false },
            title = { Text("هناك بيانات لم تُرفع بعد") },
            text = {
                Text(
                    "يوجد $pendingWrites عمليات بانتظار المزامنة و$blockedWrites عمليات تحتاج مراجعة. " +
                        "ستبقى محفوظة ومربوطة بهذا الحساب فقط، ولن تُرسل بحساب آخر. الأفضل المزامنة قبل الخروج إذا كان الاتصال متاحًا.",
                )
            },
            confirmButton = {
                Button(
                    onClick = { showLogoutConfirm = false; onLogout() },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                ) { Text("الخروج مع الاحتفاظ محليًا") }
            },
            dismissButton = {
                TextButton(onClick = { showLogoutConfirm = false; AppGraph.repo.scheduleSync() }) { Text("البقاء ومحاولة المزامنة") }
            },
        )
    }

    Column(Modifier.fillMaxSize()) {
        AppTopBar("الإعدادات")
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 110.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary),
                    shape = MaterialTheme.shapes.extraLarge,
                ) {
                    Row(
                        Modifier.fillMaxWidth().padding(18.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        Surface(shape = MaterialTheme.shapes.large, color = MaterialTheme.colorScheme.onPrimary.copy(alpha = .12f)) {
                            Icon(Icons.Default.AccountCircle, contentDescription = null, tint = MaterialTheme.colorScheme.onPrimary, modifier = Modifier.padding(12.dp).size(30.dp))
                        }
                        Column(Modifier.weight(1f)) {
                            Text(profile.fullName, color = MaterialTheme.colorScheme.onPrimary, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                            Text("${profile.role.name} · ${profile.email}", color = MaterialTheme.colorScheme.onPrimary.copy(alpha = .78f), style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }

            item { AccountNameSettingsCard(profile) }
            item { AppUpdateSettingsCard() }
            item { V6ScoringSettingsCard() }

            item {
                Text("المظهر", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                ) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("الوضع الداكن", fontWeight = FontWeight.Bold)
                                Text("اتبع النظام أو اختر الوضع المناسب", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Switch(
                                checked = uiPreferences.themeMode == ThemeMode.DARK,
                                onCheckedChange = { enabled -> AppGraph.uiPreferences.update { it.copy(themeMode = if (enabled) ThemeMode.DARK else ThemeMode.LIGHT) } },
                            )
                        }
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf(ThemeMode.SYSTEM to "النظام", ThemeMode.LIGHT to "فاتح", ThemeMode.DARK to "داكن").forEach { (mode, label) ->
                                ProFilterChip(
                                    selected = uiPreferences.themeMode == mode,
                                    onClick = { AppGraph.uiPreferences.update { it.copy(themeMode = mode) } },
                                    label = label,
                                    modifier = Modifier.weight(1f),
                                )
                            }
                        }
                        Text("ألوان حلقتي", style = MaterialTheme.typography.labelLarge)
                        val presets = listOf(
                            Triple(0xFF0D3B2F.toInt(), 0xFF2F8B69.toInt(), "الأخضر"),
                            Triple(0xFF12345B.toInt(), 0xFF2D6CDF.toInt(), "الأزرق"),
                            Triple(0xFF5A3825.toInt(), 0xFFAD744F.toInt(), "البني"),
                            Triple(0xFF342B5F.toInt(), 0xFF765BC4.toInt(), "البنفسجي"),
                        )
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            presets.forEach { (primary, accent, label) ->
                                val selected = uiPreferences.primaryArgb == primary && uiPreferences.accentArgb == accent
                                Surface(
                                    onClick = { AppGraph.uiPreferences.update { it.copy(primaryArgb = primary, accentArgb = accent) } },
                                    modifier = Modifier.weight(1f).heightIn(min = 66.dp),
                                    shape = MaterialTheme.shapes.medium,
                                    border = if (selected) androidx.compose.foundation.BorderStroke(2.dp, MaterialTheme.colorScheme.primary) else androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                                    color = MaterialTheme.colorScheme.surface,
                                ) {
                                    Column(Modifier.fillMaxSize().padding(8.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                            Surface(modifier = Modifier.size(18.dp), shape = MaterialTheme.shapes.extraLarge, color = androidx.compose.ui.graphics.Color(primary)) {}
                                            Surface(modifier = Modifier.size(18.dp), shape = MaterialTheme.shapes.extraLarge, color = androidx.compose.ui.graphics.Color(accent)) {}
                                        }
                                        Spacer(Modifier.height(5.dp))
                                        Text(label, style = MaterialTheme.typography.labelSmall)
                                    }
                                }
                            }
                        }
                        Text("كثافة الواجهة", style = MaterialTheme.typography.labelLarge)
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf(UiDensity.COMFORTABLE to "مريح", UiDensity.BALANCED to "متوازن", UiDensity.COMPACT to "مضغوط").forEach { (density, label) ->
                                ProFilterChip(
                                    selected = uiPreferences.density == density,
                                    onClick = { AppGraph.uiPreferences.update { it.copy(density = density) } },
                                    label = label,
                                    modifier = Modifier.weight(1f),
                                )
                            }
                        }
                        OutlinedButton(
                            onClick = { AppGraph.uiPreferences.reset() },
                            modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp),
                        ) { Text("إعادة ضبط المظهر") }
                    }
                }
            }

            item {
                Text("الحساب والأمان", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                Card(modifier = Modifier.fillMaxWidth(), border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline)) {
                    Column {
                        ListItem(
                            headlineContent = { Text("تغيير كلمة المرور") },
                            supportingContent = { Text("تحديث كلمة مرور الحساب مباشرة") },
                            leadingContent = { Icon(Icons.Default.LockReset, contentDescription = null) },
                            modifier = Modifier.fillMaxWidth(),
                        )
                        OutlinedButton(
                            onClick = { showPasswordDialog = true },
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp).fillMaxWidth().heightIn(min = 48.dp),
                        ) { Text("تغيير كلمة المرور") }
                        passwordMessage?.let { StateNotice(it, if (it.startsWith("تم")) "success" else "warning", Modifier.padding(12.dp)) }
                    }
                }
            }

            item {
                Text("المزامنة والإشعارات", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                Card(modifier = Modifier.fillMaxWidth(), border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline)) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Sync, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) {
                                Text("المزامنة", fontWeight = FontWeight.Bold)
                                Text(
                                    if (pendingWrites + blockedWrites == 0) "البيانات المحلية متزامنة لهذا الحساب"
                                    else "معلّق: $pendingWrites · يحتاج مراجعة: $blockedWrites · معزول حسب الحساب",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            }
                        }
                        HorizontalDivider()
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                if (notificationsEnabled) Icons.Default.NotificationsActive else Icons.Default.NotificationsOff,
                                contentDescription = null,
                                tint = if (notificationsEnabled) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error,
                            )
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) {
                                Text("إشعارات Android", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                Text(if (notificationsEnabled) "مسموح بها على هذا الجهاز" else "موقوفة من إعدادات Android", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            StatusPill(if (notificationsEnabled) "مفعلة" else "موقوفة", if (notificationsEnabled) "success" else "warning")
                        }
                        OutlinedButton(
                            onClick = { showNotificationPreferences = true },
                            modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp),
                        ) { Text("تفضيلات إشعارات الحساب") }
                        preferencesMessage?.let { StateNotice(it, kind = if (it.startsWith("تم")) "success" else "warning") }
                        pushMessage?.let { StateNotice(it, kind = if (it.startsWith("تم")) "success" else "warning") }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(
                                onClick = {
                                    context.startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName))
                                },
                                modifier = Modifier.weight(1f).heightIn(min = 48.dp),
                            ) { Text("إعدادات الإشعارات") }
                            Button(
                                onClick = {
                                    testingPush = true; pushMessage = null
                                    scope.launch {
                                        val message = withContext(Dispatchers.IO) {
                                            runCatching {
                                                val result = AppGraph.repo.testPush()
                                                when {
                                                    result.optInt("push_sent", 0) > 0 -> "تم إرسال إشعار اختباري إلى هذا الحساب."
                                                    result.optBoolean("push_configured", false) -> "تم إنشاء الاختبار لكن لا يوجد جهاز Push نشط لهذا الحساب."
                                                    else -> "مركز الإشعارات يعمل، لكن Firebase Push غير مهيأ على الخادم."
                                                }
                                            }.getOrElse { "تعذر إرسال الاختبار: ${it.message ?: "خطأ"}" }
                                        }
                                        pushMessage = message; testingPush = false
                                        notificationsEnabled = NotificationManagerCompat.from(context).areNotificationsEnabled()
                                    }
                                },
                                enabled = !testingPush && AppGraph.repo.online(),
                                modifier = Modifier.weight(1f).heightIn(min = 48.dp),
                            ) { Text(if (testingPush) "جارٍ الاختبار…" else "اختبار Push") }
                        }
                    }
                }
            }

            item {
                ListItem(
                    headlineContent = { Text("الإصدار") },
                    supportingContent = { Text("Native Kotlin / Jetpack Compose ${BuildConfig.VERSION_NAME}") },
                    leadingContent = { Icon(Icons.Default.Android, contentDescription = null) },
                )
            }
            item {
                Button(
                    onClick = { if (pendingWrites + blockedWrites > 0) showLogoutConfirm = true else onLogout() },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                    modifier = Modifier.fillMaxWidth().heightIn(min = 52.dp),
                ) { Text("تسجيل الخروج", fontWeight = FontWeight.Bold) }
            }
        }
    }

    if (showNotificationPreferences) {
        NotificationPreferencesDialog(
            current = notificationPreferences,
            close = { showNotificationPreferences = false },
            save = { updated ->
                scope.launch {
                    val result = withContext(Dispatchers.IO) {
                        runCatching {
                            AppGraph.repo.write(
                                "notification_preferences",
                                updated.put("user_id", profile.id).put("updated_at", java.time.Instant.now().toString()),
                                onConflict = "user_id",
                                dedupe = "notification-preferences:${profile.id}",
                            )
                        }
                    }
                    result.onSuccess {
                        notificationPreferences = updated
                        preferencesMessage = "تم حفظ تفضيلات الإشعارات"
                        showNotificationPreferences = false
                    }.onFailure { preferencesMessage = it.message ?: "تعذر حفظ تفضيلات الإشعارات" }
                }
            },
        )
    }
}

