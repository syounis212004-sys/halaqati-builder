package com.mohammedsamir.halaqati.ui.guardian

import androidx.compose.runtime.Immutable
import com.mohammedsamir.halaqati.quran.RecitationParityRules
import org.json.JSONObject

/** RC17: typed guardian models. JSON is parsed once in the ViewModel, never inside Composables. */
@Immutable data class GuardianChild(val id: String, val name: String, val tathbit: Boolean)

@Immutable data class GuardianRecitationLine(
    val date: String,
    val activityLabel: String,
    val range: String,
    val pages: Double,
    val quality: Double?,
)

@Immutable data class GuardianOverview(
    val childName: String,
    val tathbit: Boolean,
    val trackLabel: String,
    val subtitle: String,
    val todayAttendance: String?,
    val todayRecited: Boolean,
    val todayPages: Double,
    val todayRange: String?,
    val planTitle: String?,
    val planTarget: Double,
    val planDone: Double,
    val monthMain: Double,
    val monthMainLabel: String,
    val monthPresent: Int,
    val monthSessions: Int,
    val quality: Double?,
    val latest: List<GuardianRecitationLine>,
    val updatedAt: String?,
) {
    val planPercent: Double get() = if (planTarget > 0) (planDone * 100.0 / planTarget).coerceIn(0.0, 100.0) else 0.0
    val planRemaining: Double get() = (planTarget - planDone).coerceAtLeast(0.0)

    companion object {
        fun activityLabel(raw: String, tathbit: Boolean): String = if (tathbit && raw != "test") "تثبيت" else when (raw) {
            "new_hifz" -> "حفظ"; "review_near", "review_far", "review", "tilawah" -> "مراجعة"
            "sard" -> "سرد"; "tathbit" -> "تثبيت"; "test" -> "اختبار"; else -> "تسميع"
        }

        private fun JSONObject.intOrNull(key: String): Int? = if (!has(key) || isNull(key)) null else optInt(key).takeIf { it > 0 }
        private fun JSONObject.doubleOrNull(key: String): Double? = if (!has(key) || isNull(key)) null else optDouble(key).takeIf { !it.isNaN() }
        private fun JSONObject.text(key: String): String? = if (!has(key) || isNull(key)) null else optString(key).takeIf { it.isNotBlank() && it != "null" }

        fun range(o: JSONObject): String? {
            val ss = o.intOrNull("start_surah") ?: return null
            return RecitationParityRules.quranRangeLabel(ss, o.intOrNull("start_ayah"), o.intOrNull("end_surah"), o.intOrNull("end_ayah"), null, null)
        }

        fun parse(json: JSONObject): GuardianOverview? {
            val student = json.optJSONObject("student") ?: return null
            val tathbit = student.optString("track") == "tathbit"
            val today = json.optJSONObject("today") ?: JSONObject()
            val month = json.optJSONObject("month") ?: JSONObject()
            val plan = json.optJSONObject("plan")
            val todayRanges = today.optJSONArray("ranges")
            val todayRange = (0 until (todayRanges?.length() ?: 0)).mapNotNull { todayRanges?.optJSONObject(it)?.let { o -> range(o) } }
                .distinct().joinToString(" · ").ifBlank { null }
            val latestArr = json.optJSONArray("latest")
            val latest = (0 until (latestArr?.length() ?: 0)).mapNotNull { latestArr?.optJSONObject(it) }.map { r ->
                GuardianRecitationLine(
                    date = r.optString("date"),
                    activityLabel = activityLabel(r.optString("activity"), tathbit),
                    range = range(r) ?: "—",
                    pages = r.optDouble("pages", 0.0),
                    quality = r.doubleOrNull("quality"),
                )
            }
            return GuardianOverview(
                childName = student.text("full_name") ?: "طالب",
                tathbit = tathbit,
                trackLabel = if (tathbit) "التثبيت" else "الحفظ العام",
                subtitle = listOfNotNull(student.text("halaqa_name"), student.text("category_name")).joinToString(" · "),
                todayAttendance = today.text("attendance"),
                todayRecited = today.optBoolean("recited", false),
                todayPages = today.optDouble("pages", 0.0),
                todayRange = todayRange,
                planTitle = plan?.let { if (tathbit) "خطة التثبيت لهذا الشهر" else "خطة هذا الشهر" },
                planTarget = plan?.optDouble("target_pages", 0.0) ?: 0.0,
                planDone = plan?.optDouble("done_pages", 0.0) ?: 0.0,
                monthMain = if (tathbit) month.optDouble("tathbit", 0.0) else month.optDouble("hifz", 0.0),
                monthMainLabel = if (tathbit) "التثبيت" else "الحفظ",
                monthPresent = month.optInt("present", 0),
                monthSessions = month.optInt("sessions", 0),
                quality = month.doubleOrNull("quality"),
                latest = latest,
                updatedAt = json.text("updated_at"),
            )
        }
    }
}

@Immutable data class GuardianHomeUiState(
    val children: List<GuardianChild> = emptyList(),
    val selectedId: String? = null,
    val overview: GuardianOverview? = null,
    val loadingFirst: Boolean = true,
    val refreshing: Boolean = false,
    val stale: Boolean = false,
    val message: String? = null,
)
