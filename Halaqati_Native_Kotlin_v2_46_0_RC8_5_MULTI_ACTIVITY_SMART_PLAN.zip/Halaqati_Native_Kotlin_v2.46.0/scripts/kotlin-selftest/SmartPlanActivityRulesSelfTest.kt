import com.mohammedsamir.halaqati.plans.SmartPlanActivityRules
import com.mohammedsamir.halaqati.plans.SmartPlanEngine
import com.mohammedsamir.halaqati.quran.QuranLocation
import java.time.LocalDate

fun main() {
    check(SmartPlanActivityRules.enabledActivities("hifz", emptyList()) == listOf("hifz"))
    check(SmartPlanActivityRules.enabledActivities("hifz", listOf("hifz", "sard", "hifz")) == listOf("hifz", "sard"))

    val rows = listOf(
        SmartPlanEngine.Recitation("h1", "s", "new_hifz", LocalDate.of(2026,9,20), endSurah=12, endAyah=30, createdAt="1"),
        SmartPlanEngine.Recitation("s1", "s", "sard", LocalDate.of(2026,9,21), endSurah=67, endAyah=30, createdAt="2"),
        SmartPlanEngine.Recitation("h2", "s", "new_hifz", LocalDate.of(2026,9,22), endSurah=12, endAyah=52, createdAt="3"),
    )
    check(SmartPlanActivityRules.latestAnchor(rows, "hifz")?.id == "h2")
    check(SmartPlanActivityRules.latestAnchor(rows, "sard")?.id == "s1")

    check(SmartPlanActivityRules.nextLocation(QuranLocation(12, 30), "reverse_surahs_forward_ayahs") == QuranLocation(12, 31))
    check(SmartPlanActivityRules.nextLocation(QuranLocation(12, 111), "reverse_surahs_forward_ayahs") == QuranLocation(11, 1))
    check(SmartPlanActivityRules.nextLocation(QuranLocation(6, 165), "reverse_surahs_forward_ayahs") == QuranLocation(5, 1))
    check(SmartPlanActivityRules.nextLocation(QuranLocation(41, 54), "reverse_surahs_forward_ayahs") == QuranLocation(40, 1))
    check(SmartPlanActivityRules.nextLocation(QuranLocation(12, 111), "forward_surahs_forward_ayahs") == QuranLocation(13, 1))

    println("SmartPlanActivityRulesSelfTest PASS")
}
