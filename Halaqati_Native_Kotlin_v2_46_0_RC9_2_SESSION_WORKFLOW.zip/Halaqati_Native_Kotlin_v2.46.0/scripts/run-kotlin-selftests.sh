#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUT="${TMPDIR:-/tmp}/halaqati-kotlin-selftests"
rm -rf "$OUT"
mkdir -p "$OUT"

# Compile all pure-Kotlin native logic and self-test entry points in one compiler invocation.
kotlinc \
  "$ROOT/app/src/main/java/com/mohammedsamir/halaqati/data/SafetyScoring.kt" \
  "$ROOT/app/src/main/java/com/mohammedsamir/halaqati/data/ImportRules.kt" \
  "$ROOT/app/src/main/java/com/mohammedsamir/halaqati/data/StudentTrackRules.kt" \
  "$ROOT/app/src/main/java/com/mohammedsamir/halaqati/data/DeepLinkRules.kt" \
  "$ROOT/app/src/main/java/com/mohammedsamir/halaqati/data/AuthCallbackRules.kt" \
  "$ROOT/app/src/main/java/com/mohammedsamir/halaqati/data/SmartPlanAlertRules.kt" \
  "$ROOT/app/src/main/java/com/mohammedsamir/halaqati/data/LocalAccountScopeRules.kt" \
  "$ROOT/app/src/main/java/com/mohammedsamir/halaqati/data/GoogleAuthRules.kt" \
  "$ROOT/app/src/main/java/com/mohammedsamir/halaqati/data/ConflictRules.kt" \
  "$ROOT/app/src/main/java/com/mohammedsamir/halaqati/quran/QuranMetadata.kt" \
  "$ROOT/app/src/main/java/com/mohammedsamir/halaqati/quran/QuranRangeEngine.kt" \
  "$ROOT/app/src/main/java/com/mohammedsamir/halaqati/quran/RecitationParityRules.kt" \
  "$ROOT/app/src/main/java/com/mohammedsamir/halaqati/plans/SmartPlanEngine.kt" \
  "$ROOT/app/src/main/java/com/mohammedsamir/halaqati/plans/SmartPlanCoreState.kt" \
  "$ROOT/app/src/main/java/com/mohammedsamir/halaqati/plans/SmartPlanActivityRules.kt" \
  "$ROOT/scripts/kotlin-selftest/SafetyScoringSelfTest.kt" \
  "$ROOT/scripts/kotlin-selftest/QuranMetadataSelfTest.kt" \
  "$ROOT/scripts/kotlin-selftest/QuranRangeEngineSelfTest.kt" \
  "$ROOT/scripts/kotlin-selftest/RecitationParityRulesSelfTest.kt" \
  "$ROOT/scripts/kotlin-selftest/SmartPlanEngineSelfTest.kt" \
  "$ROOT/scripts/kotlin-selftest/SmartPlanCoreStateSelfTest.kt" \
  "$ROOT/scripts/kotlin-selftest/SmartPlanActivityRulesSelfTest.kt" \
  "$ROOT/scripts/kotlin-selftest/ImportRulesSelfTest.kt" \
  "$ROOT/scripts/kotlin-selftest/StudentTrackRulesSelfTest.kt" \
  "$ROOT/scripts/kotlin-selftest/DeepLinkRulesSelfTest.kt" \
  "$ROOT/scripts/kotlin-selftest/AuthCallbackRulesSelfTest.kt" \
  "$ROOT/scripts/kotlin-selftest/SmartPlanAlertRulesSelfTest.kt" \
  "$ROOT/scripts/kotlin-selftest/LocalAccountScopeRulesSelfTest.kt" \
  "$ROOT/scripts/kotlin-selftest/GoogleAuthRulesSelfTest.kt" \
  "$ROOT/scripts/kotlin-selftest/ConflictRulesSelfTest.kt" \
  -d "$OUT/classes.jar"

kotlin -classpath "$OUT/classes.jar" SafetyScoringSelfTestKt
kotlin -classpath "$OUT/classes.jar" QuranMetadataSelfTestKt
kotlin -classpath "$OUT/classes.jar" QuranRangeEngineSelfTestKt
kotlin -classpath "$OUT/classes.jar" RecitationParityRulesSelfTestKt
kotlin -classpath "$OUT/classes.jar" SmartPlanEngineSelfTestKt
kotlin -classpath "$OUT/classes.jar" SmartPlanCoreStateSelfTestKt
kotlin -classpath "$OUT/classes.jar" SmartPlanActivityRulesSelfTestKt
kotlin -classpath "$OUT/classes.jar" ImportRulesSelfTestKt
kotlin -classpath "$OUT/classes.jar" StudentTrackRulesSelfTestKt
kotlin -classpath "$OUT/classes.jar" DeepLinkRulesSelfTestKt
kotlin -classpath "$OUT/classes.jar" AuthCallbackRulesSelfTestKt
kotlin -classpath "$OUT/classes.jar" SmartPlanAlertRulesSelfTestKt
kotlin -classpath "$OUT/classes.jar" LocalAccountScopeRulesSelfTestKt
kotlin -classpath "$OUT/classes.jar" GoogleAuthRulesSelfTestKt
kotlin -classpath "$OUT/classes.jar" ConflictRulesSelfTestKt
